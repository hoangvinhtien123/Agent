@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Project'
define root view entity YC_IT_HUB_PROJECT
  provider contract transactional_query
  as projection on YR_IT_HUB_PROJECT
{
  key id,
  code,
  name,
  description,
  scope,
  phase,
  health,
  startDate,
  endDate,
  accent,
  archivedAt,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_IT_HUB_PROJ_VE'
  virtual completionPercent : abap.dec(5,0),
  @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_IT_HUB_PROJ_VE'
  virtual taskCount : abap.int4,
  @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_IT_HUB_PROJ_VE'
  virtual completedTaskCount : abap.int4,
  _Workstream : redirected to composition child YC_IT_HUB_WORKSTREAM,
  _Membership : redirected to composition child YC_IT_HUB_MEMBERSHIP,
  _Milestone : redirected to composition child YC_IT_HUB_MILESTONE,
  _Risk : redirected to composition child YC_IT_HUB_RISK,
  _Task : redirected to YC_IT_HUB_TASK,
  _Event : redirected to YC_IT_HUB_EVENT,
  _Document : redirected to YC_IT_HUB_DOCUMENT,
  _Comment : redirected to YC_IT_HUB_COMMENT
}
