 @EndUserText.label: 'IT Hub - Notification Inbox'
  @ObjectModel.query.implementedBy: 'ABAP:YCL_IT_HUB_NOTIF_QUERY'
  define root custom entity YCE_IT_HUB_NOTIFICATIONS
  {
    key id : abap.char(36);
    eventId : abap.char(36);
    eventType : abap.char(30);
    recipientId : abap.char(36);
    projectId : abap.char(36);
    taskId : abap.char(36);
    title : abap.char(150);
    message : abap.char(1000);

    @Semantics.systemDateTime.createdAt: true
    createdAt : abp_creation_tstmpl;
    readAt : abp_lastchange_tstmpl;

    @Semantics.systemDateTime.localInstanceLastChangedAt: true
    localLastChangedAt : abp_locinst_lastchange_tstmpl;
  }
