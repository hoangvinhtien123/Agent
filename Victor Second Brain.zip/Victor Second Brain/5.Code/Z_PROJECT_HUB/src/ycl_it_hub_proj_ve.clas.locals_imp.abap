CLASS lcx_hub_project_kpi DEFINITION
  INHERITING FROM cx_sadl_exit
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    METHODS constructor
      IMPORTING
        iv_message TYPE string.

    METHODS get_text REDEFINITION.

  PRIVATE SECTION.
    DATA mv_message TYPE string.
ENDCLASS.

CLASS lcx_hub_project_kpi IMPLEMENTATION.

  METHOD constructor.
    super->constructor( ).
    mv_message = iv_message.
  ENDMETHOD.

  METHOD get_text.
    result = mv_message.
  ENDMETHOD.

ENDCLASS.
