@EndUserText.label: 'Project Hub - SAP User Search'
@ObjectModel.query.implementedBy: 'ABAP:YCL_IT_HUB_SAPUSER_QP'
@Search.searchable: true
define custom entity YCE_IT_HUB_SAPUSER
{
  key id : abap.char(16);
  @Search.defaultSearchElement: true
  ntId : abap.char(100);
  @Search.defaultSearchElement: true
  name : abap.char(150);
  @Search.defaultSearchElement: true
  email : abap.char(254);
  title : abap.char(100);
  team : abap.char(100);
  memberId : abap.char(36);
}
