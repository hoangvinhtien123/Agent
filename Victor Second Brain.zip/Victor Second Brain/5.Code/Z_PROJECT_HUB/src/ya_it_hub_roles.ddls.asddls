@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_ROLES
{
  rolesJson : abap.string(0);
}
