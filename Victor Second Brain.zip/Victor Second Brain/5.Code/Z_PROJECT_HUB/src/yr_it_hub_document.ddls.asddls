@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Document'
define root view entity YR_IT_HUB_DOCUMENT
  as select from ytb_it_hub_docs
  composition [0..*] of YI_IT_HUB_DOCATTACH as attachments
  association [0..1] to YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
{
  key id as id,
  project_id as projectId,
  title as title,
  description as description,
  category as category,
  source_type as sourceType,
  media_kind as mediaKind,
  upload_status as uploadStatus,
  url as url,
  file_name as fileName,
  mime_type as mimeType,
  content as content,
  byte_size as byteSize,
  checksum_sha256 as checksumSha256,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  attachments,
  _Project
}
