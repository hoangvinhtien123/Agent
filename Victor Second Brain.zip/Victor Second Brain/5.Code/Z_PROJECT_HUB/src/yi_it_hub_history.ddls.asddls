@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - History'
define view entity YI_IT_HUB_HISTORY
  as select from ytb_it_hub_histo
  association [0..1] to YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
{
  key id as id,
  scope_type as scopeType,
  project_id as projectId,
  entity as entity,
  entity_id as entityId,
  action as action,
  detail as detail,
  changes_json as changesJson,
  occurred_at as createdAt,
  actor as actorTechnical,
  actor_member_id as createdBy,
  correlation_id as correlationId,
  _Project
}
