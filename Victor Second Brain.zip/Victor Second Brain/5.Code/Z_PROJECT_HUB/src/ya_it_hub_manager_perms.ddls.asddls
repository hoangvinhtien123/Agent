@EndUserText.label: 'Project Hub - Manager permissions'
define abstract entity YA_IT_HUB_MANAGER_PERMS {
  editProject : abap_boolean;
  manageMembers : abap_boolean;
  assignWork : abap_boolean;
  manageSchedule : abap_boolean;
  deleteWorkItems : abap_boolean;
  overrideWorkflow : abap_boolean;
  managePermissions : abap_boolean;
}
