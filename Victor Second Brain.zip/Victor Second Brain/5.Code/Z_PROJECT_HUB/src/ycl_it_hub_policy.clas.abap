CLASS ycl_it_hub_policy DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    TYPES: BEGIN OF ty_actor,
             id TYPE sysuuid_c36, admin TYPE abap_bool, manager TYPE abap_bool, active TYPE abap_bool,
           END OF ty_actor,
           BEGIN OF ty_permissions,
             read TYPE abap_bool, contribute TYPE abap_bool,
             edit_project TYPE abap_bool, manage_members TYPE abap_bool, assign_work TYPE abap_bool,
             manage_schedule TYPE abap_bool, delete_work_items TYPE abap_bool,
             override_workflow TYPE abap_bool, manage_permissions TYPE abap_bool,
           END OF ty_permissions.
    TYPES tt_strings TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    TYPES: BEGIN OF ty_member_access,
             actor TYPE ty_actor,
             permissions TYPE ty_permissions,
           END OF ty_member_access,
           BEGIN OF ty_transition_option,
             status TYPE string,
             allowed TYPE abap_bool,
             reason TYPE string,
             override_allowed TYPE abap_bool,
             requires_reason TYPE abap_bool,
           END OF ty_transition_option,
           tt_transition_options TYPE STANDARD TABLE OF ty_transition_option WITH EMPTY KEY.
    TYPES: BEGIN OF ty_skill, name TYPE string, proficiency TYPE string, END OF ty_skill,
           tt_skills TYPE STANDARD TABLE OF ty_skill WITH EMPTY KEY.
    CLASS-METHODS actor RETURNING VALUE(rs_actor) TYPE ty_actor.
    CLASS-METHODS startup_grants RETURNING VALUE(rs_grants) TYPE ty_actor.
    CLASS-METHODS eligible IMPORTING iv_member TYPE sysuuid_c36 RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS permissions IMPORTING iv_project TYPE sysuuid_c36 iv_ignore_archive TYPE abap_bool DEFAULT abap_false RETURNING VALUE(rs_permissions) TYPE ty_permissions.
    CLASS-METHODS member_in_project IMPORTING iv_project TYPE sysuuid_c36 iv_member TYPE sysuuid_c36
      iv_role TYPE string OPTIONAL RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS can IMPORTING iv_entity TYPE string iv_operation TYPE string ir_row TYPE REF TO data OPTIONAL
      RETURNING VALUE(rv_allowed) TYPE abap_bool.
    CLASS-METHODS final_authorizations RETURNING VALUE(rv_error) TYPE string.
    CLASS-METHODS transition_available IMPORTING is_task TYPE ytb_it_hub_task RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS transition_options IMPORTING is_task TYPE ytb_it_hub_task
      RETURNING VALUE(rt_options) TYPE tt_transition_options.
    CLASS-METHODS member_access IMPORTING iv_project TYPE sysuuid_c36 iv_member TYPE sysuuid_c36
      RETURNING VALUE(rs_access) TYPE ty_member_access RAISING ycx_it_hub.
    CLASS-METHODS removed IMPORTING iv_entity TYPE string ir_row TYPE REF TO data RETURNING VALUE(rv_error) TYPE string.
    CLASS-METHODS can_remove IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      RETURNING VALUE(rv_allowed) TYPE abap_bool.
    CLASS-METHODS validate IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      iv_precheck TYPE abap_bool DEFAULT abap_false
      RETURNING VALUE(rv_error) TYPE string.
    CLASS-METHODS precheck IMPORTING iv_entity TYPE string iv_operation TYPE string
      ir_row TYPE REF TO data is_control TYPE any OPTIONAL iv_defer_parent TYPE abap_bool DEFAULT abap_false RETURNING VALUE(rv_error) TYPE string.
    CLASS-METHODS target IMPORTING iv_type TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rr_row) TYPE REF TO data.
    CLASS-METHODS parse_array IMPORTING iv_json TYPE string iv_kind TYPE string DEFAULT 'UUID' iv_entity TYPE string OPTIONAL
      RETURNING VALUE(rt_values) TYPE tt_strings RAISING ycx_it_hub.
    CLASS-METHODS profile_fields IMPORTING iv_json TYPE string iv_fields TYPE string
      RETURNING VALUE(rt_fields) TYPE tt_strings RAISING ycx_it_hub.
    CLASS-METHODS apply_profile IMPORTING iv_json TYPE string iv_fields TYPE string ir_update TYPE REF TO data RAISING ycx_it_hub.
    CLASS-METHODS parse_skills IMPORTING iv_json TYPE string
      RETURNING VALUE(rt_values) TYPE tt_skills RAISING ycx_it_hub.
    CLASS-METHODS normalize IMPORTING iv_text TYPE string RETURNING VALUE(rv_text) TYPE string.
    CLASS-METHODS valid_date IMPORTING iv_date TYPE string RETURNING VALUE(rv_valid) TYPE abap_bool.
    CLASS-METHODS transition IMPORTING is_task TYPE ytb_it_hub_task iv_status TYPE string
      iv_reason TYPE string iv_override TYPE abap_bool
      RETURNING VALUE(rs_task) TYPE ytb_it_hub_task RAISING ycx_it_hub.
    CLASS-METHODS graph IMPORTING is_link TYPE ytb_it_hub_tdep RETURNING VALUE(rv_error) TYPE string.
  PRIVATE SECTION.
    CLASS-METHODS member_actor IMPORTING iv_member TYPE sysuuid_c36
      RETURNING VALUE(rs_actor) TYPE ty_actor.
    CLASS-METHODS actor_permissions IMPORTING iv_project TYPE sysuuid_c36 is_actor TYPE ty_actor
      iv_ignore_archive TYPE abap_bool DEFAULT abap_false RETURNING VALUE(rs_permissions) TYPE ty_permissions.
    CLASS-METHODS workflow_edges IMPORTING is_task TYPE ytb_it_hub_task RETURNING VALUE(rv_edges) TYPE string.
    CLASS-METHODS status_code IMPORTING iv_status TYPE string RETURNING VALUE(rv_code) TYPE ytb_it_hub_task-status.
    CLASS-METHODS status_label IMPORTING iv_code TYPE string RETURNING VALUE(rv_status) TYPE string.
ENDCLASS.
CLASS ycl_it_hub_policy IMPLEMENTATION.
  METHOD startup_grants.
    " Independent of Member mapping; ordinary actor() semantics stay unchanged.
    AUTHORITY-CHECK OBJECT 'Y_IT_HUB' ID 'ACTVT' FIELD '16' ID 'YHUB_CAP' FIELD 'ADMIN'.
    rs_grants-admin = xsdbool( sy-subrc = 0 ).
    rs_grants-active = rs_grants-admin.
    IF rs_grants-active = abap_false.
      AUTHORITY-CHECK OBJECT 'Y_IT_HUB' ID 'ACTVT' FIELD '03' ID 'YHUB_CAP' FIELD 'USER'.
      rs_grants-active = xsdbool( sy-subrc = 0 ).
    ENDIF.
  ENDMETHOD.
  METHOD normalize.
    rv_text = replace( val = iv_text pcre = '\A\s+|\s+\z' with = '' occ = 0 ).
  ENDMETHOD.
  METHOD actor.
    TEST-SEAM current_actor.
      CLEAR rs_actor.
    END-TEST-SEAM.
    " Trusted Admin authority must also work before directory bootstrap.
    TEST-SEAM admin_grant.
      AUTHORITY-CHECK OBJECT 'Y_IT_HUB' ID 'ACTVT' FIELD '16' ID 'YHUB_CAP' FIELD 'ADMIN'.
      rs_actor-admin = xsdbool( sy-subrc = 0 ).
    END-TEST-SEAM.
    rs_actor-active = rs_actor-admin.
    DATA lv_has_user_grant TYPE abap_bool.
    IF rs_actor-admin = abap_false.
      TEST-SEAM user_grant.
        AUTHORITY-CHECK OBJECT 'Y_IT_HUB' ID 'ACTVT' FIELD '03' ID 'YHUB_CAP' FIELD 'USER'.
        lv_has_user_grant = xsdbool( sy-subrc = 0 ).
      END-TEST-SEAM.
      IF lv_has_user_grant = abap_false. RETURN. ENDIF.
    ENDIF.
    " Mapping is optional for Admin audit enrichment, mandatory for ordinary users.
    " Use committed mapping keys and effective buffered state for revocation.
    SELECT SINGLE id, member_id FROM ytb_it_hub_midn WHERE abap_user = @sy-uname
      INTO @DATA(ls_key).
    IF sy-subrc <> 0. RETURN. ENDIF.
    DATA(lr_identity) = ycl_it_hub_tx=>get( iv_entity = 'MEMBERIDENT' iv_id = ls_key-id ).
    DATA(lr_member) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = ls_key-member_id ).
    IF ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ABAP_USER' ) <> sy-uname
      OR ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'MEMBER_ID' ) <> ls_key-member_id
      OR ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ACTIVE' ) <> abap_true
      OR ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'ACTIVE' ) <> abap_true. RETURN. ENDIF.
    rs_actor-active = abap_true.
    rs_actor-id = ls_key-member_id.
    rs_actor-manager = xsdbool( ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'IS_APP_MANAGER' ) = abap_true ).
  ENDMETHOD.
  METHOD eligible.
    DATA(lv_resolved_member) = ycl_it_hub_tx=>canonical_id( iv_entity = 'MEMBER' iv_id = iv_member ).

    DATA(lr_member) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = lv_resolved_member ).
    IF ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'ACTIVE' ) <> abap_true. RETURN. ENDIF.
    LOOP AT ycl_it_hub_tx=>rows( 'MEMBERIDENT' ) INTO DATA(lr_identity).
      IF ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'MEMBER_ID' ) <> lv_resolved_member
        OR ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ACTIVE' ) <> abap_true. CONTINUE. ENDIF.
      DATA(lv_user) = CONV syuname( ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ABAP_USER' ) ).
      SELECT SINGLE bname FROM usr02 WHERE bname = @lv_user AND ustyp = 'A' AND uflag = 0
        AND ( gltgv = '00000000' OR gltgv <= @sy-datum )
        AND ( gltgb = '00000000' OR gltgb >= @sy-datum ) INTO @DATA(lv_bname).
      IF sy-subrc <> 0. CONTINUE. ENDIF.
      TEST-SEAM eligible_grant.
      AUTHORITY-CHECK OBJECT 'Y_IT_HUB' FOR USER lv_user ID 'ACTVT' FIELD '16' ID 'YHUB_CAP' FIELD 'ADMIN'.
      IF sy-subrc = 0. rv_yes = abap_true. RETURN. ENDIF.
      AUTHORITY-CHECK OBJECT 'Y_IT_HUB' FOR USER lv_user ID 'ACTVT' FIELD '03' ID 'YHUB_CAP' FIELD 'USER'.
      IF sy-subrc = 0. rv_yes = abap_true. RETURN. ENDIF.
      END-TEST-SEAM.
    ENDLOOP.
  ENDMETHOD.
  METHOD member_in_project.
    DATA(lv_resolved_project) = ycl_it_hub_tx=>canonical_id( iv_entity = 'PROJECT' iv_id = iv_project ).
    DATA(lv_resolved_member) = ycl_it_hub_tx=>canonical_id( iv_entity = 'MEMBER' iv_id = iv_member ).

    IF eligible( lv_resolved_member ) = abap_false. RETURN. ENDIF.
    LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_membership).
      IF ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'PROJECT_ID' ) <> lv_resolved_project
        OR ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'MEMBER_ID' ) <> lv_resolved_member
        OR ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'ACTIVE' ) <> abap_true. CONTINUE. ENDIF.
      IF iv_role IS INITIAL. rv_yes = abap_true. RETURN. ENDIF.
      DATA(lv_membership) = ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'ID' ).
      LOOP AT ycl_it_hub_tx=>rows( 'ROLEASSIGN' ) INTO DATA(lr_role).
        IF ycl_it_hub_tx=>field( ir_row = lr_role iv_name = 'MEMBERSHIP_ID' ) = lv_membership
          AND ycl_it_hub_tx=>field( ir_row = lr_role iv_name = 'ROLE' ) = iv_role.
          rv_yes = abap_true. RETURN.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
  ENDMETHOD.
  METHOD permissions.
    rs_permissions = actor_permissions( iv_project = iv_project
      is_actor = actor( ) iv_ignore_archive = iv_ignore_archive ).
  ENDMETHOD.
  METHOD actor_permissions.
    DATA(lv_resolved_project) = ycl_it_hub_tx=>canonical_id( iv_entity = 'PROJECT' iv_id = iv_project ).

    DATA(ls_actor) = is_actor.
    IF ls_actor-active = abap_false. RETURN. ENDIF.
    DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = lv_resolved_project ).
    IF lr_project IS NOT BOUND. RETURN. ENDIF.
    IF ls_actor-admin = abap_true.
      rs_permissions = VALUE #( read = abap_true contribute = abap_true edit_project = abap_true
        manage_members = abap_true assign_work = abap_true manage_schedule = abap_true
        delete_work_items = abap_true override_workflow = abap_true manage_permissions = abap_true ).
    ELSE.
      LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_membership).
        IF ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'PROJECT_ID' ) <> lv_resolved_project
          OR ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'MEMBER_ID' ) <> ls_actor-id
          OR ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'ACTIVE' ) <> abap_true. CONTINUE. ENDIF.
        rs_permissions-read = abap_true.
        rs_permissions-contribute = abap_true.
        IF ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'IS_PROJECT_MANAGER' ) = abap_true.
          MOVE-CORRESPONDING lr_membership->* TO rs_permissions.
        ENDIF.
        EXIT.
      ENDLOOP.
    ENDIF.
    " Check the timestamp's typed initial value; its STRING representation is not empty at zero.
    DATA lv_archived_at TYPE ytb_it_hub_proj-archived_at.
    lv_archived_at = ycl_it_hub_tx=>field( ir_row = lr_project iv_name = 'ARCHIVED_AT' ).
    IF iv_ignore_archive = abap_false AND lv_archived_at IS NOT INITIAL.
      DATA(lv_read) = rs_permissions-read.
      rs_permissions = VALUE #( read = lv_read ).
    ENDIF.
  ENDMETHOD.
  METHOD member_actor.
    " Only member_access exposes this server-resolved target actor.
    DATA(lr_member) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = iv_member ).
    IF ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'ACTIVE' ) <> abap_true. RETURN. ENDIF.
    LOOP AT ycl_it_hub_tx=>rows( 'MEMBERIDENT' ) INTO DATA(lr_identity).
      IF ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'MEMBER_ID' ) <> iv_member
        OR ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ACTIVE' ) <> abap_true. CONTINUE. ENDIF.
      DATA(lv_user) = CONV syuname( ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ABAP_USER' ) ).
      SELECT SINGLE bname FROM usr02 WHERE bname = @lv_user AND ustyp = 'A' AND uflag = 0
        AND ( gltgv = '00000000' OR gltgv <= @sy-datum )
        AND ( gltgb = '00000000' OR gltgb >= @sy-datum ) INTO @DATA(lv_bname).
      IF sy-subrc <> 0. CONTINUE. ENDIF.
      DATA: lv_admin TYPE abap_bool, lv_user_grant TYPE abap_bool.
      CLEAR: lv_admin, lv_user_grant.
      TEST-SEAM member_grants.
        AUTHORITY-CHECK OBJECT 'Y_IT_HUB' FOR USER lv_user
          ID 'ACTVT' FIELD '16' ID 'YHUB_CAP' FIELD 'ADMIN'.
        lv_admin = xsdbool( sy-subrc = 0 ).
        AUTHORITY-CHECK OBJECT 'Y_IT_HUB' FOR USER lv_user
          ID 'ACTVT' FIELD '03' ID 'YHUB_CAP' FIELD 'USER'.
        lv_user_grant = xsdbool( sy-subrc = 0 ).
      END-TEST-SEAM.
      IF lv_admin = abap_false AND lv_user_grant = abap_false. CONTINUE. ENDIF.
      rs_actor = VALUE #( id = iv_member active = abap_true admin = lv_admin
        manager = xsdbool( ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'IS_APP_MANAGER' ) = abap_true ) ).
      " A Member can have several valid SAP identities. Preserve any trusted Admin grant.
      IF lv_admin = abap_true. RETURN. ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD member_access.
    DATA(ls_caller) = actor( ).
    DATA(ls_caller_rights) = permissions( iv_project = iv_project ).
    IF ls_caller-active = abap_false OR ls_caller_rights-read = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Project permission summaries are not accessible.'.
    ENDIF.
    IF iv_member = ls_caller-id.
      rs_access = VALUE #( actor = ls_caller permissions = ls_caller_rights ).
      RETURN.
    ENDIF.
    IF ls_caller-admin = abap_false AND ls_caller_rights-manage_members = abap_false
      AND ls_caller_rights-manage_permissions = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Team permission inspection is not granted.'.
    ENDIF.
    DATA lv_in_team TYPE abap_bool.
    LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_membership).
      IF ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'PROJECT_ID' ) = iv_project
        AND ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'MEMBER_ID' ) = iv_member.
        lv_in_team = abap_true. EXIT.
      ENDIF.
    ENDLOOP.
    IF lv_in_team = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Only this project team can be inspected.'.
    ENDIF.
    rs_access-actor = member_actor( iv_member ).
    rs_access-permissions = actor_permissions( iv_project = iv_project is_actor = rs_access-actor ).
  ENDMETHOD.
  METHOD can_remove.
    " The frontend calls this only for entities exposing standard DELETE.
    IF can( iv_entity = iv_entity iv_operation = 'DELETE' ir_row = ir_row ) = abap_false. RETURN. ENDIF.
    rv_allowed = xsdbool( removed( iv_entity = iv_entity ir_row = ir_row ) IS INITIAL ).
  ENDMETHOD.
  METHOD can.
    DATA(ls_actor) = actor( ).
    IF ls_actor-active = abap_false. RETURN. ENDIF.
    DATA(lv_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ID' ) ).
    DATA(lv_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ) ).
    IF iv_entity = 'PROJECT'. lv_project = lv_id. ENDIF.
    DATA(ls_permissions) = permissions( iv_project = lv_project iv_ignore_archive = xsdbool( iv_operation = 'ARCHIVE' OR iv_operation = 'RESTORE' ) ).
    DATA(lv_creator) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'CREATED_BY_MEMBER_ID' ).
    DATA(lv_directory) = xsdbool( ls_actor-admin = abap_true OR ls_actor-manager = abap_true ).
    CASE iv_entity.
      WHEN 'MEMBER' OR 'SKILL'.
        IF iv_entity = 'MEMBER' AND iv_operation = 'CREATE'.
          rv_allowed = ls_actor-admin.
        ELSEIF iv_operation = 'SETAPPMANAGER'.
          rv_allowed = ls_actor-admin.
        ELSEIF iv_entity = 'MEMBER' AND iv_operation = 'REPLACESKILLS'.
          rv_allowed = xsdbool( lv_directory = abap_true OR lv_id = ls_actor-id ).
        ELSEIF iv_entity = 'MEMBER' AND iv_operation = 'TOUCH'.
          rv_allowed = xsdbool( lv_directory = abap_true OR lv_id = ls_actor-id ).
        ELSE.
          rv_allowed = lv_directory.
        ENDIF.
      WHEN 'MEMBERIDENT'.
        rv_allowed = ls_actor-admin.
      WHEN 'MEMBERSKILL'.
        rv_allowed = xsdbool( lv_directory = abap_true
          OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) = ls_actor-id ).
      WHEN 'PROJECT'.
        CASE iv_operation.
          WHEN 'CREATE'. rv_allowed = lv_directory.
          WHEN 'TOUCH'. rv_allowed = ls_permissions-read.
          WHEN 'REPLACEMANAGERS'. rv_allowed = xsdbool( ls_actor-admin = abap_true AND ls_permissions-edit_project = abap_true ).
          WHEN 'RESTORE'.
            IF ls_actor-admin = abap_true. rv_allowed = abap_true. RETURN. ENDIF.
            LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_membership).
              IF ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'PROJECT_ID' ) = lv_id
                AND ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'MEMBER_ID' ) = ls_actor-id
                AND ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'ACTIVE' ) = abap_true
                AND ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'IS_PROJECT_MANAGER' ) = abap_true
                AND ycl_it_hub_tx=>field( ir_row = lr_membership iv_name = 'EDIT_PROJECT' ) = abap_true.
                rv_allowed = abap_true. RETURN.
              ENDIF.
            ENDLOOP.
          WHEN OTHERS. rv_allowed = ls_permissions-edit_project.
        ENDCASE.
      WHEN 'MEMBERSHIP' OR 'ROLEASSIGN'.
        IF iv_entity = 'MEMBERSHIP' AND iv_operation = 'CREATE'
          AND ( ycl_it_hub_tx=>in_scope( iv_name = 'CREATOR' iv_id = lv_project ) = abap_true
            OR ycl_it_hub_tx=>action( iv_entity = iv_entity iv_id = lv_id ) = 'CREATOR' )
          AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) = ls_actor-id.
          rv_allowed = lv_directory.
        ELSEIF iv_operation = 'SETMANAGERPERMISSIONS'.
          rv_allowed = xsdbool( ls_permissions-manage_permissions = abap_true
            AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) = abap_true
            AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'IS_PROJECT_MANAGER' ) = abap_true
            AND eligible( CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) ) ) = abap_true
            AND ( ls_actor-admin = abap_true
              OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) <> ls_actor-id ) ).
        ELSE.
          rv_allowed = ls_permissions-manage_members.
        ENDIF.
      WHEN 'WORKSTREAM'.
        rv_allowed = ls_permissions-manage_schedule.
        IF iv_operation = 'UPDATE' AND ls_permissions-contribute = abap_true
          AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'OWNER_ID' ) = ls_actor-id. rv_allowed = abap_true. ENDIF.
      WHEN 'MILESTONE' OR 'EVENT' OR 'EVENTATTENDEE'.
        rv_allowed = ls_permissions-manage_schedule.
      WHEN 'TASK' OR 'TASKDEP'.
        IF iv_operation = 'DELETE' AND iv_entity = 'TASK'.
          rv_allowed = ls_permissions-delete_work_items.
        ELSEIF iv_operation = 'CREATE' AND iv_entity = 'TASK'.
          rv_allowed = ls_permissions-contribute.
        ELSE.
          DATA(lr_task) = ir_row.
          IF iv_entity = 'TASKDEP'.
            lr_task = ycl_it_hub_tx=>get( iv_entity = 'TASK'
              iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_ID' ) ) ).
          ENDIF.
          DATA(lv_status) = ycl_it_hub_tx=>field( ir_row = lr_task iv_name = 'STATUS' ).
          rv_allowed = xsdbool( ls_permissions-assign_work = abap_true
            OR ( ls_permissions-contribute = abap_true
              AND ycl_it_hub_tx=>field( ir_row = lr_task iv_name = 'ASSIGNEE_ID' ) = ls_actor-id
              AND ( lv_status = 'TODO' OR lv_status = 'OPEN' OR lv_status = 'IN_PROGRESS' OR lv_status = 'IN_FIX' ) ) ).
        ENDIF.
      WHEN 'COMMENT'.
        rv_allowed = xsdbool( ls_permissions-contribute = abap_true
          AND ( iv_operation = 'CREATE' OR lv_creator = ls_actor-id OR ls_actor-admin = abap_true ) ).
      WHEN 'DOCUMENT' OR 'RISK'.
        rv_allowed = xsdbool( ls_permissions-contribute = abap_true
          AND ( iv_operation = 'CREATE' OR lv_creator = ls_actor-id
                OR ls_permissions-edit_project = abap_true OR ls_actor-admin = abap_true ) ).
      WHEN 'DOCATTACH'.
        DATA(lr_doc) = ycl_it_hub_tx=>get( iv_entity = 'DOCUMENT'
          iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'DOCUMENT_ID' ) ) ).
        DATA(lr_target) = target( iv_type = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' )
          iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ) ).
        rv_allowed = xsdbool( lr_target IS BOUND
          AND ycl_it_hub_tx=>field( ir_row = lr_doc iv_name = 'UPLOAD_STATUS' ) = 'READY'
          AND can( iv_entity = 'DOCUMENT' iv_operation = 'UPDATE' ir_row = lr_doc ) = abap_true ).
        IF rv_allowed = abap_true.
          DATA(lv_type) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ).
          rv_allowed = can( iv_entity = lv_type iv_operation = 'UPDATE' ir_row = lr_target ).
        ENDIF.
    ENDCASE.
    IF iv_entity = 'COMMENT' AND iv_operation = 'CREATE'
      AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ) = 'DOCUMENT'.
      DATA(lr_comment_doc) = target( iv_type = 'DOCUMENT'
        iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ) ).
      IF ycl_it_hub_tx=>field( ir_row = lr_comment_doc iv_name = 'UPLOAD_STATUS' ) = 'PENDING'
        AND ls_actor-admin = abap_false
        AND ycl_it_hub_tx=>field( ir_row = lr_comment_doc iv_name = 'CREATED_BY_MEMBER_ID' ) <> ls_actor-id.
        CLEAR rv_allowed.
      ENDIF.
    ENDIF.
    IF iv_entity = 'DOCUMENT' AND iv_operation <> 'CREATE'
      AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'UPLOAD_STATUS' ) = 'PENDING'
      AND ls_actor-admin = abap_false AND lv_creator <> ls_actor-id. CLEAR rv_allowed. ENDIF.
    IF ( iv_entity = 'TASKDEP' OR ( iv_entity = 'TASK' AND iv_operation = 'REPLACEDEPENDENCIES' ) )
      AND lv_status <> 'TODO' AND lv_status <> 'OPEN' AND lv_status <> 'IN_PROGRESS' AND lv_status <> 'IN_FIX'.
      CLEAR rv_allowed.
    ENDIF.
    IF ( iv_entity = 'TASK' OR iv_entity = 'EVENT' ) AND iv_operation = 'CREATE'.
      DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = lv_project ).
      IF ycl_it_hub_tx=>field( ir_row = lr_project iv_name = 'PHASE' ) = 'CLOSED'. CLEAR rv_allowed. ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD final_authorizations.
    DATA(ls_actor) = actor( ).
    IF ls_actor-active = abap_false. rv_error = 'Actor identity or trusted grant was revoked.'. RETURN. ENDIF.
    LOOP AT ycl_it_hub_tx=>guards( ) INTO DATA(ls_guard).
      IF ls_guard-operation = 'DELETE' AND ycl_it_hub_tx=>cascade_delete(
        iv_entity = ls_guard-entity iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ls_guard-row iv_name = 'ID' ) ) ) = abap_true.
        CONTINUE.
      ENDIF.
      DATA(lv_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ls_guard-row iv_name = 'PROJECT_ID' ) ).
      IF ls_guard-entity = 'PROJECT'. lv_project = ycl_it_hub_tx=>field( ir_row = ls_guard-row iv_name = 'ID' ). ENDIF.
      DATA(ls_permissions) = permissions( iv_project = lv_project ).
      IF ls_guard-operation = 'MANAGE_SCHEDULE' OR ls_guard-operation = 'ASSIGN_WORK'.
        ASSIGN COMPONENT ls_guard-operation OF STRUCTURE ls_permissions TO FIELD-SYMBOL(<permission>).
        IF sy-subrc <> 0 OR <permission> <> abap_true. rv_error = 'A required project permission was revoked before save.'. RETURN. ENDIF.
        CONTINUE.
      ELSEIF ls_guard-operation = 'TRANSITION'.
        DATA ls_task TYPE ytb_it_hub_task.
        MOVE-CORRESPONDING ls_guard-row->* TO ls_task.
        TRY.
            DATA(ls_verified) = transition( is_task = ls_task
              iv_status = ycl_it_hub_tx=>field( ir_row = ls_guard-parameter iv_name = 'STATUS' )
              iv_reason = ycl_it_hub_tx=>field( ir_row = ls_guard-parameter iv_name = 'REASON' )
              iv_override = CONV #( ycl_it_hub_tx=>field( ir_row = ls_guard-parameter iv_name = 'OVERRIDE' ) ) ).
          CATCH ycx_it_hub INTO DATA(lx_transition). rv_error = lx_transition->text. RETURN.
        ENDTRY.
        CONTINUE.
      ENDIF.
      IF can( iv_entity = ls_guard-entity iv_operation = ls_guard-operation ir_row = ls_guard-row ) = abap_false.
        rv_error = |Authority for { ls_guard-entity } { ls_guard-operation } was revoked before save.|. RETURN.
      ENDIF.
      IF ls_guard-operation = 'SETMANAGERPERMISSIONS' AND ls_actor-admin = abap_false.
        IF ycl_it_hub_tx=>field( ir_row = ls_guard-row iv_name = 'MEMBER_ID' ) = ls_actor-id.
          rv_error = 'Managers cannot grant their own permissions.'. RETURN.
        ENDIF.
        SPLIT 'EDIT_PROJECT,MANAGE_MEMBERS,ASSIGN_WORK,MANAGE_SCHEDULE,DELETE_WORK_ITEMS,OVERRIDE_WORKFLOW,MANAGE_PERMISSIONS' AT ',' INTO TABLE DATA(lt_flags).
        LOOP AT lt_flags INTO DATA(lv_flag).
          DATA(lv_parameter) = replace( val = lv_flag sub = '_' with = '' occ = 0 ).
          ASSIGN COMPONENT lv_flag OF STRUCTURE ls_permissions TO <permission>.
          IF ycl_it_hub_tx=>field( ir_row = ls_guard-parameter iv_name = lv_parameter ) = abap_true AND <permission> <> abap_true.
            rv_error = 'Cannot grant a permission revoked from the caller before save.'. RETURN.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD transition_available.
    LOOP AT transition_options( is_task ) INTO DATA(ls_option).
      IF ls_option-allowed = abap_true OR ls_option-override_allowed = abap_true.
        rv_yes = abap_true. RETURN.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD workflow_edges.
    IF is_task-task_type = 'DEFECT'.
      rv_edges = 'OPEN>IN_FIX,IN_FIX>READY_FOR_RETEST,READY_FOR_RETEST>CLOSED,READY_FOR_RETEST>OPEN,CLOSED>OPEN'.
    ELSEIF is_task-parent_id IS NOT INITIAL.
      rv_edges = 'OPEN>IN_PROGRESS,OPEN>CLOSED,IN_PROGRESS>OPEN,IN_PROGRESS>CLOSED,CLOSED>OPEN'.
    ELSE.
      rv_edges = 'TODO>IN_PROGRESS,TODO>IN_REVIEW,TODO>DONE,'
        && 'IN_PROGRESS>TODO,IN_PROGRESS>IN_REVIEW,IN_PROGRESS>DONE,'
        && 'IN_REVIEW>TODO,IN_REVIEW>IN_PROGRESS,IN_REVIEW>DONE,DONE>IN_REVIEW'.
    ENDIF.
  ENDMETHOD.
  METHOD status_code.
    rv_code = SWITCH #( iv_status WHEN 'To Do' THEN 'TODO' WHEN 'In Progress' THEN 'IN_PROGRESS'
      WHEN 'In Review' THEN 'IN_REVIEW' WHEN 'Done' THEN 'DONE' WHEN 'Open' THEN 'OPEN'
      WHEN 'In Fix' THEN 'IN_FIX' WHEN 'Ready for Retest' THEN 'READY_FOR_RETEST' WHEN 'Closed' THEN 'CLOSED' ELSE '' ).
  ENDMETHOD.
  METHOD status_label.
    rv_status = SWITCH #( iv_code WHEN 'TODO' THEN 'To Do' WHEN 'IN_PROGRESS' THEN 'In Progress'
      WHEN 'IN_REVIEW' THEN 'In Review' WHEN 'DONE' THEN 'Done' WHEN 'OPEN' THEN 'Open'
      WHEN 'IN_FIX' THEN 'In Fix' WHEN 'READY_FOR_RETEST' THEN 'Ready for Retest' WHEN 'CLOSED' THEN 'Closed' ELSE '' ).
  ENDMETHOD.
  METHOD transition_options.
    " transition() validates and returns a COPY. It performs no EML or TX writes.
    " The probe reason satisfies a required input; the UI must collect the real reason.
    SPLIT workflow_edges( is_task ) AT ',' INTO TABLE DATA(lt_edges).
    LOOP AT lt_edges INTO DATA(lv_edge).
      SPLIT lv_edge AT '>' INTO DATA(lv_from) DATA(lv_next).
      IF lv_from <> is_task-status. CONTINUE. ENDIF.
      DATA(ls_option) = VALUE ty_transition_option(
        status = status_label( lv_next )
        requires_reason = xsdbool( is_task-status = 'DONE' OR is_task-status = 'CLOSED' ) ).
      TRY.
          DATA(ls_normal) = transition( is_task = is_task iv_status = ls_option-status
            iv_reason = 'Authorization capability check' iv_override = abap_false ).
          ls_option-allowed = abap_true.
        CATCH ycx_it_hub INTO DATA(lx_normal).
          ls_option-reason = lx_normal->text.
      ENDTRY.
      TRY.
          DATA(ls_override) = transition( is_task = is_task iv_status = ls_option-status
            iv_reason = 'Authorization capability check' iv_override = abap_true ).
          ls_option-override_allowed = abap_true.
        CATCH ycx_it_hub.
          ls_option-override_allowed = abap_false.
      ENDTRY.
      APPEND ls_option TO rt_options.
    ENDLOOP.
  ENDMETHOD.
  METHOD target.
    IF iv_type <> 'PROJECT' AND iv_type <> 'WORKSTREAM' AND iv_type <> 'TASK'
      AND iv_type <> 'MILESTONE' AND iv_type <> 'EVENT' AND iv_type <> 'RISK' AND iv_type <> 'DOCUMENT'
      AND iv_type <> 'COMMENT'. RETURN. ENDIF.
    rr_row = ycl_it_hub_tx=>get( iv_entity = iv_type iv_id = iv_id ).
  ENDMETHOD.
  METHOD parse_array.
    IF strlen( iv_json ) > 16000.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'JSON payload exceeds 16000 characters.'.
    ENDIF.
    DATA(lv_string) = '"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"'.
    DATA(lv_pattern) = '\A\s*\[\s*(?:' && lv_string && '(?:\s*,\s*' && lv_string && ')*)?\s*\]\s*\z'.
    IF NOT matches( val = iv_json pcre = lv_pattern ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Expected a JSON array containing only strings.'.
    ENDIF.
    /ui2/cl_json=>deserialize( EXPORTING json = iv_json CHANGING data = rt_values ).
    IF lines( rt_values ) > 200.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'At most 200 items are allowed.'.
    ENDIF.
    DATA lt_seen TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line.
    LOOP AT rt_values ASSIGNING FIELD-SYMBOL(<value>).
      DATA(lv_value) = <value>.
      IF iv_kind = 'UUID' AND NOT matches( val = lv_value pcre = '\A[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\z' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Expected C36 identifiers.'.
      ELSEIF iv_kind = 'ROLE' AND lv_value <> 'BUSINESS_OWNER' AND lv_value <> 'TECHNICAL_LEAD'
        AND lv_value <> 'DEVELOPER' AND lv_value <> 'TESTER'.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Unknown project responsibility.'.
      ENDIF.
      " UUID identity is case-insensitive; keep the supplied value for callers.
      DATA(lv_seen) = COND string( WHEN iv_kind = 'UUID' THEN to_upper( lv_value ) ELSE lv_value ).
      INSERT lv_seen INTO TABLE lt_seen.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Duplicate JSON entries are not allowed.'.
      ENDIF.
      IF iv_kind = 'UUID' AND iv_entity IS NOT INITIAL.
        <value> = ycl_it_hub_tx=>canonical_id( iv_entity = iv_entity iv_id = CONV #( lv_value ) ).
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD profile_fields.
    IF strlen( iv_json ) > 16000. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile exceeds 16000 characters.'. ENDIF.
    DATA(lv_string) = '"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"'.
    DATA(lv_key) = '"(?:' && replace( val = iv_fields sub = ',' with = '|' occ = 0 ) && ')"'.
    DATA(lv_scalar) = '(?:' && lv_string && '|true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)'.
    DATA(lv_pair) = lv_key && '\s*:\s*' && lv_scalar.
    DATA(lv_object) = '\A\s*\{\s*(?:' && lv_pair && '(?:\s*,\s*' && lv_pair && ')*)?\s*\}\s*\z'.
    IF NOT matches( val = iv_json pcre = lv_object ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile contains malformed JSON or unsupported fields.'.
    ENDIF.
    FIND ALL OCCURRENCES OF PCRE lv_pair IN iv_json RESULTS DATA(lt_matches).
    LOOP AT lt_matches INTO DATA(ls_match).
      DATA(lv_start) = ls_match-offset + 1.
      DATA(lv_tail) = substring( val = iv_json off = lv_start ).
      FIND FIRST OCCURRENCE OF '"' IN lv_tail MATCH OFFSET DATA(lv_length).
      DATA(lv_field) = substring( val = lv_tail len = lv_length ).
      IF line_exists( rt_fields[ table_line = lv_field ] ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Duplicate profile field.'.
      ENDIF.
      APPEND lv_field TO rt_fields.
    ENDLOOP.
  ENDMETHOD.
  METHOD apply_profile.
    DATA(lt_fields) = profile_fields( iv_json = iv_json iv_fields = iv_fields ).
    DATA(lv_string) = '"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"'.
    DATA(lv_number) = '-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?'.
    DATA(lv_scalar) = '(?:' && lv_string && '|true|false|null|' && lv_number && ')'.
    FIELD-SYMBOLS: <target> TYPE any, <control> TYPE any, <flag> TYPE any.
    ASSIGN COMPONENT '%CONTROL' OF STRUCTURE ir_update->* TO <control>.
    IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile update control is unavailable.'. ENDIF.
    LOOP AT lt_fields INTO DATA(lv_field).
      DATA(lv_component) = to_upper( lv_field ).
      ASSIGN COMPONENT lv_component OF STRUCTURE ir_update->* TO <target>.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile field is unavailable.'. ENDIF.
      DATA(lv_pattern) = '"' && lv_field && '"\s*:\s*(' && lv_scalar && ')'.
      FIND FIRST OCCURRENCE OF PCRE lv_pattern IN iv_json RESULTS DATA(ls_match).
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile scalar is unavailable.'. ENDIF.
      READ TABLE ls_match-submatches INTO DATA(ls_scalar) INDEX 1.
      DATA(lv_json_value) = substring( val = iv_json off = ls_scalar-offset len = ls_scalar-length ).
      TRY.
          IF lv_component = 'ACTIVE' OR lv_component = 'BLOCKED' OR lv_component = 'REMINDERENABLED'.
            IF lv_json_value <> 'true' AND lv_json_value <> 'false'.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile boolean must be true or false.'.
            ENDIF.
            <target> = xsdbool( lv_json_value = 'true' ).
          ELSEIF lv_component = 'ESTIMATEHOURS' OR lv_component = 'SORTORDER' OR lv_component = 'REMINDERMINUTES'.
            DATA(lv_numeric_pattern) = '\A' && lv_number && '\z'.
            IF NOT matches( val = lv_json_value pcre = lv_numeric_pattern ).
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile numeric field requires a JSON number.'.
            ENDIF.
            DATA(lv_numeric) = CONV decfloat34( lv_json_value ).
            <target> = lv_numeric.
            IF CONV decfloat34( <target> ) <> lv_numeric.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile number exceeds field precision or scale.'.
            ENDIF.
          ELSEIF lv_json_value = 'null' AND lv_component = 'DUEDATE'.
            CLEAR <target>.
          ELSE.
            IF substring( val = lv_json_value len = 1 ) <> '"'.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile text field requires a JSON string.'.
            ENDIF.
            DATA lv_text TYPE string.
            CLEAR lv_text.
            /ui2/cl_json=>deserialize( EXPORTING json = lv_json_value CHANGING data = lv_text ).
            IF lv_component = 'DUEDATE'.
              IF NOT matches( val = lv_text pcre = '\A\d{4}-\d{2}-\d{2}\z' ).
                RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid profile date.'.
              ENDIF.
              <target> = replace( val = lv_text sub = '-' with = '' occ = 0 ).
            ELSEIF lv_component = 'STARTAT' OR lv_component = 'ENDAT'.
              IF NOT matches( val = lv_text pcre = '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,7})?Z\z' ).
                RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile timestamp must be ISO UTC.'.
              ENDIF.
              <target> = replace( val = lv_text pcre = '[-\x3aTZ]' with = '' occ = 0 ).
            ELSE.
              DATA(lo_target) = cl_abap_typedescr=>describe_by_data( <target> ).
              IF lo_target->type_kind = cl_abap_typedescr=>typekind_char.
                DATA lv_max_length TYPE i.
                DESCRIBE FIELD <target> LENGTH lv_max_length IN CHARACTER MODE.
                IF strlen( lv_text ) > lv_max_length.
                  RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile text exceeds field length.'.
                ENDIF.
              ENDIF.
              <target> = lv_text.
            ENDIF.
          ENDIF.
        CATCH cx_sy_conversion_error.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile value is incompatible with its field.'.
      ENDTRY.
      ASSIGN COMPONENT lv_component OF STRUCTURE <control> TO <flag>.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile field control is unavailable.'. ENDIF.
      <flag> = if_abap_behv=>mk-on.
    ENDLOOP.
  ENDMETHOD.
  METHOD parse_skills.
    IF strlen( iv_json ) > 16000.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Skills payload exceeds 16000 characters.'.
    ENDIF.
    DATA(lv_string) = '"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"'.
    DATA(lv_object) = '\{\s*(?:\"name\"\s*:\s*' && lv_string && '\s*,\s*\"proficiency\"\s*:\s*' && lv_string && '|\"proficiency\"\s*:\s*' && lv_string && '\s*,\s*\"name\"\s*:\s*' && lv_string && ')\s*\}'.
    DATA(lv_pattern) = '\A\s*\[\s*(?:' && lv_object && '(?:\s*,\s*' && lv_object && ')*)?\s*\]\s*\z'.
    IF NOT matches( val = iv_json pcre = lv_pattern ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Skills must contain exactly name and proficiency strings.'.
    ENDIF.
    /ui2/cl_json=>deserialize( EXPORTING json = iv_json CHANGING data = rt_values ).
    IF lines( rt_values ) > 200.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'At most 200 skills are allowed.'.
    ENDIF.
    DATA lt_seen TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line.
    LOOP AT rt_values ASSIGNING FIELD-SYMBOL(<skill>).
      DATA(lv_name) = to_lower( normalize( <skill>-name ) ).
      IF lv_name IS INITIAL OR strlen( <skill>-name ) > 100.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Skill name is required and must fit 100 characters.'.
      ENDIF.
      INSERT lv_name INTO TABLE lt_seen.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Duplicate skills are not allowed.'.
      ENDIF.
      CASE <skill>-proficiency.
        WHEN 'Foundation'. <skill>-proficiency = 'FOUNDATION'.
        WHEN 'Working'. <skill>-proficiency = 'WORKING'.
        WHEN 'Advanced'. <skill>-proficiency = 'ADVANCED'.
        WHEN 'Expert'. <skill>-proficiency = 'EXPERT'.
        WHEN OTHERS. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Unknown proficiency label.'.
      ENDCASE.
    ENDLOOP.
  ENDMETHOD.
  METHOD valid_date.
    IF iv_date IS INITIAL OR iv_date = '00000000'. rv_valid = abap_true. RETURN. ENDIF.
    IF NOT matches( val = iv_date pcre = '\A[0-9]{8}\z' ). RETURN. ENDIF.
    DATA(lv_year) = CONV i( iv_date(4) ).
    DATA(lv_month) = CONV i( iv_date+4(2) ).
    DATA(lv_day) = CONV i( iv_date+6(2) ).
    IF lv_year < 1 OR lv_month < 1 OR lv_month > 12 OR lv_day < 1. RETURN. ENDIF.
    DATA(lv_max) = SWITCH i( lv_month WHEN 4 OR 6 OR 9 OR 11 THEN 30 WHEN 2 THEN 28 ELSE 31 ).
    IF lv_month = 2 AND ( lv_year MOD 400 = 0 OR ( lv_year MOD 4 = 0 AND lv_year MOD 100 <> 0 ) ). lv_max = 29. ENDIF.
    rv_valid = xsdbool( lv_day <= lv_max ).
  ENDMETHOD.
  METHOD graph.
    IF is_link-task_id = is_link-depends_on_task_id.
      rv_error = 'A task cannot depend on itself.'. RETURN.
    ENDIF.
    DATA(lr_source) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = is_link-task_id ).
    DATA(lr_target) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = is_link-depends_on_task_id ).
    IF lr_source IS NOT BOUND OR lr_target IS NOT BOUND
      OR ycl_it_hub_tx=>field( ir_row = lr_source iv_name = 'PROJECT_ID' ) <> is_link-project_id
      OR ycl_it_hub_tx=>field( ir_row = lr_target iv_name = 'PROJECT_ID' ) <> is_link-project_id.
      rv_error = 'Dependencies require two tasks in the same project.'. RETURN.
    ENDIF.
    DATA lt_pending TYPE STANDARD TABLE OF sysuuid_c36 WITH EMPTY KEY.
    DATA lt_seen TYPE SORTED TABLE OF sysuuid_c36 WITH UNIQUE KEY table_line.
    APPEND is_link-depends_on_task_id TO lt_pending.
    DATA(lt_edges) = ycl_it_hub_tx=>rows( 'TASKDEP' ).
    WHILE lt_pending IS NOT INITIAL.
      READ TABLE lt_pending INDEX 1 INTO DATA(lv_current).
      DELETE lt_pending INDEX 1.
      IF lv_current = is_link-task_id. rv_error = 'Dependency cycles are not allowed.'. RETURN. ENDIF.
      INSERT lv_current INTO TABLE lt_seen.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
      LOOP AT lt_edges INTO DATA(lr_edge).
        IF ycl_it_hub_tx=>field( ir_row = lr_edge iv_name = 'TASK_ID' ) = lv_current.
          APPEND CONV #( ycl_it_hub_tx=>field( ir_row = lr_edge iv_name = 'DEPENDS_ON_TASK_ID' ) ) TO lt_pending.
        ENDIF.
      ENDLOOP.
    ENDWHILE.
  ENDMETHOD.

  METHOD validate.
    DATA(lv_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ID' ) ).
    DATA(lr_before) = ycl_it_hub_tx=>before( iv_entity = iv_entity iv_id = lv_id ).
    DATA(lv_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ) ).
    DATA lv_booleans TYPE string.
    CASE iv_entity.
      WHEN 'MEMBER'. lv_booleans = 'ACTIVE,IS_APP_MANAGER'.
      WHEN 'SKILL' OR 'MEMBERIDENT'. lv_booleans = 'ACTIVE'.
      WHEN 'MEMBERSHIP'. lv_booleans = 'ACTIVE,IS_PROJECT_MANAGER,EDIT_PROJECT,MANAGE_MEMBERS,ASSIGN_WORK,MANAGE_SCHEDULE,DELETE_WORK_ITEMS,OVERRIDE_WORKFLOW,MANAGE_PERMISSIONS'.
      WHEN 'TASK'. lv_booleans = 'BLOCKED,CYCLE_REOPENED'.
      WHEN 'EVENT'. lv_booleans = 'REMINDER_ENABLED'.
    ENDCASE.
    SPLIT lv_booleans AT ',' INTO TABLE DATA(lt_booleans).
    LOOP AT lt_booleans INTO DATA(lv_boolean) WHERE table_line IS NOT INITIAL.
      DATA(lv_bool_value) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_boolean ).
      IF lv_bool_value <> abap_true AND lv_bool_value <> abap_false.
        rv_error = |{ lv_boolean } must be a boolean.|. RETURN.
      ENDIF.
    ENDLOOP.
    DATA lv_lengths TYPE string.
    DATA lv_codes TYPE string.
    DATA lv_unique TYPE string.
    CASE iv_entity.
      WHEN 'PROJECT'.
        lv_lengths = 'CODE:30;NAME:150;DESCRIPTION:4000;SCOPE:8000'.
        lv_codes = 'PHASE:INITIATION,DESIGN,BUILD,SIT,UAT,GO_LIVE,HYPERCARE,CLOSED;HEALTH:ON_TRACK,AT_RISK,DELAYED'.
        lv_unique = 'CODE'.
      WHEN 'WORKSTREAM'.
        lv_lengths = 'NAME:150;DESCRIPTION:4000'.
      WHEN 'MEMBERSHIP'.
        lv_unique = 'PROJECT_ID,MEMBER_ID'.
      WHEN 'ROLEASSIGN'.
        lv_codes = 'ROLE:BUSINESS_OWNER,TECHNICAL_LEAD,DEVELOPER,TESTER'.
        lv_unique = 'MEMBERSHIP_ID,ROLE'.
      WHEN 'MILESTONE'.
        lv_lengths = 'TITLE:200'.
        lv_codes = 'STATUS:UPCOMING,AT_RISK,COMPLETE'.
      WHEN 'RISK'.
        lv_lengths = 'TITLE:200;DESCRIPTION:4000;MITIGATION_PLAN:4000;RESOLUTION:4000'.
        lv_codes = 'IMPACT:LOW,MEDIUM,HIGH;PRIORITY:LOW,MEDIUM,HIGH,CRITICAL;STATUS:OPEN,MITIGATING,RESOLVED'.
      WHEN 'MEMBER'.
        lv_lengths = 'NAME:150;EMAIL:254;TITLE:100;TEAM:100'.
        lv_unique = 'EMAIL_NORMALIZED'.
      WHEN 'MEMBERIDENT'.
        lv_unique = 'ABAP_USER'.
      WHEN 'MEMBERSKILL'.
        lv_codes = 'PROFICIENCY:FOUNDATION,WORKING,ADVANCED,EXPERT'.
        lv_unique = 'MEMBER_ID,SKILL_ID'.
      WHEN 'SKILL'.
        lv_lengths = 'NAME:100;DESCRIPTION:1000'.
        lv_unique = 'NAME_NORMALIZED'.
      WHEN 'TASK'.
        lv_lengths = 'TITLE:200;DESCRIPTION:8000;IMPACT:2000;RESOLUTION:4000;BLOCKED_REASON:2000;IMPLEMENTATION_ACTORS_JSON:10000;LAST_OUTCOME_JSON:16000'.
        lv_codes = 'TASK_TYPE:TASK,DEFECT;PRIORITY:LOW,MEDIUM,HIGH,CRITICAL'.
      WHEN 'TASKDEP'.
        lv_unique = 'TASK_ID,DEPENDS_ON_TASK_ID'.
      WHEN 'EVENT'.
        lv_lengths = 'TITLE:200;LOCATION:300;TIME_ZONE:64'.
        lv_codes = 'KIND:MEETING,WORKSHOP,SIT,UAT,GO_LIVE'.
      WHEN 'EVENTATTENDEE'.
        lv_unique = 'EVENT_ID,MEMBER_ID'.
      WHEN 'COMMENT'.
        lv_lengths = 'BODY:8000'.
        lv_codes = 'TARGET_TYPE:PROJECT,WORKSTREAM,TASK,MILESTONE,EVENT,RISK,DOCUMENT'.
      WHEN 'DOCUMENT'.
        lv_lengths = 'TITLE:200;DESCRIPTION:2000;URL:2048;FILE_NAME:255;MIME_TYPE:100'.
        lv_codes = 'CATEGORY:REQUIREMENTS,DESIGN,TESTING,DEPLOYMENT,GOVERNANCE,OTHER;SOURCE_TYPE:FILE,URL;UPLOAD_STATUS:PENDING,READY'.
      WHEN 'DOCATTACH'.
        lv_codes = 'TARGET_TYPE:PROJECT,TASK,COMMENT,RISK'.
        lv_unique = 'DOCUMENT_ID,TARGET_TYPE,TARGET_ID'.
    ENDCASE.
    SPLIT lv_lengths AT ';' INTO TABLE DATA(lt_lengths).
    LOOP AT lt_lengths INTO DATA(lv_length) WHERE table_line IS NOT INITIAL.
      SPLIT lv_length AT ':' INTO DATA(lv_field) DATA(lv_max).
      DATA(lv_value) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_field ).
      IF strlen( lv_value ) > CONV i( lv_max ). rv_error = |{ lv_field } exceeds { lv_max } characters.|. RETURN. ENDIF.
      IF ( lv_field = 'NAME' OR ( lv_field = 'TITLE' AND iv_entity <> 'MEMBER' )
        OR lv_field = 'BODY' OR lv_field = 'CODE' ) AND normalize( lv_value ) IS INITIAL.
        rv_error = |{ lv_field } is required.|. RETURN.
      ENDIF.
    ENDLOOP.
    SPLIT lv_codes AT ';' INTO TABLE DATA(lt_codes).
    LOOP AT lt_codes INTO DATA(lv_code_rule) WHERE table_line IS NOT INITIAL.
      SPLIT lv_code_rule AT ':' INTO lv_field DATA(lv_allowed).
      SPLIT lv_allowed AT ',' INTO TABLE DATA(lt_allowed).
      lv_value = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_field ).
      READ TABLE lt_allowed TRANSPORTING NO FIELDS WITH KEY table_line = lv_value.
      IF sy-subrc <> 0. rv_error = |Unknown { lv_field } value.|. RETURN. ENDIF.
    ENDLOOP.
    IF lv_unique IS NOT INITIAL.
      SPLIT lv_unique AT ',' INTO TABLE DATA(lt_unique).
      LOOP AT ycl_it_hub_tx=>rows( iv_entity ) INTO DATA(lr_other).
        IF ycl_it_hub_tx=>field( ir_row = lr_other iv_name = 'ID' ) = lv_id. CONTINUE. ENDIF.
        DATA(lv_duplicate) = abap_true.
        LOOP AT lt_unique INTO lv_field.
          IF ycl_it_hub_tx=>field( ir_row = lr_other iv_name = lv_field ) <> ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_field ).
            lv_duplicate = abap_false. EXIT.
          ENDIF.
        ENDLOOP.
        IF lv_duplicate = abap_true. rv_error = |Duplicate { lv_unique } is not allowed.|. RETURN. ENDIF.
      ENDLOOP.
    ENDIF.
    IF lv_project IS NOT INITIAL.
      DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = lv_project ).
      IF lr_project IS NOT BOUND. rv_error = 'Project does not exist in the effective transaction state.'. RETURN. ENDIF.
    ENDIF.
    DATA lv_references TYPE string.
    CASE iv_entity.
      WHEN 'TASK'. lv_references = 'ASSIGNEE_ID,TESTER_ID'.
      WHEN 'WORKSTREAM' OR 'MILESTONE' OR 'RISK'. lv_references = 'OWNER_ID'.
      WHEN 'MEMBERSHIP' OR 'EVENTATTENDEE'. lv_references = 'MEMBER_ID'.
    ENDCASE.
    SPLIT lv_references AT ',' INTO TABLE DATA(lt_references).
    LOOP AT lt_references INTO lv_field WHERE table_line IS NOT INITIAL.
      lv_value = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_field ).
      IF lv_value IS INITIAL. CONTINUE. ENDIF.
      IF lr_before IS BOUND AND lv_value = ycl_it_hub_tx=>field( ir_row = lr_before iv_name = lv_field )
        AND ( iv_entity <> 'MEMBERSHIP'
          OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) <> abap_true
          OR ycl_it_hub_tx=>field( ir_row = lr_before iv_name = 'ACTIVE' ) = abap_true ).
        CONTINUE.
      ENDIF.
      DATA(lv_role) = CONV string( '' ).
      IF iv_entity = 'TASK' AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_TYPE' ) = 'DEFECT'.
        lv_role = COND #( WHEN lv_field = 'TESTER_ID' THEN 'TESTER' ELSE 'DEVELOPER' ).
      ENDIF.
      IF iv_entity = 'MEMBERSHIP'.
        IF eligible( CONV #( lv_value ) ) = abap_false. rv_error = 'Member requires an active identity and trusted app grant.'. RETURN. ENDIF.
      ELSEIF member_in_project( iv_project = lv_project iv_member = CONV #( lv_value ) iv_role = lv_role ) = abap_false.
        rv_error = SWITCH #( lv_role
          WHEN 'DEVELOPER' THEN 'Defect assignee needs an eligible Developer.'
          WHEN 'TESTER' THEN 'Defect tester needs an eligible Tester.'
          ELSE 'New assignments require an active eligible member in the same project.' ).
        RETURN.
      ENDIF.
    ENDLOOP.
    CASE iv_entity.
      WHEN 'PROJECT'.
        DATA(lv_start) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'START_DATE' ).
        DATA(lv_end) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'END_DATE' ).
        IF valid_date( lv_start ) = abap_false OR valid_date( lv_end ) = abap_false
          OR ( lv_start <> '00000000' AND lv_end <> '00000000' AND lv_start IS NOT INITIAL AND lv_end IS NOT INITIAL AND lv_end < lv_start ).
          rv_error = 'Invalid project calendar date or date range.'. RETURN.
        ENDIF.
        " PCRE extended mode treats an unescaped # as a comment.
        IF NOT matches( val = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACCENT' ) pcre = '\A\#[0-9A-Fa-f]{6}\z' ).
          rv_error = 'Accent must be a #RRGGBB color.'. RETURN.
        ENDIF.
        DATA(lv_phase) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PHASE' ).
        IF lr_before IS NOT BOUND AND lv_phase <> 'INITIATION'. rv_error = 'New projects start in INITIATION.'. RETURN. ENDIF.
        IF lr_before IS BOUND.
          DATA(lv_old_phase) = ycl_it_hub_tx=>field( ir_row = lr_before iv_name = 'PHASE' ).
          IF lv_old_phase <> lv_phase.
            SPLIT 'INITIATION,DESIGN,BUILD,SIT,UAT,GO_LIVE,HYPERCARE,CLOSED' AT ',' INTO TABLE DATA(lt_phases).
            READ TABLE lt_phases TRANSPORTING NO FIELDS WITH KEY table_line = lv_old_phase.
            DATA(lv_next) = sy-tabix + 1.
            READ TABLE lt_phases INDEX lv_next INTO DATA(lv_next_phase).
            IF sy-subrc <> 0 OR lv_phase <> lv_next_phase. rv_error = 'Project phase may advance by one step only.'. RETURN. ENDIF.
          ENDIF.
        ENDIF.
        IF lv_phase <> 'INITIATION'.
          DATA(lv_has_manager) = abap_false.
          LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_appointment).
            IF ycl_it_hub_tx=>field( ir_row = lr_appointment iv_name = 'PROJECT_ID' ) = lv_id
              AND ycl_it_hub_tx=>field( ir_row = lr_appointment iv_name = 'ACTIVE' ) = abap_true
              AND ycl_it_hub_tx=>field( ir_row = lr_appointment iv_name = 'IS_PROJECT_MANAGER' ) = abap_true
              AND eligible( CONV #( ycl_it_hub_tx=>field( ir_row = lr_appointment iv_name = 'MEMBER_ID' ) ) ) = abap_true.
              lv_has_manager = abap_true. EXIT.
            ENDIF.
          ENDLOOP.
          IF lv_has_manager = abap_false. rv_error = 'Project requires at least one eligible appointed manager after INITIATION.'. RETURN. ENDIF.
        ENDIF.
      WHEN 'MEMBER'.
        IF NOT matches( val = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'EMAIL' ) pcre = '\A[^\s@]+@[^\s@]+\.[^\s@]+\z' ).
          rv_error = 'A valid email is required.'. RETURN.
        ENDIF.
        IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) <> abap_true.
          LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_member_appointment).
            IF ycl_it_hub_tx=>field( ir_row = lr_member_appointment iv_name = 'MEMBER_ID' ) = lv_id
              AND ycl_it_hub_tx=>field( ir_row = lr_member_appointment iv_name = 'IS_PROJECT_MANAGER' ) = abap_true.
              rv_error = 'Remove project manager appointments before deactivating the Member.'. RETURN.
            ENDIF.
          ENDLOOP.
        ENDIF.
      WHEN 'MEMBERIDENT'.
        DATA(lv_user) = CONV syuname( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ABAP_USER' ) ).
        IF lr_before IS NOT BOUND OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) = abap_true.
          SELECT SINGLE bname FROM usr02 WHERE bname = @lv_user AND ustyp = 'A' AND uflag = 0
            AND ( gltgv = '00000000' OR gltgv <= @sy-datum )
            AND ( gltgb = '00000000' OR gltgb >= @sy-datum ) INTO @DATA(lv_bname).
          IF sy-subrc <> 0. rv_error = 'Active/new identity requires a currently valid unlocked dialog SAP user.'. RETURN. ENDIF.
        ENDIF.
        DATA(lv_identity_member) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) ).
        " CREATE prechecks run before the new parent is necessarily buffered.
        " Its key can still be represented by %cid_ref. Only defer this lookup
        " for new identities; save validation uses the strict default.
        IF iv_precheck <> abap_true OR lr_before IS BOUND.
          IF ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = lv_identity_member ) IS NOT BOUND.
            rv_error = 'Identity parent Member does not exist.'. RETURN.
          ENDIF.
        ENDIF.
        IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) <> abap_true.
          LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_identity_appointment).
            IF ycl_it_hub_tx=>field( ir_row = lr_identity_appointment iv_name = 'MEMBER_ID' ) = lv_identity_member
              AND ycl_it_hub_tx=>field( ir_row = lr_identity_appointment iv_name = 'IS_PROJECT_MANAGER' ) = abap_true.
              rv_error = 'Remove manager appointments before deactivating an identity.'. RETURN.
            ENDIF.
          ENDLOOP.
        ENDIF.
      WHEN 'MEMBERSHIP'.
        DATA(lv_appointed) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'IS_PROJECT_MANAGER' ).
        IF lv_appointed = abap_true AND ( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) <> abap_true
          OR eligible( CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) ) ) = abap_false ).
          rv_error = 'Manager appointments require an active eligible Membership/Member/identity.'. RETURN.
        ENDIF.
        IF lv_appointed <> abap_true.
          SPLIT 'EDIT_PROJECT,MANAGE_MEMBERS,ASSIGN_WORK,MANAGE_SCHEDULE,DELETE_WORK_ITEMS,OVERRIDE_WORKFLOW,MANAGE_PERMISSIONS' AT ',' INTO TABLE DATA(lt_flags).
          LOOP AT lt_flags INTO DATA(lv_flag).
            IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_flag ) = abap_true.
              rv_error = 'Only appointed managers may have manager permission flags.'. RETURN.
            ENDIF.
          ENDLOOP.
        ENDIF.
      WHEN 'ROLEASSIGN'.
        DATA(lr_role_parent) = ycl_it_hub_tx=>get( iv_entity = 'MEMBERSHIP'
          iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBERSHIP_ID' ) ) ).
        IF lr_role_parent IS NOT BOUND OR ycl_it_hub_tx=>field( ir_row = lr_role_parent iv_name = 'PROJECT_ID' ) <> lv_project.
          rv_error = 'Responsibility parent/project mismatch.'. RETURN.
        ENDIF.
        IF lr_before IS NOT BOUND AND ( ycl_it_hub_tx=>field( ir_row = lr_role_parent iv_name = 'ACTIVE' ) <> abap_true
          OR eligible( CONV #( ycl_it_hub_tx=>field( ir_row = lr_role_parent iv_name = 'MEMBER_ID' ) ) ) = abap_false ).
          rv_error = 'New responsibilities require an active eligible membership.'. RETURN.
        ENDIF.
      WHEN 'MEMBERSKILL'.
        " A deep-create parent can be unresolved before RAP buffers the Member.
        " Save validation and updates still require the effective parent.
        IF iv_precheck <> abap_true OR lr_before IS BOUND.
          IF ycl_it_hub_tx=>get( iv_entity = 'MEMBER'
            iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) ) ) IS NOT BOUND.
            rv_error = 'Skill assignment parent Member does not exist.'. RETURN.
          ENDIF.
        ENDIF.
        DATA(lr_catalog) = ycl_it_hub_tx=>get( iv_entity = 'SKILL'
          iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'SKILL_ID' ) ) ).
        IF lr_catalog IS NOT BOUND. rv_error = 'Skill catalog entry does not exist.'. RETURN. ENDIF.
        IF ycl_it_hub_tx=>field( ir_row = lr_catalog iv_name = 'ACTIVE' ) <> abap_true
          AND ( lr_before IS NOT BOUND OR ycl_it_hub_tx=>field( ir_row = lr_before iv_name = 'PROFICIENCY' )
            <> ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROFICIENCY' ) ).
          rv_error = 'Retired assignments may be retained unchanged or removed.'. RETURN.
        ENDIF.
      WHEN 'WORKSTREAM'.
        IF CONV i( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'SORT_ORDER' ) ) < 0. rv_error = 'sortOrder must be nonnegative.'. RETURN. ENDIF.
      WHEN 'MILESTONE'.
        lv_value = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'DUE_DATE' ).
        IF lv_value IS INITIAL OR lv_value = '00000000' OR valid_date( lv_value ) = abap_false.
          rv_error = 'Milestone requires a valid due date.'. RETURN.
        ENDIF.
      WHEN 'RISK'.
        DATA(lv_likelihood) = CONV i( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'LIKELIHOOD' ) ).
        IF lv_likelihood < 1 OR lv_likelihood > 3. rv_error = 'Likelihood must be 1, 2 or 3.'. RETURN. ENDIF.
        IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'STATUS' ) = 'RESOLVED'
          AND normalize( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'RESOLUTION' ) ) IS INITIAL.
          rv_error = 'Resolved risks require a resolution.'. RETURN.
        ENDIF.
        DATA(lv_risk_task) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_ID' ) ).
        IF lv_risk_task IS NOT INITIAL AND ycl_it_hub_tx=>field(
          ir_row = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = lv_risk_task ) iv_name = 'PROJECT_ID' ) <> lv_project.
          rv_error = 'Risk task must belong to the same project.'. RETURN.
        ENDIF.
      WHEN 'TASK'.
        DATA ls_task TYPE ytb_it_hub_task.
        MOVE-CORRESPONDING ir_row->* TO ls_task.
        IF ls_task-sort_order < 0 OR ls_task-estimate_hours < 0 OR valid_date( CONV #( ls_task-due_date ) ) = abap_false.
          rv_error = 'Invalid task estimate, sort order or due date.'. RETURN.
        ENDIF.
        IF ls_task-parent_id IS NOT INITIAL.
          DATA(lr_parent_task) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = ls_task-parent_id ).
          IF ls_task-task_type <> 'TASK' OR lr_parent_task IS NOT BOUND OR ls_task-parent_id = ls_task-id
            OR ycl_it_hub_tx=>field( ir_row = lr_parent_task iv_name = 'PROJECT_ID' ) <> ls_task-project_id
            OR ycl_it_hub_tx=>field( ir_row = lr_parent_task iv_name = 'TASK_TYPE' ) <> 'TASK'
            OR ycl_it_hub_tx=>field( ir_row = lr_parent_task iv_name = 'PARENT_ID' ) IS NOT INITIAL
            OR ycl_it_hub_tx=>field( ir_row = lr_parent_task iv_name = 'STATUS' ) = 'DONE'.
            rv_error = 'Subtasks require a main Task in the same project that is not Done.'. RETURN.
          ENDIF.
        ENDIF.
        IF ls_task-source_task_id IS NOT INITIAL.
          DATA(lr_source_task) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = ls_task-source_task_id ).
          IF ls_task-task_type <> 'DEFECT' OR ls_task-source_task_id = ls_task-id OR lr_source_task IS NOT BOUND
            OR ycl_it_hub_tx=>field( ir_row = lr_source_task iv_name = 'PROJECT_ID' ) <> lv_project
            OR ycl_it_hub_tx=>field( ir_row = lr_source_task iv_name = 'TASK_TYPE' ) <> 'TASK'.
            rv_error = 'Defect source must be a different Task or subtask in the same project.'. RETURN.
          ENDIF.
        ENDIF.
        IF ls_task-workstream_id IS NOT INITIAL AND ycl_it_hub_tx=>field(
          ir_row = ycl_it_hub_tx=>get( iv_entity = 'WORKSTREAM' iv_id = ls_task-workstream_id ) iv_name = 'PROJECT_ID' ) <> lv_project.
          rv_error = 'Workstream must belong to the same project.'. RETURN.
        ENDIF.
        IF ls_task-task_type <> 'DEFECT' AND ( ls_task-tester_id IS NOT INITIAL OR ls_task-impact IS NOT INITIAL OR ls_task-resolution IS NOT INITIAL ).
          rv_error = 'Tester, impact and resolution are defect-only fields.'. RETURN.
        ENDIF.
        IF ls_task-blocked = abap_true AND normalize( ls_task-blocked_reason ) IS INITIAL.
          rv_error = 'Blocked work requires a reason.'. RETURN.
        ENDIF.
        IF ( ls_task-status = 'DONE' OR ls_task-status = 'CLOSED' ) AND ls_task-blocked = abap_true.
          rv_error = 'Blocked work cannot be terminal.'. RETURN.
        ENDIF.
        IF ls_task-task_type = 'DEFECT' AND ls_task-status = 'CLOSED' AND normalize( ls_task-resolution ) IS INITIAL.
          rv_error = 'Closed defects require a resolution.'. RETURN.
        ENDIF.
        IF lr_before IS NOT BOUND AND ycl_it_hub_tx=>in_scope( iv_name = 'DEFAULTED_TASK' iv_id = ls_task-id ) = abap_false
          AND ls_task-status <> COND #( WHEN ls_task-task_type = 'DEFECT' OR ls_task-parent_id IS NOT INITIAL THEN 'OPEN' ELSE 'TODO' ).
          rv_error = 'New work must start in its initial workflow state.'. RETURN.
        ENDIF.
        DATA(lv_valid_status) = COND string( WHEN ls_task-task_type = 'DEFECT' THEN 'OPEN,IN_FIX,READY_FOR_RETEST,CLOSED'
          WHEN ls_task-parent_id IS NOT INITIAL THEN 'OPEN,IN_PROGRESS,CLOSED' ELSE 'TODO,IN_PROGRESS,IN_REVIEW,DONE' ).
        SPLIT lv_valid_status AT ',' INTO TABLE DATA(lt_statuses).
        READ TABLE lt_statuses TRANSPORTING NO FIELDS WITH KEY table_line = ls_task-status.
        IF sy-subrc <> 0. rv_error = 'Status is not valid for this work-item kind.'. RETURN. ENDIF.
        TRY.
            DATA(lt_evidence) = parse_array( iv_json = ls_task-implementation_actors_json ).
          CATCH ycx_it_hub INTO DATA(lx_evidence). rv_error = lx_evidence->text. RETURN.
        ENDTRY.
        IF ls_task-status = 'DONE' AND ls_task-task_type = 'TASK' AND ls_task-parent_id IS INITIAL.
          LOOP AT ycl_it_hub_tx=>rows( 'TASK' ) INTO DATA(lr_child_task).
            IF ycl_it_hub_tx=>field( ir_row = lr_child_task iv_name = 'PARENT_ID' ) = ls_task-id
              AND ycl_it_hub_tx=>field( ir_row = lr_child_task iv_name = 'STATUS' ) <> 'CLOSED'.
              rv_error = 'All subtasks must be Closed before completing their parent.'. RETURN.
            ENDIF.
          ENDLOOP.
        ENDIF.
      WHEN 'TASKDEP'.
        DATA ls_link TYPE ytb_it_hub_tdep.
        MOVE-CORRESPONDING ir_row->* TO ls_link.
        rv_error = graph( ls_link ).
        IF rv_error IS INITIAL.
          DATA(lr_dependency_task) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = ls_link-task_id ).
          DATA(lv_dependency_status) = ycl_it_hub_tx=>field( ir_row = lr_dependency_task iv_name = 'STATUS' ).
          IF lv_dependency_status <> 'TODO' AND lv_dependency_status <> 'OPEN'
            AND lv_dependency_status <> 'IN_PROGRESS' AND lv_dependency_status <> 'IN_FIX'.
            rv_error = 'Dependencies require an editable implementation state.'. RETURN.
          ENDIF.
          DATA(lv_dependency_parent) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = lr_dependency_task iv_name = 'PARENT_ID' ) ).
          IF lv_dependency_parent IS NOT INITIAL AND ycl_it_hub_tx=>field(
            ir_row = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = lv_dependency_parent ) iv_name = 'STATUS' ) = 'DONE'.
            rv_error = 'Reopen the parent before changing subtask dependencies.'. RETURN.
          ENDIF.
        ENDIF.
      WHEN 'EVENT'.
        DATA(lv_start_at) = CONV timestampl( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'START_AT' ) ).
        DATA(lv_end_at) = CONV timestampl( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'END_AT' ) ).
        DATA: lv_timestamp_date TYPE d, lv_timestamp_time TYPE t.
        CONVERT TIME STAMP lv_start_at TIME ZONE 'UTC' INTO DATE lv_timestamp_date TIME lv_timestamp_time.
        IF sy-subrc <> 0. rv_error = 'Event start timestamp is not a valid UTC instant.'. RETURN. ENDIF.
        CONVERT TIME STAMP lv_end_at TIME ZONE 'UTC' INTO DATE lv_timestamp_date TIME lv_timestamp_time.
        IF sy-subrc <> 0. rv_error = 'Event end timestamp is not a valid UTC instant.'. RETURN. ENDIF.
        IF lv_start_at <= 0
          OR CONV timestampl( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'END_AT' ) )
            <= CONV timestampl( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'START_AT' ) ).
          rv_error = 'Event requires valid UTC timestamps with end after start.'. RETURN.
        ENDIF.
        DATA(lv_zone) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TIME_ZONE' ).
        DATA lv_cfg_zone TYPE ytb_it_hub_cfg-name.
        DATA lv_cfg_zone_length TYPE i.
        DESCRIBE FIELD lv_cfg_zone LENGTH lv_cfg_zone_length IN CHARACTER MODE.
        IF strlen( lv_zone ) > lv_cfg_zone_length.
          rv_error = |Timezone name exceeds { lv_cfg_zone_length } characters.|. RETURN.
        ENDIF.
        IF lv_zone <> 'UTC'.
          SELECT SINGLE value FROM ytb_it_hub_cfg WHERE kind = 'TIME_ZONE' AND name = @lv_zone AND active = @abap_true INTO @DATA(lv_sap_zone).
          IF sy-subrc <> 0. rv_error = 'Unknown or unconfigured IANA timezone.'. RETURN. ENDIF.
          SELECT SINGLE tzone FROM ttzz WHERE tzone = @lv_sap_zone INTO @DATA(lv_installed_zone).
          IF sy-subrc <> 0. rv_error = 'IANA mapping does not resolve to an installed SAP timezone.'. RETURN. ENDIF.
        ENDIF.
        DATA(lv_minutes) = CONV i( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'REMINDER_MINUTES' ) ).
        IF lv_minutes < 0 OR lv_minutes > 10080. rv_error = 'Reminder minutes must be between 0 and 10080.'. RETURN. ENDIF.
      WHEN 'EVENTATTENDEE'.
        DATA(lr_event_parent) = ycl_it_hub_tx=>get( iv_entity = 'EVENT'
          iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'EVENT_ID' ) ) ).
        IF lr_event_parent IS NOT BOUND OR ycl_it_hub_tx=>field( ir_row = lr_event_parent iv_name = 'PROJECT_ID' ) <> lv_project.
          rv_error = 'Attendee parent/project mismatch.'. RETURN.
        ENDIF.
      WHEN 'COMMENT' OR 'DOCATTACH'.
        DATA(lv_target_type) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ).
        DATA(lv_target_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ).
        DATA(lr_bound_target) = target( iv_type = lv_target_type iv_id = lv_target_id ).
        DATA(lv_target_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = lr_bound_target iv_name = 'PROJECT_ID' ) ).
        IF lv_target_type = 'PROJECT'. lv_target_project = lv_target_id. ENDIF.
        IF lr_bound_target IS NOT BOUND OR lv_target_project <> lv_project.
          rv_error = 'Target must exist in the same project.'. RETURN.
        ENDIF.
        IF iv_entity = 'DOCATTACH'.
          DATA(lr_attachment_doc) = ycl_it_hub_tx=>get( iv_entity = 'DOCUMENT'
            iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'DOCUMENT_ID' ) ) ).
          IF lr_attachment_doc IS NOT BOUND OR ycl_it_hub_tx=>field( ir_row = lr_attachment_doc iv_name = 'PROJECT_ID' ) <> lv_project
            OR ycl_it_hub_tx=>field( ir_row = lr_attachment_doc iv_name = 'UPLOAD_STATUS' ) <> 'READY'.
            rv_error = 'Attachments require a Ready Document in the same project.'. RETURN.
          ENDIF.
        ENDIF.
      WHEN 'DOCUMENT'.
        DATA ls_document TYPE ytb_it_hub_docs.
        MOVE-CORRESPONDING ir_row->* TO ls_document.
        TRY.
            IF ls_document-source_type = 'URL'.
              ycl_it_hub_media=>url( ls_document-url ).
              IF ls_document-content IS NOT INITIAL OR ls_document-file_name IS NOT INITIAL OR ls_document-mime_type IS NOT INITIAL
                OR ls_document-media_kind <> 'LINK' OR ls_document-upload_status <> 'READY'
                OR ls_document-byte_size <> 0 OR ls_document-checksum_sha256 IS NOT INITIAL.
                rv_error = 'URL Documents cannot contain file attributes.'. RETURN.
              ENDIF.
            ELSEIF ls_document-url IS NOT INITIAL.
              rv_error = 'FILE Documents cannot contain a URL.'. RETURN.
            ELSEIF ls_document-upload_status = 'READY'.
              DATA(ls_checked) = ycl_it_hub_media=>file( ls_document ).
              IF ls_checked-checksum_sha256 <> ls_document-checksum_sha256 OR ls_checked-byte_size <> ls_document-byte_size.
                rv_error = 'File derived metadata does not match validated bytes.'. RETURN.
              ENDIF.
            ENDIF.
          CATCH ycx_it_hub INTO DATA(lx_document). rv_error = lx_document->text.
        ENDTRY.
    ENDCASE.
  ENDMETHOD.


  METHOD precheck.
    DATA(lv_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ID' ) ).
    DATA(lr_current) = ycl_it_hub_tx=>get( iv_entity = iv_entity iv_id = lv_id ).
    DATA(lr_permission_row) = COND #( WHEN iv_operation = 'CREATE' THEN ir_row ELSE lr_current ).
    DATA lv_parent_entity TYPE string.
    DATA lv_parent_field TYPE string.
    CASE iv_entity.
      WHEN 'TASKDEP'. lv_parent_entity = 'TASK'. lv_parent_field = 'TASK_ID'.
      WHEN 'EVENTATTENDEE'. lv_parent_entity = 'EVENT'. lv_parent_field = 'EVENT_ID'.
      WHEN 'ROLEASSIGN'. lv_parent_entity = 'MEMBERSHIP'. lv_parent_field = 'MEMBERSHIP_ID'.
      WHEN 'DOCATTACH'. lv_parent_entity = 'DOCUMENT'. lv_parent_field = 'DOCUMENT_ID'.
    ENDCASE.
    DATA(lv_defer) = xsdbool( iv_defer_parent = abap_true AND iv_operation = 'CREATE' AND lv_parent_entity IS NOT INITIAL
      AND ycl_it_hub_tx=>get( iv_entity = lv_parent_entity iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_parent_field ) ) ) IS NOT BOUND ).
    DATA(ls_precheck_actor) = actor( ).
    IF ( lv_defer = abap_true AND ls_precheck_actor-active = abap_false )
      OR ( lv_defer = abap_false AND can( iv_entity = iv_entity iv_operation = iv_operation ir_row = ir_row ) = abap_false ).
      rv_error = 'You are not authorized for this operation.'. RETURN.
    ENDIF.
    IF iv_operation = 'CREATE' AND lv_id IS NOT INITIAL
      AND ycl_it_hub_tx=>in_scope( iv_name = |NUMBERED_{ iv_entity }| iv_id = lv_id ) = abap_false.
      rv_error = 'Externally supplied identifiers are not allowed.'. RETURN.
    ENDIF.
    IF iv_operation = 'DELETE'. rv_error = removed( iv_entity = iv_entity ir_row = ir_row ). RETURN. ENDIF.
    DATA lv_readonly TYPE string.
    CASE iv_entity.
      WHEN 'PROJECT'. lv_readonly = 'ARCHIVED_AT,ARCHIVED_BY'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',CODE'. ENDIF.
      WHEN 'WORKSTREAM'. lv_readonly = 'PROJECT_ID'.
      WHEN 'MEMBERSHIP'. lv_readonly = 'PROJECT_ID,IS_PROJECT_MANAGER,EDIT_PROJECT,MANAGE_MEMBERS,ASSIGN_WORK,MANAGE_SCHEDULE,DELETE_WORK_ITEMS,OVERRIDE_WORKFLOW,MANAGE_PERMISSIONS'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',MEMBER_ID'. ENDIF.
      WHEN 'ROLEASSIGN'. lv_readonly = 'PROJECT_ID,MEMBERSHIP_ID'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',ROLE'. ENDIF.
      WHEN 'MILESTONE'. lv_readonly = 'PROJECT_ID,COMPLETED_AT'.
      WHEN 'RISK'. lv_readonly = 'PROJECT_ID'.
      WHEN 'MEMBER'. lv_readonly = 'IS_APP_MANAGER,EMAIL_NORMALIZED,INITIALS'.
      WHEN 'MEMBERIDENT'. lv_readonly = 'MEMBER_ID'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',ABAP_USER'. ENDIF.
      WHEN 'MEMBERSKILL'. lv_readonly = 'MEMBER_ID'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',SKILL_ID'. ENDIF.
      WHEN 'SKILL'. lv_readonly = 'NAME_NORMALIZED'.
      WHEN 'TASK'. lv_readonly = 'STATUS,COMPLETED_AT,IMPLEMENTATION_ACTORS_JSON,LAST_OUTCOME_JSON,CYCLE_REOPENED'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',PROJECT_ID,PARENT_ID,TASK_TYPE'. ENDIF.
      WHEN 'TASKDEP'. lv_readonly = 'PROJECT_ID,TASK_ID'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',DEPENDS_ON_TASK_ID'. ENDIF.
      WHEN 'EVENT'. lv_readonly = ''.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',PROJECT_ID'. ENDIF.
      WHEN 'EVENTATTENDEE'. lv_readonly = 'PROJECT_ID,EVENT_ID'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',MEMBER_ID'. ENDIF.
      WHEN 'COMMENT'. lv_readonly = ''.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',PROJECT_ID,TARGET_TYPE,TARGET_ID'. ENDIF.
      WHEN 'DOCUMENT'. lv_readonly = 'MEDIA_KIND,UPLOAD_STATUS,BYTE_SIZE,CHECKSUM_SHA256'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',PROJECT_ID,SOURCE_TYPE'. ENDIF.
      WHEN 'DOCATTACH'. lv_readonly = 'PROJECT_ID,DOCUMENT_ID'.
        IF iv_operation = 'UPDATE'. lv_readonly = lv_readonly && ',TARGET_TYPE,TARGET_ID'. ENDIF.
    ENDCASE.
    lv_readonly = lv_readonly && ',ID,CREATED_AT,CREATED_BY,UPDATED_AT,UPDATED_BY,LOCAL_LAST_CHANGED_AT,CREATED_BY_MEMBER_ID,UPDATED_BY_MEMBER_ID,CHANGE_TOKEN'.
    SPLIT lv_readonly AT ',' INTO TABLE DATA(lt_readonly).
    LOOP AT lt_readonly INTO DATA(lv_field) WHERE table_line IS NOT INITIAL.
      ASSIGN COMPONENT lv_field OF STRUCTURE is_control TO FIELD-SYMBOL(<control>).
      IF sy-subrc = 0 AND <control> = if_abap_behv=>mk-on.
        rv_error = |{ lv_field } is maintained by the server.|. RETURN.
      ENDIF.
    ENDLOOP.
    DATA(lv_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ) ).
    IF iv_entity = 'PROJECT'. lv_project = lv_id. ENDIF.
    DATA(ls_permissions) = permissions( iv_project = lv_project ).
    IF iv_operation = 'UPDATE'.
      IF iv_entity = 'PROJECT' AND (
        ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'START_DATE' ) <> ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'START_DATE' )
        OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'END_DATE' ) <> ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'END_DATE' ) )
        AND ls_permissions-manage_schedule = abap_false.
        rv_error = 'Changing project dates requires manageSchedule.'. RETURN.
      ENDIF.
      IF iv_entity = 'WORKSTREAM' AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'OWNER_ID' )
        <> ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'OWNER_ID' ) AND ls_permissions-manage_schedule = abap_false.
        rv_error = 'Changing the workstream owner requires manageSchedule.'. RETURN.
      ENDIF.
      IF iv_entity = 'TASK'.
        SPLIT 'ASSIGNEE_ID,TESTER_ID,DUE_DATE,PRIORITY' AT ',' INTO TABLE DATA(lt_admin_fields).
        LOOP AT lt_admin_fields INTO DATA(lv_admin_field).
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_admin_field ) <> ycl_it_hub_tx=>field( ir_row = lr_current iv_name = lv_admin_field )
            AND ls_permissions-assign_work = abap_false.
            rv_error = 'Assignment, tester, due date and priority changes require assignWork.'. RETURN.
          ENDIF.
        ENDLOOP.
        DATA(lv_status) = ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'STATUS' ).
        IF lv_status = 'IN_REVIEW' OR lv_status = 'READY_FOR_RETEST' OR lv_status = 'DONE' OR lv_status = 'CLOSED'.
          SPLIT 'TITLE,DESCRIPTION,ESTIMATE_HOURS,BLOCKED,BLOCKED_REASON,IMPACT,RESOLUTION,WORKSTREAM_ID,SORT_ORDER' AT ',' INTO TABLE DATA(lt_work_fields).
          LOOP AT lt_work_fields INTO DATA(lv_work_field).
            IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_work_field ) <> ycl_it_hub_tx=>field( ir_row = lr_current iv_name = lv_work_field ).
              rv_error = 'Return work to an implementation state before editing its content.'. RETURN.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
      IF iv_entity = 'DOCUMENT' AND ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'SOURCE_TYPE' ) = 'FILE'.
        DATA(ls_actor) = actor( ).
        ASSIGN COMPONENT 'CONTENT' OF STRUCTURE is_control TO <control>.
        IF sy-subrc = 0 AND <control> = if_abap_behv=>mk-on.
          IF ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'UPLOAD_STATUS' ) = 'READY'
            OR ( ls_actor-admin = abap_false AND ycl_it_hub_tx=>field( ir_row = lr_current iv_name = 'CREATED_BY_MEMBER_ID' ) <> ls_actor-id ).
            rv_error = 'Only the uploader/admin may upload pending bytes; Ready bytes are immutable.'. RETURN.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
    IF lv_defer = abap_true.
      CASE iv_entity.
        WHEN 'TASKDEP'.
          IF ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'DEPENDS_ON_TASK_ID' ) ) ) IS NOT BOUND.
            rv_error = 'Dependency target does not exist.'.
          ENDIF.
        WHEN 'EVENTATTENDEE'.
          IF eligible( CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) ) ) = abap_false.
            rv_error = 'New assignments require an active eligible member.'.
          ENDIF.
        WHEN 'ROLEASSIGN'.
          DATA(lv_role) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ROLE' ).
          IF lv_role <> 'BUSINESS_OWNER' AND lv_role <> 'TECHNICAL_LEAD' AND lv_role <> 'DEVELOPER' AND lv_role <> 'TESTER'.
            rv_error = 'Unknown project responsibility.'.
          ENDIF.
        WHEN 'DOCATTACH'.
          DATA(lv_target_type) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ).
          IF lv_target_type <> 'PROJECT' AND lv_target_type <> 'TASK' AND lv_target_type <> 'COMMENT' AND lv_target_type <> 'RISK'.
            rv_error = 'Unknown attachment target type.'.
          ELSEIF target( iv_type = lv_target_type iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ) ) IS NOT BOUND.
            rv_error = 'Attachment target does not exist.'.
          ENDIF.
      ENDCASE.
      RETURN.
    ENDIF.
    rv_error = validate( iv_entity = iv_entity ir_row = ir_row
      iv_precheck = xsdbool( iv_operation = 'CREATE' ) ).
  ENDMETHOD.


  METHOD removed.
    DATA(lv_id) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ID' ).
    LOOP AT ycl_it_hub_tx=>rows( 'COMMENT' ) INTO DATA(lr_comment).
      IF ycl_it_hub_tx=>field( ir_row = lr_comment iv_name = 'TARGET_TYPE' ) = iv_entity
        AND ycl_it_hub_tx=>field( ir_row = lr_comment iv_name = 'TARGET_ID' ) = lv_id.
        rv_error = 'Remove direct comments before deleting their target.'. RETURN.
      ENDIF.
    ENDLOOP.
    IF iv_entity = 'TASK' OR iv_entity = 'WORKSTREAM'.
      LOOP AT ycl_it_hub_tx=>rows( 'TASK' ) INTO DATA(lr_task).
        IF ( iv_entity = 'TASK' AND ycl_it_hub_tx=>field( ir_row = lr_task iv_name = 'PARENT_ID' ) = lv_id )
          OR ( iv_entity = 'WORKSTREAM' AND ycl_it_hub_tx=>field( ir_row = lr_task iv_name = 'WORKSTREAM_ID' ) = lv_id ).
          rv_error = 'Linked tasks/subtasks prevent deletion.'. RETURN.
        ENDIF.
      ENDLOOP.
    ENDIF.
    IF iv_entity = 'TASK'.
      LOOP AT ycl_it_hub_tx=>rows( 'TASK' ) INTO DATA(lr_source_defect).
        IF ycl_it_hub_tx=>field( ir_row = lr_source_defect iv_name = 'SOURCE_TASK_ID' ) = lv_id.
          rv_error = 'Linked defects prevent deletion.'. RETURN.
        ENDIF.
      ENDLOOP.
      LOOP AT ycl_it_hub_tx=>rows( 'TASKDEP' ) INTO DATA(lr_link).
        IF ycl_it_hub_tx=>field( ir_row = lr_link iv_name = 'DEPENDS_ON_TASK_ID' ) = lv_id.
          rv_error = 'Inbound dependencies prevent deletion.'. RETURN.
        ENDIF.
      ENDLOOP.
      LOOP AT ycl_it_hub_tx=>rows( 'RISK' ) INTO DATA(lr_risk).
        IF ycl_it_hub_tx=>field( ir_row = lr_risk iv_name = 'TASK_ID' ) = lv_id.
          rv_error = 'Linked risks prevent deletion.'. RETURN.
        ENDIF.
      ENDLOOP.
      DATA(lv_parent) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PARENT_ID' ) ).
      IF lv_parent IS NOT INITIAL AND ycl_it_hub_tx=>field(
        ir_row = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = lv_parent ) iv_name = 'STATUS' ) = 'DONE'.
        rv_error = 'Reopen the parent before deleting a subtask.'. RETURN.
      ENDIF.
    ENDIF.
    IF iv_entity = 'TASKDEP'.
      DATA(lr_dep_task) = ycl_it_hub_tx=>get( iv_entity = 'TASK'
        iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_ID' ) ) ).
      DATA(lv_dep_status) = ycl_it_hub_tx=>field( ir_row = lr_dep_task iv_name = 'STATUS' ).
      IF lv_dep_status <> 'TODO' AND lv_dep_status <> 'OPEN' AND lv_dep_status <> 'IN_PROGRESS' AND lv_dep_status <> 'IN_FIX'.
        rv_error = 'Dependencies require editable implementation state.'. RETURN.
      ENDIF.
    ENDIF.
    IF iv_entity = 'MEMBERIDENT'.
      DATA(lv_member) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ).
      LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_appointment).
        IF ycl_it_hub_tx=>field( ir_row = lr_appointment iv_name = 'MEMBER_ID' ) = lv_member
          AND ycl_it_hub_tx=>field( ir_row = lr_appointment iv_name = 'IS_PROJECT_MANAGER' ) = abap_true.
          rv_error = 'Remove appointments before deleting an identity.'. RETURN.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


  METHOD transition.
    rs_task = is_task.
    DATA(ls_actor) = actor( ).
    DATA(ls_permissions) = permissions( iv_project = is_task-project_id ).
    IF ls_actor-active = abap_false OR ls_permissions-read = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Work item is not currently accessible.'.
    ENDIF.
    IF iv_override <> abap_true AND iv_override <> abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'override must be a boolean.'.
    ENDIF.
    IF strlen( iv_reason ) > 2000.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Workflow reason exceeds 2000 characters.'.
    ENDIF.
    DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = is_task-project_id ).
    DATA lv_archived_at TYPE ytb_it_hub_proj-archived_at.
    lv_archived_at = ycl_it_hub_tx=>field( ir_row = lr_project iv_name = 'ARCHIVED_AT' ).
    IF lv_archived_at IS NOT INITIAL.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Archived project work is immutable.'.
    ENDIF.
    IF is_task-parent_id IS NOT INITIAL AND ycl_it_hub_tx=>field(
      ir_row = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = is_task-parent_id ) iv_name = 'STATUS' ) = 'DONE'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Reopen the parent before changing a subtask.'.
    ENDIF.
    DATA(lv_next) = status_code( iv_status ).
    DATA(lv_edges) = workflow_edges( is_task ).
    SPLIT lv_edges AT ',' INTO TABLE DATA(lt_edges).
    DATA(lv_edge) = |{ is_task-status }>{ lv_next }|.
    READ TABLE lt_edges TRANSPORTING NO FIELDS WITH KEY table_line = lv_edge.
    IF lv_next IS INITIAL OR sy-subrc <> 0.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'This workflow transition is not legal.'.
    ENDIF.
    DATA(lv_terminal) = xsdbool( lv_next = 'DONE' OR lv_next = 'CLOSED' ).
    IF lv_terminal = abap_true AND is_task-blocked = abap_true.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Blocked work cannot be completed.'.
    ENDIF.
    IF lv_next = 'DONE' AND is_task-parent_id IS INITIAL.
      LOOP AT ycl_it_hub_tx=>rows( 'TASK' ) INTO DATA(lr_child).
        IF ycl_it_hub_tx=>field( ir_row = lr_child iv_name = 'PARENT_ID' ) = is_task-id
          AND ycl_it_hub_tx=>field( ir_row = lr_child iv_name = 'STATUS' ) <> 'CLOSED'.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Every subtask must be Closed before Done.'.
        ENDIF.
      ENDLOOP.
    ENDIF.
    IF is_task-task_type = 'DEFECT' AND lv_next = 'READY_FOR_RETEST'
      AND member_in_project( iv_project = is_task-project_id iv_member = is_task-tester_id iv_role = 'TESTER' ) = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Ready for Retest requires an eligible assigned tester.'.
    ENDIF.
    IF is_task-task_type = 'DEFECT' AND lv_next = 'CLOSED' AND normalize( is_task-resolution ) IS INITIAL.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Defect completion requires a resolution.'.
    ENDIF.
    DATA lt_actors TYPE tt_strings.
    DATA(lv_known) = xsdbool( is_task-implementation_actors_json IS NOT INITIAL ).
    IF lv_known = abap_true. lt_actors = parse_array( iv_json = is_task-implementation_actors_json ). ENDIF.
    IF iv_override = abap_true.
      IF ls_permissions-override_workflow = abap_false OR normalize( iv_reason ) IS INITIAL.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Override requires overrideWorkflow and a nonblank reason.'.
      ENDIF.
    ELSEIF is_task-task_type = 'DEFECT' AND ( is_task-status = 'READY_FOR_RETEST' OR is_task-status = 'CLOSED' ).
      READ TABLE lt_actors TRANSPORTING NO FIELDS WITH KEY table_line = CONV string( ls_actor-id ).
      DATA(lv_participated) = xsdbool( sy-subrc = 0 ).
      IF lv_known = abap_false OR lt_actors IS INITIAL OR lv_participated = abap_true
        OR ls_actor-id <> is_task-tester_id OR member_in_project(
          iv_project = is_task-project_id iv_member = ls_actor-id iv_role = 'TESTER' ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Retest requires an assigned independent Tester and known implementation evidence.'.
      ENDIF.
    ELSEIF ls_permissions-contribute = abap_false OR ls_actor-id IS INITIAL
      OR ls_actor-id <> is_task-assignee_id
      OR ( is_task-task_type = 'DEFECT' AND member_in_project(
        iv_project = is_task-project_id iv_member = ls_actor-id iv_role = 'DEVELOPER' ) = abap_false ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Transition requires the contributing assigned implementer.'.
    ENDIF.
    IF ( is_task-status = 'DONE' OR is_task-status = 'CLOSED' ) AND normalize( iv_reason ) IS INITIAL.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Reopening completed work requires a reason.'.
    ENDIF.
    IF lv_next = 'IN_PROGRESS' OR lv_next = 'IN_FIX'.
      IF is_task-cycle_reopened = abap_true. CLEAR lt_actors. ENDIF.
      DATA(lv_implementer) = CONV string( COND sysuuid_c36(
        WHEN is_task-task_type = 'TASK' AND is_task-status = 'IN_REVIEW' AND is_task-assignee_id IS NOT INITIAL
        THEN is_task-assignee_id ELSE ls_actor-id ) ).
      IF lv_implementer IS NOT INITIAL.
        READ TABLE lt_actors TRANSPORTING NO FIELDS WITH KEY table_line = lv_implementer.
        IF sy-subrc <> 0. APPEND lv_implementer TO lt_actors. ENDIF.
      ENDIF.
      rs_task-cycle_reopened = abap_false.
    ELSEIF is_task-status = 'DONE' OR is_task-status = 'CLOSED'.
      rs_task-cycle_reopened = abap_true.
    ENDIF.
    IF lines( lt_actors ) > 200.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Implementation evidence exceeds 200 actors.'.
    ENDIF.
    rs_task-status = lv_next.
    rs_task-implementation_actors_json = /ui2/cl_json=>serialize( lt_actors ).
    IF lv_terminal = abap_true. GET TIME STAMP FIELD rs_task-completed_at. ELSE. CLEAR rs_task-completed_at. ENDIF.
    DATA: BEGIN OF ls_outcome,
            status TYPE string, actor_id TYPE sysuuid_c36, at TYPE timestampl,
            reason TYPE string, override TYPE abap_bool,
          END OF ls_outcome.
    ls_outcome-status = iv_status.
    ls_outcome-actor_id = ls_actor-id.
    GET TIME STAMP FIELD ls_outcome-at.
    ls_outcome-reason = iv_reason.
    ls_outcome-override = iv_override.
    rs_task-last_outcome_json = /ui2/cl_json=>serialize( data = ls_outcome
      pretty_name = /ui2/cl_json=>pretty_mode-camel_case ts_as_iso8601 = abap_true ).
  ENDMETHOD.

ENDCLASS.
