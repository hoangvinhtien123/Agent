@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_ATTACH_DOC
{
  targetType : abap.char(30);
  targetId : sysuuid_c36;
}
