CLASS ltc_uuid DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PRIVATE SECTION.
    CLASS-DATA go_environment TYPE REF TO if_osql_test_environment.
    CLASS-METHODS class_setup RAISING cx_static_check.
    CLASS-METHODS class_teardown.
    METHODS setup.
    METHODS generated_key_lookup FOR TESTING RAISING cx_uuid_error.
ENDCLASS.

CLASS ltc_uuid IMPLEMENTATION.
  METHOD class_setup.
    go_environment = cl_osql_test_environment=>create( VALUE #( ( 'YTB_IT_HUB_MEMB' ) ) ).
  ENDMETHOD.
  METHOD class_teardown.
    go_environment->destroy( ).
  ENDMETHOD.
  METHOD setup.
    go_environment->clear_doubles( ).
  ENDMETHOD.
  METHOD generated_key_lookup.
    DATA(lv_id) = ycl_it_hub_util=>create_uuid_c36( ).
    cl_abap_unit_assert=>assert_true( act = xsdbool( matches( val = lv_id
      pcre = '\A[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\z' ) ) ).
    DATA lt_members TYPE STANDARD TABLE OF ytb_it_hub_memb WITH EMPTY KEY.
    lt_members = VALUE #( ( client = sy-mandt id = lv_id name = 'Key lookup test' ) ).
    go_environment->insert_test_data( lt_members ).
    " ST05 confirmed that the service supplies an uppercase ID predicate.
    DATA(lv_lookup_id) = to_upper( lv_id ).
    SELECT SINGLE id FROM ytb_it_hub_memb
      WHERE id = @lv_lookup_id INTO @DATA(lv_found).
    cl_abap_unit_assert=>assert_subrc( exp = 0 ).
    cl_abap_unit_assert=>assert_equals( act = lv_found exp = lv_id ).
  ENDMETHOD.
ENDCLASS.
