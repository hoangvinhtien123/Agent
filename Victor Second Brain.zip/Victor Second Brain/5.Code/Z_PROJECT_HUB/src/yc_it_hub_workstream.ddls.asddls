@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Workstream'
define view entity YC_IT_HUB_WORKSTREAM
  as projection on YI_IT_HUB_WORKSTREAM
{
  key id,
  projectId,
  name,
  ownerId,
  description,
  sortOrder,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Project : redirected to parent YC_IT_HUB_PROJECT,
  _Owner : redirected to YC_IT_HUB_MEMBER
}
