@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Comment'
define root view entity YC_IT_HUB_COMMENT
  provider contract transactional_query
  as projection on YR_IT_HUB_COMMENT
{
  key id,
  projectId,
  targetType,
  targetId,
  body,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Project : redirected to YC_IT_HUB_PROJECT
}
