@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - MemberSkill'
define view entity YC_IT_HUB_MEMBERSKILL
  as projection on YI_IT_HUB_MEMBERSKILL
{
  key id,
  memberId,
  skillId,
  proficiency,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  name,
  catalogActive,
  _Member : redirected to parent YC_IT_HUB_MEMBER,
  _Catalog : redirected to YC_IT_HUB_SKILL
}
