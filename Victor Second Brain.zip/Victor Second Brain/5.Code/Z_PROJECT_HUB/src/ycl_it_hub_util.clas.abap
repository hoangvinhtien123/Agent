CLASS ycl_it_hub_util DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CLASS-METHODS create_uuid_c36
      RETURNING VALUE(rv_id) TYPE sysuuid_c36
      RAISING cx_uuid_error.
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.

CLASS ycl_it_hub_util IMPLEMENTATION.
  METHOD create_uuid_c36.
    " Persist new C36 keys in the case used by Gateway/DDIC key conversion.
    rv_id = to_upper( cl_system_uuid=>create_uuid_c36_static( ) ).
  ENDMETHOD.
ENDCLASS.
