CLASS ycl_it_hub_notif_plan DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CLASS-METHODS prepare IMPORTING is_task TYPE ytb_it_hub_task RAISING ycx_it_hub.
    CLASS-METHODS save IMPORTING is_create TYPE any is_update TYPE any.
    CLASS-METHODS reset.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_event, task_id TYPE sysuuid_c36, event_type TYPE string, event_id TYPE sysuuid_c36, END OF ty_event.
    CLASS-DATA gt_events TYPE HASHED TABLE OF ty_event WITH UNIQUE KEY task_id event_type.
    CLASS-DATA gt_notifications TYPE STANDARD TABLE OF ytb_it_hub_notf WITH EMPTY KEY.
    CLASS-DATA gt_deliveries TYPE STANDARD TABLE OF ytb_it_hub_ndlv WITH EMPTY KEY.
    CLASS-DATA gt_previous TYPE STANDARD TABLE OF ytb_it_hub_notf WITH EMPTY KEY.
    CLASS-DATA gt_previous_delivery TYPE STANDARD TABLE OF ytb_it_hub_ndlv WITH EMPTY KEY.
    CLASS-METHODS event IMPORTING is_task TYPE ytb_it_hub_task iv_type TYPE string iv_recipient TYPE sysuuid_c36
      RAISING ycx_it_hub.
ENDCLASS.
CLASS ycl_it_hub_notif_plan IMPLEMENTATION.
  METHOD event.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF iv_recipient IS INITIAL OR iv_recipient = ls_actor-id OR ycl_it_hub_policy=>member_in_project(
      iv_project = is_task-project_id iv_member = iv_recipient ) = abap_false. RETURN. ENDIF.
    READ TABLE gt_events INTO DATA(ls_event) WITH TABLE KEY task_id = is_task-id event_type = iv_type.
    TRY.
        IF sy-subrc <> 0.
          ls_event = VALUE #( task_id = is_task-id event_type = iv_type event_id = ycl_it_hub_util=>create_uuid_c36( ) ).
          INSERT ls_event INTO TABLE gt_events.
        ENDIF.
        LOOP AT gt_notifications TRANSPORTING NO FIELDS WHERE event_id = ls_event-event_id AND recipient_id = iv_recipient. RETURN. ENDLOOP.
        DATA(ls_notification) = VALUE ytb_it_hub_notf( client = sy-mandt id = ycl_it_hub_util=>create_uuid_c36( )
          event_id = ls_event-event_id event_type = iv_type recipient_id = iv_recipient
          project_id = is_task-project_id task_id = is_task-id title = |Project Hub: { iv_type }|
          message = |{ is_task-title }: { iv_type }| created_by = sy-uname updated_by = sy-uname ).
        LOOP AT gt_previous INTO DATA(ls_previous) WHERE event_id = ls_event-event_id AND recipient_id = iv_recipient.
          ls_notification = ls_previous. EXIT.
        ENDLOOP.
        IF ls_notification-created_at IS INITIAL. GET TIME STAMP FIELD ls_notification-created_at. ENDIF.
        ls_notification-updated_at = ls_notification-created_at.
        ls_notification-local_last_changed_at = ls_notification-created_at.
        DATA(ls_delivery) = VALUE ytb_it_hub_ndlv( client = sy-mandt id = ycl_it_hub_util=>create_uuid_c36( )
          notification_id = ls_notification-id channel = 'EMAIL' status = 'PENDING'
          created_at = ls_notification-created_at updated_at = ls_notification-created_at
          local_last_changed_at = ls_notification-created_at created_by = sy-uname updated_by = sy-uname ).
        LOOP AT gt_previous_delivery INTO DATA(ls_previous_delivery) WHERE notification_id = ls_notification-id.
          ls_delivery = ls_previous_delivery. EXIT.
        ENDLOOP.
        IF strlen( ls_notification-title ) > 150 OR strlen( ls_notification-message ) > 1000.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Notification text exceeds its supported length.'.
        ENDIF.
        APPEND ls_notification TO gt_notifications.
        APPEND ls_delivery TO gt_deliveries.
      CATCH cx_uuid_error.
        ycl_it_hub_tx=>fail( 'Could not prepare notification/outbox identifiers.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDTRY.
  ENDMETHOD.
  METHOD prepare.
    " Replan from original before and final after; preserve IDs for unchanged semantic recipients.
    DATA(lr_before) = ycl_it_hub_tx=>before( iv_entity = 'TASK' iv_id = is_task-id ).
    DATA ls_before TYPE ytb_it_hub_task.
    IF lr_before IS BOUND. MOVE-CORRESPONDING lr_before->* TO ls_before. ENDIF.
    DATA lt_old TYPE STANDARD TABLE OF ytb_it_hub_notf WITH EMPTY KEY.
    LOOP AT gt_notifications INTO DATA(ls_old) WHERE task_id = is_task-id. APPEND ls_old TO lt_old. ENDLOOP.
    CLEAR: gt_previous, gt_previous_delivery.
    gt_previous = lt_old.
    LOOP AT lt_old INTO DATA(ls_previous_task).
      LOOP AT gt_deliveries INTO DATA(ls_previous_row) WHERE notification_id = ls_previous_task-id.
        APPEND ls_previous_row TO gt_previous_delivery.
      ENDLOOP.
    ENDLOOP.
    DELETE gt_notifications WHERE task_id = is_task-id.
    LOOP AT lt_old INTO ls_old. DELETE gt_deliveries WHERE notification_id = ls_old-id. ENDLOOP.
    IF is_task-assignee_id IS NOT INITIAL AND is_task-assignee_id <> ls_before-assignee_id.
      event( is_task = is_task iv_type = 'ASSIGNED' iv_recipient = is_task-assignee_id ).
    ENDIF.
    IF is_task-task_type = 'DEFECT' AND is_task-status = 'READY_FOR_RETEST'
      AND ( ls_before-status <> 'READY_FOR_RETEST' OR ls_before-tester_id <> is_task-tester_id ).
      IF ycl_it_hub_policy=>member_in_project( iv_project = is_task-project_id iv_member = is_task-tester_id iv_role = 'TESTER' ) = abap_true.
        event( is_task = is_task iv_type = 'RETEST_REQUESTED' iv_recipient = is_task-tester_id ).
      ENDIF.
    ENDIF.
    IF is_task-status <> ls_before-status.
      IF is_task-task_type = 'DEFECT' AND ( is_task-status = 'CLOSED' OR is_task-status = 'OPEN' ) AND ls_before-status IS NOT INITIAL.
        event( is_task = is_task iv_type = 'DEFECT_OUTCOME' iv_recipient = is_task-assignee_id ).
      ELSEIF is_task-task_type = 'TASK' AND is_task-parent_id IS INITIAL AND ( is_task-status = 'IN_REVIEW' OR is_task-status = 'DONE' ).
        LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_manager).
          IF ycl_it_hub_tx=>field( ir_row = lr_manager iv_name = 'PROJECT_ID' ) = is_task-project_id
            AND ycl_it_hub_tx=>field( ir_row = lr_manager iv_name = 'ACTIVE' ) = abap_true
            AND ycl_it_hub_tx=>field( ir_row = lr_manager iv_name = 'IS_PROJECT_MANAGER' ) = abap_true.
            event( is_task = is_task iv_type = COND #( WHEN is_task-status = 'DONE' THEN 'TASK_DONE' ELSE 'TASK_REVIEW' )
              iv_recipient = CONV #( ycl_it_hub_tx=>field( ir_row = lr_manager iv_name = 'MEMBER_ID' ) ) ).
          ENDIF.
        ENDLOOP.
      ELSEIF is_task-task_type = 'TASK' AND ( ls_before-status = 'DONE' OR ls_before-status = 'CLOSED' ).
        event( is_task = is_task iv_type = 'REOPENED' iv_recipient = is_task-assignee_id ).
      ENDIF.
    ENDIF.
  ENDMETHOD.
  METHOD save.
    DATA lt_notifications TYPE STANDARD TABLE OF ytb_it_hub_notf WITH EMPTY KEY.
    DATA lt_deliveries TYPE STANDARD TABLE OF ytb_it_hub_ndlv WITH EMPTY KEY.
    FIELD-SYMBOLS <changes> TYPE ANY TABLE.
    LOOP AT gt_notifications INTO DATA(ls_notification).
      DATA(lv_confirmed) = abap_false.
      DO 2 TIMES.
        IF sy-index = 1. ASSIGN COMPONENT 'TASK' OF STRUCTURE is_create TO <changes>.
        ELSE. ASSIGN COMPONENT 'TASK' OF STRUCTURE is_update TO <changes>. ENDIF.
        IF sy-subrc <> 0. CONTINUE. ENDIF.
        LOOP AT <changes> ASSIGNING FIELD-SYMBOL(<change>).
          ASSIGN COMPONENT 'ID' OF STRUCTURE <change> TO FIELD-SYMBOL(<id>).
          IF sy-subrc = 0 AND <id> = ls_notification-task_id. lv_confirmed = abap_true. EXIT. ENDIF.
        ENDLOOP.
        IF lv_confirmed = abap_true. EXIT. ENDIF.
      ENDDO.
      IF lv_confirmed = abap_false. CONTINUE. ENDIF.
      APPEND ls_notification TO lt_notifications.
      LOOP AT gt_deliveries INTO DATA(ls_delivery) WHERE notification_id = ls_notification-id. APPEND ls_delivery TO lt_deliveries. ENDLOOP.
    ENDLOOP.
    IF lt_notifications IS NOT INITIAL.
      INSERT ytb_it_hub_notf FROM TABLE @lt_notifications.
      ASSERT sy-subrc = 0.
      INSERT ytb_it_hub_ndlv FROM TABLE @lt_deliveries.
      ASSERT sy-subrc = 0.
    ENDIF.
  ENDMETHOD.
  METHOD reset.
    CLEAR: gt_events, gt_notifications, gt_deliveries, gt_previous, gt_previous_delivery.
  ENDMETHOD.
ENDCLASS.
