@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - EventAttendee'
define view entity YC_IT_HUB_EVENTATTENDEE
  as projection on YI_IT_HUB_EVENTATTENDEE
{
  key id,
  projectId,
  eventId,
  memberId,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Event : redirected to parent YC_IT_HUB_EVENT,
  _Project : redirected to YC_IT_HUB_PROJECT,
  _Member : redirected to YC_IT_HUB_MEMBER
}
