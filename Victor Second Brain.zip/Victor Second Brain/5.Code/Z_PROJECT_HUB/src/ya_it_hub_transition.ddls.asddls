@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_TRANSITION
{
  status : abap.char(30);
  reason : abap.string(0);
  override : abap_boolean;
}
