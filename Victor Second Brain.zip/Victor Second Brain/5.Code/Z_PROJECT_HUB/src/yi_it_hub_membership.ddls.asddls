@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Membership'
define view entity YI_IT_HUB_MEMBERSHIP
  as select from ytb_it_hub_mship
  composition [0..*] of YI_IT_HUB_ROLEASSIGN as roles
  association to parent YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
  association [0..1] to YR_IT_HUB_MEMBER as _Member on $projection.memberId = _Member.id
{
  key id as id,
  project_id as projectId,
  member_id as memberId,
  active as active,
  is_project_manager as isProjectManager,
  edit_project as editProject,
  manage_members as manageMembers,
  assign_work as assignWork,
  manage_schedule as manageSchedule,
  delete_work_items as deleteWorkItems,
  override_workflow as overrideWorkflow,
  manage_permissions as managePermissions,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  roles,
  _Project,
  _Member
}
