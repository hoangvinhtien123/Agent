CLASS ltc_notif_query DEFINITION DEFERRED.
CLASS ycl_it_hub_notif_query DEFINITION LOCAL FRIENDS ltc_notif_query.
CLASS ltc_notif_query DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PRIVATE SECTION.
    METHODS provider_construction FOR TESTING RAISING cx_static_check.
    METHODS supported_filters FOR TESTING RAISING cx_static_check.
    METHODS whitespace_filters FOR TESTING RAISING cx_static_check.
    METHODS reject_unsafe_filters FOR TESTING.
    METHODS recipient_ownership FOR TESTING.
    METHODS retention_and_unread FOR TESTING.
    METHODS paging_boundaries FOR TESTING RAISING cx_static_check.
    METHODS requested_fields FOR TESTING RAISING cx_static_check.
ENDCLASS.
CLASS ltc_notif_query IMPLEMENTATION.
  METHOD provider_construction.
    DATA lo_provider TYPE REF TO if_rap_query_provider.
    TRY.
        CREATE OBJECT lo_provider TYPE ('YCL_IT_HUB_NOTIF_QUERY').
      CATCH cx_sy_create_object_error INTO DATA(lx_create).
        cl_abap_unit_assert=>fail( msg = lx_create->get_text( ) ).
    ENDTRY.
    cl_abap_unit_assert=>assert_bound( act = lo_provider ).
  ENDMETHOD.

  METHOD supported_filters.
    DATA(ls_filter) = ycl_it_hub_notif_query=>parse_filter( '' ).
    cl_abap_unit_assert=>assert_initial( act = ls_filter ).
    ls_filter = ycl_it_hub_notif_query=>parse_filter( '( READAT IS NULL )' ).
    cl_abap_unit_assert=>assert_true( act = ls_filter-unread_only ).
    cl_abap_unit_assert=>assert_false( act = ls_filter-has_id ).
    ls_filter = ycl_it_hub_notif_query=>parse_filter(
      `( ID = 'Ab123456-1234-1234-1234-123456789abc' ) and ( readAt is null )` ).
    cl_abap_unit_assert=>assert_true( act = ls_filter-has_id ).
    cl_abap_unit_assert=>assert_true( act = ls_filter-unread_only ).
    cl_abap_unit_assert=>assert_equals( act = ls_filter-id exp = 'Ab123456-1234-1234-1234-123456789abc' ).
    ls_filter = ycl_it_hub_notif_query=>parse_filter(
      `ID = 'ab123456-1234-1234-1234-123456789abc'` ).
    cl_abap_unit_assert=>assert_false( act = ls_filter-unread_only ).
  ENDMETHOD.

  METHOD whitespace_filters.
    " Actual tabs/newlines plus repeated spaces must retain SQL token boundaries.
    DATA(ls_filter) = ycl_it_hub_notif_query=>parse_filter( |\t(\tREADAT\nIS  NULL\t)\n| ).
    cl_abap_unit_assert=>assert_true( act = ls_filter-unread_only ).
    ls_filter = ycl_it_hub_notif_query=>parse_filter(
      `(READAT IS NULL)and(ID='ab123456-1234-1234-1234-123456789abc')` ).
    cl_abap_unit_assert=>assert_true( act = ls_filter-unread_only ).
    cl_abap_unit_assert=>assert_true( act = ls_filter-has_id ).
    cl_abap_unit_assert=>assert_equals( act = ls_filter-id exp = 'ab123456-1234-1234-1234-123456789abc' ).
  ENDMETHOD.

  METHOD reject_unsafe_filters.
    DATA lt_bad TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    lt_bad = VALUE #( ( `READAT IS NULL OR ID = 'ab123456-1234-1234-1234-123456789abc'` )
      ( `RECIPIENTID = 'another-member'` ) ( `ID = ''` ) ( `READAT IS NOT NULL` ) ( `READATISNULL` )
      ( `(READAT IS NULL` ) ( `READAT IS NULL AND READAT IS NULL` )
      ( `ID = '(ab123456-1234-1234-1234-123456789abc)'` )
      ( `ID = 'ab123456-1234-1234-1234-123456789abc' AND 1 = 1` ) ).
    LOOP AT lt_bad INTO DATA(lv_bad).
      TRY.
          ycl_it_hub_notif_query=>parse_filter( lv_bad ).
          cl_abap_unit_assert=>fail( msg = 'Unsupported filter was accepted.' ).
        CATCH ycx_it_hub_authctx.
          CONTINUE.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD recipient_ownership.
    DATA(ls_actor) = VALUE ycl_it_hub_policy=>ty_actor( id = 'owner' active = abap_true admin = abap_true ).
    DATA(ls_row) = VALUE ytb_it_hub_notf( client = sy-mandt recipient_id = 'other'
      created_at = '20261011080000.0000000' ).
    DATA ls_filter TYPE ycl_it_hub_notif_query=>ty_filter.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    ls_row-recipient_id = 'owner'.
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    ls_actor-active = abap_false.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    ls_actor-active = abap_true.
    CLEAR ls_actor-id.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    ls_actor-id = 'owner'.
    ls_row-client = COND #( WHEN sy-mandt = '999' THEN '998' ELSE '999' ).
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
  ENDMETHOD.

  METHOD retention_and_unread.
    DATA(ls_actor) = VALUE ycl_it_hub_policy=>ty_actor( id = 'owner' active = abap_true ).
    DATA(ls_row) = VALUE ytb_it_hub_notf( client = sy-mandt id = 'selected' recipient_id = 'owner'
      created_at = '20261001000000.0000000' ).
    DATA(ls_filter) = VALUE ycl_it_hub_notif_query=>ty_filter( unread_only = abap_true ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    ls_row-read_at = '20261002000000.0000000'.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    CLEAR ls_row-read_at.
    ls_row-created_at = '20260930235959.9999999'.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
    ls_row-created_at = '20261001000000.0000000'.
    ls_filter-has_id = abap_true.
    ls_filter-id = 'another'.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_notif_query=>matches_row(
      is_row = ls_row is_actor = ls_actor iv_cutoff = '20261001000000.0000000' is_filter = ls_filter ) ).
  ENDMETHOD.

  METHOD paging_boundaries.
    DATA lt_rows TYPE ycl_it_hub_notif_query=>tt_inbox.
    lt_rows = VALUE #( ( id = '3' ) ( id = '2' ) ( id = '1' ) ).
    DATA(lt_page) = ycl_it_hub_notif_query=>page( it_rows = lt_rows iv_skip = 0 iv_top = 0 ).
    cl_abap_unit_assert=>assert_initial( act = lt_page ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_rows ) exp = 3 ).
    lt_page = ycl_it_hub_notif_query=>page( it_rows = lt_rows iv_skip = 1 iv_top = 1 ).
    cl_abap_unit_assert=>assert_equals( act = lt_page[ 1 ]-id exp = '2' ).
    lt_page = ycl_it_hub_notif_query=>page( it_rows = lt_rows iv_skip = 1
      iv_top = if_rap_query_paging=>page_size_unlimited ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_page ) exp = 2 ).
    lt_page = ycl_it_hub_notif_query=>page( it_rows = lt_rows iv_skip = 3 iv_top = 20 ).
    cl_abap_unit_assert=>assert_initial( act = lt_page ).
    lt_page = ycl_it_hub_notif_query=>page( it_rows = lt_rows iv_skip = 1
      iv_top = CONV int8( '9223372036854775807' ) ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_page ) exp = 2 ).
    TRY.
        ycl_it_hub_notif_query=>page( it_rows = lt_rows iv_skip = -1 iv_top = 20 ).
        cl_abap_unit_assert=>fail( msg = 'Negative offset was accepted.' ).
      CATCH ycx_it_hub_authctx.
        RETURN.
    ENDTRY.
  ENDMETHOD.

  METHOD requested_fields.
    DATA(lt_rows) = VALUE ycl_it_hub_notif_query=>tt_inbox(
      ( id = 'visible' title = 'Selected title' message = 'Not selected' ) ).
    DATA(lt_fields) = VALUE ycl_it_hub_notif_query=>tt_fields( ( `ID` ) ( `TITLE` ) ).
    DATA(lt_selected) = ycl_it_hub_notif_query=>project_fields( it_rows = lt_rows it_fields = lt_fields ).
    cl_abap_unit_assert=>assert_equals( act = lt_selected[ 1 ]-title exp = 'Selected title' ).
    cl_abap_unit_assert=>assert_initial( act = lt_selected[ 1 ]-message ).
    TRY.
        ycl_it_hub_notif_query=>project_fields( it_rows = VALUE #( ) it_fields = VALUE #( ( `CREATED_BY` ) ) ).
        cl_abap_unit_assert=>fail( msg = 'Unsupported projection was accepted.' ).
      CATCH ycx_it_hub_authctx.
        RETURN.
    ENDTRY.
  ENDMETHOD.
ENDCLASS.
