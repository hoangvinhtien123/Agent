CLASS lhc_Document DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Document RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Document RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Document RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE Document.

    METHODS precheck_create FOR PRECHECK
      IMPORTING entities FOR CREATE Document.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Document.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE Document.

    METHODS earlynumbering_cba_Attachments FOR NUMBERING
      IMPORTING entities FOR CREATE Document\Attachments.

    METHODS precheck_cba_Attachments FOR PRECHECK
      IMPORTING entities FOR CREATE Document\Attachments.

    METHODS Attach FOR MODIFY
      IMPORTING keys FOR ACTION Document~Attach RESULT result.

    METHODS Detach FOR MODIFY
      IMPORTING keys FOR ACTION Document~Detach RESULT result.

    METHODS MarkReady FOR MODIFY
      IMPORTING keys FOR ACTION Document~MarkReady RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Document~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Document~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Document~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Document~TouchGoverned.

    METHODS CleanupTarget FOR MODIFY IMPORTING keys FOR ACTION Document~CleanupTarget.
    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR Document~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR Document~validate_delete.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Document~TouchOnSave.
    METHODS CleanupOnSave FOR MODIFY IMPORTING keys FOR ACTION Document~CleanupOnSave.
ENDCLASS.

CLASS lhc_Document IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-MarkReady = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Attach = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Detach = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-Attachments = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-MarkReady = COND #( WHEN xsdbool( ls_db-source_type = 'FILE' AND ls_db-upload_status = 'PENDING' AND ( ls_actor-admin = abap_true OR ls_db-created_by_member_id = ls_actor-id ) AND ycl_it_hub_policy=>can( iv_entity =
'DOCUMENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Attach = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'ATTACH' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Detach = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'DETACH' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%assoc-Attachments = COND #( WHEN xsdbool( ls_db-upload_status = 'READY' AND ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true ) = abap_true
       THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF requested_authorizations-%update = if_abap_behv=>mk-on.
     <result>-%update = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%delete = if_abap_behv=>mk-on.
     <result>-%delete = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-MarkReady = if_abap_behv=>mk-on.
     <result>-%action-MarkReady = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'MARKREADY' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized )
.
     ENDIF.
     IF requested_authorizations-%action-Attach = if_abap_behv=>mk-on.
     <result>-%action-Attach = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'ATTACH' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Detach = if_abap_behv=>mk-on.
     <result>-%action-Detach = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'DETACH' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
      ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%create = if_abap_behv=>mk-on.
     result-%create = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%update = if_abap_behv=>mk-on.
     result-%update = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%delete = if_abap_behv=>mk-on.
     result-%delete = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-MarkReady = if_abap_behv=>mk-on.
     result-%action-MarkReady = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Attach = if_abap_behv=>mk-on.
     result-%action-Attach = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Detach = if_abap_behv=>mk-on.
     result-%action-Detach = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD earlynumbering_create.
    LOOP AT entities INTO DATA(ls_entity).
      DATA(lv_id) = ls_entity-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_DOCUMENT' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-document.
        APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-document.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_DOCUMENT' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'DOCUMENT' iv_id = lv_id is_control = ls_entity-%control ).
          APPEND VALUE #( %cid = ls_entity-%cid id = lv_id ) TO mapped-document.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-document.
          APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Document identifier.' ) ) TO reported-document.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_create.
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at
= createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_defaults=>apply( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      category TYPE abp_behv_flag,
      source_type TYPE abp_behv_flag,
      media_kind TYPE abp_behv_flag,
      upload_status TYPE abp_behv_flag,
      url TYPE abp_behv_flag,
      file_name TYPE abp_behv_flag,
      mime_type TYPE abp_behv_flag,
      content TYPE abp_behv_flag,
      byte_size TYPE abp_behv_flag,
      checksum_sha256 TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      title = ls_entity-%control-title
      description = ls_entity-%control-description
      category = ls_entity-%control-category
      source_type = ls_entity-%control-sourceType
      media_kind = ls_entity-%control-mediaKind
      upload_status = ls_entity-%control-uploadStatus
      url = ls_entity-%control-url
      file_name = ls_entity-%control-fileName
      mime_type = ls_entity-%control-mimeType
      content = ls_entity-%control-content
      byte_size = ls_entity-%control-byteSize
      checksum_sha256 = ls_entity-%control-checksumSha256
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'DOCUMENT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'DOCUMENT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-document.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-title = if_abap_behv=>mk-on. ls_db-title = ls_entity-title. ENDIF.
     IF ls_entity-%control-description = if_abap_behv=>mk-on. ls_db-description = ls_entity-description. ENDIF.
     IF ls_entity-%control-category = if_abap_behv=>mk-on. ls_db-category = ls_entity-category. ENDIF.
     IF ls_entity-%control-sourceType = if_abap_behv=>mk-on. ls_db-source_type = ls_entity-sourceType. ENDIF.
     IF ls_entity-%control-mediaKind = if_abap_behv=>mk-on. ls_db-media_kind = ls_entity-mediaKind. ENDIF.
     IF ls_entity-%control-uploadStatus = if_abap_behv=>mk-on. ls_db-upload_status = ls_entity-uploadStatus. ENDIF.
     IF ls_entity-%control-url = if_abap_behv=>mk-on. ls_db-url = ls_entity-url. ENDIF.
     IF ls_entity-%control-fileName = if_abap_behv=>mk-on. ls_db-file_name = ls_entity-fileName. ENDIF.
     IF ls_entity-%control-mimeType = if_abap_behv=>mk-on. ls_db-mime_type = ls_entity-mimeType. ENDIF.
     IF ls_entity-%control-content = if_abap_behv=>mk-on. ls_db-content = ls_entity-content. ENDIF.
     IF ls_entity-%control-byteSize = if_abap_behv=>mk-on. ls_db-byte_size = ls_entity-byteSize. ENDIF.
     IF ls_entity-%control-checksumSha256 = if_abap_behv=>mk-on. ls_db-checksum_sha256 = ls_entity-checksumSha256. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      category TYPE abp_behv_flag,
      source_type TYPE abp_behv_flag,
      media_kind TYPE abp_behv_flag,
      upload_status TYPE abp_behv_flag,
      url TYPE abp_behv_flag,
      file_name TYPE abp_behv_flag,
      mime_type TYPE abp_behv_flag,
      content TYPE abp_behv_flag,
      byte_size TYPE abp_behv_flag,
      checksum_sha256 TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      title = ls_entity-%control-title
      description = ls_entity-%control-description
      category = ls_entity-%control-category
      source_type = ls_entity-%control-sourceType
      media_kind = ls_entity-%control-mediaKind
      upload_status = ls_entity-%control-uploadStatus
      url = ls_entity-%control-url
      file_name = ls_entity-%control-fileName
      mime_type = ls_entity-%control-mimeType
      content = ls_entity-%control-content
      byte_size = ls_entity-%control-byteSize
      checksum_sha256 = ls_entity-%control-checksumSha256
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'DOCUMENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_docs.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256
created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'DOCUMENT' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'DOCUMENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_docs.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256
created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'DOCUMENT' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Attachments.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_DOCATTACH' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-docattach.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-docattach.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_DOCATTACH' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'DOCATTACH' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-docattach.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-docattach.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a DocAttach identifier.' ) ) TO reported-docattach.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Attachments.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-document_id = ls_source-id.
     DATA(lr_parent) = ycl_it_hub_tx=>get( iv_entity = 'DOCUMENT' iv_id = ls_source-id ).
     ls_db-project_id = ycl_it_hub_tx=>field( ir_row = lr_parent iv_name = 'PROJECT_ID' ).
     ycl_it_hub_defaults=>apply( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      document_id TYPE abp_behv_flag,
      target_type TYPE abp_behv_flag,
      target_id TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      document_id = ls_entity-%control-documentId
      target_type = ls_entity-%control-targetType
      target_id = ls_entity-%control-targetId
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'DOCATTACH' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control
      iv_defer_parent = xsdbool( lr_parent IS NOT BOUND AND ( ls_source-%cid_ref IS NOT INITIAL OR ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_DOCUMENT' iv_id = ls_source-id ) = abap_true ) ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     IF lr_parent IS BOUND. ycl_it_hub_tx=>guard( iv_entity = 'DOCATTACH' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-docattach.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-docattach.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD Attach.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'ATTACH' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'DOCUMENT' iv_operation = 'ATTACH' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'DOCUMENT' iv_id = ls_db-id iv_action = 'ATTACH' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'DOCUMENT' iv_id = ls_db-id ).

    DATA(lv_target_type) = to_upper( ls_key-%param-targetType ).
    ls_key-%param-targetId = ycl_it_hub_tx=>canonical_id( iv_entity = lv_target_type iv_id = ls_key-%param-targetId ).
    DATA(lr_target) = ycl_it_hub_policy=>target( iv_type = CONV #( lv_target_type ) iv_id = ls_key-%param-targetId ).
    DATA(ls_link) = VALUE ytb_it_hub_doatt( document_id = ls_db-id project_id = ls_db-project_id
      target_type = lv_target_type target_id = ls_key-%param-targetId ).
    ycl_it_hub_defaults=>apply( iv_entity = 'DOCATTACH' ir_row = REF #( ls_link ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    DATA(lv_link_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCATTACH' ir_row = REF #( ls_link ) ).
    IF lv_link_error IS NOT INITIAL OR ycl_it_hub_policy=>can( iv_entity = 'DOCATTACH' iv_operation = 'CREATE' ir_row = REF #( ls_link ) ) = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Attachment target/readiness/permission check failed.'.
    ENDIF.
    READ ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document BY \attachments
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_attachments).
    DATA lt_remove TYPE TABLE FOR DELETE YR_IT_HUB_DOCUMENT\\DocAttach.
    CLEAR lt_remove.
    LOOP AT lt_attachments INTO DATA(ls_attachment) WHERE targetType = lv_target_type AND targetId = ls_key-%param-targetId.
      APPEND VALUE #( id = ls_attachment-id ) TO lt_remove.
    ENDLOOP.

    IF lt_remove IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Document is already attached to this target.'. ENDIF.
    MODIFY ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document CREATE BY \attachments
      FIELDS ( targetType targetId ) WITH VALUE #( ( id = ls_db-id %target = VALUE #( (
        %cid = |ATTACH_{ ls_db-id }| targetType = lv_target_type targetId = ls_key-%param-targetId ) ) ) )
      FAILED DATA(ls_attachment_failed) REPORTED DATA(ls_attachment_reported).
    ls_messages = CORRESPONDING #( DEEP ls_attachment_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
    IF ls_attachment_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Attachment change failed; no part of the change may be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'DOCUMENT' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-document TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        CLEAR ls_final-content.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD Detach.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'DETACH' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'DOCUMENT' iv_operation = 'DETACH' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'DOCUMENT' iv_id = ls_db-id iv_action = 'DETACH' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'DOCUMENT' iv_id = ls_db-id ).

    DATA(lv_target_type) = to_upper( ls_key-%param-targetType ).
    ls_key-%param-targetId = ycl_it_hub_tx=>canonical_id( iv_entity = lv_target_type iv_id = ls_key-%param-targetId ).
    DATA(lr_target) = ycl_it_hub_policy=>target( iv_type = CONV #( lv_target_type ) iv_id = ls_key-%param-targetId ).
    DATA(ls_link) = VALUE ytb_it_hub_doatt( document_id = ls_db-id project_id = ls_db-project_id
      target_type = lv_target_type target_id = ls_key-%param-targetId ).
    DATA(lv_link_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCATTACH' ir_row = REF #( ls_link ) ).
    IF lv_link_error IS NOT INITIAL OR ycl_it_hub_policy=>can( iv_entity = 'DOCATTACH' iv_operation = 'CREATE' ir_row = REF #( ls_link ) ) = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Attachment target/readiness/permission check failed.'.
    ENDIF.
    READ ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document BY \attachments
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_attachments).
    DATA lt_remove TYPE TABLE FOR DELETE YR_IT_HUB_DOCUMENT\\DocAttach.
    CLEAR lt_remove.
    LOOP AT lt_attachments INTO DATA(ls_attachment) WHERE targetType = lv_target_type AND targetId = ls_key-%param-targetId.
      APPEND VALUE #( id = ls_attachment-id ) TO lt_remove.
    ENDLOOP.

    LOOP AT lt_remove INTO DATA(ls_remove).
      READ TABLE lt_attachments INTO DATA(ls_removed_attachment) WITH TABLE KEY entity COMPONENTS id = ls_remove-id.
      DATA ls_deleted_db TYPE ytb_it_hub_doatt.
    ls_deleted_db = CORRESPONDING #( ls_removed_attachment MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ycl_it_hub_tx=>stage_delete( iv_entity = 'DOCATTACH' ir_row = REF #( ls_deleted_db ) iv_actor = ls_actor-id ).
    ENDLOOP.
    MODIFY ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY DocAttach DELETE FROM lt_remove
      FAILED DATA(ls_attachment_failed) REPORTED DATA(ls_attachment_reported).
    ls_messages = CORRESPONDING #( DEEP ls_attachment_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
    IF ls_attachment_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Attachment change failed; no part of the change may be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    LOOP AT lt_remove INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'DOCATTACH' iv_id = ls_removed_key-id ).
    ENDLOOP.

    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'DOCUMENT' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-document TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        CLEAR ls_final-content.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD MarkReady.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'DOCUMENT' iv_operation = 'MARKREADY' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'DOCUMENT' iv_operation = 'MARKREADY' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'DOCUMENT' iv_id = ls_db-id iv_action = 'MARK_READY' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'DOCUMENT' iv_id = ls_db-id ).
     IF ls_db-source_type <> 'FILE' OR ls_db-upload_status <> 'PENDING' OR ( ls_actor-admin = abap_false AND ls_db-created_by_member_id <> ls_actor-id ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text =
'Only the uploader/admin may finalize a Pending FILE Document.'. ENDIF.
     ls_db = ycl_it_hub_media=>file( ls_db ).
     ls_db-upload_status = 'READY'.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-document TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        CLEAR ls_final-content.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'DOCUMENT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'DOCUMENT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCUMENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_DOCUMENT' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'DOCUMENT' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD CleanupTarget.

    DATA ls_messages LIKE reported.
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope(
        iv_name = |CLEANUP_{ ls_key-%param-targetType }| iv_id = ls_key-%param-targetId ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted target-deletion ticket is required.'.
      ENDIF.
      READ ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document BY \attachments
        ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_children).
      DATA lt_delete TYPE TABLE FOR DELETE YR_IT_HUB_DOCUMENT\\DocAttach.
      CLEAR lt_delete.
      LOOP AT lt_children INTO DATA(ls_child) WHERE targetType = ls_key-%param-targetType AND targetId = ls_key-%param-targetId.
        DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_child MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
        ycl_it_hub_tx=>stage_delete( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
        APPEND VALUE #( id = ls_child-id ) TO lt_delete.
      ENDLOOP.
      MODIFY ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY DocAttach DELETE FROM lt_delete
        FAILED DATA(ls_cleanup_failed) REPORTED DATA(ls_cleanup_reported).
      ls_messages = CORRESPONDING #( DEEP ls_cleanup_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_cleanup_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'Target attachment cleanup failed.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    LOOP AT lt_delete INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'DOCATTACH' iv_id = ls_removed_key-id ).
    ENDLOOP.

      ycl_it_hub_tx=>operation( iv_entity = 'DOCUMENT' iv_id = ls_key-id iv_action = 'DETACH' ).
      ycl_it_hub_bridge=>touch( iv_entity = 'DOCUMENT' iv_id = ls_key-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'DOCUMENT' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-document.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'DOCUMENT' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'DOCUMENT' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'DOCUMENT' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-document.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-document.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY Document ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_DOCUMENT' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_docs.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId source_type = sourceType media_kind = mediaKind upload_status = uploadStatus file_name = fileName mime_type = mimeType byte_size = byteSize checksum_sha256 = checksumSha256 created_at =
createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'DOCUMENT' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-category <> ls_db-category. ls_update-category = ls_db-category. ls_update-%control-category = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceType <> ls_db-source_type. ls_update-sourceType = ls_db-source_type. ls_update-%control-sourceType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mediaKind <> ls_db-media_kind. ls_update-mediaKind = ls_db-media_kind. ls_update-%control-mediaKind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-uploadStatus <> ls_db-upload_status. ls_update-uploadStatus = ls_db-upload_status. ls_update-%control-uploadStatus = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-url <> ls_db-url. ls_update-url = ls_db-url. ls_update-%control-url = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-fileName <> ls_db-file_name. ls_update-fileName = ls_db-file_name. ls_update-%control-fileName = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mimeType <> ls_db-mime_type. ls_update-mimeType = ls_db-mime_type. ls_update-%control-mimeType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-content <> ls_db-content. ls_update-content = ls_db-content. ls_update-%control-content = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-byteSize <> ls_db-byte_size. ls_update-byteSize = ls_db-byte_size. ls_update-%control-byteSize = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-checksumSha256 <> ls_db-checksum_sha256. ls_update-checksumSha256 = ls_db-checksum_sha256. ls_update-%control-checksumSha256 = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY Document UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-document.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD CleanupOnSave.

    DATA ls_messages LIKE reported.
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope(
        iv_name = |CLEANUP_{ ls_key-%param-targetType }| iv_id = ls_key-%param-targetId ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted target-deletion ticket is required.'.
      ENDIF.
      READ ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document BY \attachments
        ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_children).
      DATA lt_delete TYPE TABLE FOR DELETE YR_IT_HUB_DOCUMENT\\DocAttach.
      CLEAR lt_delete.
      LOOP AT lt_children INTO DATA(ls_child) WHERE targetType = ls_key-%param-targetType AND targetId = ls_key-%param-targetId.
        DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_child MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
        ycl_it_hub_tx=>stage_delete( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
        APPEND VALUE #( id = ls_child-id ) TO lt_delete.
      ENDLOOP.
      MODIFY ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY DocAttach DELETE FROM lt_delete
        FAILED DATA(ls_cleanup_failed) REPORTED DATA(ls_cleanup_reported).
      ls_messages = CORRESPONDING #( DEEP ls_cleanup_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_cleanup_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'Target attachment cleanup failed.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    LOOP AT lt_delete INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'DOCATTACH' iv_id = ls_removed_key-id ).
    ENDLOOP.

      ycl_it_hub_tx=>operation( iv_entity = 'DOCUMENT' iv_id = ls_key-id iv_action = 'DETACH' ).
      ycl_it_hub_bridge=>touch( iv_entity = 'DOCUMENT' iv_id = ls_key-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-document.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-document.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_DocAttach DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR DocAttach RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE DocAttach.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE DocAttach.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR DocAttach~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR DocAttach~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR DocAttach~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR DocAttach~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR DocAttach~validate_delete.
ENDCLASS.

CLASS lhc_DocAttach IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY DocAttach ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN abap_false = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'DOCATTACH' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY DocAttach ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-documentId = if_abap_behv=>mk-on. ls_db-document_id = ls_entity-documentId. ENDIF.
     IF ls_entity-%control-targetType = if_abap_behv=>mk-on. ls_db-target_type = ls_entity-targetType. ENDIF.
     IF ls_entity-%control-targetId = if_abap_behv=>mk-on. ls_db-target_id = ls_entity-targetId. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      document_id TYPE abp_behv_flag,
      target_type TYPE abp_behv_flag,
      target_id TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      document_id = ls_entity-%control-documentId
      target_type = ls_entity-%control-targetType
      target_id = ls_entity-%control-targetId
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'DOCATTACH' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_doatt.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'DOCATTACH' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Link records are immutable; use the replacement action or create/delete.'.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-docattach.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-docattach.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY DocAttach ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'DOCATTACH' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_doatt.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'DOCATTACH' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-docattach.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-docattach.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY DocAttach ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'DOCATTACH' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-document_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT\\DocAttach.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-documentId <> ls_db-document_id. ls_update-documentId = ls_db-document_id. ls_update-%control-documentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-targetType <> ls_db-target_type. ls_update-targetType = ls_db-target_type. ls_update-%control-targetType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-targetId <> ls_db-target_id. ls_update-targetId = ls_db-target_id. ls_update-%control-targetId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY DocAttach UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-docattach.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY DocAttach ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'DOCATTACH' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_document IN LOCAL MODE ENTITY Document
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-document_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     IF ycl_it_hub_tx=>before( iv_entity = 'DOCATTACH' iv_id = ls_db-id ) IS NOT BOUND.
       ycl_it_hub_tx=>guard( iv_entity = 'DOCATTACH' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_DOCUMENT\\DocAttach.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-documentId <> ls_db-document_id. ls_update-documentId = ls_db-document_id. ls_update-%control-documentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-targetType <> ls_db-target_type. ls_update-targetType = ls_db-target_type. ls_update-%control-targetType = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-targetId <> ls_db-target_id. ls_update-targetId = ls_db-target_id. ls_update-%control-targetId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE ENTITY DocAttach UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-document TO reported-document.
    APPEND LINES OF ls_messages-docattach TO reported-docattach.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-docattach.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_DOCUMENT IN LOCAL MODE
      ENTITY DocAttach ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_doatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId document_id = documentId target_type = targetType target_id = targetId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'DOCATTACH' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-docattach.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-docattach.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'DOCATTACH' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-docattach.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'DOCATTACH' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'DOCATTACH' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'DOCATTACH' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-docattach.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-docattach.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_YR_IT_HUB_DOCUMENT DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_YR_IT_HUB_DOCUMENT IMPLEMENTATION.
  METHOD save_modified.
    ycl_it_hub_tx=>save( iv_owner = 'DOCUMENT' is_create = create is_update = update is_delete = delete ).
  ENDMETHOD.

  METHOD cleanup.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD cleanup_finalize.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

ENDCLASS.
