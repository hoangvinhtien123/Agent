@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Milestone'
define view entity YI_IT_HUB_MILESTONE
  as select from ytb_it_hub_mile
  association to parent YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
  association [0..1] to YR_IT_HUB_MEMBER as _Owner on $projection.ownerId = _Owner.id
{
  key id as id,
  project_id as projectId,
  title as title,
  due_date as dueDate,
  status as status,
  owner_id as ownerId,
  completed_at as completedAt,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Project,
  _Owner
}
