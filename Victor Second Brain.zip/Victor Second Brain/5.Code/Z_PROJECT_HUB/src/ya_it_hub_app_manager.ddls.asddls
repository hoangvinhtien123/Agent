@EndUserText.label: 'Project Hub - App manager flag'
define abstract entity YA_IT_HUB_APP_MANAGER {
  enabled : abap_boolean;
}
