@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Member'
define root view entity YR_IT_HUB_MEMBER
  as select from ytb_it_hub_memb
  composition [0..*] of YI_IT_HUB_MEMBERSKILL as skills
  composition [0..*] of YI_IT_HUB_MEMBERIDENT as _Identity
{
  key id as id,
  name as name,
  email as email,
  email_normalized as emailNormalized,
  title as title,
  team as team,
  initials as initials,
  active as active,
  is_app_manager as isAppManager,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  skills,
  _Identity
}
