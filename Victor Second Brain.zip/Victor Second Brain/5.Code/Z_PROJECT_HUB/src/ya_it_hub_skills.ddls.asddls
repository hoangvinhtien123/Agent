@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_SKILLS
{
  skillsJson : abap.string(0);
}
