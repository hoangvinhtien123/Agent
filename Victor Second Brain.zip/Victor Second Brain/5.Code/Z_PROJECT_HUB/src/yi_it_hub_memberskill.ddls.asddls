@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - MemberSkill'
define view entity YI_IT_HUB_MEMBERSKILL
  as select from ytb_it_hub_mskil
  association to parent YR_IT_HUB_MEMBER as _Member on $projection.memberId = _Member.id
  association [0..1] to YR_IT_HUB_SKILL as _Catalog on $projection.skillId = _Catalog.id
{
  key id as id,
  member_id as memberId,
  skill_id as skillId,
  proficiency as proficiency,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Catalog.name as name,
  _Catalog.active as catalogActive,
  _Member,
  _Catalog
}
