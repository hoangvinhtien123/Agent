@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_ATTENDEES
{
  attendeeIdsJson : abap.string(0);
}
