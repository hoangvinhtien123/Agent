@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Skill'
define root view entity YR_IT_HUB_SKILL
  as select from ytb_it_hub_skill
{
  key id as id,
  name as name,
  name_normalized as nameNormalized,
  description as description,
  active as active,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken
}
