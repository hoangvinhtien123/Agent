CLASS ltc_authctx DEFINITION DEFERRED.
CLASS ltc_startup DEFINITION DEFERRED.
CLASS ycl_it_hub_authctx DEFINITION LOCAL FRIENDS ltc_authctx ltc_startup.
CLASS ltc_authctx DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PRIVATE SECTION.
    METHODS empty_maps_and_arrays FOR TESTING RAISING ycx_it_hub.
    METHODS nested_maps_and_escaped_text FOR TESTING RAISING ycx_it_hub.
    METHODS stored_grants_are_preserved FOR TESTING.
    METHODS admin_without_appointment FOR TESTING.
    METHODS denied_is_not_conditional FOR TESTING.
    METHODS malformed_map_fails FOR TESTING.
ENDCLASS.
CLASS ltc_authctx IMPLEMENTATION.
  METHOD empty_maps_and_arrays.
    DATA(ls_context) = VALUE ycl_it_hub_authctx=>ty_context(
      schema_version = 5 member_id = '11111111-1111-4111-8111-111111111111' ).
    DATA(lv_json) = ycl_it_hub_authctx=>serialize( ls_context ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"projects":{}' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"records":{}' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"taskActions":{}' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"managerCandidates":{}' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"teamAccess":{}' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"memberPermissions":{}' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"roleCollections":[]' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"admin":false' ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"schemaVersion":5' ) ).
  ENDMETHOD.
  METHOD nested_maps_and_escaped_text.
    DATA(ls_context) = VALUE ycl_it_hub_authctx=>ty_context(
      schema_version = 5 member_id = '11111111-1111-4111-8111-111111111111' ).
    DATA(lv_project) = CONV string( '22222222-2222-4222-8222-222222222222' ).
    DATA(lv_member) = ls_context-member_id.
    DATA ls_summary TYPE ycl_it_hub_authctx=>ty_member_summary.
    DATA(lv_reason) = 'QAS "connectivity"'
      && cl_abap_char_utilities=>newline && 'SAP S/4HANA – test'.
    APPEND VALUE #( action = 'read' allowed = abap_true conditional = abap_false
      reason = lv_reason ) TO ls_summary-decisions.
    DATA lt_summaries TYPE ycl_it_hub_authctx=>ty_member_summaries.
    INSERT VALUE #( key = lv_member value = ls_summary ) INTO TABLE lt_summaries.
    INSERT VALUE #( key = lv_project value = lt_summaries ) INTO TABLE ls_context-member_permissions.
    INSERT VALUE #( key = lv_project value = VALUE #( read = abap_true ) ) INTO TABLE ls_context-projects.
    INSERT VALUE #( key = '33333333-3333-4333-8333-333333333333' value = VALUE #( ) )
      INTO TABLE ls_context-task_actions.
    DATA(lv_json) = ycl_it_hub_authctx=>serialize( ls_context ).
    DATA(lv_expected_prefix) = '"memberPermissions":{"'
      && lv_project && '":{"' && lv_member && '":{'.
    cl_abap_unit_assert=>assert_true(
      act = xsdbool( lv_json CS lv_expected_prefix ) ).
    cl_abap_unit_assert=>assert_true( xsdbool( lv_json CS '"taskActions":{"33333333-3333-4333-8333-333333333333":[]}' ) ).
    cl_abap_unit_assert=>assert_false( xsdbool( lv_json CS '"value":' ) ).

    " Round-trip a summary's typed booleans, array and escaped English text.
    DATA(lv_summary_json) = /ui2/cl_json=>serialize( data = ls_summary compress = abap_false
      pretty_name = /ui2/cl_json=>pretty_mode-camel_case ).
    DATA ls_roundtrip TYPE ycl_it_hub_authctx=>ty_member_summary.
    /ui2/cl_json=>deserialize( EXPORTING json = lv_summary_json
      pretty_name = /ui2/cl_json=>pretty_mode-camel_case CHANGING data = ls_roundtrip ).
    cl_abap_unit_assert=>assert_equals( act = ls_roundtrip exp = ls_summary ).
  ENDMETHOD.
  METHOD stored_grants_are_preserved.
    DATA(lo_builder) = NEW ycl_it_hub_authctx( ).
    DATA(ls_project) = VALUE ytb_it_hub_proj(
      id = '22222222-2222-4222-8222-222222222222' phase = 'BUILD' ).
    DATA(lv_member) = CONV sysuuid_c36( '11111111-1111-4111-8111-111111111111' ).
    APPEND VALUE #( project_id = ls_project-id member_id = lv_member active = abap_true
      is_project_manager = abap_true edit_project = abap_true override_workflow = abap_false )
      TO lo_builder->mt_memberships.
    DATA(ls_access) = VALUE ycl_it_hub_policy=>ty_member_access(
      actor = VALUE #( id = lv_member active = abap_true admin = abap_true )
      permissions = VALUE #( read = abap_true contribute = abap_true edit_project = abap_true
        manage_members = abap_true assign_work = abap_true manage_schedule = abap_true
        delete_work_items = abap_true override_workflow = abap_true manage_permissions = abap_true ) ).
    DATA(ls_summary) = lo_builder->member_summary(
      is_project = ls_project iv_member = lv_member is_access = ls_access ).
    cl_abap_unit_assert=>assert_true( ls_summary-is_project_manager ).
    cl_abap_unit_assert=>assert_true( ls_summary-configured_permissions-edit_project ).
    cl_abap_unit_assert=>assert_false( ls_summary-configured_permissions-override_workflow ).
    cl_abap_unit_assert=>assert_equals( act = lines( ls_summary-decisions ) exp = 13 ).
    cl_abap_unit_assert=>assert_true( ls_summary-decisions[ action = 'overrideWorkflow' ]-allowed ).
  ENDMETHOD.
  METHOD admin_without_appointment.
    DATA(lo_builder) = NEW ycl_it_hub_authctx( ).
    DATA(ls_project) = VALUE ytb_it_hub_proj(
      id = '22222222-2222-4222-8222-222222222222' phase = 'BUILD' ).
    DATA(lv_member) = CONV sysuuid_c36( '11111111-1111-4111-8111-111111111111' ).
    DATA(ls_access) = VALUE ycl_it_hub_policy=>ty_member_access(
      actor = VALUE #( id = lv_member active = abap_true admin = abap_true )
      permissions = VALUE #( read = abap_true contribute = abap_true override_workflow = abap_true ) ).
    DATA(ls_summary) = lo_builder->member_summary(
      is_project = ls_project iv_member = lv_member is_access = ls_access ).
    cl_abap_unit_assert=>assert_false( ls_summary-is_project_manager ).
    cl_abap_unit_assert=>assert_initial( ls_summary-configured_permissions ).
    cl_abap_unit_assert=>assert_true( ls_summary-decisions[ action = 'appointManagers' ]-allowed ).
  ENDMETHOD.
  METHOD denied_is_not_conditional.
    DATA lt_decisions TYPE ycl_it_hub_authctx=>ty_decisions.
    ycl_it_hub_authctx=>add_decision( EXPORTING iv_action = 'managePermissions'
      iv_allowed = abap_false iv_conditional = abap_true CHANGING ct_decisions = lt_decisions ).
    cl_abap_unit_assert=>assert_false( lt_decisions[ 1 ]-allowed ).
    cl_abap_unit_assert=>assert_false( lt_decisions[ 1 ]-conditional ).
  ENDMETHOD.
  METHOD malformed_map_fails.
    DATA lt_invalid TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    APPEND CONV string( 'not a key/value row' ) TO lt_invalid.
    TRY.
        DATA(lv_json) = ycl_it_hub_authctx=>json_object( lt_invalid ).
        cl_abap_unit_assert=>fail( 'Malformed permission maps must be rejected.' ).
      CATCH ycx_it_hub.
        RETURN.
    ENDTRY.
  ENDMETHOD.
ENDCLASS.



CLASS ltc_startup DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PRIVATE SECTION.
    METHODS unmapped_admin FOR TESTING RAISING ycx_it_hub.
    METHODS mapped_user FOR TESTING RAISING ycx_it_hub.
    METHODS ordinary_user FOR TESTING RAISING ycx_it_hub.
    METHODS inactive_mapping FOR TESTING RAISING ycx_it_hub.
    METHODS broken_mapping FOR TESTING RAISING ycx_it_hub.
    METHODS bad_profile FOR TESTING RAISING ycx_it_hub.
    METHODS profile_conflict FOR TESTING RAISING ycx_it_hub.
    METHODS no_grant FOR TESTING.
ENDCLASS.
CLASS ltc_startup IMPLEMENTATION.
  METHOD unmapped_admin.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true eligible = abap_true
      profile = VALUE #( abap_user = 'DEMOADMIN' name = 'Demo Admin' email = 'demo@example.test' ) ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-state exp = 'SETUP_REQUIRED' ).
    cl_abap_unit_assert=>assert_true( ls_result-can_bootstrap ).
    cl_abap_unit_assert=>assert_initial( ls_result-member_id ).
  ENDMETHOD.
  METHOD mapped_user.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true mapping_count = 1 identity_active = abap_true
      member_exists = abap_true member_active = abap_true member_id = '00000000-0000-0000-0000-000000000001' ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-state exp = 'READY' ).
    cl_abap_unit_assert=>assert_false( ls_result-can_bootstrap ).
  ENDMETHOD.
  METHOD ordinary_user.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'MEMBER_NOT_PROVISIONED' ).
  ENDMETHOD.
  METHOD inactive_mapping.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true mapping_count = 1 ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'IDENTITY_INACTIVE' ).
    ls_result = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true mapping_count = 1
      identity_active = abap_true member_exists = abap_true member_id = '00000000-0000-0000-0000-000000000001' ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'MEMBER_INACTIVE' ).
  ENDMETHOD.
  METHOD broken_mapping.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true mapping_count = 1 identity_active = abap_true ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'IDENTITY_BROKEN' ).
    ls_result = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true mapping_count = 2 ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'IDENTITY_BROKEN' ).
  ENDMETHOD.
  METHOD bad_profile.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true eligible = abap_true ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'SAP_PROFILE_INCOMPLETE' ).
    ls_result = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'SAP_ACCOUNT_INELIGIBLE' ).
  ENDMETHOD.
  METHOD profile_conflict.
    DATA(ls_result) = ycl_it_hub_authctx=>classify_startup( VALUE #( has_grant = abap_true admin = abap_true eligible = abap_true conflict = abap_true
      profile = VALUE #( abap_user = 'DEMOADMIN' name = 'Demo Admin' email = 'demo@example.test' ) ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_result-reason_code exp = 'PROFILE_CONFLICT' ).
  ENDMETHOD.
  METHOD no_grant.
    TRY.
        ycl_it_hub_authctx=>classify_startup( VALUE #( ) ).
        cl_abap_unit_assert=>fail( 'No-grant callers must be denied.' ).
      CATCH ycx_it_hub.
        cl_abap_unit_assert=>assert_true( abap_true ).
    ENDTRY.
  ENDMETHOD.
ENDCLASS.
