@EndUserText.label: 'Project Hub - Current User Startup State'
@ObjectModel.query.implementedBy: 'ABAP:YCL_IT_HUB_AUTHCTX_QP'
 define custom entity YCE_IT_HUB_STARTUP
 {
   key id      : abap.char(7);
   contextJson : abap.string(0);
 }
