@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - TaskDep'
define view entity YC_IT_HUB_TASKDEP
  as projection on YI_IT_HUB_TASKDEP
{
  key id,
  projectId,
  taskId,
  dependsOnTaskId,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Task : redirected to parent YC_IT_HUB_TASK,
  _Project : redirected to YC_IT_HUB_PROJECT,
  _DependsOn : redirected to YC_IT_HUB_TASK
}
