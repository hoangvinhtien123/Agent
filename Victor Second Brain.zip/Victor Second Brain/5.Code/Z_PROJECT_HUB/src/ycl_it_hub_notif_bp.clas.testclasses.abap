CLASS ltc_inbox DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PRIVATE SECTION.
    METHODS owner_and_retention FOR TESTING.
    METHODS read_is_idempotent FOR TESTING.
    METHODS mark_all_cutoff FOR TESTING.
ENDCLASS.
CLASS ltc_inbox IMPLEMENTATION.
  METHOD owner_and_retention.
    DATA(ls_actor) = VALUE ycl_it_hub_policy=>ty_actor( id = 'AABBCCDD-1111-4222-8333-AABBCCDDEEFF' active = abap_true admin = abap_true ).
    DATA(ls_row) = VALUE ytb_it_hub_notf( client = sy-mandt recipient_id = to_lower( ls_actor-id ) created_at = '20261012000000.0000000' ).
    cl_abap_unit_assert=>assert_true( lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = '20261012120000.0000000' iv_project_read = abap_true ) ).
    cl_abap_unit_assert=>assert_false( lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = '20261012120000.0000000' iv_project_read = abap_false ) ).
    ls_row-recipient_id = '00000000-0000-0000-0000-000000000099'.
    cl_abap_unit_assert=>assert_false( lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = '20261012120000.0000000' iv_project_read = abap_true ) ).
    ls_row-recipient_id = ls_actor-id.
    ls_row-created_at = '20260101000000.0000000'.
    cl_abap_unit_assert=>assert_false( lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = '20261012120000.0000000' iv_project_read = abap_true ) ).
    ls_actor-id = ''.
    cl_abap_unit_assert=>assert_false( lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = '20261012120000.0000000' iv_project_read = abap_true ) ).
  ENDMETHOD.
  METHOD read_is_idempotent.
    DATA(ls_row) = VALUE ytb_it_hub_notf( client = sy-mandt id = '00000000-0000-0000-0000-000000000001' ).
    DATA(ls_read) = lcl_inbox=>stamp( is_row = ls_row iv_now = '20261012120000.0000001' ).
    cl_abap_unit_assert=>assert_equals( act = ls_read-read_at exp = CONV timestampl( '20261012120000.0000001' ) ).
    cl_abap_unit_assert=>assert_equals( act = lcl_inbox=>stamp( is_row = ls_read iv_now = '20261012130000.0000000' ) exp = ls_read ).
    cl_abap_unit_assert=>assert_initial( ls_row-read_at ).
  ENDMETHOD.
  METHOD mark_all_cutoff.
    DATA(ls_actor) = VALUE ycl_it_hub_policy=>ty_actor( id = '00000000-0000-0000-0000-000000000001' active = abap_true ).
    DATA(ls_row) = VALUE ytb_it_hub_notf( client = sy-mandt recipient_id = ls_actor-id created_at = '20261012120000.0000001' ).
    cl_abap_unit_assert=>assert_false( lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = '20261012120000.0000000' iv_project_read = abap_true ) ).
  ENDMETHOD.
ENDCLASS.
