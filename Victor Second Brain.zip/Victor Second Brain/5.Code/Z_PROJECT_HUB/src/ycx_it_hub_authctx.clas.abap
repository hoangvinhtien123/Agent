CLASS ycx_it_hub_authctx DEFINITION
    PUBLIC
    INHERITING FROM cx_rap_query_provider
    FINAL
    CREATE PUBLIC.

    PUBLIC SECTION.
      CONSTANTS:
        gc_access_denied TYPE string
          VALUE 'An active mapped Project Hub member is required.',
        gc_unsupported_query TYPE string
          VALUE 'Authorization query options are not supported.',
        gc_context_failed TYPE string
          VALUE 'Unable to build the authorization context.'.

      DATA message_text TYPE string READ-ONLY.

      METHODS constructor
        IMPORTING
          iv_text  TYPE string OPTIONAL
          previous LIKE previous OPTIONAL.

      METHODS if_message~get_text REDEFINITION.
    PROTECTED SECTION.
    PRIVATE SECTION.
  ENDCLASS.

  CLASS ycx_it_hub_authctx IMPLEMENTATION.
    METHOD constructor ##ADT_SUPPRESS_GENERATION.
      super->constructor( previous = previous ).

      me->message_text = COND #(
        WHEN iv_text IS INITIAL THEN gc_context_failed
        ELSE iv_text ).
    ENDMETHOD.

    METHOD if_message~get_text.
      result = me->message_text.
    ENDMETHOD.
  ENDCLASS.
