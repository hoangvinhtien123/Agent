CLASS ycl_it_hub_authctx DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CLASS-METHODS get_json
      RETURNING VALUE(rv_json) TYPE string
      RAISING ycx_it_hub.
    CLASS-METHODS get_startup_json RETURNING VALUE(rv_json) TYPE string RAISING ycx_it_hub.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_startup_profile,
             abap_user TYPE string, nt_id TYPE string, name TYPE string, email TYPE string,
           END OF ty_startup_profile,
           BEGIN OF ty_startup_context,
             state TYPE string, reason_code TYPE string, can_bootstrap TYPE abap_bool,
             member_id TYPE sysuuid_c36, current_user TYPE ty_startup_profile,
           END OF ty_startup_context.
    TYPES: BEGIN OF ty_startup_facts,
             has_grant TYPE abap_bool, admin TYPE abap_bool,
             mapping_count TYPE i, identity_active TYPE abap_bool,
             member_exists TYPE abap_bool, member_active TYPE abap_bool,
             member_id TYPE sysuuid_c36, eligible TYPE abap_bool,
             conflict TYPE abap_bool, profile TYPE ty_startup_profile,
           END OF ty_startup_facts.
    CLASS-METHODS startup_context RETURNING VALUE(rs_context) TYPE ty_startup_context RAISING ycx_it_hub.
    CLASS-METHODS startup_account RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS startup_profile RETURNING VALUE(rs_profile) TYPE ty_startup_profile RAISING ycx_it_hub.
    CLASS-METHODS classify_startup IMPORTING is_facts TYPE ty_startup_facts
      RETURNING VALUE(rs_context) TYPE ty_startup_context RAISING ycx_it_hub.
    TYPES ty_strings TYPE STANDARD TABLE OF string WITH EMPTY KEY.

    TYPES:
      BEGIN OF ty_global,
        admin            TYPE abap_bool,
        create_project   TYPE abap_bool,
        manage_directory TYPE abap_bool,
        manage_skills    TYPE abap_bool,
        edit_own_skills   TYPE abap_bool,
      END OF ty_global,
      BEGIN OF ty_manager_permissions,
        edit_project      TYPE abap_bool,
        manage_members    TYPE abap_bool,
        assign_work       TYPE abap_bool,
        manage_schedule   TYPE abap_bool,
        delete_work_items TYPE abap_bool,
        override_workflow TYPE abap_bool,
        manage_permissions TYPE abap_bool,
      END OF ty_manager_permissions,
      BEGIN OF ty_project_permissions,
        read              TYPE abap_bool,
        manage            TYPE abap_bool,
        contribute        TYPE abap_bool,
        plan              TYPE abap_bool,
        create_task       TYPE abap_bool,
        create_event      TYPE abap_bool,
        edit_project      TYPE abap_bool,
        manage_members    TYPE abap_bool,
        assign_work       TYPE abap_bool,
        manage_schedule   TYPE abap_bool,
        delete_work_items TYPE abap_bool,
        override_workflow TYPE abap_bool,
        manage_permissions TYPE abap_bool,
        restore_project   TYPE abap_bool,
      END OF ty_project_permissions,
      BEGIN OF ty_project_entry,
        key   TYPE string,
        value TYPE ty_project_permissions,
      END OF ty_project_entry,
      ty_projects TYPE SORTED TABLE OF ty_project_entry WITH UNIQUE KEY key,
      BEGIN OF ty_record_permissions,
        edit   TYPE abap_bool,
        remove TYPE abap_bool,
      END OF ty_record_permissions,
      BEGIN OF ty_record_entry,
        key   TYPE string,
        value TYPE ty_record_permissions,
      END OF ty_record_entry,
      ty_records TYPE SORTED TABLE OF ty_record_entry WITH UNIQUE KEY key,
      BEGIN OF ty_task_action,
        status           TYPE string,
        allowed          TYPE abap_bool,
        reason           TYPE string,
        override_allowed TYPE abap_bool,
        requires_reason  TYPE abap_bool,
      END OF ty_task_action,
      ty_task_action_list TYPE STANDARD TABLE OF ty_task_action WITH EMPTY KEY,
      BEGIN OF ty_task_action_entry,
        key   TYPE string,
        value TYPE ty_task_action_list,
      END OF ty_task_action_entry,
      ty_task_actions TYPE SORTED TABLE OF ty_task_action_entry WITH UNIQUE KEY key,
      BEGIN OF ty_candidate_entry,
        key   TYPE string,
        value TYPE ty_strings,
      END OF ty_candidate_entry,
      ty_manager_candidates TYPE SORTED TABLE OF ty_candidate_entry WITH UNIQUE KEY key,
      BEGIN OF ty_access_entry,
        key   TYPE string,
        value TYPE string,
      END OF ty_access_entry,
      ty_member_access TYPE SORTED TABLE OF ty_access_entry WITH UNIQUE KEY key,
      BEGIN OF ty_team_entry,
        key   TYPE string,
        value TYPE ty_member_access,
      END OF ty_team_entry,
      ty_team_access TYPE SORTED TABLE OF ty_team_entry WITH UNIQUE KEY key,
      BEGIN OF ty_decision,
        action      TYPE string,
        allowed     TYPE abap_bool,
        conditional TYPE abap_bool,
        reason      TYPE string,
      END OF ty_decision,
      ty_decisions TYPE STANDARD TABLE OF ty_decision WITH EMPTY KEY,
      BEGIN OF ty_member_summary,
        is_project_manager     TYPE abap_bool,
        configured_permissions TYPE ty_manager_permissions,
        decisions              TYPE ty_decisions,
      END OF ty_member_summary,
      BEGIN OF ty_member_summary_entry,
        key   TYPE string,
        value TYPE ty_member_summary,
      END OF ty_member_summary_entry,
      ty_member_summaries TYPE SORTED TABLE OF ty_member_summary_entry WITH UNIQUE KEY key,
      BEGIN OF ty_project_summary_entry,
        key   TYPE string,
        value TYPE ty_member_summaries,
      END OF ty_project_summary_entry,
      ty_member_permissions TYPE SORTED TABLE OF ty_project_summary_entry WITH UNIQUE KEY key,
      BEGIN OF ty_context,
        schema_version     TYPE i,
        member_id          TYPE string,
        role_collections   TYPE ty_strings,
        global             TYPE ty_global,
        projects           TYPE ty_projects,
        records            TYPE ty_records,
        task_actions       TYPE ty_task_actions,
        manager_candidates TYPE ty_manager_candidates,
        team_access        TYPE ty_team_access,
        member_permissions TYPE ty_member_permissions,
      END OF ty_context.

    DATA ms_actor TYPE ycl_it_hub_policy=>ty_actor.
    DATA ms_context TYPE ty_context.
    DATA mt_memberships TYPE STANDARD TABLE OF ytb_it_hub_mship WITH EMPTY KEY.

    METHODS build RETURNING VALUE(rs_context) TYPE ty_context RAISING ycx_it_hub.
    METHODS build_projects RAISING ycx_it_hub.
    METHODS build_records RAISING ycx_it_hub.
    METHODS add_records IMPORTING iv_entity TYPE string iv_prefix TYPE string RAISING ycx_it_hub.
    METHODS visible IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      iv_depth TYPE i DEFAULT 0 RETURNING VALUE(rv_visible) TYPE abap_bool.
    METHODS record_flags IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      RETURNING VALUE(rs_flags) TYPE ty_record_permissions.
    METHODS membership IMPORTING iv_project TYPE sysuuid_c36 iv_member TYPE sysuuid_c36
      RETURNING VALUE(rs_membership) TYPE ytb_it_hub_mship.
    METHODS project_flags IMPORTING is_project TYPE ytb_it_hub_proj
      is_access TYPE ycl_it_hub_policy=>ty_member_access
      RETURNING VALUE(rs_flags) TYPE ty_project_permissions.
    METHODS member_summary IMPORTING is_project TYPE ytb_it_hub_proj iv_member TYPE sysuuid_c36
      is_access TYPE ycl_it_hub_policy=>ty_member_access
      RETURNING VALUE(rs_summary) TYPE ty_member_summary.
    CLASS-METHODS add_decision IMPORTING iv_action TYPE string iv_allowed TYPE abap_bool
      iv_conditional TYPE abap_bool DEFAULT abap_false CHANGING ct_decisions TYPE ty_decisions.
    CLASS-METHODS access_label IMPORTING is_flags TYPE ty_project_permissions
      RETURNING VALUE(rv_label) TYPE string.
    CLASS-METHODS serialize IMPORTING is_context TYPE ty_context
      RETURNING VALUE(rv_json) TYPE string RAISING ycx_it_hub.
    CLASS-METHODS json_object IMPORTING it_entries TYPE ANY TABLE
      iv_nested TYPE abap_bool DEFAULT abap_false RETURNING VALUE(rv_json) TYPE string RAISING ycx_it_hub.
ENDCLASS.

CLASS ycl_it_hub_authctx IMPLEMENTATION.
  METHOD startup_account.
    SELECT SINGLE bname FROM usr02 WHERE bname = @sy-uname AND ustyp = 'A' AND uflag = 0
      AND ( gltgv = '00000000' OR gltgv <= @sy-datum )
      AND ( gltgb = '00000000' OR gltgb >= @sy-datum ) INTO @DATA(lv_name).
    rv_yes = xsdbool( sy-subrc = 0 ).
  ENDMETHOD.

  METHOD startup_profile.
    " Standard ABAP, current SAP account only. Never accept a browser username.
    " Verify the installed BAPI signature and approved corporate source in ADT.
    DATA ls_address TYPE bapiaddr3.
    DATA lt_return TYPE STANDARD TABLE OF bapiret2 WITH EMPTY KEY.
    CALL FUNCTION 'BAPI_USER_GET_DETAIL'
      EXPORTING username = sy-uname cache_results = space
      IMPORTING address = ls_address
      TABLES return = lt_return.
    LOOP AT lt_return INTO DATA(ls_return) WHERE type = 'E' OR type = 'A' OR type = 'X'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'SAP user profile lookup failed. Ask your SAP administrator to check the directory API.'.
    ENDLOOP.
    rs_profile-abap_user = sy-uname.
    rs_profile-name = condense( CONV string( ls_address-fullname ) ).
    IF rs_profile-name IS INITIAL.
      rs_profile-name = condense( |{ ls_address-firstname } { ls_address-lastname }| ).
    ENDIF.
    rs_profile-email = condense( CONV string( ls_address-e_mail ) ).
    " NT ID is optional until the approved corporate mapping is connected.
    " An ABAP username must never be advertised as the corporate NT ID.
    CLEAR rs_profile-nt_id.
  ENDMETHOD.

  METHOD classify_startup.
    IF is_facts-has_grant = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Your SAP user has no trusted Project Hub access grant.'.
    ENDIF.
    rs_context-state = 'BLOCKED'.
    IF is_facts-mapping_count > 1.
      rs_context-reason_code = 'IDENTITY_BROKEN'.
    ELSEIF is_facts-mapping_count = 1.
      IF is_facts-identity_active = abap_false.
        rs_context-reason_code = 'IDENTITY_INACTIVE'.
      ELSEIF is_facts-member_exists = abap_false OR is_facts-member_id IS INITIAL.
        rs_context-reason_code = 'IDENTITY_BROKEN'.
      ELSEIF is_facts-member_active = abap_false.
        rs_context-reason_code = 'MEMBER_INACTIVE'.
      ELSE.
        rs_context-state = 'READY'. rs_context-reason_code = 'ACTIVE_MEMBER'.
        rs_context-member_id = is_facts-member_id.
      ENDIF.
    ELSEIF is_facts-admin = abap_false.
      rs_context-reason_code = 'MEMBER_NOT_PROVISIONED'.
    ELSEIF is_facts-eligible = abap_false.
      rs_context-reason_code = 'SAP_ACCOUNT_INELIGIBLE'.
    ELSEIF is_facts-profile-abap_user IS INITIAL OR is_facts-profile-name IS INITIAL
      OR strlen( is_facts-profile-name ) > 150 OR strlen( is_facts-profile-email ) > 254
      OR NOT matches( val = is_facts-profile-email pcre = '\A[^\s@]+@[^\s@]+\.[^\s@]+\z' ).
      rs_context-reason_code = 'SAP_PROFILE_INCOMPLETE'.
    ELSEIF is_facts-conflict = abap_true.
      rs_context-reason_code = 'PROFILE_CONFLICT'.
    ELSE.
      rs_context-state = 'SETUP_REQUIRED'. rs_context-reason_code = 'ADMIN_MEMBER_MISSING'.
      rs_context-can_bootstrap = abap_true. rs_context-current_user = is_facts-profile.
    ENDIF.
  ENDMETHOD.

  METHOD startup_context.
    DATA ls_facts TYPE ty_startup_facts.
    DATA(ls_grants) = ycl_it_hub_policy=>startup_grants( ).
    ls_facts-admin = ls_grants-admin. ls_facts-has_grant = ls_grants-active.
    IF ls_facts-has_grant = abap_false.
      rs_context = classify_startup( ls_facts ). RETURN.
    ENDIF.
    LOOP AT ycl_it_hub_tx=>rows( 'MEMBERIDENT' ) INTO DATA(lr_identity).
      IF ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ABAP_USER' ) <> sy-uname. CONTINUE. ENDIF.
      ls_facts-mapping_count += 1.
      ls_facts-identity_active = xsdbool( ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'ACTIVE' ) = abap_true ).
      ls_facts-member_id = ycl_it_hub_tx=>field( ir_row = lr_identity iv_name = 'MEMBER_ID' ).
      DATA(lr_member) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = ls_facts-member_id ).
      ls_facts-member_exists = xsdbool( lr_member IS BOUND ).
      IF lr_member IS BOUND.
        " Return the persisted member key so clients can address Members(<id>).
        ls_facts-member_id = ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'ID' ).
      ENDIF.
      ls_facts-member_active = xsdbool( ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'ACTIVE' ) = abap_true ).
    ENDLOOP.
    IF ls_facts-mapping_count = 0 AND ls_facts-admin = abap_true.
      ls_facts-eligible = startup_account( ).
      IF ls_facts-eligible = abap_true.
        ls_facts-profile = startup_profile( ).
        LOOP AT ycl_it_hub_tx=>rows( 'MEMBER' ) INTO lr_member.
          IF to_lower( ycl_it_hub_policy=>normalize( ycl_it_hub_tx=>field( ir_row = lr_member iv_name = 'EMAIL' ) ) ) = to_lower( ycl_it_hub_policy=>normalize( ls_facts-profile-email ) ).
            ls_facts-conflict = abap_true. EXIT.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.
    rs_context = classify_startup( ls_facts ).
  ENDMETHOD.

  METHOD get_startup_json.
    DATA(lv_owns_read) = xsdbool( ycl_it_hub_tx=>read_active( ) = abap_false ).
    IF lv_owns_read = abap_true. ycl_it_hub_tx=>begin_read( ). ENDIF.
    TRY.
        DATA(ls_context) = startup_context( ).
        DATA(lv_member) = CONV string( 'null' ).
        DATA(lv_user) = CONV string( 'null' ).
        IF ls_context-state = 'READY'.
          lv_member = /ui2/cl_json=>serialize( data = CONV string( ls_context-member_id ) ).
        ELSEIF ls_context-state = 'SETUP_REQUIRED'.
          lv_user = /ui2/cl_json=>serialize( data = ls_context-current_user pretty_name = /ui2/cl_json=>pretty_mode-camel_case ).
        ENDIF.
        rv_json = '{"schemaVersion":1,"state":' && /ui2/cl_json=>serialize( data = ls_context-state )
          && ',"reasonCode":' && /ui2/cl_json=>serialize( data = ls_context-reason_code )
          && ',"canBootstrap":' && COND string( WHEN ls_context-can_bootstrap = abap_true THEN 'true' ELSE 'false' )
          && ',"memberId":' && lv_member && ',"currentUser":' && lv_user && '}'.
      CLEANUP.
        IF lv_owns_read = abap_true. ycl_it_hub_tx=>end_read( ). ENDIF.
    ENDTRY.
    IF lv_owns_read = abap_true. ycl_it_hub_tx=>end_read( ). ENDIF.
  ENDMETHOD.

  METHOD get_json.
    " A provider can own the same read scope for key and count-only requests.
    " Direct callers get an isolated scope here, with cleanup on every exit.
    DATA(lv_owns_read) = xsdbool( ycl_it_hub_tx=>read_active( ) = abap_false ).
    IF lv_owns_read = abap_true.
      ycl_it_hub_tx=>begin_read( ).
    ENDIF.
    TRY.
        DATA(lo_builder) = NEW ycl_it_hub_authctx( ).
        DATA(ls_context) = lo_builder->build( ).
        rv_json = serialize( ls_context ).
      CLEANUP.
        IF lv_owns_read = abap_true.
          ycl_it_hub_tx=>end_read( ).
        ENDIF.
    ENDTRY.
    IF lv_owns_read = abap_true.
      ycl_it_hub_tx=>end_read( ).
    ENDIF.
  ENDMETHOD.

  METHOD build.
    ms_actor = ycl_it_hub_policy=>actor( ).
    IF ms_actor-active = abap_false OR ms_actor-id IS INITIAL.
      RAISE EXCEPTION TYPE ycx_it_hub
        EXPORTING iv_text = 'An active mapped Project Hub member is required.'.
    ENDIF.
    ms_context-schema_version = 5.
    ms_context-member_id = ms_actor-id.
    IF ms_actor-admin = abap_true.
      APPEND CONV string( 'HubAdmin' ) TO ms_context-role_collections.
    ELSE.
      APPEND CONV string( 'HubUser' ) TO ms_context-role_collections.
    ENDIF.
    DATA(lv_directory) = xsdbool(
      ms_actor-admin = abap_true OR ms_actor-manager = abap_true ).
    ms_context-global = VALUE #(
      admin = ms_actor-admin create_project = lv_directory
      manage_directory = lv_directory manage_skills = lv_directory
      edit_own_skills = abap_true ).

    FIELD-SYMBOLS <membership> TYPE ytb_it_hub_mship.
    LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_membership).
      ASSIGN lr_membership->* TO <membership>.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ycx_it_hub
          EXPORTING iv_text = 'Membership permission data has an unexpected type.'.
      ENDIF.
      APPEND <membership> TO mt_memberships.
    ENDLOOP.
    build_projects( ).
    build_records( ).
    rs_context = ms_context.
  ENDMETHOD.

  METHOD membership.
    " The persisted unique index includes inactive memberships.
    READ TABLE mt_memberships INTO rs_membership
      WITH KEY project_id = iv_project member_id = iv_member.
  ENDMETHOD.

  METHOD project_flags.
    DATA(ls_rights) = is_access-permissions.
    IF is_access-actor-active = abap_false OR ls_rights-read = abap_false.
      RETURN.
    ENDIF.
    DATA(ls_membership) = membership(
      iv_project = is_project-id iv_member = is_access-actor-id ).
    DATA(lv_appointed) = xsdbool(
      ls_membership-active = abap_true AND ls_membership-is_project_manager = abap_true ).
    DATA(lv_create) = xsdbool(
      is_project-archived_at IS INITIAL AND is_project-phase <> 'CLOSED' ).
    rs_flags = VALUE #(
      read = ls_rights-read
      manage = xsdbool( is_access-actor-admin = abap_true OR lv_appointed = abap_true )
      contribute = ls_rights-contribute
      plan = ls_rights-manage_schedule
      create_task = xsdbool( lv_create = abap_true AND ls_rights-contribute = abap_true )
      create_event = xsdbool( lv_create = abap_true AND ls_rights-manage_schedule = abap_true )
      edit_project = ls_rights-edit_project
      manage_members = ls_rights-manage_members
      assign_work = ls_rights-assign_work
      manage_schedule = ls_rights-manage_schedule
      delete_work_items = ls_rights-delete_work_items
      override_workflow = ls_rights-override_workflow
      manage_permissions = ls_rights-manage_permissions
      restore_project = xsdbool( is_project-archived_at IS NOT INITIAL
        AND ( is_access-actor-admin = abap_true
          OR ( lv_appointed = abap_true AND ls_membership-edit_project = abap_true ) ) ) ).
  ENDMETHOD.

  METHOD add_decision.
    DATA(ls_decision) = VALUE ty_decision(
      action = iv_action allowed = iv_allowed
      conditional = xsdbool( iv_allowed = abap_true AND iv_conditional = abap_true ) ).
    IF iv_allowed = abap_true.
      IF iv_conditional = abap_true.
        ls_decision-reason = 'Assignment, record and workflow conditions still apply.'.
      ELSE.
        ls_decision-reason = 'Granted by current application and project permissions.'.
      ENDIF.
    ELSE.
      ls_decision-reason = 'This action is not granted or the project state prevents it.'.
    ENDIF.
    APPEND ls_decision TO ct_decisions.
  ENDMETHOD.

  METHOD member_summary.
    DATA(ls_membership) = membership(
      iv_project = is_project-id iv_member = iv_member ).
    rs_summary-is_project_manager = xsdbool(
      ls_membership-active = abap_true AND ls_membership-is_project_manager = abap_true ).
    " Configured grants are stored appointment flags, never the inspecting Admin's flags.
    IF rs_summary-is_project_manager = abap_true.
      rs_summary-configured_permissions = CORRESPONDING #( ls_membership ).
    ENDIF.
    DATA(ls_flags) = project_flags( is_project = is_project is_access = is_access ).
    DATA(lv_retest) = xsdbool( ls_flags-override_workflow = abap_true
      OR ( ls_flags-contribute = abap_true
        AND ycl_it_hub_policy=>member_in_project(
          iv_project = is_project-id iv_member = iv_member iv_role = 'TESTER' ) = abap_true ) ).
    add_decision( EXPORTING iv_action = 'read' iv_allowed = ls_flags-read
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'contribute' iv_allowed = ls_flags-contribute
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'editAssignedWork'
      iv_allowed = xsdbool( ls_flags-contribute = abap_true OR ls_flags-assign_work = abap_true )
      iv_conditional = abap_true CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'editProject' iv_allowed = ls_flags-edit_project
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'manageMembers' iv_allowed = ls_flags-manage_members
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'assignWork' iv_allowed = ls_flags-assign_work
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'manageSchedule' iv_allowed = ls_flags-manage_schedule
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'deleteWorkItems' iv_allowed = ls_flags-delete_work_items
      iv_conditional = abap_true CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'retestDefects' iv_allowed = lv_retest
      iv_conditional = abap_true CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'overrideWorkflow' iv_allowed = ls_flags-override_workflow
      iv_conditional = abap_true CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'appointManagers'
      iv_allowed = xsdbool( is_access-actor-admin = abap_true AND ls_flags-contribute = abap_true )
      CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'managePermissions' iv_allowed = ls_flags-manage_permissions
      iv_conditional = abap_true CHANGING ct_decisions = rs_summary-decisions ).
    add_decision( EXPORTING iv_action = 'restoreProject' iv_allowed = ls_flags-restore_project
      CHANGING ct_decisions = rs_summary-decisions ).
  ENDMETHOD.

  METHOD access_label.
    IF is_flags-read = abap_false.
      rv_label = 'No access'.
    ELSEIF is_flags-manage = abap_true.
      rv_label = 'Project manager'.
    ELSE.
      rv_label = 'Contributor'.
    ENDIF.
  ENDMETHOD.

  METHOD build_projects.
    FIELD-SYMBOLS <project> TYPE ytb_it_hub_proj.
    LOOP AT ycl_it_hub_tx=>rows( 'PROJECT' ) INTO DATA(lr_project).
      ASSIGN lr_project->* TO <project>.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ycx_it_hub
          EXPORTING iv_text = 'Project permission data has an unexpected type.'.
      ENDIF.
      DATA(ls_access) = VALUE ycl_it_hub_policy=>ty_member_access(
        actor = ms_actor permissions = ycl_it_hub_policy=>permissions( <project>-id ) ).
      IF ls_access-permissions-read = abap_false.
        CONTINUE.
      ENDIF.
      DATA(lv_project) = CONV string( <project>-id ).
      DATA(ls_flags) = project_flags( is_project = <project> is_access = ls_access ).
      INSERT VALUE #( key = lv_project value = ls_flags ) INTO TABLE ms_context-projects.

      DATA lt_summaries TYPE ty_member_summaries.
      DATA lt_access TYPE ty_member_access.
      DATA lt_candidates TYPE ty_strings.
      CLEAR: lt_summaries, lt_access, lt_candidates.
      INSERT VALUE #( key = CONV string( ms_actor-id )
        value = member_summary( is_project = <project> iv_member = ms_actor-id is_access = ls_access ) )
        INTO TABLE lt_summaries.

      DATA(lv_inspect) = xsdbool( ms_actor-admin = abap_true
        OR ls_flags-manage_members = abap_true OR ls_flags-manage_permissions = abap_true ).
      IF lv_inspect = abap_true.
        INSERT VALUE #( key = CONV string( ms_actor-id ) value = access_label( ls_flags ) )
          INTO TABLE lt_access.
        LOOP AT mt_memberships INTO DATA(ls_membership) WHERE project_id = <project>-id.
          IF ls_membership-member_id IS INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub
              EXPORTING iv_text = 'A team membership has no mapped member.'.
          ENDIF.
          " Each target is resolved by shared policy after checking inspection authority.
          DATA(ls_target) = ycl_it_hub_policy=>member_access(
            iv_project = <project>-id iv_member = ls_membership-member_id ).
          DATA(ls_target_flags) = project_flags( is_project = <project> is_access = ls_target ).
          IF ls_membership-member_id <> ms_actor-id.
            INSERT VALUE #( key = CONV string( ls_membership-member_id )
              value = member_summary( is_project = <project>
                iv_member = ls_membership-member_id is_access = ls_target ) )
              INTO TABLE lt_summaries.
            INSERT VALUE #( key = CONV string( ls_membership-member_id )
              value = access_label( ls_target_flags ) ) INTO TABLE lt_access.
          ENDIF.
          IF ms_actor-admin = abap_true AND <project>-archived_at IS INITIAL
            AND ls_membership-active = abap_true
            AND ycl_it_hub_policy=>eligible( ls_membership-member_id ) = abap_true.
            APPEND CONV string( ls_membership-member_id ) TO lt_candidates.
          ENDIF.
        ENDLOOP.
        INSERT VALUE #( key = lv_project value = lt_access ) INTO TABLE ms_context-team_access.
      ENDIF.
      INSERT VALUE #( key = lv_project value = lt_summaries ) INTO TABLE ms_context-member_permissions.
      IF ms_actor-admin = abap_true AND <project>-archived_at IS INITIAL.
        SORT lt_candidates.
        DELETE ADJACENT DUPLICATES FROM lt_candidates.
        INSERT VALUE #( key = lv_project value = lt_candidates ) INTO TABLE ms_context-manager_candidates.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD visible.
    IF ir_row IS NOT BOUND OR iv_depth > 20.
      RETURN.
    ENDIF.
    DATA(lv_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ID' ) ).
    IF iv_entity = 'SKILL'.
      rv_visible = abap_true.
      RETURN.
    ENDIF.
    IF iv_entity = 'MEMBER'.
      IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) = abap_true
        OR lv_id = ms_actor-id OR ms_context-global-manage_directory = abap_true.
        rv_visible = abap_true.
        RETURN.
      ENDIF.
      LOOP AT mt_memberships INTO DATA(ls_membership) WHERE member_id = lv_id.
        IF line_exists( ms_context-projects[ key = CONV string( ls_membership-project_id ) ] ).
          rv_visible = abap_true.
          RETURN.
        ENDIF.
      ENDLOOP.
      RETURN.
    ENDIF.
    DATA(lv_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ) ).
    IF iv_entity = 'PROJECT'.
      lv_project = lv_id.
    ENDIF.
    IF NOT line_exists( ms_context-projects[ key = CONV string( lv_project ) ] ).
      RETURN.
    ENDIF.
    IF iv_entity = 'DOCUMENT'.
      DATA(lv_upload) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'UPLOAD_STATUS' ).
      rv_visible = xsdbool( lv_upload = 'READY'
        OR ( lv_upload = 'PENDING' AND ( ms_actor-admin = abap_true
          OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'CREATED_BY_MEMBER_ID' ) = ms_actor-id ) ) ).
      RETURN.
    ENDIF.
    IF iv_entity = 'COMMENT'.
      DATA(lv_target_type) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ).
      DATA(lr_target) = ycl_it_hub_policy=>target( iv_type = lv_target_type
        iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ) ).
      IF lr_target IS NOT BOUND.
        RETURN.
      ENDIF.
      DATA(lv_target_project) = CONV sysuuid_c36(
        ycl_it_hub_tx=>field( ir_row = lr_target iv_name = 'PROJECT_ID' ) ).
      IF lv_target_type = 'PROJECT'.
        lv_target_project = ycl_it_hub_tx=>field( ir_row = lr_target iv_name = 'ID' ).
      ENDIF.
      IF lv_target_project <> lv_project.
        RETURN.
      ENDIF.
      rv_visible = visible( iv_entity = lv_target_type ir_row = lr_target iv_depth = iv_depth + 1 ).
      RETURN.
    ENDIF.
    rv_visible = abap_true.
  ENDMETHOD.

  METHOD record_flags.
    rs_flags-edit = ycl_it_hub_policy=>can(
      iv_entity = iv_entity iv_operation = 'UPDATE' ir_row = ir_row ).
    CASE iv_entity.
      WHEN 'PROJECT' OR 'MEMBER' OR 'SKILL'.
        " These expose Archive/Restore or Deactivate, not standard DELETE.
        rs_flags-remove = abap_false.
      WHEN 'MEMBERSHIP'.
        rs_flags-remove = xsdbool( rs_flags-edit = abap_true
          AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACTIVE' ) = abap_true
          AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'IS_PROJECT_MANAGER' ) <> abap_true ).
      WHEN 'TASK' OR 'WORKSTREAM' OR 'MILESTONE' OR 'EVENT' OR 'RISK' OR 'COMMENT' OR 'DOCUMENT'.
        rs_flags-remove = ycl_it_hub_policy=>can_remove( iv_entity = iv_entity ir_row = ir_row ).
      WHEN OTHERS.
        CLEAR rs_flags.
    ENDCASE.
    IF iv_entity = 'TASK'.
      DATA(lv_parent) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PARENT_ID' ) ).
      IF lv_parent IS NOT INITIAL AND ycl_it_hub_tx=>field(
        ir_row = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = lv_parent ) iv_name = 'STATUS' ) = 'DONE'.
        CLEAR rs_flags.
      ENDIF.
    ENDIF.
  ENDMETHOD.

  METHOD add_records.
    LOOP AT ycl_it_hub_tx=>rows( iv_entity ) INTO DATA(lr_row).
      IF visible( iv_entity = iv_entity ir_row = lr_row ) = abap_false.
        CONTINUE.
      ENDIF.
      DATA(lv_id) = ycl_it_hub_tx=>field( ir_row = lr_row iv_name = 'ID' ).
      INSERT VALUE #( key = |{ iv_prefix }:{ lv_id }|
        value = record_flags( iv_entity = iv_entity ir_row = lr_row ) ) INTO TABLE ms_context-records.
      IF iv_entity = 'TASK'.
        FIELD-SYMBOLS <task> TYPE ytb_it_hub_task.
        ASSIGN lr_row->* TO <task>.
        IF sy-subrc <> 0.
          RAISE EXCEPTION TYPE ycx_it_hub
            EXPORTING iv_text = 'Task permission data has an unexpected type.'.
        ENDIF.
        INSERT VALUE #( key = lv_id value = CORRESPONDING ty_task_action_list(
          ycl_it_hub_policy=>transition_options( <task> ) ) ) INTO TABLE ms_context-task_actions.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD build_records.
    add_records( iv_entity = 'PROJECT' iv_prefix = 'projects' ).
    add_records( iv_entity = 'MEMBER' iv_prefix = 'members' ).
    add_records( iv_entity = 'SKILL' iv_prefix = 'skillCatalog' ).
    add_records( iv_entity = 'MEMBERSHIP' iv_prefix = 'memberships' ).
    add_records( iv_entity = 'TASK' iv_prefix = 'tasks' ).
    add_records( iv_entity = 'WORKSTREAM' iv_prefix = 'workstreams' ).
    add_records( iv_entity = 'MILESTONE' iv_prefix = 'milestones' ).
    add_records( iv_entity = 'EVENT' iv_prefix = 'events' ).
    add_records( iv_entity = 'RISK' iv_prefix = 'risks' ).
    add_records( iv_entity = 'COMMENT' iv_prefix = 'comments' ).
    add_records( iv_entity = 'DOCUMENT' iv_prefix = 'documents' ).

    " History is append-only and is not a TX entity. Select only readable scopes.
    DATA lt_projects TYPE RANGE OF sysuuid_c36.
    LOOP AT ms_context-projects INTO DATA(ls_project).
      APPEND VALUE #( sign = 'I' option = 'EQ' low = CONV sysuuid_c36( ls_project-key ) ) TO lt_projects.
    ENDLOOP.
    IF lt_projects IS NOT INITIAL.
      SELECT id FROM ytb_it_hub_histo
        WHERE scope_type = 'PROJECT' AND project_id IN @lt_projects
        INTO TABLE @DATA(lt_history).
      LOOP AT lt_history INTO DATA(ls_history).
        INSERT VALUE #( key = |history:{ ls_history-id }| value = VALUE #( ) ) INTO TABLE ms_context-records.
      ENDLOOP.
    ENDIF.
    IF ms_context-global-manage_directory = abap_true.
      SELECT id FROM ytb_it_hub_histo WHERE scope_type = 'GLOBAL'
        INTO TABLE @DATA(lt_global_history).
      LOOP AT lt_global_history INTO DATA(ls_global_history).
        INSERT VALUE #( key = |history:{ ls_global_history-id }| value = VALUE #( ) ) INTO TABLE ms_context-records.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.

  METHOD json_object.
    " Escape every key and serialize typed values. Empty maps ALWAYS become {}.
    " Nested maps use this same encoder; standard action/UUID tables remain [].
    rv_json = '{'.
    DATA lv_separator TYPE string.
    LOOP AT it_entries ASSIGNING FIELD-SYMBOL(<entry>).
      IF cl_abap_typedescr=>describe_by_data( <entry> )->kind <> cl_abap_typedescr=>kind_struct.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A permission map row is not a structure.'.
      ENDIF.
      ASSIGN COMPONENT 'KEY' OF STRUCTURE <entry> TO FIELD-SYMBOL(<key>).
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A permission map has no key component.'.
      ENDIF.
      ASSIGN COMPONENT 'VALUE' OF STRUCTURE <entry> TO FIELD-SYMBOL(<value>).
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A permission map has no value component.'.
      ENDIF.
      DATA(lv_key) = /ui2/cl_json=>serialize( data = <key> compress = abap_false ).
      DATA lv_value TYPE string.
      IF iv_nested = abap_true.
        IF cl_abap_typedescr=>describe_by_data( <value> )->kind <> cl_abap_typedescr=>kind_table.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A nested permission map is not a table.'.
        ENDIF.
        FIELD-SYMBOLS <nested> TYPE ANY TABLE.
        ASSIGN <value> TO <nested>.
        IF sy-subrc <> 0.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A nested permission map is not a table.'.
        ENDIF.
        lv_value = json_object( <nested> ).
      ELSE.
        lv_value = /ui2/cl_json=>serialize( data = <value> compress = abap_false
          pretty_name = /ui2/cl_json=>pretty_mode-camel_case ).
      ENDIF.
      rv_json = rv_json && lv_separator && lv_key && ':' && lv_value.
      lv_separator = ','.
    ENDLOOP.
    rv_json = rv_json && '}'.
  ENDMETHOD.

  METHOD serialize.
    " Only fixed punctuation/property names are concatenated. Dynamic values are escaped.
    rv_json = '{'
      && '"schemaVersion":' && /ui2/cl_json=>serialize( is_context-schema_version )
      && ',"memberId":' && /ui2/cl_json=>serialize( is_context-member_id )
      && ',"roleCollections":' && /ui2/cl_json=>serialize( data = is_context-role_collections compress = abap_false )
      && ',"global":' && /ui2/cl_json=>serialize( data = is_context-global compress = abap_false
        pretty_name = /ui2/cl_json=>pretty_mode-camel_case )
      && ',"projects":' && json_object( is_context-projects )
      && ',"records":' && json_object( is_context-records )
      && ',"taskActions":' && json_object( is_context-task_actions )
      && ',"managerCandidates":' && json_object( is_context-manager_candidates )
      && ',"teamAccess":' && json_object( it_entries = is_context-team_access iv_nested = abap_true )
      && ',"memberPermissions":' && json_object( it_entries = is_context-member_permissions iv_nested = abap_true )
      && '}'.
  ENDMETHOD.
ENDCLASS.
