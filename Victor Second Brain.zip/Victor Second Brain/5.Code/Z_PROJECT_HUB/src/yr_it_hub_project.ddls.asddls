@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Project'
define root view entity YR_IT_HUB_PROJECT
  as select from ytb_it_hub_proj
  composition [0..*] of YI_IT_HUB_WORKSTREAM as _Workstream
  composition [0..*] of YI_IT_HUB_MEMBERSHIP as _Membership
  composition [0..*] of YI_IT_HUB_MILESTONE as _Milestone
  composition [0..*] of YI_IT_HUB_RISK as _Risk
  association [0..*] to YR_IT_HUB_TASK as _Task on $projection.id = _Task.projectId
  association [0..*] to YR_IT_HUB_EVENT as _Event on $projection.id = _Event.projectId
  association [0..*] to YR_IT_HUB_DOCUMENT as _Document on $projection.id = _Document.projectId
  association [0..*] to YR_IT_HUB_COMMENT as _Comment on $projection.id = _Comment.projectId
{
  key id as id,
  code as code,
  name as name,
  description as description,
  scope as scope,
  phase as phase,
  health as health,
  start_date as startDate,
  end_date as endDate,
  accent as accent,
  archived_at as archivedAt,
  archived_by as archivedByTechnical,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Workstream,
  _Membership,
  _Milestone,
  _Risk,
  _Task,
  _Event,
  _Document,
  _Comment
}
