CLASS ycl_it_hub_notif_mail DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    " Internal dispatcher adapter. Inputs come from validated outbox/configuration.
    " The dispatcher must atomically persist its submission reference and commit.
    CLASS-METHODS submit
      IMPORTING
        iv_sender TYPE string
        iv_recipient TYPE string
        iv_title TYPE string
        iv_message TYPE string
        iv_task_id TYPE string
        iv_app_url TYPE string
        iv_delivery_id TYPE string
        iv_html TYPE abap_bool DEFAULT abap_true
      RETURNING VALUE(ro_monitor) TYPE REF TO if_bcs_mail_status_monitor
      RAISING cx_bcs_mail.
ENDCLASS.

CLASS ycl_it_hub_notif_mail IMPLEMENTATION.
  METHOD submit.
    " Configure an HTTPS application base URL without a trailing slash.
    " Task identifiers are trusted C36 UUIDs, not client-supplied URL fragments.
    DATA(lv_url) = |{ iv_app_url }/tasks?taskId={ iv_task_id }|.
    DATA(lo_mail) = cl_bcs_mail_message=>create_instance( ).
    lo_mail->set_sender( CONV #( iv_sender ) ).
    lo_mail->add_recipient( iv_address = CONV #( iv_recipient ) ).
    lo_mail->set_subject( CONV #( |Project Hub: { iv_title }| ) ).
    lo_mail->set_additional_mime_headers( VALUE #(
      ( field_name = 'X-ProjectHub-Delivery-ID' field_body = iv_delivery_id ) ) ).
    IF iv_html = abap_true.
      DATA(lv_title) = escape( val = iv_title format = cl_abap_format=>e_html_text ).
      DATA(lv_message) = escape( val = iv_message format = cl_abap_format=>e_html_text ).
      DATA(lv_link) = escape( val = lv_url format = cl_abap_format=>e_html_attr ).
      DATA(lv_html) = |<h1>{ lv_title }</h1><p>{ lv_message }</p>| &&
        |<p><a href="{ lv_link }">Open work item</a></p>|.
      lo_mail->set_main( cl_bcs_mail_textpart=>create_text_html( lv_html ) ).
    ELSE.
      DATA(lv_plain) = |{ iv_title }\n\n{ iv_message }\n\nOpen work item: { lv_url }|.
      lo_mail->set_main( cl_bcs_mail_textpart=>create_text_plain( lv_plain ) ).
    ENDIF.
    " No network call or explicit commit in a RAP interaction handler.
    " SEND_ASYNC requires a permitted save context. No COMMIT WORK here.
    ro_monitor = lo_mail->send_async( ).
  ENDMETHOD.
ENDCLASS.

