@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub admin projection'
define view entity YC_IT_HUB_MEMBERIDENT_ADM
  as projection on YI_IT_HUB_MEMBERIDENT
{
  key id,
  memberId,
  abapUser,
  active,
  createdAt,
  updatedAt,
  localLastChangedAt,
  createdBy,
  updatedBy,
  _Member : redirected to parent YC_IT_HUB_MEMBER_ADM
}
