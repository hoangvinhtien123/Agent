CLASS ycl_it_hub_bridge DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CLASS-METHODS touch IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36 RAISING ycx_it_hub.
    CLASS-METHODS parents IMPORTING iv_entity TYPE string ir_row TYPE REF TO data RAISING ycx_it_hub.
    CLASS-METHODS prepare_delete IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36 RAISING ycx_it_hub.
    CLASS-METHODS cleanup_target IMPORTING iv_type TYPE string iv_id TYPE sysuuid_c36 RAISING ycx_it_hub.
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.
CLASS ycl_it_hub_bridge IMPLEMENTATION.
  METHOD touch.
    IF iv_id IS INITIAL. RETURN. ENDIF.
    DATA(lv_token) = ycl_it_hub_tx=>touch( iv_entity = iv_entity iv_id = iv_id ).
    CASE iv_entity.
      WHEN 'PROJECT'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_PROJECT ENTITY Project EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_project_save_failed).
        IF ls_project_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_PROJECT ENTITY Project EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_project_failed).
        IF ls_project_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'MEMBER'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_MEMBER ENTITY Member EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_member_save_failed).
        IF ls_member_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_MEMBER ENTITY Member EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_member_failed).
        IF ls_member_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'SKILL'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_SKILL ENTITY Skill EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_skill_save_failed).
        IF ls_skill_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_SKILL ENTITY Skill EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_skill_failed).
        IF ls_skill_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'TASK'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_TASK ENTITY Task EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_task_save_failed).
        IF ls_task_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_TASK ENTITY Task EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_task_failed).
        IF ls_task_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'EVENT'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_EVENT ENTITY Event EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_event_save_failed).
        IF ls_event_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_EVENT ENTITY Event EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_event_failed).
        IF ls_event_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'COMMENT'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_COMMENT ENTITY Comment EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_comment_save_failed).
        IF ls_comment_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_COMMENT ENTITY Comment EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_comment_failed).
        IF ls_comment_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'DOCUMENT'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT ENTITY Document EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_document_save_failed).
        IF ls_document_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_DOCUMENT ENTITY Document EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_document_failed).
        IF ls_document_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
      WHEN 'MEMBERSHIP'.
        IF ycl_it_hub_tx=>in_save( ) = abap_true.
        MODIFY ENTITIES OF YR_IT_HUB_PROJECT ENTITY Membership EXECUTE TouchOnSave
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_membership_save_failed).
        IF ls_membership_save_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ELSE.
        MODIFY ENTITIES OF YR_IT_HUB_PROJECT ENTITY Membership EXECUTE TouchGoverned
          FROM VALUE #( ( id = iv_id ) ) FAILED DATA(ls_membership_failed).
        IF ls_membership_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'A governing root could not be touched.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
        ENDIF.
    ENDCASE.
  ENDMETHOD.
  METHOD parents.
    DATA lv_parent_type TYPE string.
    DATA lv_parent TYPE sysuuid_c36.
    CASE iv_entity.
      WHEN 'WORKSTREAM' OR 'MEMBERSHIP' OR 'MILESTONE' OR 'RISK' OR 'EVENT' OR 'COMMENT' OR 'DOCUMENT'.
        lv_parent_type = 'PROJECT'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ).
      WHEN 'ROLEASSIGN'. lv_parent_type = 'MEMBERSHIP'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBERSHIP_ID' ).
      WHEN 'MEMBERIDENT' OR 'MEMBERSKILL'. lv_parent_type = 'MEMBER'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ).
      WHEN 'TASKDEP'.
        lv_parent_type = 'TASK'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_ID' ).
        ycl_it_hub_tx=>scope( iv_name = 'IMPLEMENTATION_TASK' iv_id = lv_parent iv_on = abap_true ).
      WHEN 'EVENTATTENDEE'. lv_parent_type = 'EVENT'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'EVENT_ID' ).
      WHEN 'DOCATTACH'. lv_parent_type = 'DOCUMENT'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'DOCUMENT_ID' ).
      WHEN 'TASK'.
        lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PARENT_ID' ).
        IF lv_parent IS NOT INITIAL.
          ycl_it_hub_tx=>operation( iv_entity = 'TASK' iv_id = lv_parent iv_action = 'SUBTASK_CHANGED' ).
          touch( iv_entity = 'TASK' iv_id = lv_parent ).
        ENDIF.
        lv_parent_type = 'PROJECT'. lv_parent = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ).
    ENDCASE.
    IF lv_parent IS NOT INITIAL AND ycl_it_hub_tx=>get( iv_entity = lv_parent_type iv_id = lv_parent ) IS BOUND.
      touch( iv_entity = lv_parent_type iv_id = lv_parent ).
    ENDIF.
  ENDMETHOD.
  METHOD prepare_delete.
    DATA(lv_previous_phase) = ycl_it_hub_tx=>in_save( ).
    ycl_it_hub_tx=>save_phase( abap_true ).
    TRY.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = iv_entity iv_id = iv_id ).
        IF ycl_it_hub_tx=>confirm_delete( iv_entity = iv_entity iv_id = iv_id ) = abap_true.
          ycl_it_hub_tx=>confirm_children( iv_entity = iv_entity ir_row = lr_before ).
          IF ycl_it_hub_tx=>cascade_delete( iv_entity = iv_entity iv_id = iv_id ) = abap_false.
            parents( iv_entity = iv_entity ir_row = lr_before ).
          ENDIF.
          IF iv_entity = 'TASK' OR iv_entity = 'COMMENT' OR iv_entity = 'RISK'.
            cleanup_target( iv_type = iv_entity iv_id = iv_id ).
          ENDIF.
        ENDIF.
        ycl_it_hub_tx=>save_phase( lv_previous_phase ).
      CATCH ycx_it_hub INTO DATA(lx_delete).
        ycl_it_hub_tx=>save_phase( lv_previous_phase ).
        RAISE EXCEPTION lx_delete.
    ENDTRY.
  ENDMETHOD.
  METHOD cleanup_target.
    ycl_it_hub_tx=>scope( iv_name = |CLEANUP_{ iv_type }| iv_id = iv_id iv_on = abap_true ).
    DATA lt_documents TYPE SORTED TABLE OF sysuuid_c36 WITH UNIQUE KEY table_line.
    LOOP AT ycl_it_hub_tx=>rows( 'DOCATTACH' ) INTO DATA(lr_link).
      IF ycl_it_hub_tx=>field( ir_row = lr_link iv_name = 'TARGET_TYPE' ) = iv_type
        AND ycl_it_hub_tx=>field( ir_row = lr_link iv_name = 'TARGET_ID' ) = iv_id.
        INSERT CONV #( ycl_it_hub_tx=>field( ir_row = lr_link iv_name = 'DOCUMENT_ID' ) ) INTO TABLE lt_documents.
      ENDIF.
    ENDLOOP.
    LOOP AT lt_documents INTO DATA(lv_document).
      IF ycl_it_hub_tx=>in_save( ) = abap_true.
      MODIFY ENTITIES OF yr_it_hub_document ENTITY Document EXECUTE CleanupOnSave
        FROM VALUE #( ( id = lv_document %param-targetType = iv_type %param-targetId = iv_id ) )
        FAILED DATA(ls_save_failed).
      IF ls_save_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'Cross-BO attachment cleanup failed.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
      ELSE.
      MODIFY ENTITIES OF yr_it_hub_document ENTITY Document EXECUTE CleanupTarget
        FROM VALUE #( ( id = lv_document %param-targetType = iv_type %param-targetId = iv_id ) )
        FAILED DATA(ls_failed).
      IF ls_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'Cross-BO attachment cleanup failed.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
      ENDIF.
    ENDLOOP.
    ycl_it_hub_tx=>scope( iv_name = |CLEANUP_{ iv_type }| iv_id = iv_id iv_on = abap_false ).
  ENDMETHOD.
ENDCLASS.
