CLASS ycl_it_hub_authctx_qp DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.
ENDCLASS.
CLASS ycl_it_hub_authctx_qp IMPLEMENTATION.
  METHOD if_rap_query_provider~select.
    TRY.
        ycl_it_hub_tx=>begin_read( ).
      CATCH ycx_it_hub INTO DATA(lx_read).
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = lx_read->text previous = lx_read.
    ENDTRY.
    TRY.
        TRY.
            " Authorize and classify even count-only requests and excluded keys.
            DATA lv_json TYPE string.
            DATA(lv_entity) = to_upper( io_request->get_entity_id( ) ).
            CASE lv_entity.
              WHEN 'YCE_IT_HUB_AUTHCTX'. lv_json = ycl_it_hub_authctx=>get_json( ).
              WHEN 'YCE_IT_HUB_STARTUP'. lv_json = ycl_it_hub_authctx=>get_startup_json( ).
              WHEN OTHERS.
                RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
            ENDCASE.
          CATCH ycx_it_hub INTO DATA(lx_policy).
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = lx_policy->text previous = lx_policy.
        ENDTRY.
        IF io_request->get_search_expression( ) IS NOT INITIAL OR io_request->get_parameters( ) IS NOT INITIAL.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
        ENDIF.
        DATA(lo_aggregation) = io_request->get_aggregation( ).
        IF lo_aggregation IS BOUND.
          IF lo_aggregation->get_aggregated_elements( ) IS NOT INITIAL OR lo_aggregation->get_grouped_elements( ) IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
          ENDIF.
        ENDIF.
        LOOP AT io_request->get_requested_elements( ) INTO DATA(lv_field).
          IF to_upper( lv_field ) <> 'ID' AND to_upper( lv_field ) <> 'CONTEXTJSON' AND lv_field <> '*'.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
          ENDIF.
        ENDLOOP.
        LOOP AT io_request->get_sort_elements( ) INTO DATA(ls_sort).
          IF to_upper( ls_sort-element_name ) <> 'ID' AND to_upper( ls_sort-element_name ) <> 'CONTEXTJSON'.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
          ENDIF.
        ENDLOOP.
        TRY.
            DATA(lt_filters) = io_request->get_filter( )->get_as_ranges( ).
          CATCH cx_rap_query_filter_no_range INTO DATA(lx_filter).
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query previous = lx_filter.
        ENDTRY.
        DATA lv_id TYPE yce_it_hub_authctx-id VALUE 'CURRENT'.
        DATA(lv_matches) = abap_true.
        LOOP AT lt_filters INTO DATA(ls_filter).
          IF to_upper( ls_filter-name ) <> 'ID'.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
          ENDIF.
          LOOP AT ls_filter-range INTO DATA(ls_range).
            IF ( ls_range-sign <> 'I' AND ls_range-sign <> 'E' ) OR ( ls_range-option <> 'EQ' AND ls_range-option <> 'NE' ).
              RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
            ENDIF.
          ENDLOOP.
          IF lv_id NOT IN ls_filter-range. lv_matches = abap_false. ENDIF.
        ENDLOOP.
        DATA(lo_paging) = io_request->get_paging( ).
        DATA(lv_offset) = lo_paging->get_offset( ).
        DATA(lv_size) = lo_paging->get_page_size( ).
        IF lv_offset < 0 OR lv_size < if_rap_query_paging=>page_size_unlimited.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = ycx_it_hub_authctx=>gc_unsupported_query.
        ENDIF.
        IF io_request->is_total_numb_of_rec_requested( ).
          io_response->set_total_number_of_records( COND int8( WHEN lv_matches = abap_true THEN 1 ELSE 0 ) ).
        ENDIF.
        IF io_request->is_data_requested( ).
          CASE lv_entity.
            WHEN 'YCE_IT_HUB_AUTHCTX'.
              DATA lt_authctx TYPE STANDARD TABLE OF yce_it_hub_authctx WITH EMPTY KEY.
              IF lv_matches = abap_true AND lv_offset = 0 AND lv_size <> 0.
                APPEND VALUE #( id = lv_id contextJson = lv_json ) TO lt_authctx.
              ENDIF.
              io_response->set_data( lt_authctx ).
            WHEN 'YCE_IT_HUB_STARTUP'.
              DATA lt_startup TYPE STANDARD TABLE OF yce_it_hub_startup WITH EMPTY KEY.
              IF lv_matches = abap_true AND lv_offset = 0 AND lv_size <> 0.
                APPEND VALUE #( id = lv_id contextJson = lv_json ) TO lt_startup.
              ENDIF.
              io_response->set_data( lt_startup ).
          ENDCASE.
        ENDIF.
      CLEANUP.
        ycl_it_hub_tx=>end_read( ).
    ENDTRY.
    ycl_it_hub_tx=>end_read( ).
  ENDMETHOD.
ENDCLASS.
