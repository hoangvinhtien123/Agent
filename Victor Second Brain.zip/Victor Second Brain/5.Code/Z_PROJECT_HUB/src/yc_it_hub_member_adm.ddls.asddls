@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub admin projection'
define root view entity YC_IT_HUB_MEMBER_ADM
  provider contract transactional_query
  as projection on YR_IT_HUB_MEMBER
{
  key id,
  name,
  email,
  emailNormalized,
  title,
  team,
  initials,
  active,
  isAppManager,
  createdAt,
  updatedAt,
  localLastChangedAt,
  createdBy,
  updatedBy,
  _Identity : redirected to composition child YC_IT_HUB_MEMBERIDENT_ADM,
  skills : redirected to composition child YC_IT_HUB_MEMBERSKILL_ADM
}
