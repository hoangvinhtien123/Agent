@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - DocAttach'
define view entity YC_IT_HUB_DOCATTACH
  as projection on YI_IT_HUB_DOCATTACH
{
  key id,
  projectId,
  documentId,
  targetType,
  targetId,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Document : redirected to parent YC_IT_HUB_DOCUMENT,
  _Project : redirected to YC_IT_HUB_PROJECT
}
