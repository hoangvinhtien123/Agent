@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - RoleAssign'
define view entity YC_IT_HUB_ROLEASSIGN
  as projection on YI_IT_HUB_ROLEASSIGN
{
  key id,
  projectId,
  membershipId,
  role,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Membership : redirected to parent YC_IT_HUB_MEMBERSHIP,
  _Project : redirected to YC_IT_HUB_PROJECT
}
