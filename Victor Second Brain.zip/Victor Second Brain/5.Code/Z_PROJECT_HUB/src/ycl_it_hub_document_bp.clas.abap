CLASS ycl_it_hub_document_bp DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF yr_it_hub_document.
ENDCLASS.

CLASS ycl_it_hub_document_bp IMPLEMENTATION.
ENDCLASS.
