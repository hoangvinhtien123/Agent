CLASS ycl_it_hub_const DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CONSTANTS: BEGIN OF gc_phase,
      initiation TYPE c LENGTH 30 VALUE 'INITIATION',
      design TYPE c LENGTH 30 VALUE 'DESIGN',
      build TYPE c LENGTH 30 VALUE 'BUILD',
      sit TYPE c LENGTH 30 VALUE 'SIT',
      uat TYPE c LENGTH 30 VALUE 'UAT',
      go_live TYPE c LENGTH 30 VALUE 'GO_LIVE',
      hypercare TYPE c LENGTH 30 VALUE 'HYPERCARE',
      closed TYPE c LENGTH 30 VALUE 'CLOSED',
    END OF gc_phase.
    CONSTANTS: BEGIN OF gc_health,
      on_track TYPE c LENGTH 30 VALUE 'ON_TRACK',
      at_risk TYPE c LENGTH 30 VALUE 'AT_RISK',
      delayed TYPE c LENGTH 30 VALUE 'DELAYED',
    END OF gc_health.
    CONSTANTS: BEGIN OF gc_task_type,
      task TYPE c LENGTH 30 VALUE 'TASK',
      defect TYPE c LENGTH 30 VALUE 'DEFECT',
    END OF gc_task_type.
    CONSTANTS: BEGIN OF gc_task_status,
      todo TYPE c LENGTH 30 VALUE 'TODO',
      in_progress TYPE c LENGTH 30 VALUE 'IN_PROGRESS',
      in_review TYPE c LENGTH 30 VALUE 'IN_REVIEW',
      done TYPE c LENGTH 30 VALUE 'DONE',
    END OF gc_task_status.
    CONSTANTS: BEGIN OF gc_defect_status,
      open TYPE c LENGTH 30 VALUE 'OPEN',
      in_fix TYPE c LENGTH 30 VALUE 'IN_FIX',
      ready_for_retest TYPE c LENGTH 30 VALUE 'READY_FOR_RETEST',
      closed TYPE c LENGTH 30 VALUE 'CLOSED',
    END OF gc_defect_status.
    CONSTANTS: BEGIN OF gc_subtask_status,
      open TYPE c LENGTH 30 VALUE 'OPEN',
      in_progress TYPE c LENGTH 30 VALUE 'IN_PROGRESS',
      closed TYPE c LENGTH 30 VALUE 'CLOSED',
    END OF gc_subtask_status.
    CONSTANTS: BEGIN OF gc_priority,
      low TYPE c LENGTH 30 VALUE 'LOW',
      medium TYPE c LENGTH 30 VALUE 'MEDIUM',
      high TYPE c LENGTH 30 VALUE 'HIGH',
      critical TYPE c LENGTH 30 VALUE 'CRITICAL',
    END OF gc_priority.
    CONSTANTS: BEGIN OF gc_impact,
      low TYPE c LENGTH 30 VALUE 'LOW',
      medium TYPE c LENGTH 30 VALUE 'MEDIUM',
      high TYPE c LENGTH 30 VALUE 'HIGH',
    END OF gc_impact.
    CONSTANTS: BEGIN OF gc_milestone_status,
      upcoming TYPE c LENGTH 30 VALUE 'UPCOMING',
      at_risk TYPE c LENGTH 30 VALUE 'AT_RISK',
      complete TYPE c LENGTH 30 VALUE 'COMPLETE',
    END OF gc_milestone_status.
    CONSTANTS: BEGIN OF gc_risk_status,
      open TYPE c LENGTH 30 VALUE 'OPEN',
      mitigating TYPE c LENGTH 30 VALUE 'MITIGATING',
      resolved TYPE c LENGTH 30 VALUE 'RESOLVED',
    END OF gc_risk_status.
    CONSTANTS: BEGIN OF gc_proficiency,
      foundation TYPE c LENGTH 30 VALUE 'FOUNDATION',
      working TYPE c LENGTH 30 VALUE 'WORKING',
      advanced TYPE c LENGTH 30 VALUE 'ADVANCED',
      expert TYPE c LENGTH 30 VALUE 'EXPERT',
    END OF gc_proficiency.
    CONSTANTS: BEGIN OF gc_event_kind,
      meeting TYPE c LENGTH 30 VALUE 'MEETING',
      workshop TYPE c LENGTH 30 VALUE 'WORKSHOP',
      sit TYPE c LENGTH 30 VALUE 'SIT',
      uat TYPE c LENGTH 30 VALUE 'UAT',
      go_live TYPE c LENGTH 30 VALUE 'GO_LIVE',
    END OF gc_event_kind.
    CONSTANTS: BEGIN OF gc_project_role,
      business_owner TYPE c LENGTH 30 VALUE 'BUSINESS_OWNER',
      technical_lead TYPE c LENGTH 30 VALUE 'TECHNICAL_LEAD',
      developer TYPE c LENGTH 30 VALUE 'DEVELOPER',
      tester TYPE c LENGTH 30 VALUE 'TESTER',
    END OF gc_project_role.
    CONSTANTS: BEGIN OF gc_comment_target,
      project TYPE c LENGTH 30 VALUE 'PROJECT',
      workstream TYPE c LENGTH 30 VALUE 'WORKSTREAM',
      task TYPE c LENGTH 30 VALUE 'TASK',
      milestone TYPE c LENGTH 30 VALUE 'MILESTONE',
      event TYPE c LENGTH 30 VALUE 'EVENT',
      risk TYPE c LENGTH 30 VALUE 'RISK',
      document TYPE c LENGTH 30 VALUE 'DOCUMENT',
    END OF gc_comment_target.
    CONSTANTS: BEGIN OF gc_attach_target,
      project TYPE c LENGTH 30 VALUE 'PROJECT',
      task TYPE c LENGTH 30 VALUE 'TASK',
      comment TYPE c LENGTH 30 VALUE 'COMMENT',
      risk TYPE c LENGTH 30 VALUE 'RISK',
    END OF gc_attach_target.
    CONSTANTS: BEGIN OF gc_doc_category,
      requirements TYPE c LENGTH 30 VALUE 'REQUIREMENTS',
      design TYPE c LENGTH 30 VALUE 'DESIGN',
      testing TYPE c LENGTH 30 VALUE 'TESTING',
      deployment TYPE c LENGTH 30 VALUE 'DEPLOYMENT',
      governance TYPE c LENGTH 30 VALUE 'GOVERNANCE',
      other TYPE c LENGTH 30 VALUE 'OTHER',
    END OF gc_doc_category.
    CONSTANTS: BEGIN OF gc_doc_source,
      file TYPE c LENGTH 30 VALUE 'FILE',
      url TYPE c LENGTH 30 VALUE 'URL',
    END OF gc_doc_source.
    CONSTANTS: BEGIN OF gc_media_kind,
      image TYPE c LENGTH 30 VALUE 'IMAGE',
      video TYPE c LENGTH 30 VALUE 'VIDEO',
      link TYPE c LENGTH 30 VALUE 'LINK',
    END OF gc_media_kind.
    CONSTANTS: BEGIN OF gc_upload_status,
      pending TYPE c LENGTH 30 VALUE 'PENDING',
      ready TYPE c LENGTH 30 VALUE 'READY',
    END OF gc_upload_status.
ENDCLASS.
CLASS ycl_it_hub_const IMPLEMENTATION.
ENDCLASS.
