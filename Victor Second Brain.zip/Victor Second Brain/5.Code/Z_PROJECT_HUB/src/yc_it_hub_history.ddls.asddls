@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - History'
define view entity YC_IT_HUB_HISTORY
  as select from YI_IT_HUB_HISTORY
{
  key id,
  scopeType,
  projectId,
  entity,
  entityId,
  action,
  detail,
  changesJson,
  createdAt,
  createdBy,
  correlationId
}
