CLASS lhc_Task DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Task RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Task RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Task RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE Task.

    METHODS precheck_create FOR PRECHECK
      IMPORTING entities FOR CREATE Task.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Task.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE Task.

    METHODS earlynumbering_cba_Dependencie FOR NUMBERING
      IMPORTING entities FOR CREATE Task\Dependencies.

    METHODS precheck_cba_Dependencies FOR PRECHECK
      IMPORTING entities FOR CREATE Task\Dependencies.

    METHODS ReplaceDependencies FOR MODIFY
      IMPORTING keys FOR ACTION Task~ReplaceDependencies RESULT result.

    METHODS Transition FOR MODIFY
      IMPORTING keys FOR ACTION Task~Transition RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Task~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Task~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Task~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Task~TouchGoverned.
    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR Task~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR Task~validate_delete.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Task~TouchOnSave.
    METHODS SaveDetails FOR MODIFY IMPORTING keys FOR ACTION Task~SaveDetails RESULT result.
ENDCLASS.

CLASS lhc_Task IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Transition = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-ReplaceDependencies = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-Dependencies = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Transition = COND #( WHEN ycl_it_hub_policy=>transition_available( ls_db ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-ReplaceDependencies = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'REPLACEDEPENDENCIES' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%assoc-Dependencies = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
    DATA(ls_permissions) = ycl_it_hub_policy=>permissions( ls_db-project_id ).
     IF requested_authorizations-%update = if_abap_behv=>mk-on.
     <result>-%update = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%delete = if_abap_behv=>mk-on.
     <result>-%delete = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Transition = if_abap_behv=>mk-on.
     <result>-%action-Transition = COND #( WHEN lv_found = abap_true AND ls_permissions-read = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-ReplaceDependencies = if_abap_behv=>mk-on.
     <result>-%action-ReplaceDependencies = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'REPLACEDEPENDENCIES' ir_row = REF #( ls_db ) ) = abap_true
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%create = if_abap_behv=>mk-on.
     result-%create = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%update = if_abap_behv=>mk-on.
     result-%update = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%delete = if_abap_behv=>mk-on.
     result-%delete = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Transition = if_abap_behv=>mk-on.
     result-%action-Transition = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-ReplaceDependencies = if_abap_behv=>mk-on.
     result-%action-ReplaceDependencies = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD earlynumbering_create.
    LOOP AT entities INTO DATA(ls_entity).
      DATA(lv_id) = ls_entity-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_TASK' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-task.
        APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-task.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_TASK' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'TASK' iv_id = lv_id is_control = ls_entity-%control ).
          APPEND VALUE #( %cid = ls_entity-%cid id = lv_id ) TO mapped-task.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-task.
          APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Task identifier.' ) ) TO reported-task.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_create.
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      workstream_id TYPE abp_behv_flag,
      parent_id TYPE abp_behv_flag,
      source_task_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      task_type TYPE abp_behv_flag,
      status TYPE abp_behv_flag,
      priority TYPE abp_behv_flag,
      assignee_id TYPE abp_behv_flag,
      tester_id TYPE abp_behv_flag,
      implementation_actors_json TYPE abp_behv_flag,
      cycle_reopened TYPE abp_behv_flag,
      last_outcome_json TYPE abp_behv_flag,
      due_date TYPE abp_behv_flag,
      estimate_hours TYPE abp_behv_flag,
      blocked TYPE abp_behv_flag,
      blocked_reason TYPE abp_behv_flag,
      impact TYPE abp_behv_flag,
      resolution TYPE abp_behv_flag,
      completed_at TYPE abp_behv_flag,
      sort_order TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      workstream_id = ls_entity-%control-workstreamId
      parent_id = ls_entity-%control-parentId
      source_task_id = ls_entity-%control-sourceTaskId
      title = ls_entity-%control-title
      description = ls_entity-%control-description
      task_type = ls_entity-%control-type
      status = ls_entity-%control-status
      priority = ls_entity-%control-priority
      assignee_id = ls_entity-%control-assigneeId
      tester_id = ls_entity-%control-testerId
      implementation_actors_json = ls_entity-%control-implementationActorsJson
      cycle_reopened = ls_entity-%control-cycleReopened
      last_outcome_json = ls_entity-%control-lastOutcomeJson
      due_date = ls_entity-%control-dueDate
      estimate_hours = ls_entity-%control-estimateHours
      blocked = ls_entity-%control-blocked
      blocked_reason = ls_entity-%control-blockedReason
      impact = ls_entity-%control-impact
      resolution = ls_entity-%control-resolution
      completed_at = ls_entity-%control-completedAt
      sort_order = ls_entity-%control-sortOrder
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'TASK' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-task.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-workstreamId = if_abap_behv=>mk-on. ls_db-workstream_id = ls_entity-workstreamId. ENDIF.
     IF ls_entity-%control-parentId = if_abap_behv=>mk-on. ls_db-parent_id = ls_entity-parentId. ENDIF.
     IF ls_entity-%control-sourceTaskId = if_abap_behv=>mk-on. ls_db-source_task_id = ls_entity-sourceTaskId. ENDIF.
     IF ls_entity-%control-title = if_abap_behv=>mk-on. ls_db-title = ls_entity-title. ENDIF.
     IF ls_entity-%control-description = if_abap_behv=>mk-on. ls_db-description = ls_entity-description. ENDIF.
     IF ls_entity-%control-type = if_abap_behv=>mk-on. ls_db-task_type = ls_entity-type. ENDIF.
     IF ls_entity-%control-status = if_abap_behv=>mk-on. ls_db-status = ls_entity-status. ENDIF.
     IF ls_entity-%control-priority = if_abap_behv=>mk-on. ls_db-priority = ls_entity-priority. ENDIF.
     IF ls_entity-%control-assigneeId = if_abap_behv=>mk-on. ls_db-assignee_id = ls_entity-assigneeId. ENDIF.
     IF ls_entity-%control-testerId = if_abap_behv=>mk-on. ls_db-tester_id = ls_entity-testerId. ENDIF.
     IF ls_entity-%control-implementationActorsJson = if_abap_behv=>mk-on. ls_db-implementation_actors_json = ls_entity-implementationActorsJson. ENDIF.
     IF ls_entity-%control-cycleReopened = if_abap_behv=>mk-on. ls_db-cycle_reopened = ls_entity-cycleReopened. ENDIF.
     IF ls_entity-%control-lastOutcomeJson = if_abap_behv=>mk-on. ls_db-last_outcome_json = ls_entity-lastOutcomeJson. ENDIF.
     IF ls_entity-%control-dueDate = if_abap_behv=>mk-on. ls_db-due_date = ls_entity-dueDate. ENDIF.
     IF ls_entity-%control-estimateHours = if_abap_behv=>mk-on. ls_db-estimate_hours = ls_entity-estimateHours. ENDIF.
     IF ls_entity-%control-blocked = if_abap_behv=>mk-on. ls_db-blocked = ls_entity-blocked. ENDIF.
     IF ls_entity-%control-blockedReason = if_abap_behv=>mk-on. ls_db-blocked_reason = ls_entity-blockedReason. ENDIF.
     IF ls_entity-%control-impact = if_abap_behv=>mk-on. ls_db-impact = ls_entity-impact. ENDIF.
     IF ls_entity-%control-resolution = if_abap_behv=>mk-on. ls_db-resolution = ls_entity-resolution. ENDIF.
     IF ls_entity-%control-completedAt = if_abap_behv=>mk-on. ls_db-completed_at = ls_entity-completedAt. ENDIF.
     IF ls_entity-%control-sortOrder = if_abap_behv=>mk-on. ls_db-sort_order = ls_entity-sortOrder. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      workstream_id TYPE abp_behv_flag,
      parent_id TYPE abp_behv_flag,
      source_task_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      task_type TYPE abp_behv_flag,
      status TYPE abp_behv_flag,
      priority TYPE abp_behv_flag,
      assignee_id TYPE abp_behv_flag,
      tester_id TYPE abp_behv_flag,
      implementation_actors_json TYPE abp_behv_flag,
      cycle_reopened TYPE abp_behv_flag,
      last_outcome_json TYPE abp_behv_flag,
      due_date TYPE abp_behv_flag,
      estimate_hours TYPE abp_behv_flag,
      blocked TYPE abp_behv_flag,
      blocked_reason TYPE abp_behv_flag,
      impact TYPE abp_behv_flag,
      resolution TYPE abp_behv_flag,
      completed_at TYPE abp_behv_flag,
      sort_order TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      workstream_id = ls_entity-%control-workstreamId
      parent_id = ls_entity-%control-parentId
      source_task_id = ls_entity-%control-sourceTaskId
      title = ls_entity-%control-title
      description = ls_entity-%control-description
      task_type = ls_entity-%control-type
      status = ls_entity-%control-status
      priority = ls_entity-%control-priority
      assignee_id = ls_entity-%control-assigneeId
      tester_id = ls_entity-%control-testerId
      implementation_actors_json = ls_entity-%control-implementationActorsJson
      cycle_reopened = ls_entity-%control-cycleReopened
      last_outcome_json = ls_entity-%control-lastOutcomeJson
      due_date = ls_entity-%control-dueDate
      estimate_hours = ls_entity-%control-estimateHours
      blocked = ls_entity-%control-blocked
      blocked_reason = ls_entity-%control-blockedReason
      impact = ls_entity-%control-impact
      resolution = ls_entity-%control-resolution
      completed_at = ls_entity-%control-completedAt
      sort_order = ls_entity-%control-sortOrder
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'TASK' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_task.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     IF ls_row-assigneeId <> ls_db-assignee_id. ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'ASSIGN_WORK' ir_row = REF #( ls_permission_db ) ). ENDIF.
     IF ls_row-testerId <> ls_db-tester_id. ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'ASSIGN_WORK' ir_row = REF #( ls_permission_db ) ). ENDIF.
     IF ls_row-dueDate <> ls_db-due_date. ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'ASSIGN_WORK' ir_row = REF #( ls_permission_db ) ). ENDIF.
     IF ls_row-priority <> ls_db-priority. ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'ASSIGN_WORK' ir_row = REF #( ls_permission_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-task.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'TASK' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_task.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'TASK' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-task.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Dependencie.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_TASKDEP' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-taskdep.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-taskdep.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_TASKDEP' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'TASKDEP' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-taskdep.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-taskdep.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a TaskDep identifier.' ) ) TO reported-taskdep.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Dependencies.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-task_id = ls_source-id.
     DATA(lr_parent) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = ls_source-id ).
     ls_db-project_id = ycl_it_hub_tx=>field( ir_row = lr_parent iv_name = 'PROJECT_ID' ).
     ycl_it_hub_defaults=>apply( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      task_id TYPE abp_behv_flag,
      depends_on_task_id TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      task_id = ls_entity-%control-taskId
      depends_on_task_id = ls_entity-%control-dependsOnTaskId
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'TASKDEP' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control
      iv_defer_parent = xsdbool( lr_parent IS NOT BOUND AND ( ls_source-%cid_ref IS NOT INITIAL OR ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_TASK' iv_id = ls_source-id ) = abap_true ) ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     IF lr_parent IS BOUND. ycl_it_hub_tx=>guard( iv_entity = 'TASKDEP' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-taskdep.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-taskdep.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD ReplaceDependencies.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'REPLACEDEPENDENCIES' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'REPLACEDEPENDENCIES' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'TASK' iv_id = ls_db-id iv_action = 'REPLACE_DEPENDENCIES' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'TASK' iv_id = ls_db-id ).
     ycl_it_hub_tx=>scope( iv_name = 'IMPLEMENTATION_TASK' iv_id = ls_db-id iv_on = abap_true ).
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task BY \dependencies
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_children).
    DATA lt_delete TYPE TABLE FOR DELETE YR_IT_HUB_TASK\\TaskDep.
    DATA lt_create TYPE TABLE FOR CREATE YR_IT_HUB_TASK\dependencies.
    CLEAR: lt_delete, lt_create.
    DATA(lt_desired) = ycl_it_hub_policy=>parse_array( iv_json = ls_key-%param-dependencyIdsJson iv_kind = 'UUID' iv_entity = 'TASK' ).
    APPEND VALUE #( id = ls_db-id ) TO lt_create ASSIGNING FIELD-SYMBOL(<source>).
    LOOP AT lt_children INTO DATA(ls_child).
      READ TABLE lt_desired TRANSPORTING NO FIELDS WITH KEY table_line = CONV string( ls_child-dependsOnTaskId ).
      IF sy-subrc <> 0. APPEND VALUE #( id = ls_child-id ) TO lt_delete. ENDIF.
    ENDLOOP.
    LOOP AT lt_desired INTO DATA(lv_value).
      DATA(lv_existing) = abap_false.
      LOOP AT lt_children TRANSPORTING NO FIELDS WHERE dependsOnTaskId = lv_value. lv_existing = abap_true. EXIT. ENDLOOP.
      IF lv_existing = abap_true. CONTINUE. ENDIF.
    DATA(ls_candidate) = VALUE ytb_it_hub_tdep( project_id = ls_db-project_id task_id = ls_db-id depends_on_task_id = CONV #( lv_value ) ).
    DATA(lv_graph_error) = ycl_it_hub_policy=>graph( ls_candidate ).
    IF lv_graph_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_graph_error. ENDIF.
    APPEND VALUE #( %cid = |LINK_{ lv_value }| dependsOnTaskId = CONV #( lv_value ) %control-dependsOnTaskId = if_abap_behv=>mk-on ) TO <source>-%target.
    ENDLOOP.
    LOOP AT lt_delete INTO DATA(ls_delete_key).
      READ TABLE lt_children INTO DATA(ls_deleted_child) WITH TABLE KEY entity COMPONENTS id = ls_delete_key-id.
      DATA ls_deleted_db TYPE ytb_it_hub_tdep.
    ls_deleted_db = CORRESPONDING #( ls_deleted_child MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ycl_it_hub_tx=>stage_delete( iv_entity = 'TASKDEP' ir_row = REF #( ls_deleted_db ) iv_actor = ls_actor-id ).
    ENDLOOP.
    MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep DELETE FROM lt_delete
      ENTITY Task CREATE BY \dependencies FROM lt_create
      FAILED DATA(ls_replace_failed) REPORTED DATA(ls_replace_reported).
    ls_messages = CORRESPONDING #( DEEP ls_replace_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
    IF ls_replace_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Replacement failed; no part of the replacement may be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    LOOP AT lt_delete INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'TASKDEP' iv_id = ls_removed_key-id ).
    ENDLOOP.

    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'TASK' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'TASK' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-workstreamId <> ls_db-workstream_id. ls_update-workstreamId = ls_db-workstream_id. ls_update-%control-workstreamId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-parentId <> ls_db-parent_id. ls_update-parentId = ls_db-parent_id. ls_update-%control-parentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceTaskId <> ls_db-source_task_id. ls_update-sourceTaskId = ls_db-source_task_id. ls_update-%control-sourceTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-type <> ls_db-task_type. ls_update-type = ls_db-task_type. ls_update-%control-type = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assigneeId <> ls_db-assignee_id. ls_update-assigneeId = ls_db-assignee_id. ls_update-%control-assigneeId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-testerId <> ls_db-tester_id. ls_update-testerId = ls_db-tester_id. ls_update-%control-testerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-implementationActorsJson <> ls_db-implementation_actors_json. ls_update-implementationActorsJson = ls_db-implementation_actors_json. ls_update-%control-implementationActorsJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-cycleReopened <> ls_db-cycle_reopened. ls_update-cycleReopened = ls_db-cycle_reopened. ls_update-%control-cycleReopened = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-lastOutcomeJson <> ls_db-last_outcome_json. ls_update-lastOutcomeJson = ls_db-last_outcome_json. ls_update-%control-lastOutcomeJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-estimateHours <> ls_db-estimate_hours. ls_update-estimateHours = ls_db-estimate_hours. ls_update-%control-estimateHours = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blocked <> ls_db-blocked. ls_update-blocked = ls_db-blocked. ls_update-%control-blocked = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blockedReason <> ls_db-blocked_reason. ls_update-blockedReason = ls_db-blocked_reason. ls_update-%control-blockedReason = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-task.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-task TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD Transition.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'TASK' iv_operation = 'TRANSITION' ir_row = REF #( ls_db ) is_parameter = ls_key-%param ).
     ycl_it_hub_tx=>operation( iv_entity = 'TASK' iv_id = ls_db-id iv_action = 'TRANSITION' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'TASK' iv_id = ls_db-id ).
     ls_db = ycl_it_hub_policy=>transition( is_task = ls_db iv_status = CONV #( ls_key-%param-status ) iv_reason = ls_key-%param-reason iv_override = ls_key-%param-override ).
     IF ls_key-%param-override = abap_true. ycl_it_hub_tx=>operation( iv_entity = 'TASK' iv_id = ls_db-id iv_action = 'WORKFLOW_OVERRIDE' ). ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'TASK' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-workstreamId <> ls_db-workstream_id. ls_update-workstreamId = ls_db-workstream_id. ls_update-%control-workstreamId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-parentId <> ls_db-parent_id. ls_update-parentId = ls_db-parent_id. ls_update-%control-parentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceTaskId <> ls_db-source_task_id. ls_update-sourceTaskId = ls_db-source_task_id. ls_update-%control-sourceTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-type <> ls_db-task_type. ls_update-type = ls_db-task_type. ls_update-%control-type = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assigneeId <> ls_db-assignee_id. ls_update-assigneeId = ls_db-assignee_id. ls_update-%control-assigneeId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-testerId <> ls_db-tester_id. ls_update-testerId = ls_db-tester_id. ls_update-%control-testerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-implementationActorsJson <> ls_db-implementation_actors_json. ls_update-implementationActorsJson = ls_db-implementation_actors_json. ls_update-%control-implementationActorsJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-cycleReopened <> ls_db-cycle_reopened. ls_update-cycleReopened = ls_db-cycle_reopened. ls_update-%control-cycleReopened = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-lastOutcomeJson <> ls_db-last_outcome_json. ls_update-lastOutcomeJson = ls_db-last_outcome_json. ls_update-%control-lastOutcomeJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-estimateHours <> ls_db-estimate_hours. ls_update-estimateHours = ls_db-estimate_hours. ls_update-%control-estimateHours = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blocked <> ls_db-blocked. ls_update-blocked = ls_db-blocked. ls_update-%control-blocked = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blockedReason <> ls_db-blocked_reason. ls_update-blockedReason = ls_db-blocked_reason. ls_update-%control-blockedReason = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-task.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-task TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'TASK' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'TASK' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-workstreamId <> ls_db-workstream_id. ls_update-workstreamId = ls_db-workstream_id. ls_update-%control-workstreamId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-parentId <> ls_db-parent_id. ls_update-parentId = ls_db-parent_id. ls_update-%control-parentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceTaskId <> ls_db-source_task_id. ls_update-sourceTaskId = ls_db-source_task_id. ls_update-%control-sourceTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-type <> ls_db-task_type. ls_update-type = ls_db-task_type. ls_update-%control-type = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assigneeId <> ls_db-assignee_id. ls_update-assigneeId = ls_db-assignee_id. ls_update-%control-assigneeId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-testerId <> ls_db-tester_id. ls_update-testerId = ls_db-tester_id. ls_update-%control-testerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-implementationActorsJson <> ls_db-implementation_actors_json. ls_update-implementationActorsJson = ls_db-implementation_actors_json. ls_update-%control-implementationActorsJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-cycleReopened <> ls_db-cycle_reopened. ls_update-cycleReopened = ls_db-cycle_reopened. ls_update-%control-cycleReopened = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-lastOutcomeJson <> ls_db-last_outcome_json. ls_update-lastOutcomeJson = ls_db-last_outcome_json. ls_update-%control-lastOutcomeJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-estimateHours <> ls_db-estimate_hours. ls_update-estimateHours = ls_db-estimate_hours. ls_update-%control-estimateHours = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blocked <> ls_db-blocked. ls_update-blocked = ls_db-blocked. ls_update-%control-blocked = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blockedReason <> ls_db-blocked_reason. ls_update-blockedReason = ls_db-blocked_reason. ls_update-%control-blockedReason = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'TASK' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'TASK' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'TASK' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-workstreamId <> ls_db-workstream_id. ls_update-workstreamId = ls_db-workstream_id. ls_update-%control-workstreamId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-parentId <> ls_db-parent_id. ls_update-parentId = ls_db-parent_id. ls_update-%control-parentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceTaskId <> ls_db-source_task_id. ls_update-sourceTaskId = ls_db-source_task_id. ls_update-%control-sourceTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-type <> ls_db-task_type. ls_update-type = ls_db-task_type. ls_update-%control-type = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assigneeId <> ls_db-assignee_id. ls_update-assigneeId = ls_db-assignee_id. ls_update-%control-assigneeId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-testerId <> ls_db-tester_id. ls_update-testerId = ls_db-tester_id. ls_update-%control-testerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-implementationActorsJson <> ls_db-implementation_actors_json. ls_update-implementationActorsJson = ls_db-implementation_actors_json. ls_update-%control-implementationActorsJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-cycleReopened <> ls_db-cycle_reopened. ls_update-cycleReopened = ls_db-cycle_reopened. ls_update-%control-cycleReopened = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-lastOutcomeJson <> ls_db-last_outcome_json. ls_update-lastOutcomeJson = ls_db-last_outcome_json. ls_update-%control-lastOutcomeJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-estimateHours <> ls_db-estimate_hours. ls_update-estimateHours = ls_db-estimate_hours. ls_update-%control-estimateHours = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blocked <> ls_db-blocked. ls_update-blocked = ls_db-blocked. ls_update-%control-blocked = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blockedReason <> ls_db-blocked_reason. ls_update-blockedReason = ls_db-blocked_reason. ls_update-%control-blockedReason = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'TASK' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'TASK' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'TASK' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_notif_plan=>prepare( ls_db ).
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-task.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_TASK' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'TASK' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-workstreamId <> ls_db-workstream_id. ls_update-workstreamId = ls_db-workstream_id. ls_update-%control-workstreamId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-parentId <> ls_db-parent_id. ls_update-parentId = ls_db-parent_id. ls_update-%control-parentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceTaskId <> ls_db-source_task_id. ls_update-sourceTaskId = ls_db-source_task_id. ls_update-%control-sourceTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-type <> ls_db-task_type. ls_update-type = ls_db-task_type. ls_update-%control-type = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assigneeId <> ls_db-assignee_id. ls_update-assigneeId = ls_db-assignee_id. ls_update-%control-assigneeId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-testerId <> ls_db-tester_id. ls_update-testerId = ls_db-tester_id. ls_update-%control-testerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-implementationActorsJson <> ls_db-implementation_actors_json. ls_update-implementationActorsJson = ls_db-implementation_actors_json. ls_update-%control-implementationActorsJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-cycleReopened <> ls_db-cycle_reopened. ls_update-cycleReopened = ls_db-cycle_reopened. ls_update-%control-cycleReopened = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-lastOutcomeJson <> ls_db-last_outcome_json. ls_update-lastOutcomeJson = ls_db-last_outcome_json. ls_update-%control-lastOutcomeJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-estimateHours <> ls_db-estimate_hours. ls_update-estimateHours = ls_db-estimate_hours. ls_update-%control-estimateHours = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blocked <> ls_db-blocked. ls_update-blocked = ls_db-blocked. ls_update-%control-blocked = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blockedReason <> ls_db-blocked_reason. ls_update-blockedReason = ls_db-blocked_reason. ls_update-%control-blockedReason = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-task.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'TASK' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-task.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'TASK' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'TASK' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'TASK' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-task.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-task.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY Task ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_TASK' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_task.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId workstream_id = workstreamId parent_id = parentId source_task_id = sourceTaskId task_type = type assignee_id = assigneeId tester_id = testerId implementation_actors_json =
implementationActorsJson cycle_reopened = cycleReopened last_outcome_json = lastOutcomeJson due_date = dueDate estimate_hours = estimateHours blocked_reason = blockedReason completed_at = completedAt sort_order = sortOrder created_at = createdAt
created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'TASK' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-workstreamId <> ls_db-workstream_id. ls_update-workstreamId = ls_db-workstream_id. ls_update-%control-workstreamId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-parentId <> ls_db-parent_id. ls_update-parentId = ls_db-parent_id. ls_update-%control-parentId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sourceTaskId <> ls_db-source_task_id. ls_update-sourceTaskId = ls_db-source_task_id. ls_update-%control-sourceTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-type <> ls_db-task_type. ls_update-type = ls_db-task_type. ls_update-%control-type = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assigneeId <> ls_db-assignee_id. ls_update-assigneeId = ls_db-assignee_id. ls_update-%control-assigneeId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-testerId <> ls_db-tester_id. ls_update-testerId = ls_db-tester_id. ls_update-%control-testerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-implementationActorsJson <> ls_db-implementation_actors_json. ls_update-implementationActorsJson = ls_db-implementation_actors_json. ls_update-%control-implementationActorsJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-cycleReopened <> ls_db-cycle_reopened. ls_update-cycleReopened = ls_db-cycle_reopened. ls_update-%control-cycleReopened = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-lastOutcomeJson <> ls_db-last_outcome_json. ls_update-lastOutcomeJson = ls_db-last_outcome_json. ls_update-%control-lastOutcomeJson = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-estimateHours <> ls_db-estimate_hours. ls_update-estimateHours = ls_db-estimate_hours. ls_update-%control-estimateHours = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blocked <> ls_db-blocked. ls_update-blocked = ls_db-blocked. ls_update-%control-blocked = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-blockedReason <> ls_db-blocked_reason. ls_update-blockedReason = ls_db-blocked_reason. ls_update-%control-blockedReason = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY Task UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-task.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-task.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD SaveDetails.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_tx=>lock( ).
          DATA(lt_desired) = ycl_it_hub_policy=>parse_array( iv_json = ls_key-%param-relatedIdsJson iv_kind = 'UUID' iv_entity = 'TASK' ).
          DATA lt_update TYPE TABLE FOR UPDATE yr_it_hub_task\\Task.
          CLEAR lt_update.
          APPEND VALUE #( %tky = ls_key-%tky ) TO lt_update ASSIGNING FIELD-SYMBOL(<update>).
          ycl_it_hub_policy=>apply_profile( iv_json = ls_key-%param-profileJson
            iv_fields = 'title,description,priority,assigneeId,testerId,dueDate,estimateHours,workstreamId,sourceTaskId,blocked,blockedReason,impact,resolution,sortOrder' ir_update = REF #( <update> ) ).
          " Use normal EML so profile prechecks, features and authorization run.
          IF <update>-%control IS NOT INITIAL.
            MODIFY ENTITIES OF yr_it_hub_task ENTITY Task UPDATE FROM lt_update
              FAILED DATA(ls_update_failed) REPORTED DATA(ls_update_reported).
            LOOP AT ls_update_reported-task INTO DATA(ls_message).
              APPEND CORRESPONDING #( ls_message ) TO reported-task.
            ENDLOOP.
            IF ls_update_failed IS NOT INITIAL.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile update failed; no detail changes were saved.'.
            ENDIF.
          ENDIF.
          MODIFY ENTITIES OF yr_it_hub_task ENTITY Task EXECUTE ReplaceDependencies
            FROM VALUE #( ( id = ls_key-id %param-dependencyIdsJson = ls_key-%param-relatedIdsJson ) )
            FAILED DATA(ls_related_failed) REPORTED DATA(ls_related_reported).
          LOOP AT ls_related_reported-task INTO DATA(ls_related_message).
            APPEND CORRESPONDING #( ls_related_message ) TO reported-task.
          ENDLOOP.
          IF ls_related_failed IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Related collection failed; no detail changes were saved.'.
          ENDIF.
          READ ENTITIES OF yr_it_hub_task IN LOCAL MODE ENTITY Task
            ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_after).
          READ TABLE lt_after INTO DATA(ls_after) INDEX 1.
          IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Saved detail could not be read.'. ENDIF.
          APPEND VALUE #( %tky = ls_key-%tky %param = ls_after ) TO result.
        CATCH ycx_it_hub INTO DATA(lx_detail).
          ycl_it_hub_tx=>fail( lx_detail->text ).
          APPEND VALUE #( %tky = ls_key-%tky ) TO failed-task.
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_detail->text ) ) TO reported-task.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_TaskDep DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR TaskDep RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE TaskDep.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE TaskDep.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR TaskDep~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR TaskDep~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR TaskDep~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR TaskDep~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR TaskDep~validate_delete.
ENDCLASS.

CLASS lhc_TaskDep IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN abap_false = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'TASKDEP' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-taskId = if_abap_behv=>mk-on. ls_db-task_id = ls_entity-taskId. ENDIF.
     IF ls_entity-%control-dependsOnTaskId = if_abap_behv=>mk-on. ls_db-depends_on_task_id = ls_entity-dependsOnTaskId. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      task_id TYPE abp_behv_flag,
      depends_on_task_id TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      task_id = ls_entity-%control-taskId
      depends_on_task_id = ls_entity-%control-dependsOnTaskId
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'TASKDEP' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_tdep.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'TASKDEP' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Link records are immutable; use the replacement action or create/delete.'.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-taskdep.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-taskdep.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'TASKDEP' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_tdep.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'TASKDEP' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-taskdep.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-taskdep.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'TASKDEP' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_task IN LOCAL MODE ENTITY Task
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-task_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK\\TaskDep.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-taskId <> ls_db-task_id. ls_update-taskId = ls_db-task_id. ls_update-%control-taskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dependsOnTaskId <> ls_db-depends_on_task_id. ls_update-dependsOnTaskId = ls_db-depends_on_task_id. ls_update-%control-dependsOnTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY TaskDep UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-taskdep.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'TASKDEP' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_task IN LOCAL MODE ENTITY Task
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-task_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     IF ycl_it_hub_tx=>before( iv_entity = 'TASKDEP' iv_id = ls_db-id ) IS NOT BOUND.
       ycl_it_hub_tx=>guard( iv_entity = 'TASKDEP' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_TASK\\TaskDep.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-taskId <> ls_db-task_id. ls_update-taskId = ls_db-task_id. ls_update-%control-taskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dependsOnTaskId <> ls_db-depends_on_task_id. ls_update-dependsOnTaskId = ls_db-depends_on_task_id. ls_update-%control-dependsOnTaskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE ENTITY TaskDep UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-task TO reported-task.
    APPEND LINES OF ls_messages-taskdep TO reported-taskdep.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-taskdep.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_TASK IN LOCAL MODE
      ENTITY TaskDep ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_tdep.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId depends_on_task_id = dependsOnTaskId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'TASKDEP' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-taskdep.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-taskdep.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'TASKDEP' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-taskdep.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'TASKDEP' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'TASKDEP' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'TASKDEP' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-taskdep.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-taskdep.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_YR_IT_HUB_TASK DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_YR_IT_HUB_TASK IMPLEMENTATION.
  METHOD save_modified.
    ycl_it_hub_tx=>save( iv_owner = 'TASK' is_create = create is_update = update is_delete = delete ).
    ycl_it_hub_notif_plan=>save( is_create = create is_update = update ).
  ENDMETHOD.

  METHOD cleanup.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD cleanup_finalize.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

ENDCLASS.
