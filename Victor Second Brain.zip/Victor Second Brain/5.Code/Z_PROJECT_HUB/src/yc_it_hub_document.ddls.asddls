@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Document'
define root view entity YC_IT_HUB_DOCUMENT
  provider contract transactional_query
  as projection on YR_IT_HUB_DOCUMENT
{
  key id,
  projectId,
  title,
  description,
  category,
  sourceType,
  mediaKind,
  uploadStatus,
  url,
  fileName,
  @Semantics.mimeType: true
  mimeType,
  @Semantics.largeObject: { mimeType: 'mimeType', fileName: 'fileName', contentDispositionPreference: #ATTACHMENT }
  content,
  byteSize,
  checksumSha256,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  attachments : redirected to composition child YC_IT_HUB_DOCATTACH,
  _Project : redirected to YC_IT_HUB_PROJECT
}
