@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Risk'
define view entity YI_IT_HUB_RISK
  as select from ytb_it_hub_risk
  association to parent YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
  association [0..1] to YR_IT_HUB_TASK as _Task on $projection.taskId = _Task.id
  association [0..1] to YR_IT_HUB_MEMBER as _Owner on $projection.ownerId = _Owner.id
{
  key id as id,
  project_id as projectId,
  task_id as taskId,
  title as title,
  description as description,
  impact as impact,
  likelihood as likelihood,
  priority as priority,
  owner_id as ownerId,
  status as status,
  mitigation_plan as mitigationPlan,
  resolution as resolution,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  likelihood * case impact when 'LOW' then 1 when 'MEDIUM' then 2 when 'HIGH' then 3 else 0 end as riskScore,
  _Project,
  _Task,
  _Owner
}
