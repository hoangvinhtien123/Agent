CLASS lhc_Event DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Event RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Event RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Event RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE Event.

    METHODS precheck_create FOR PRECHECK
      IMPORTING entities FOR CREATE Event.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Event.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE Event.

    METHODS earlynumbering_cba_Attendees FOR NUMBERING
      IMPORTING entities FOR CREATE Event\Attendees.

    METHODS precheck_cba_Attendees FOR PRECHECK
      IMPORTING entities FOR CREATE Event\Attendees.

    METHODS ReplaceAttendees FOR MODIFY
      IMPORTING keys FOR ACTION Event~ReplaceAttendees RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Event~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Event~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Event~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Event~TouchGoverned.
    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR Event~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR Event~validate_delete.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Event~TouchOnSave.
    METHODS SaveDetails FOR MODIFY IMPORTING keys FOR ACTION Event~SaveDetails RESULT result.
ENDCLASS.

CLASS lhc_Event IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-ReplaceAttendees = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-Attendees = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-ReplaceAttendees = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'REPLACEATTENDEES' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%assoc-Attendees = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF requested_authorizations-%update = if_abap_behv=>mk-on.
     <result>-%update = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%delete = if_abap_behv=>mk-on.
     <result>-%delete = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-ReplaceAttendees = if_abap_behv=>mk-on.
     <result>-%action-ReplaceAttendees = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'REPLACEATTENDEES' ir_row = REF #( ls_db ) ) = abap_true
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%create = if_abap_behv=>mk-on.
     result-%create = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%update = if_abap_behv=>mk-on.
     result-%update = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%delete = if_abap_behv=>mk-on.
     result-%delete = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-ReplaceAttendees = if_abap_behv=>mk-on.
     result-%action-ReplaceAttendees = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD earlynumbering_create.
    LOOP AT entities INTO DATA(ls_entity).
      DATA(lv_id) = ls_entity-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_EVENT' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-event.
        APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-event.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_EVENT' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'EVENT' iv_id = lv_id is_control = ls_entity-%control ).
          APPEND VALUE #( %cid = ls_entity-%cid id = lv_id ) TO mapped-event.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-event.
          APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Event identifier.' ) ) TO reported-event.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_create.
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_defaults=>apply( iv_entity = 'EVENT' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      kind TYPE abp_behv_flag,
      start_at TYPE abp_behv_flag,
      end_at TYPE abp_behv_flag,
      time_zone TYPE abp_behv_flag,
      location TYPE abp_behv_flag,
      reminder_minutes TYPE abp_behv_flag,
      reminder_enabled TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      title = ls_entity-%control-title
      kind = ls_entity-%control-kind
      start_at = ls_entity-%control-startAt
      end_at = ls_entity-%control-endAt
      time_zone = ls_entity-%control-eventTimeZone
      location = ls_entity-%control-location
      reminder_minutes = ls_entity-%control-reminderMinutes
      reminder_enabled = ls_entity-%control-reminderEnabled
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'EVENT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'EVENT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-event.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-title = if_abap_behv=>mk-on. ls_db-title = ls_entity-title. ENDIF.
     IF ls_entity-%control-kind = if_abap_behv=>mk-on. ls_db-kind = ls_entity-kind. ENDIF.
     IF ls_entity-%control-startAt = if_abap_behv=>mk-on. ls_db-start_at = ls_entity-startAt. ENDIF.
     IF ls_entity-%control-endAt = if_abap_behv=>mk-on. ls_db-end_at = ls_entity-endAt. ENDIF.
     IF ls_entity-%control-eventTimeZone = if_abap_behv=>mk-on. ls_db-time_zone = ls_entity-eventTimeZone. ENDIF.
     IF ls_entity-%control-location = if_abap_behv=>mk-on. ls_db-location = ls_entity-location. ENDIF.
     IF ls_entity-%control-reminderMinutes = if_abap_behv=>mk-on. ls_db-reminder_minutes = ls_entity-reminderMinutes. ENDIF.
     IF ls_entity-%control-reminderEnabled = if_abap_behv=>mk-on. ls_db-reminder_enabled = ls_entity-reminderEnabled. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      kind TYPE abp_behv_flag,
      start_at TYPE abp_behv_flag,
      end_at TYPE abp_behv_flag,
      time_zone TYPE abp_behv_flag,
      location TYPE abp_behv_flag,
      reminder_minutes TYPE abp_behv_flag,
      reminder_enabled TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      title = ls_entity-%control-title
      kind = ls_entity-%control-kind
      start_at = ls_entity-%control-startAt
      end_at = ls_entity-%control-endAt
      time_zone = ls_entity-%control-eventTimeZone
      location = ls_entity-%control-location
      reminder_minutes = ls_entity-%control-reminderMinutes
      reminder_enabled = ls_entity-%control-reminderEnabled
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'EVENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_event.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by =
createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'EVENT' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-event.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'EVENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_event.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by =
createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'EVENT' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'EVENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-event.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Attendees.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_EVENTATTENDEE' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-eventattendee.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-eventattendee.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_EVENTATTENDEE' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'EVENTATTENDEE' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-eventattendee.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-eventattendee.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a EventAttendee identifier.' ) ) TO reported-eventattendee.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Attendees.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-event_id = ls_source-id.
     DATA(lr_parent) = ycl_it_hub_tx=>get( iv_entity = 'EVENT' iv_id = ls_source-id ).
     ls_db-project_id = ycl_it_hub_tx=>field( ir_row = lr_parent iv_name = 'PROJECT_ID' ).
     ycl_it_hub_defaults=>apply( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      event_id TYPE abp_behv_flag,
      member_id TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      event_id = ls_entity-%control-eventId
      member_id = ls_entity-%control-memberId
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'EVENTATTENDEE' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control iv_defer_parent = xsdbool( lr_parent IS NOT BOUND AND ( ls_source-%cid_ref IS NOT INITIAL OR
ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_EVENT' iv_id = ls_source-id ) = abap_true ) ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     IF lr_parent IS BOUND. ycl_it_hub_tx=>guard( iv_entity = 'EVENTATTENDEE' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-eventattendee.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-eventattendee.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD ReplaceAttendees.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'EVENT' iv_operation = 'REPLACEATTENDEES' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'EVENT' iv_operation = 'REPLACEATTENDEES' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'EVENT' iv_id = ls_db-id iv_action = 'REPLACE_ATTENDEES' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'EVENT' iv_id = ls_db-id ).
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event BY \attendees
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_children).
    DATA lt_delete TYPE TABLE FOR DELETE YR_IT_HUB_EVENT\\EventAttendee.
    DATA lt_create TYPE TABLE FOR CREATE YR_IT_HUB_EVENT\attendees.
    CLEAR: lt_delete, lt_create.
    DATA(lt_desired) = ycl_it_hub_policy=>parse_array( iv_json = ls_key-%param-attendeeIdsJson iv_kind = 'UUID' iv_entity = 'MEMBER' ).
    APPEND VALUE #( id = ls_db-id ) TO lt_create ASSIGNING FIELD-SYMBOL(<source>).
    LOOP AT lt_children INTO DATA(ls_child).
      READ TABLE lt_desired TRANSPORTING NO FIELDS WITH KEY table_line = CONV string( ls_child-memberId ).
      IF sy-subrc <> 0. APPEND VALUE #( id = ls_child-id ) TO lt_delete. ENDIF.
    ENDLOOP.
    LOOP AT lt_desired INTO DATA(lv_value).
      DATA(lv_existing) = abap_false.
      LOOP AT lt_children TRANSPORTING NO FIELDS WHERE memberId = lv_value. lv_existing = abap_true. EXIT. ENDLOOP.
      IF lv_existing = abap_true. CONTINUE. ENDIF.
    IF ycl_it_hub_policy=>member_in_project( iv_project = ls_db-project_id iv_member = CONV #( lv_value ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'New attendees require active eligible project membership.'. ENDIF.
    APPEND VALUE #( %cid = |LINK_{ lv_value }| memberId = CONV #( lv_value ) %control-memberId = if_abap_behv=>mk-on ) TO <source>-%target.
    ENDLOOP.
    LOOP AT lt_delete INTO DATA(ls_delete_key).
      READ TABLE lt_children INTO DATA(ls_deleted_child) WITH TABLE KEY entity COMPONENTS id = ls_delete_key-id.
      DATA ls_deleted_db TYPE ytb_it_hub_eatt.
    ls_deleted_db = CORRESPONDING #( ls_deleted_child MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ycl_it_hub_tx=>stage_delete( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_deleted_db ) iv_actor = ls_actor-id ).
    ENDLOOP.
    MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee DELETE FROM lt_delete
      ENTITY Event CREATE BY \attendees FROM lt_create
      FAILED DATA(ls_replace_failed) REPORTED DATA(ls_replace_reported).
    ls_messages = CORRESPONDING #( DEEP ls_replace_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
    IF ls_replace_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Replacement failed; no part of the replacement may be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    LOOP AT lt_delete INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'EVENTATTENDEE' iv_id = ls_removed_key-id ).
    ENDLOOP.

    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'EVENT' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'EVENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-kind <> ls_db-kind. ls_update-kind = ls_db-kind. ls_update-%control-kind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startAt <> ls_db-start_at. ls_update-startAt = ls_db-start_at. ls_update-%control-startAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endAt <> ls_db-end_at. ls_update-endAt = ls_db-end_at. ls_update-%control-endAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventTimeZone <> ls_db-time_zone. ls_update-eventTimeZone = ls_db-time_zone. ls_update-%control-eventTimeZone = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-location <> ls_db-location. ls_update-location = ls_db-location. ls_update-%control-location = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderMinutes <> ls_db-reminder_minutes. ls_update-reminderMinutes = ls_db-reminder_minutes. ls_update-%control-reminderMinutes = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderEnabled <> ls_db-reminder_enabled. ls_update-reminderEnabled = ls_db-reminder_enabled. ls_update-%control-reminderEnabled = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-event.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-event TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'EVENT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'EVENT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'EVENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-kind <> ls_db-kind. ls_update-kind = ls_db-kind. ls_update-%control-kind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startAt <> ls_db-start_at. ls_update-startAt = ls_db-start_at. ls_update-%control-startAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endAt <> ls_db-end_at. ls_update-endAt = ls_db-end_at. ls_update-%control-endAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventTimeZone <> ls_db-time_zone. ls_update-eventTimeZone = ls_db-time_zone. ls_update-%control-eventTimeZone = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-location <> ls_db-location. ls_update-location = ls_db-location. ls_update-%control-location = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderMinutes <> ls_db-reminder_minutes. ls_update-reminderMinutes = ls_db-reminder_minutes. ls_update-%control-reminderMinutes = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderEnabled <> ls_db-reminder_enabled. ls_update-reminderEnabled = ls_db-reminder_enabled. ls_update-%control-reminderEnabled = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'EVENT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'EVENT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'EVENT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'EVENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-kind <> ls_db-kind. ls_update-kind = ls_db-kind. ls_update-%control-kind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startAt <> ls_db-start_at. ls_update-startAt = ls_db-start_at. ls_update-%control-startAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endAt <> ls_db-end_at. ls_update-endAt = ls_db-end_at. ls_update-%control-endAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventTimeZone <> ls_db-time_zone. ls_update-eventTimeZone = ls_db-time_zone. ls_update-%control-eventTimeZone = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-location <> ls_db-location. ls_update-location = ls_db-location. ls_update-%control-location = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderMinutes <> ls_db-reminder_minutes. ls_update-reminderMinutes = ls_db-reminder_minutes. ls_update-%control-reminderMinutes = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderEnabled <> ls_db-reminder_enabled. ls_update-reminderEnabled = ls_db-reminder_enabled. ls_update-%control-reminderEnabled = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'EVENT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'EVENT' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'EVENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-event.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_EVENT' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'EVENT' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-kind <> ls_db-kind. ls_update-kind = ls_db-kind. ls_update-%control-kind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startAt <> ls_db-start_at. ls_update-startAt = ls_db-start_at. ls_update-%control-startAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endAt <> ls_db-end_at. ls_update-endAt = ls_db-end_at. ls_update-%control-endAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventTimeZone <> ls_db-time_zone. ls_update-eventTimeZone = ls_db-time_zone. ls_update-%control-eventTimeZone = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-location <> ls_db-location. ls_update-location = ls_db-location. ls_update-%control-location = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderMinutes <> ls_db-reminder_minutes. ls_update-reminderMinutes = ls_db-reminder_minutes. ls_update-%control-reminderMinutes = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderEnabled <> ls_db-reminder_enabled. ls_update-reminderEnabled = ls_db-reminder_enabled. ls_update-%control-reminderEnabled = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-event.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'EVENT' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-event.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'EVENT' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'EVENT' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'EVENT' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-event.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-event.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY Event ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_EVENT' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_event.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId start_at = startAt end_at = endAt time_zone = eventTimeZone reminder_minutes = reminderMinutes reminder_enabled = reminderEnabled created_at = createdAt created_by = createdByTechnical
updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'EVENT' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-kind <> ls_db-kind. ls_update-kind = ls_db-kind. ls_update-%control-kind = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startAt <> ls_db-start_at. ls_update-startAt = ls_db-start_at. ls_update-%control-startAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endAt <> ls_db-end_at. ls_update-endAt = ls_db-end_at. ls_update-%control-endAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventTimeZone <> ls_db-time_zone. ls_update-eventTimeZone = ls_db-time_zone. ls_update-%control-eventTimeZone = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-location <> ls_db-location. ls_update-location = ls_db-location. ls_update-%control-location = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderMinutes <> ls_db-reminder_minutes. ls_update-reminderMinutes = ls_db-reminder_minutes. ls_update-%control-reminderMinutes = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-reminderEnabled <> ls_db-reminder_enabled. ls_update-reminderEnabled = ls_db-reminder_enabled. ls_update-%control-reminderEnabled = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY Event UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-event.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-event.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD SaveDetails.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_tx=>lock( ).
          DATA(lt_desired) = ycl_it_hub_policy=>parse_array( iv_json = ls_key-%param-relatedIdsJson iv_kind = 'UUID' iv_entity = 'MEMBER' ).
          DATA lt_update TYPE TABLE FOR UPDATE yr_it_hub_event\\Event.
          CLEAR lt_update.
          APPEND VALUE #( %tky = ls_key-%tky ) TO lt_update ASSIGNING FIELD-SYMBOL(<update>).
          ycl_it_hub_policy=>apply_profile( iv_json = ls_key-%param-profileJson
            iv_fields = 'title,kind,startAt,endAt,eventTimeZone,location,reminderMinutes,reminderEnabled' ir_update = REF #( <update> ) ).
          " Use normal EML so profile prechecks, features and authorization run.
          IF <update>-%control IS NOT INITIAL.
            MODIFY ENTITIES OF yr_it_hub_event ENTITY Event UPDATE FROM lt_update
              FAILED DATA(ls_update_failed) REPORTED DATA(ls_update_reported).
            LOOP AT ls_update_reported-event INTO DATA(ls_message).
              APPEND CORRESPONDING #( ls_message ) TO reported-event.
            ENDLOOP.
            IF ls_update_failed IS NOT INITIAL.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile update failed; no detail changes were saved.'.
            ENDIF.
          ENDIF.
          MODIFY ENTITIES OF yr_it_hub_event ENTITY Event EXECUTE ReplaceAttendees
            FROM VALUE #( ( id = ls_key-id %param-attendeeIdsJson = ls_key-%param-relatedIdsJson ) )
            FAILED DATA(ls_related_failed) REPORTED DATA(ls_related_reported).
          LOOP AT ls_related_reported-event INTO DATA(ls_related_message).
            APPEND CORRESPONDING #( ls_related_message ) TO reported-event.
          ENDLOOP.
          IF ls_related_failed IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Related collection failed; no detail changes were saved.'.
          ENDIF.
          READ ENTITIES OF yr_it_hub_event IN LOCAL MODE ENTITY Event
            ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_after).
          READ TABLE lt_after INTO DATA(ls_after) INDEX 1.
          IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Saved detail could not be read.'. ENDIF.
          APPEND VALUE #( %tky = ls_key-%tky %param = ls_after ) TO result.
        CATCH ycx_it_hub INTO DATA(lx_detail).
          ycl_it_hub_tx=>fail( lx_detail->text ).
          APPEND VALUE #( %tky = ls_key-%tky ) TO failed-event.
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_detail->text ) ) TO reported-event.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_EventAttendee DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR EventAttendee RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE EventAttendee.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE EventAttendee.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR EventAttendee~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR EventAttendee~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR EventAttendee~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR EventAttendee~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR EventAttendee~validate_delete.
ENDCLASS.

CLASS lhc_EventAttendee IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN abap_false = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'EVENTATTENDEE' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-eventId = if_abap_behv=>mk-on. ls_db-event_id = ls_entity-eventId. ENDIF.
     IF ls_entity-%control-memberId = if_abap_behv=>mk-on. ls_db-member_id = ls_entity-memberId. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      event_id TYPE abp_behv_flag,
      member_id TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      event_id = ls_entity-%control-eventId
      member_id = ls_entity-%control-memberId
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'EVENTATTENDEE' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_eatt.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'EVENTATTENDEE' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Link records are immutable; use the replacement action or create/delete.'.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-eventattendee.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-eventattendee.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'EVENTATTENDEE' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_eatt.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'EVENTATTENDEE' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-eventattendee.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-eventattendee.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'EVENTATTENDEE' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_event IN LOCAL MODE ENTITY Event
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-event_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT\\EventAttendee.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventId <> ls_db-event_id. ls_update-eventId = ls_db-event_id. ls_update-%control-eventId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY EventAttendee UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-eventattendee.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'EVENTATTENDEE' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_event IN LOCAL MODE ENTITY Event
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-event_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     IF ycl_it_hub_tx=>before( iv_entity = 'EVENTATTENDEE' iv_id = ls_db-id ) IS NOT BOUND.
       ycl_it_hub_tx=>guard( iv_entity = 'EVENTATTENDEE' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_EVENT\\EventAttendee.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-eventId <> ls_db-event_id. ls_update-eventId = ls_db-event_id. ls_update-%control-eventId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE ENTITY EventAttendee UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-event TO reported-event.
    APPEND LINES OF ls_messages-eventattendee TO reported-eventattendee.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-eventattendee.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_EVENT IN LOCAL MODE
      ENTITY EventAttendee ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_eatt.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId event_id = eventId member_id = memberId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'EVENTATTENDEE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-eventattendee.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-eventattendee.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'EVENTATTENDEE' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-eventattendee.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'EVENTATTENDEE' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'EVENTATTENDEE' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'EVENTATTENDEE' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-eventattendee.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-eventattendee.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_YR_IT_HUB_EVENT DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_YR_IT_HUB_EVENT IMPLEMENTATION.
  METHOD save_modified.
    ycl_it_hub_tx=>save( iv_owner = 'EVENT' is_create = create is_update = update is_delete = delete ).
  ENDMETHOD.

  METHOD cleanup.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD cleanup_finalize.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

ENDCLASS.
