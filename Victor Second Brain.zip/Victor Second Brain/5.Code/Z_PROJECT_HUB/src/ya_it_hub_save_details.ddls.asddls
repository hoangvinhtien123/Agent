@EndUserText.label: 'IT Hub - Atomic Detail Save'
define abstract entity YA_IT_HUB_SAVE_DETAILS
{
  profileJson : abap.string(0);
  relatedIdsJson : abap.string(0);
}
