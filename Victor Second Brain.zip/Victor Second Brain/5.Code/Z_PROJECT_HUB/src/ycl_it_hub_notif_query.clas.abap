CLASS ycl_it_hub_notif_query DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_filter,
             has_id TYPE abap_bool,
             id TYPE sysuuid_c36,
             unread_only TYPE abap_bool,
           END OF ty_filter,
           tt_inbox TYPE STANDARD TABLE OF yce_it_hub_notifications WITH EMPTY KEY,
           tt_db TYPE STANDARD TABLE OF ytb_it_hub_notf WITH EMPTY KEY,
           tt_fields TYPE STANDARD TABLE OF string WITH EMPTY KEY,
           BEGIN OF ty_access,
             project_id TYPE sysuuid_c36,
             read TYPE abap_bool,
           END OF ty_access,
           tt_access TYPE HASHED TABLE OF ty_access WITH UNIQUE KEY project_id.
    CLASS-METHODS parse_filter IMPORTING iv_sql TYPE string
      RETURNING VALUE(rs_filter) TYPE ty_filter RAISING ycx_it_hub_authctx.
    CLASS-METHODS matches_row IMPORTING is_row TYPE ytb_it_hub_notf
      is_actor TYPE ycl_it_hub_policy=>ty_actor iv_cutoff TYPE timestampl
      is_filter TYPE ty_filter RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS page IMPORTING it_rows TYPE tt_inbox iv_skip TYPE int8 iv_top TYPE int8
      RETURNING VALUE(rt_page) TYPE tt_inbox RAISING ycx_it_hub_authctx.
    CLASS-METHODS project_fields IMPORTING it_rows TYPE tt_inbox it_fields TYPE tt_fields
      RETURNING VALUE(rt_rows) TYPE tt_inbox RAISING ycx_it_hub_authctx.
ENDCLASS.

CLASS ycl_it_hub_notif_query IMPLEMENTATION.
  METHOD parse_filter.
    " Parse a small allowlist of framework SQL, never execute this string as SQL.
    " String literals preserve separators; text-field literals would trim their trailing blanks.
    DATA(lv_sql) = condense( replace( val = iv_sql pcre = '\s+' with = ` ` occ = 0 ) ).
    IF lv_sql IS INITIAL. RETURN. ENDIF.
    DATA lv_depth TYPE i.
    DATA lv_quoted TYPE abap_bool.
    DATA lv_flat TYPE string.
    DO strlen( lv_sql ) TIMES.
      DATA(lv_offset) = sy-index - 1.
      DATA(lv_char) = substring( val = lv_sql off = lv_offset len = 1 ).
      IF lv_char = ''''.
        lv_quoted = xsdbool( lv_quoted = abap_false ).
        lv_flat = lv_flat && lv_char.
      ELSEIF lv_quoted = abap_true.
        lv_flat = lv_flat && lv_char.
      ELSEIF lv_char = '('.
        lv_depth = lv_depth + 1.
        lv_flat = lv_flat && ` `.
      ELSEIF lv_char = ')'.
        lv_depth = lv_depth - 1.
        lv_flat = lv_flat && ` `.
      ELSE.
        lv_flat = lv_flat && lv_char.
      ENDIF.
      IF lv_depth < 0.
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Unsupported notification filter.'.
      ENDIF.
    ENDDO.
    IF lv_depth <> 0 OR lv_quoted = abap_true.
      RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Unsupported notification filter.'.
    ENDIF.
    lv_sql = replace( val = lv_flat pcre = '(?i)\bAND\b' with = ` AND ` occ = 0 ).
    lv_sql = condense( lv_sql ).
    DATA lt_terms TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    SPLIT lv_sql AT ` AND ` INTO TABLE lt_terms.
    IF lines( lt_terms ) > 2.
      RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Unsupported notification filter.'.
    ENDIF.
    LOOP AT lt_terms INTO DATA(lv_term).
      lv_term = condense( lv_term ).
      IF matches( val = lv_term pcre = '(?i)\AREADAT\s+IS\s+NULL\z' ).
        IF rs_filter-unread_only = abap_true.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Duplicate notification unread filter.'.
        ENDIF.
        rs_filter-unread_only = abap_true.
      ELSE.
        DATA lv_id TYPE string.
        CLEAR lv_id.
        FIND FIRST OCCURRENCE OF PCRE
          `(?i)\AID\s*=\s*'([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})'\z`
          IN lv_term SUBMATCHES lv_id.
        IF sy-subrc <> 0 OR rs_filter-has_id = abap_true.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Use readAt eq null or one notification ID filter.'.
        ENDIF.
        rs_filter-has_id = abap_true.
        rs_filter-id = lv_id.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD matches_row.
    " Ownership also applies to Admin; an empty Admin bootstrap mapping is not an inbox owner.
    IF is_actor-active = abap_false OR is_actor-id IS INITIAL
      OR is_row-client <> sy-mandt OR to_upper( is_row-recipient_id ) <> to_upper( is_actor-id )
      OR is_row-created_at < iv_cutoff.
      RETURN.
    ENDIF.
    IF is_filter-has_id = abap_true AND to_upper( is_row-id ) <> to_upper( is_filter-id ). RETURN. ENDIF.
    IF is_filter-unread_only = abap_true AND is_row-read_at IS NOT INITIAL. RETURN. ENDIF.
    rv_yes = abap_true.
  ENDMETHOD.

  METHOD page.
    IF iv_skip < 0 OR iv_top < if_rap_query_paging=>page_size_unlimited.
      RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Invalid notification paging.'.
    ENDIF.
    IF iv_top = 0 OR iv_skip >= lines( it_rows ). RETURN. ENDIF.
    DATA(lv_remaining) = CONV int8( lines( it_rows ) ) - iv_skip.
    DATA(lv_count) = COND int8( WHEN iv_top = if_rap_query_paging=>page_size_unlimited
      THEN lv_remaining ELSE nmin( val1 = iv_top val2 = lv_remaining ) ).
    DATA(lv_first) = CONV i( iv_skip + 1 ).
    DATA(lv_last) = CONV i( iv_skip + lv_count ).
    LOOP AT it_rows INTO DATA(ls_row) FROM lv_first TO lv_last.
      APPEND ls_row TO rt_page.
    ENDLOOP.
  ENDMETHOD.

  METHOD project_fields.
    LOOP AT it_fields INTO DATA(lv_field).
      CASE to_upper( lv_field ).
        WHEN '*' OR 'ID' OR 'EVENTID' OR 'EVENTTYPE' OR 'RECIPIENTID' OR 'PROJECTID'
          OR 'TASKID' OR 'TITLE' OR 'MESSAGE' OR 'CREATEDAT' OR 'READAT' OR 'LOCALLASTCHANGEDAT'.
          CONTINUE.
        WHEN OTHERS.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Unsupported notification fields.'.
      ENDCASE.
    ENDLOOP.
    IF line_exists( it_fields[ table_line = '*' ] ). rt_rows = it_rows. RETURN. ENDIF.
    LOOP AT it_rows INTO DATA(ls_full).
      DATA ls_selected TYPE yce_it_hub_notifications.
      CLEAR ls_selected.
      LOOP AT it_fields INTO lv_field.
        DATA(lv_component) = to_upper( lv_field ).
        ASSIGN COMPONENT lv_component OF STRUCTURE ls_full TO FIELD-SYMBOL(<source>).
        ASSIGN COMPONENT lv_component OF STRUCTURE ls_selected TO FIELD-SYMBOL(<target>).
        IF <source> IS NOT ASSIGNED OR <target> IS NOT ASSIGNED.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Notification field mapping failed.'.
        ENDIF.
        <target> = <source>.
        UNASSIGN: <source>, <target>.
      ENDLOOP.
      APPEND ls_selected TO rt_rows.
    ENDLOOP.
  ENDMETHOD.

  METHOD if_rap_query_provider~select.
    TRY.
        ycl_it_hub_tx=>begin_read( ).
      CATCH ycx_it_hub INTO DATA(lx_scope).
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = lx_scope->text previous = lx_scope.
    ENDTRY.
    TRY.
        DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
        IF ls_actor-active = abap_false OR ls_actor-id IS INITIAL.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx
            EXPORTING iv_text = 'An active mapped Project Hub member is required for notifications.'.
        ENDIF.
        IF to_upper( io_request->get_entity_id( ) ) <> 'YCE_IT_HUB_NOTIFICATIONS'
          OR io_request->get_parameters( ) IS NOT INITIAL
          OR io_request->get_search_expression( ) IS NOT INITIAL.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Unsupported notification query options.'.
        ENDIF.
        DATA(lo_aggregation) = io_request->get_aggregation( ).
        IF lo_aggregation IS BOUND.
          IF lo_aggregation->get_aggregated_elements( ) IS NOT INITIAL
            OR lo_aggregation->get_grouped_elements( ) IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Notification aggregation is not supported.'.
          ENDIF.
        ENDIF.
        LOOP AT io_request->get_sort_elements( ) INTO DATA(ls_sort).
          IF ls_sort-descending = abap_false OR sy-tabix > 2
            OR ( sy-tabix = 1 AND to_upper( ls_sort-element_name ) <> 'CREATEDAT' )
            OR ( sy-tabix = 2 AND to_upper( ls_sort-element_name ) <> 'ID' ).
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Sort notifications by createdAt desc,id desc.'.
          ENDIF.
        ENDLOOP.
        DATA(ls_filter) = parse_filter( io_request->get_filter( )->get_as_sql_string( ) ).
        DATA(lv_top) = io_request->get_paging( )->get_page_size( ).
        DATA(lv_skip) = io_request->get_paging( )->get_offset( ).
        IF lv_skip < 0 OR lv_top < if_rap_query_paging=>page_size_unlimited.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Invalid notification paging.'.
        ENDIF.
        DATA lt_fields TYPE tt_fields.
        LOOP AT io_request->get_requested_elements( ) INTO DATA(lv_requested).
          APPEND CONV string( lv_requested ) TO lt_fields.
        ENDLOOP.
        " Validate projections even when a page has zero records.
        DATA lt_empty TYPE tt_inbox.
        project_fields( it_rows = lt_empty it_fields = lt_fields ).
        DATA lv_now TYPE timestampl.
        DATA lv_cutoff TYPE timestampl.
        DATA lt_db TYPE tt_db.
        DATA lt_ids TYPE RANGE OF ytb_it_hub_notf-id.
        DATA lv_unread TYPE ytb_it_hub_notf-read_at.
        IF ls_filter-has_id = abap_true.
          lt_ids = VALUE #( ( sign = 'I' option = 'EQ' low = to_lower( ls_filter-id ) ) ).
        ENDIF.
        DATA(lv_recipient) = to_lower( ls_actor-id ).
        TRY.
            GET TIME STAMP FIELD lv_now.
            lv_cutoff = cl_abap_tstmp=>subtractsecs( tstmp = lv_now secs = 7776000 ).
            " Implicit ABAP SQL client handling; never load another recipient's inbox.
            SELECT * FROM ytb_it_hub_notf
              WHERE lower( recipient_id ) = @lv_recipient AND created_at >= @lv_cutoff
                AND lower( id ) IN @lt_ids
                AND ( @ls_filter-unread_only = @abap_false OR read_at = @lv_unread )
              INTO TABLE @lt_db.
          CATCH cx_root INTO DATA(lx_storage).
            RAISE EXCEPTION TYPE ycx_it_hub_authctx
              EXPORTING iv_text = 'Notification lookup failed. Check the SAP error log.' previous = lx_storage.
        ENDTRY.
        DATA lt_access TYPE tt_access.
        DATA lt_inbox TYPE tt_inbox.
        LOOP AT lt_db INTO DATA(ls_db).
          IF matches_row( is_row = ls_db is_actor = ls_actor iv_cutoff = lv_cutoff
            is_filter = ls_filter ) = abap_false. CONTINUE. ENDIF.
          READ TABLE lt_access INTO DATA(ls_access) WITH TABLE KEY project_id = ls_db-project_id.
          IF sy-subrc <> 0.
            DATA(ls_permissions) = ycl_it_hub_policy=>permissions( iv_project = ls_db-project_id ).
            ls_access = VALUE #( project_id = ls_db-project_id read = ls_permissions-read ).
            INSERT ls_access INTO TABLE lt_access.
          ENDIF.
          IF ls_access-read = abap_false. CONTINUE. ENDIF.
          APPEND VALUE #( id = ls_db-id eventId = ls_db-event_id eventType = ls_db-event_type
            recipientId = ls_db-recipient_id projectId = ls_db-project_id taskId = ls_db-task_id
            title = ls_db-title message = ls_db-message createdAt = ls_db-created_at
            readAt = ls_db-read_at localLastChangedAt = ls_db-local_last_changed_at ) TO lt_inbox.
        ENDLOOP.
        SORT lt_inbox BY createdAt DESCENDING id DESCENDING.
        IF io_request->is_total_numb_of_rec_requested( ).
          io_response->set_total_number_of_records( CONV int8( lines( lt_inbox ) ) ).
        ENDIF.
        IF io_request->is_data_requested( ).
          DATA(lt_page) = page( it_rows = lt_inbox iv_skip = lv_skip iv_top = lv_top ).
          io_response->set_data( project_fields( it_rows = lt_page it_fields = lt_fields ) ).
        ENDIF.
      CLEANUP.
        ycl_it_hub_tx=>end_read( ).
    ENDTRY.
    ycl_it_hub_tx=>end_read( ).
  ENDMETHOD.
ENDCLASS.
