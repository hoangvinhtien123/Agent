@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Risk'
define view entity YC_IT_HUB_RISK
  as projection on YI_IT_HUB_RISK
{
  key id,
  projectId,
  taskId,
  title,
  description,
  impact,
  likelihood,
  priority,
  ownerId,
  status,
  mitigationPlan,
  resolution,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  riskScore,
  _Project : redirected to parent YC_IT_HUB_PROJECT,
  _Task : redirected to YC_IT_HUB_TASK,
  _Owner : redirected to YC_IT_HUB_MEMBER
}
