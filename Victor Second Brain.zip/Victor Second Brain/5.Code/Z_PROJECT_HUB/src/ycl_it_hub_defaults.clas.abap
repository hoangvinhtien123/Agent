CLASS ycl_it_hub_defaults DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CLASS-METHODS apply IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      iv_new TYPE abap_bool iv_actor TYPE sysuuid_c36
      iv_preview TYPE abap_bool DEFAULT abap_false RAISING ycx_it_hub.
  PROTECTED SECTION.
  PRIVATE SECTION.
ENDCLASS.
CLASS ycl_it_hub_defaults IMPLEMENTATION.
  METHOD apply.
    DATA(lv_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ID' ) ).
    DATA(lr_old) = ycl_it_hub_tx=>get( iv_entity = iv_entity iv_id = lv_id ).
    IF iv_new = abap_true AND ( iv_preview = abap_true
      OR ycl_it_hub_tx=>in_scope( iv_name = |DEFAULTED_{ iv_entity }| iv_id = lv_id ) = abap_false ).
      IF iv_preview = abap_false.
        ycl_it_hub_tx=>scope( iv_name = |DEFAULTED_{ iv_entity }| iv_id = lv_id iv_on = abap_true ).
      ENDIF.
      CASE iv_entity.
        WHEN 'PROJECT'.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PHASE' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'PHASE' iv_value = 'INITIATION' ).
          ENDIF.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'HEALTH' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'HEALTH' iv_value = 'ON_TRACK' ).
          ENDIF.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ACCENT' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'ACCENT' iv_value = '#0EA5E9' ).
          ENDIF.
        WHEN 'TASK'.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_TYPE' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'TASK_TYPE' iv_value = 'TASK' ).
          ENDIF.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PRIORITY' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'PRIORITY' iv_value = 'MEDIUM' ).
          ENDIF.
        WHEN 'MILESTONE'.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'STATUS' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'STATUS' iv_value = 'UPCOMING' ).
          ENDIF.
        WHEN 'RISK'.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'STATUS' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'STATUS' iv_value = 'OPEN' ).
          ENDIF.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PRIORITY' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'PRIORITY' iv_value = 'MEDIUM' ).
          ENDIF.
          IF CONV i( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'LIKELIHOOD' ) ) = 0 AND ycl_it_hub_tx=>controlled( iv_entity = iv_entity iv_id = lv_id iv_name = 'LIKELIHOOD' ) = abap_false.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'LIKELIHOOD' iv_value = 2 ).
          ENDIF.
        WHEN 'EVENT'.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'KIND' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'KIND' iv_value = 'MEETING' ).
          ENDIF.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TIME_ZONE' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'TIME_ZONE' iv_value = 'UTC' ).
          ENDIF.
        WHEN 'DOCUMENT'.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'SOURCE_TYPE' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'SOURCE_TYPE' iv_value = 'URL' ).
          ENDIF.
          IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'CATEGORY' ) IS INITIAL.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'CATEGORY' iv_value = 'OTHER' ).
          ENDIF.
      ENDCASE.
      IF iv_entity = 'MEMBER' OR iv_entity = 'SKILL' OR iv_entity = 'MEMBERIDENT' OR iv_entity = 'MEMBERSHIP'.
        IF ycl_it_hub_tx=>controlled( iv_entity = iv_entity iv_id = lv_id iv_name = 'ACTIVE' ) = abap_false.
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'ACTIVE' iv_value = abap_true ).
        ENDIF.
      ENDIF.
      IF iv_entity = 'MEMBER'.
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'IS_APP_MANAGER' iv_value = abap_false ).
      ELSEIF iv_entity = 'MEMBERSHIP'.
        DATA(lv_project) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PROJECT_ID' ) ).
        DATA(lv_creator) = xsdbool( iv_actor IS NOT INITIAL
          AND ycl_it_hub_tx=>in_scope( iv_name = 'CREATOR' iv_id = lv_project ) = abap_true
          AND ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'MEMBER_ID' ) = iv_actor ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'IS_PROJECT_MANAGER' iv_value = lv_creator ).
        SPLIT 'EDIT_PROJECT,MANAGE_MEMBERS,ASSIGN_WORK,MANAGE_SCHEDULE,DELETE_WORK_ITEMS,OVERRIDE_WORKFLOW,MANAGE_PERMISSIONS' AT ',' INTO TABLE DATA(lt_flags).
        LOOP AT lt_flags INTO DATA(lv_flag).
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = lv_flag iv_value = lv_creator ).
        ENDLOOP.
        IF lv_creator = abap_true AND iv_preview = abap_false. ycl_it_hub_tx=>operation( iv_entity = iv_entity iv_id = lv_id iv_action = 'CREATOR' ). ENDIF.
      ELSEIF iv_entity = 'TASK'.
        DATA(lv_status) = COND string( WHEN ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TASK_TYPE' ) = 'DEFECT'
          OR ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'PARENT_ID' ) IS NOT INITIAL THEN 'OPEN' ELSE 'TODO' ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'STATUS' iv_value = lv_status ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'IMPLEMENTATION_ACTORS_JSON' iv_value = '[]' ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'CYCLE_REOPENED' iv_value = abap_false ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'LAST_OUTCOME_JSON' iv_value = CONV string( '' ) ).
      ELSEIF iv_entity = 'DOCUMENT'.
        DATA(lv_url) = xsdbool( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'SOURCE_TYPE' ) = 'URL' ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'UPLOAD_STATUS' iv_value = COND string( WHEN lv_url = abap_true THEN 'READY' ELSE 'PENDING' ) ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'MEDIA_KIND' iv_value = COND string( WHEN lv_url = abap_true THEN 'LINK' ELSE '' ) ).
      ENDIF.
    ENDIF.
    " Resolve supplied references to the existing row's spelling, never rewrite keys.
    SPLIT
'PROJECT_ID:PROJECT,MEMBER_ID:MEMBER,MEMBERSHIP_ID:MEMBERSHIP,SKILL_ID:SKILL,WORKSTREAM_ID:WORKSTREAM,PARENT_ID:TASK,SOURCE_TASK_ID:TASK,TASK_ID:TASK,DEPENDS_ON_TASK_ID:TASK,ASSIGNEE_ID:MEMBER,TESTER_ID:MEMBER,OWNER_ID:MEMBER,DOCUMENT_ID:DOCUMENT' AT ','
INTO TABLE DATA(lt_references).
    LOOP AT lt_references INTO DATA(lv_reference).
      SPLIT lv_reference AT ':' INTO DATA(lv_ref_field) DATA(lv_ref_entity).
      DATA(lv_reference_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_ref_field ) ).
      IF lv_reference_id IS INITIAL. CONTINUE. ENDIF.
      IF iv_new = abap_false AND ycl_it_hub_tx=>field( ir_row = lr_old iv_name = lv_ref_field ) = lv_reference_id. CONTINUE. ENDIF.
      DATA(lv_canonical) = ycl_it_hub_tx=>canonical_id( iv_entity = lv_ref_entity iv_id = lv_reference_id ).
      ycl_it_hub_tx=>put( ir_row = ir_row iv_name = lv_ref_field iv_value = lv_canonical ).
    ENDLOOP.
    IF iv_entity = 'COMMENT' OR iv_entity = 'DOCATTACH'.
      DATA(lv_target_type) = to_upper( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ) ).
      DATA(lv_target_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ).
      IF iv_new = abap_true OR ycl_it_hub_tx=>field( ir_row = lr_old iv_name = 'TARGET_ID' ) <> lv_target_id.
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'TARGET_TYPE' iv_value = lv_target_type ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'TARGET_ID' iv_value = ycl_it_hub_tx=>canonical_id( iv_entity = lv_target_type iv_id = lv_target_id ) ).
      ENDIF.
    ENDIF.
    CASE iv_entity.
      WHEN 'PROJECT'.
        DATA(lv_code) = to_upper( ycl_it_hub_policy=>normalize( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'CODE' ) ) ).
        IF lv_code IS INITIAL OR strlen( lv_code ) > 30.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Normalized project code must fit 30 characters and be nonblank.'.
        ENDIF.
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'CODE' iv_value = lv_code ).
      WHEN 'MEMBER'.
        DATA(lv_email) = to_lower( ycl_it_hub_policy=>normalize( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'EMAIL' ) ) ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'EMAIL_NORMALIZED' iv_value = lv_email ).
        DATA(lv_name) = ycl_it_hub_policy=>normalize( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'NAME' ) ).
        SPLIT lv_name AT space INTO TABLE DATA(lt_words).
        DELETE lt_words WHERE table_line IS INITIAL.
        DATA lv_initials TYPE string.
        LOOP AT lt_words INTO DATA(lv_word) TO 2. lv_initials = lv_initials && to_upper( lv_word(1) ). ENDLOOP.
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'INITIALS' iv_value = lv_initials ).
      WHEN 'SKILL'.
        DATA(lv_skill) = to_lower( ycl_it_hub_policy=>normalize( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'NAME' ) ) ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'NAME_NORMALIZED' iv_value = lv_skill ).
      WHEN 'MEMBERSKILL'.
        IF iv_new = abap_true.
          " A new reference uses the existing catalog row's actual key spelling.
          DATA(lr_catalog) = ycl_it_hub_tx=>get( iv_entity = 'SKILL'
            iv_id = CONV #( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'SKILL_ID' ) ) ).
          IF lr_catalog IS BOUND.
            ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'SKILL_ID'
              iv_value = ycl_it_hub_tx=>field( ir_row = lr_catalog iv_name = 'ID' ) ).
          ENDIF.
        ENDIF.
      WHEN 'MEMBERIDENT'.
        DATA(lv_user) = to_upper( ycl_it_hub_policy=>normalize( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'ABAP_USER' ) ) ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'ABAP_USER' iv_value = lv_user ).
      WHEN 'COMMENT'.
        DATA(lv_type) = to_upper( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_TYPE' ) ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'TARGET_TYPE' iv_value = lv_type ).
        DATA(lv_target) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'TARGET_ID' ) ).
        DATA(lr_target) = ycl_it_hub_policy=>target( iv_type = lv_type iv_id = lv_target ).
        DATA(lv_target_project) = COND sysuuid_c36( WHEN lv_type = 'PROJECT' THEN lv_target
          ELSE CONV #( ycl_it_hub_tx=>field( ir_row = lr_target iv_name = 'PROJECT_ID' ) ) ).
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'PROJECT_ID' iv_value = lv_target_project ).
      WHEN 'MILESTONE'.
        DATA(lv_complete) = xsdbool( ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'STATUS' ) = 'COMPLETE' ).
        DATA lv_completed TYPE timestampl.
        IF lv_complete = abap_true.
          lv_completed = ycl_it_hub_tx=>field( ir_row = lr_old iv_name = 'COMPLETED_AT' ).
          IF lv_completed IS INITIAL. GET TIME STAMP FIELD lv_completed. ENDIF.
        ENDIF.
        ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'COMPLETED_AT' iv_value = lv_completed ).
      WHEN 'TASK'.
        IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'BLOCKED' ) <> abap_true.
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'BLOCKED_REASON' iv_value = CONV string( '' ) ).
        ENDIF.
        DATA(lv_actors_json) = ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'IMPLEMENTATION_ACTORS_JSON' ).
        DATA lt_actors TYPE ycl_it_hub_policy=>tt_strings.
        IF lv_actors_json IS NOT INITIAL. lt_actors = ycl_it_hub_policy=>parse_array( iv_json = lv_actors_json ). ENDIF.
        DATA(lv_old_status) = ycl_it_hub_tx=>field( ir_row = lr_old iv_name = 'STATUS' ).
        IF lv_old_status = 'IN_PROGRESS' OR lv_old_status = 'IN_FIX'.
          SPLIT 'TITLE,DESCRIPTION,ESTIMATE_HOURS,BLOCKED,BLOCKED_REASON,IMPACT,RESOLUTION' AT ',' INTO TABLE DATA(lt_work).
          DATA(lv_work_changed) = ycl_it_hub_tx=>in_scope( iv_name = 'IMPLEMENTATION_TASK' iv_id = lv_id ).
          LOOP AT lt_work INTO DATA(lv_work_field).
            IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = lv_work_field ) <> ycl_it_hub_tx=>field( ir_row = lr_old iv_name = lv_work_field ).
              lv_work_changed = abap_true. EXIT.
            ENDIF.
          ENDLOOP.
          IF lv_work_changed = abap_true AND iv_actor IS NOT INITIAL.
            READ TABLE lt_actors TRANSPORTING NO FIELDS WITH KEY table_line = CONV string( iv_actor ).
            IF sy-subrc <> 0. APPEND CONV string( iv_actor ) TO lt_actors. ENDIF.
          ENDIF.
        ENDIF.
        LOOP AT ycl_it_hub_tx=>rows( 'TASK' ) INTO DATA(lr_child).
          IF ycl_it_hub_tx=>field( ir_row = lr_child iv_name = 'PARENT_ID' ) <> lv_id. CONTINUE. ENDIF.
          DATA(lv_child_json) = ycl_it_hub_tx=>field( ir_row = lr_child iv_name = 'IMPLEMENTATION_ACTORS_JSON' ).
          IF lv_child_json IS INITIAL. CONTINUE. ENDIF.
          LOOP AT ycl_it_hub_policy=>parse_array( iv_json = lv_child_json ) INTO DATA(lv_child_actor).
            READ TABLE lt_actors TRANSPORTING NO FIELDS WITH KEY table_line = lv_child_actor.
            IF sy-subrc <> 0. APPEND lv_child_actor TO lt_actors. ENDIF.
          ENDLOOP.
        ENDLOOP.
        IF lines( lt_actors ) > 200.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Parent/child implementation evidence exceeds 200 actors.'.
        ENDIF.
        IF lv_actors_json IS NOT INITIAL OR lt_actors IS NOT INITIAL.
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'IMPLEMENTATION_ACTORS_JSON'
            iv_value = /ui2/cl_json=>serialize( lt_actors ) ).
        ENDIF.
      WHEN 'EVENT'.
        IF ycl_it_hub_tx=>field( ir_row = ir_row iv_name = 'REMINDER_ENABLED' ) <> abap_true.
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'REMINDER_MINUTES' iv_value = 0 ).
        ENDIF.
      WHEN 'DOCUMENT'.
        DATA ls_document TYPE ytb_it_hub_docs.
        MOVE-CORRESPONDING ir_row->* TO ls_document.
        IF ls_document-source_type = 'FILE' AND ls_document-content IS NOT INITIAL.
          DATA(ls_validated) = ycl_it_hub_media=>file( ls_document ).
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'FILE_NAME' iv_value = ls_validated-file_name ).
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'MIME_TYPE' iv_value = ls_validated-mime_type ).
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'MEDIA_KIND' iv_value = ls_validated-media_kind ).
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'BYTE_SIZE' iv_value = ls_validated-byte_size ).
          ycl_it_hub_tx=>put( ir_row = ir_row iv_name = 'CHECKSUM_SHA256' iv_value = ls_validated-checksum_sha256 ).
        ENDIF.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
