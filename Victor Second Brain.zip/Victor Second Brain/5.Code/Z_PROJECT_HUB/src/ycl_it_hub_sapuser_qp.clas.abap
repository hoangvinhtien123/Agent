CLASS ycl_it_hub_sapuser_qp DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.
  PRIVATE SECTION.
    TYPES tt_terms TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    TYPES tt_users TYPE STANDARD TABLE OF yce_it_hub_sapuser WITH EMPTY KEY.
    CLASS-METHODS search_terms IMPORTING iv_expression TYPE string
      RETURNING VALUE(rt_terms) TYPE tt_terms RAISING ycx_it_hub_authctx.
    CLASS-METHODS has_terms IMPORTING is_user TYPE yce_it_hub_sapuser it_terms TYPE tt_terms
      RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS users IMPORTING it_terms TYPE tt_terms
      RETURNING VALUE(rt_users) TYPE tt_users RAISING ycx_it_hub_authctx.
ENDCLASS.

CLASS ycl_it_hub_sapuser_qp IMPLEMENTATION.
  METHOD search_terms.
    " The picker sends a single OData quoted literal, not boolean search syntax.
    DATA(lv_expression) = ycl_it_hub_policy=>normalize( iv_expression ).
    DATA(lv_length) = strlen( lv_expression ).
    DATA lv_phrase TYPE string.
    IF lv_length >= 2 AND lv_expression(1) = '"'.
      DATA(lv_last) = lv_length - 1.
      IF lv_expression+lv_last(1) <> '"'.
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Use one quoted SAP user search phrase.'.
      ENDIF.
      DATA lv_escape TYPE abap_bool.
      DATA lv_index TYPE i VALUE 1.
      WHILE lv_index < lv_last.
        DATA(lv_char) = lv_expression+lv_index(1).
        IF lv_escape = abap_true.
          IF lv_char <> '"' AND lv_char <> '\'.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Invalid SAP user search escape.'.
          ENDIF.
          lv_phrase = lv_phrase && lv_char.
          lv_escape = abap_false.
        ELSEIF lv_char = '\'.
          lv_escape = abap_true.
        ELSEIF lv_char = '"'.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Use one quoted SAP user search phrase.'.
        ELSE.
          lv_phrase = lv_phrase && lv_char.
        ENDIF.
        lv_index = lv_index + 1.
      ENDWHILE.
      IF lv_escape = abap_true.
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Invalid SAP user search escape.'.
      ENDIF.
    ELSE.
      IF lv_expression CS '"' OR lv_expression CS space OR lv_expression CS '\'.
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Use one quoted SAP user search phrase.'.
      ENDIF.
      lv_phrase = lv_expression.
    ENDIF.
    lv_phrase = condense( lv_phrase ).
    IF strlen( lv_phrase ) < 2 OR strlen( lv_phrase ) > 100.
      RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Enter 2 to 100 characters to search SAP users.'.
    ENDIF.
    SPLIT to_upper( lv_phrase ) AT space INTO TABLE rt_terms.
  ENDMETHOD.

  METHOD has_terms.
    rv_yes = abap_false.
    IF it_terms IS INITIAL. RETURN. ENDIF.
    DATA(lv_name) = to_upper( CONV string( is_user-name ) ).
    DATA(lv_login) = to_upper( CONV string( is_user-ntId ) ).
    DATA(lv_email) = to_upper( CONV string( is_user-email ) ).
    LOOP AT it_terms INTO DATA(lv_term).
      IF lv_name NS lv_term AND lv_login NS lv_term AND lv_email NS lv_term. RETURN. ENDIF.
    ENDLOOP.
    rv_yes = abap_true.
  ENDMETHOD.

  METHOD users.
    " Standard ABAP on-premise candidate search. These SAP tables are not
    " released ABAP Cloud APIs. Return canonical address data from the BAPI.
    IF it_terms IS INITIAL.
      RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'An SAP user search phrase is required.'.
    ENDIF.
    DATA(lv_literal) = replace( val = it_terms[ 1 ] sub = '/' with = '//' occ = 0 ).
    lv_literal = replace( val = lv_literal sub = '%' with = '/%' occ = 0 ).
    lv_literal = replace( val = lv_literal sub = '_' with = '/_' occ = 0 ).
    DATA(lv_pattern) = '%' && lv_literal && '%'.
    SELECT DISTINCT account~bname
      FROM usr02 AS account
      LEFT OUTER JOIN usr21 AS address_key ON address_key~bname = account~bname
      LEFT OUTER JOIN adrp AS person ON person~persnumber = address_key~persnumber
      LEFT OUTER JOIN adr6 AS mail ON mail~addrnumber = address_key~addrnumber
        AND mail~persnumber = address_key~persnumber
      WHERE account~ustyp = 'A' AND account~uflag = 0
        AND ( account~gltgv = '00000000' OR account~gltgv <= @sy-datum )
        AND ( account~gltgb = '00000000' OR account~gltgb >= @sy-datum )
        AND ( upper( account~bname ) LIKE @lv_pattern ESCAPE '/'
          OR upper( person~name_text ) LIKE @lv_pattern ESCAPE '/'
          OR upper( person~name_first ) LIKE @lv_pattern ESCAPE '/'
          OR upper( person~name_last ) LIKE @lv_pattern ESCAPE '/'
          OR upper( mail~smtp_addr ) LIKE @lv_pattern ESCAPE '/' )
      ORDER BY account~bname
      INTO TABLE @DATA(lt_candidates) UP TO 1001 ROWS.
    IF lines( lt_candidates ) > 1000.
      " Never return a truncated result with a misleading count.
      RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Too many SAP users match. Start with a more specific name, logon ID or email.'.
    ENDIF.
    SELECT abap_user, member_id FROM ytb_it_hub_midn INTO TABLE @DATA(lt_identities).
    SELECT id, email_normalized FROM ytb_it_hub_memb INTO TABLE @DATA(lt_members).
    SORT lt_identities BY abap_user.
    SORT lt_members BY email_normalized.
    LOOP AT lt_candidates INTO DATA(ls_candidate).
      DATA ls_address TYPE bapiaddr3.
      DATA lt_return TYPE STANDARD TABLE OF bapiret2 WITH EMPTY KEY.
      CLEAR: ls_address, lt_return.
      CALL FUNCTION 'BAPI_USER_GET_DETAIL'
        EXPORTING username = ls_candidate-bname cache_results = space
        IMPORTING address = ls_address
        TABLES return = lt_return.
      LOOP AT lt_return INTO DATA(ls_return) WHERE type = 'E' OR type = 'A' OR type = 'X'.
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'SAP user profile lookup failed. Ask your SAP administrator to check BAPI_USER_GET_DETAIL.'.
      ENDLOOP.
      DATA(lv_name) = condense( CONV string( ls_address-fullname ) ).
      IF lv_name IS INITIAL.
        lv_name = condense( |{ ls_address-firstname } { ls_address-lastname }| ).
      ENDIF.
      DATA(lv_email) = ycl_it_hub_policy=>normalize( CONV string( ls_address-e_mail ) ).
      IF lv_name IS INITIAL OR strlen( lv_name ) > 150 OR strlen( lv_email ) > 254
        OR NOT matches( val = lv_email pcre = '\A[^\s@]+@[^\s@]+\.[^\s@]+\z' ).
        CONTINUE.
      ENDIF.
      " SAP logon ID is the explicitly agreed interim NT-ID source.
      DATA(ls_user) = VALUE yce_it_hub_sapuser(
        id = |SAP:{ ls_candidate-bname }| ntId = ls_candidate-bname
        name = lv_name email = lv_email title = '' team = '' memberId = '' ).
      IF has_terms( is_user = ls_user it_terms = it_terms ) = abap_false. CONTINUE. ENDIF.
      READ TABLE lt_identities INTO DATA(ls_identity) WITH KEY abap_user = ls_candidate-bname BINARY SEARCH.
      IF sy-subrc = 0.
        " Include inactive identities/members: they must not be imported twice.
        ls_user-memberId = ls_identity-member_id.
      ELSE.
        DATA(lv_normalized_email) = to_lower( lv_email ).
        READ TABLE lt_members INTO DATA(ls_member) WITH KEY email_normalized = lv_normalized_email BINARY SEARCH.
        IF sy-subrc = 0. ls_user-memberId = ls_member-id. ENDIF.
      ENDIF.
      APPEND ls_user TO rt_users.
    ENDLOOP.
    SORT rt_users BY name id.
  ENDMETHOD.

  METHOD if_rap_query_provider~select.
    TRY.
        ycl_it_hub_tx=>begin_read( ).
      CATCH ycx_it_hub INTO DATA(lx_read).
        RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = lx_read->text previous = lx_read.
    ENDTRY.
    TRY.
        DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
        IF ls_actor-active = abap_false OR ( ls_actor-admin = abap_false AND ls_actor-manager = abap_false ).
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'You do not have permission to search the SAP user directory.'.
        ENDIF.
        IF to_upper( io_request->get_entity_id( ) ) <> 'YCE_IT_HUB_SAPUSER'
          OR io_request->get_parameters( ) IS NOT INITIAL
          OR io_request->get_filter( )->get_as_sql_string( ) IS NOT INITIAL.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'SAP directory query options are not supported.'.
        ENDIF.
        DATA(lo_aggregation) = io_request->get_aggregation( ).
        IF lo_aggregation IS BOUND.
          IF lo_aggregation->get_aggregated_elements( ) IS NOT INITIAL OR lo_aggregation->get_grouped_elements( ) IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'SAP directory aggregation is not supported.'.
          ENDIF.
        ENDIF.
        LOOP AT io_request->get_requested_elements( ) INTO DATA(lv_field).
          IF lv_field <> '*' AND to_upper( lv_field ) <> 'ID' AND to_upper( lv_field ) <> 'NTID'
            AND to_upper( lv_field ) <> 'NAME' AND to_upper( lv_field ) <> 'EMAIL'
            AND to_upper( lv_field ) <> 'TITLE' AND to_upper( lv_field ) <> 'TEAM'
            AND to_upper( lv_field ) <> 'MEMBERID'.
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'SAP directory fields are not supported.'.
          ENDIF.
        ENDLOOP.
        LOOP AT io_request->get_sort_elements( ) INTO DATA(ls_sort).
          IF ls_sort-descending = abap_true OR sy-tabix > 2
            OR ( sy-tabix = 1 AND to_upper( ls_sort-element_name ) <> 'NAME' )
            OR ( sy-tabix = 2 AND to_upper( ls_sort-element_name ) <> 'ID' ).
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Sort SAP users by name asc,id asc.'.
          ENDIF.
        ENDLOOP.
        DATA(lt_terms) = search_terms( io_request->get_search_expression( ) ).
        DATA(lo_paging) = io_request->get_paging( ).
        DATA(lv_skip) = lo_paging->get_offset( ).
        DATA(lv_top) = lo_paging->get_page_size( ).
        IF lv_top = if_rap_query_paging=>page_size_unlimited. lv_top = 5. ENDIF.
        IF lv_top < 0 OR lv_top > 25 OR lv_skip < 0.
          RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'Use an SAP user page size from 0 to 25 and a nonnegative offset.'.
        ENDIF.
        TRY.
            DATA(lt_users) = users( lt_terms ).
          CATCH cx_sy_open_sql_db INTO DATA(lx_sql).
            RAISE EXCEPTION TYPE ycx_it_hub_authctx EXPORTING iv_text = 'SAP user directory lookup failed. Check the server error log.' previous = lx_sql.
        ENDTRY.
        IF io_request->is_total_numb_of_rec_requested( ).
          io_response->set_total_number_of_records( CONV int8( lines( lt_users ) ) ).
        ENDIF.
        IF io_request->is_data_requested( ).
          DATA lt_page TYPE tt_users.
          IF lv_top > 0 AND lv_skip < lines( lt_users ).
            DATA(lv_first) = CONV i( lv_skip + 1 ).
            DATA(lv_last) = CONV i( lv_skip + lv_top ).
            LOOP AT lt_users INTO DATA(ls_user) FROM lv_first TO lv_last.
              APPEND ls_user TO lt_page.
            ENDLOOP.
          ENDIF.
          io_response->set_data( lt_page ).
        ENDIF.
      CLEANUP.
        ycl_it_hub_tx=>end_read( ).
    ENDTRY.
    ycl_it_hub_tx=>end_read( ).
  ENDMETHOD.
ENDCLASS.
