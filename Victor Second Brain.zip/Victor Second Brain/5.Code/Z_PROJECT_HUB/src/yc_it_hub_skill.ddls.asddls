@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Skill'
define root view entity YC_IT_HUB_SKILL
  provider contract transactional_query
  as projection on YR_IT_HUB_SKILL
{
  key id,
  name,
  nameNormalized,
  description,
  active,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt
}
