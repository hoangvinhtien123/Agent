CLASS ycl_it_hub_media DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    CLASS-METHODS url IMPORTING iv_url TYPE string RAISING ycx_it_hub.
    CLASS-METHODS file IMPORTING is_document TYPE ytb_it_hub_docs
      RETURNING VALUE(rs_document) TYPE ytb_it_hub_docs RAISING ycx_it_hub.
  PRIVATE SECTION.
    CLASS-METHODS u32 IMPORTING iv_bytes TYPE xstring iv_offset TYPE i
      iv_little TYPE abap_bool DEFAULT abap_false RETURNING VALUE(rv_number) TYPE int8 RAISING ycx_it_hub.
    CLASS-METHODS png IMPORTING iv_bytes TYPE xstring RAISING ycx_it_hub.
    CLASS-METHODS crc IMPORTING iv_bytes TYPE xstring RETURNING VALUE(rv_crc) TYPE xstring.
    CLASS-METHODS jpeg IMPORTING iv_bytes TYPE xstring RAISING ycx_it_hub.
    CLASS-METHODS webp IMPORTING iv_bytes TYPE xstring RAISING ycx_it_hub.
    CLASS-METHODS mp4 IMPORTING iv_bytes TYPE xstring iv_nested TYPE abap_bool DEFAULT abap_false
      iv_depth TYPE i DEFAULT 0
      RETURNING VALUE(rv_video) TYPE abap_bool RAISING ycx_it_hub.
    TYPES tt_numbers TYPE SORTED TABLE OF i WITH UNIQUE KEY table_line.
    TYPES: BEGIN OF ty_ebml,
             doctype TYPE abap_bool, segment TYPE abap_bool, tracks TYPE abap_bool, cluster TYPE abap_bool,
             width TYPE abap_bool, height TYPE abap_bool, video_tracks TYPE tt_numbers, block_tracks TYPE tt_numbers,
           END OF ty_ebml.
    CLASS-METHODS ebml IMPORTING iv_bytes TYPE xstring iv_context TYPE string iv_depth TYPE i DEFAULT 0
      RETURNING VALUE(rs_info) TYPE ty_ebml RAISING ycx_it_hub.
    CLASS-METHODS webm IMPORTING iv_bytes TYPE xstring RAISING ycx_it_hub.
ENDCLASS.
CLASS ycl_it_hub_media IMPLEMENTATION.
  METHOD url.
    IF strlen( iv_url ) > 2048 OR contains( val = iv_url pcre = '[\x00-\x20\x7f]|%(?![0-9A-Fa-f]{2})' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid HTTPS URL encoding or length.'.
    ENDIF.
    DATA lv_authority TYPE string.
    FIND FIRST OCCURRENCE OF PCRE '\A(?i:https)://([^/?#]+)(?:[/?#].*)?\z' IN iv_url SUBMATCHES lv_authority.
    IF sy-subrc <> 0 OR lv_authority CS '@'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'An absolute HTTPS URL without credentials is required.'.
    ENDIF.
    DATA: lv_host TYPE string, lv_port TYPE string.
    FIND FIRST OCCURRENCE OF PCRE '\A([A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?)(?::([0-9]{1,5}))?\z'
      IN lv_authority SUBMATCHES lv_host lv_port.
    IF sy-subrc <> 0 OR strlen( lv_host ) > 253
      OR ( lv_port IS NOT INITIAL AND ( CONV i( lv_port ) < 1 OR CONV i( lv_port ) > 65535 ) ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid URL host or port.'.
    ENDIF.
    SPLIT lv_host AT '.' INTO TABLE DATA(lt_labels).
    LOOP AT lt_labels INTO DATA(lv_label).
      IF strlen( lv_label ) > 63 OR NOT matches( val = lv_label pcre = '\A[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\z' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid hostname label.'.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD u32.
    IF iv_offset < 0 OR iv_offset + 4 > xstrlen( iv_bytes ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Truncated media length field.'.
    ENDIF.
    DO 4 TIMES.
      DATA(lv_offset) = iv_offset + COND i( WHEN iv_little = abap_true THEN 4 - sy-index ELSE sy-index - 1 ).
      rv_number = rv_number * 256 + CONV i( iv_bytes+lv_offset(1) ).
    ENDDO.
  ENDMETHOD.
  METHOD crc.
    CONSTANTS lc_polynomial TYPE x LENGTH 4 VALUE 'EDB88320'.
    CONSTANTS lc_final_mask TYPE x LENGTH 4 VALUE 'FFFFFFFF'.
    DATA lv_crc TYPE int8 VALUE 4294967295.
    DATA lv_word TYPE x LENGTH 4.
    DATA lv_low TYPE x LENGTH 1.
    DO xstrlen( iv_bytes ) TIMES.
      DATA(lv_offset) = sy-index - 1.
      lv_low = lv_crc MOD 256.
      lv_low = lv_low BIT-XOR iv_bytes+lv_offset(1).
      lv_crc = ( lv_crc DIV 256 ) * 256 + CONV i( lv_low ).
      DO 8 TIMES.
        DATA(lv_odd) = lv_crc MOD 2.
        lv_crc = lv_crc DIV 2.
        IF lv_odd = 1.
          lv_word = lv_crc.
          lv_word = lv_word BIT-XOR lc_polynomial.
          lv_crc = lv_word.
        ENDIF.
      ENDDO.
    ENDDO.
    lv_word = lv_crc.
    lv_word = lv_word BIT-XOR lc_final_mask.
    rv_crc = lv_word.
  ENDMETHOD.
  METHOD png.
    IF xstrlen( iv_bytes ) < 45 OR iv_bytes(8) <> '89504E470D0A1A0A'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid PNG signature.'.
    ENDIF.
    DATA lv_offset TYPE i VALUE 8.
    DATA lv_idat TYPE abap_bool.
    DATA lv_iend TYPE abap_bool.
    DATA lv_crc_input TYPE xstring.
    DATA lv_stored_crc TYPE x LENGTH 4.
    WHILE lv_offset < xstrlen( iv_bytes ).
      DATA(lv_size) = u32( iv_bytes = iv_bytes iv_offset = lv_offset ).
      IF lv_size > 2147483647 OR lv_offset + lv_size + 12 > xstrlen( iv_bytes ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Truncated PNG chunk.'.
      ENDIF.
      DATA(lv_type_offset) = lv_offset + 4.
      DATA(lv_type) = iv_bytes+lv_type_offset(4).
      DATA(lv_crc_length) = CONV i( lv_size + 4 ).
      DATA(lv_crc_offset) = CONV i( lv_offset + lv_size + 8 ).
      lv_crc_input = iv_bytes+lv_type_offset(lv_crc_length).
      lv_stored_crc = iv_bytes+lv_crc_offset(4).
      IF crc( iv_bytes = lv_crc_input ) <> lv_stored_crc.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'PNG chunk checksum is invalid.'.
      ENDIF.
      IF lv_offset = 8 AND ( lv_type <> '49484452' OR lv_size <> 13
        OR u32( iv_bytes = iv_bytes iv_offset = 16 ) = 0 OR u32( iv_bytes = iv_bytes iv_offset = 20 ) = 0 ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid PNG image header.'.
      ENDIF.
      IF lv_type = '49444154' AND lv_size > 0. lv_idat = abap_true. ENDIF.
      IF lv_type = '49454E44'.
        IF lv_size <> 0 OR lv_offset + 12 <> xstrlen( iv_bytes ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid PNG terminator.'.
        ENDIF.
        lv_iend = abap_true.
      ENDIF.
      lv_offset = lv_offset + lv_size + 12.
    ENDWHILE.
    IF lv_idat = abap_false OR lv_iend = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'PNG requires image data and an IEND chunk.'.
    ENDIF.
  ENDMETHOD.
  METHOD jpeg.
    DATA(lv_length) = xstrlen( iv_bytes ).
    IF lv_length < 12 OR iv_bytes(2) <> 'FFD8'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid JPEG signature.'.
    ENDIF.
    DATA(lv_end) = lv_length - 2.
    IF iv_bytes+lv_end(2) <> 'FFD9'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'JPEG terminator is missing.'.
    ENDIF.
    DATA lv_offset TYPE i VALUE 2.
    DATA lv_frame TYPE abap_bool.
    DATA lv_scan TYPE abap_bool.
    WHILE lv_offset < lv_end.
      IF iv_bytes+lv_offset(1) <> 'FF' OR lv_offset + 4 > lv_end.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid JPEG marker.'.
      ENDIF.
      lv_offset += 1.
      WHILE lv_offset < lv_end AND iv_bytes+lv_offset(1) = 'FF'. lv_offset += 1. ENDWHILE.
      DATA(lv_marker) = CONV i( iv_bytes+lv_offset(1) ).
      lv_offset += 1.
      IF lv_offset + 2 > lv_end.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Truncated JPEG segment.'.
      ENDIF.
      DATA(lv_size) = CONV i( iv_bytes+lv_offset(2) ).
      IF lv_size < 2 OR lv_offset + lv_size > lv_end.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid JPEG segment length.'.
      ENDIF.
      IF lv_marker = 192 OR lv_marker = 193 OR lv_marker = 194.
        DATA(lv_dimensions) = lv_offset + 3.
        IF lv_size < 8 OR iv_bytes+lv_dimensions(4) = '00000000'.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid JPEG frame dimensions.'.
        ENDIF.
        lv_frame = abap_true.
      ENDIF.
      IF lv_marker = 218.
        lv_scan = abap_true.
        EXIT.
      ENDIF.
      lv_offset += lv_size.
    ENDWHILE.
    IF lv_frame = abap_false OR lv_scan = abap_false OR lv_offset >= lv_end.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'JPEG frame/scan data is missing.'.
    ENDIF.
  ENDMETHOD.
  METHOD webp.
    DATA(lv_length) = xstrlen( iv_bytes ).
    IF lv_length < 20 OR iv_bytes(4) <> '52494646' OR iv_bytes+8(4) <> '57454250'
      OR u32( iv_bytes = iv_bytes iv_offset = 4 iv_little = abap_true ) + 8 <> lv_length.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid WebP RIFF container.'.
    ENDIF.
    DATA lv_offset TYPE i VALUE 12.
    DATA lv_image TYPE abap_bool.
    WHILE lv_offset < lv_length.
      DATA(lv_size) = u32( iv_bytes = iv_bytes iv_offset = lv_offset + 4 iv_little = abap_true ).
      IF lv_size > 2147483647 OR lv_offset + 8 + lv_size + lv_size MOD 2 > lv_length.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Truncated WebP chunk.'.
      ENDIF.
      DATA(lv_payload_offset) = lv_offset + 8.
      IF iv_bytes+lv_offset(4) = '56503820'.
        DATA(lv_start_code) = lv_payload_offset + 3.
        IF lv_size < 10 OR CONV i( iv_bytes+lv_payload_offset(1) ) MOD 2 <> 0 OR iv_bytes+lv_start_code(3) <> '9D012A'.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid WebP VP8 key frame.'.
        ENDIF.
        lv_image = abap_true.
      ELSEIF iv_bytes+lv_offset(4) = '5650384C'.
        IF lv_size < 5 OR iv_bytes+lv_payload_offset(1) <> '2F'.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid WebP lossless frame.'.
        ENDIF.
        lv_image = abap_true.
      ENDIF.
      lv_offset = lv_offset + 8 + lv_size + lv_size MOD 2.
    ENDWHILE.
    IF lv_image = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'WebP image chunk is missing.'. ENDIF.
  ENDMETHOD.
  METHOD mp4.
    IF iv_depth > 8. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'MP4 nesting exceeds the supported depth.'. ENDIF.
    DATA lv_offset TYPE i.
    DATA lv_ftyp TYPE abap_bool.
    DATA lv_mdat TYPE abap_bool.
    DATA lv_payload_bytes TYPE xstring.
    WHILE lv_offset < xstrlen( iv_bytes ).
      DATA(lv_size) = u32( iv_bytes = iv_bytes iv_offset = lv_offset ).
      IF lv_size = 0. lv_size = xstrlen( iv_bytes ) - lv_offset. ENDIF.
      IF lv_size < 8 OR lv_size > 2147483647 OR lv_offset + lv_size > xstrlen( iv_bytes ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid or unsupported MP4 box length.'.
      ENDIF.
      DATA(lv_type_offset) = lv_offset + 4.
      DATA(lv_type) = iv_bytes+lv_type_offset(4).
      IF lv_type = '66747970' AND lv_size >= 16. lv_ftyp = abap_true. ENDIF.
      IF lv_type = '6D646174' AND lv_size > 8. lv_mdat = abap_true. ENDIF.
      IF lv_type = '68646C72' AND lv_size >= 24.
        DATA(lv_handler) = lv_offset + 16.
        IF iv_bytes+lv_handler(4) = '76696465'. rv_video = abap_true. ENDIF.
      ENDIF.
      IF lv_type = '6D6F6F76' OR lv_type = '7472616B' OR lv_type = '6D646961'.
        DATA(lv_payload) = lv_offset + 8.
        DATA(lv_payload_length) = CONV i( lv_size - 8 ).
        lv_payload_bytes = iv_bytes+lv_payload(lv_payload_length).
        IF mp4( iv_bytes = lv_payload_bytes iv_nested = abap_true iv_depth = iv_depth + 1 ) = abap_true.
          rv_video = abap_true.
        ENDIF.
      ENDIF.
      lv_offset = lv_offset + lv_size.
    ENDWHILE.
    IF iv_nested = abap_false AND ( lv_ftyp = abap_false OR lv_mdat = abap_false OR rv_video = abap_false ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'MP4 requires ftyp, video track metadata and nonempty media data.'.
    ENDIF.
  ENDMETHOD.
  METHOD ebml.
    IF iv_depth > 6. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'EBML nesting exceeds the supported depth.'. ENDIF.
    DATA lv_offset TYPE i.
    DATA: lv_track TYPE i, lv_track_type TYPE i, lv_codec TYPE abap_bool.
    WHILE lv_offset < xstrlen( iv_bytes ).
      DATA(lv_first) = CONV i( iv_bytes+lv_offset(1) ).
      DATA lv_id_length TYPE i.
      DATA lv_mask TYPE i.
      lv_id_length = 1. lv_mask = 128.
      WHILE lv_mask > 0 AND lv_first < lv_mask. lv_mask = lv_mask DIV 2. lv_id_length += 1. ENDWHILE.
      IF lv_id_length > 4 OR lv_offset + lv_id_length >= xstrlen( iv_bytes ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid EBML element ID.'.
      ENDIF.
      DATA(lv_id) = iv_bytes+lv_offset(lv_id_length).
      lv_offset += lv_id_length.
      lv_first = CONV i( iv_bytes+lv_offset(1) ).
      DATA lv_size_length TYPE i.
      lv_size_length = 1. lv_mask = 128.
      WHILE lv_mask > 0 AND lv_first < lv_mask. lv_mask = lv_mask DIV 2. lv_size_length += 1. ENDWHILE.
      IF lv_size_length > 8 OR lv_offset + lv_size_length > xstrlen( iv_bytes ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid EBML element size.'.
      ENDIF.
      DATA(lv_size) = CONV int8( lv_first - lv_mask ).
      DATA(lv_unknown) = xsdbool( lv_first - lv_mask = lv_mask - 1 ).
      DO lv_size_length - 1 TIMES.
        DATA(lv_byte_offset) = lv_offset + sy-index.
        DATA(lv_byte) = CONV i( iv_bytes+lv_byte_offset(1) ).
        IF lv_byte <> 255. lv_unknown = abap_false. ENDIF.
        IF lv_size <= 2147483647. lv_size = lv_size * 256 + lv_byte. ENDIF.
      ENDDO.
      lv_offset += lv_size_length.
      IF lv_unknown = abap_true.
        IF iv_context <> 'ROOT' OR lv_id <> '18538067'.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Only the outer WebM Segment may have unknown length.'.
        ENDIF.
        lv_size = xstrlen( iv_bytes ) - lv_offset.
      ENDIF.
      IF lv_size > 2147483647 OR lv_offset + lv_size > xstrlen( iv_bytes ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Truncated EBML element.'.
      ENDIF.
      DATA(lv_length) = CONV i( lv_size ).
      DATA(lv_payload) = iv_bytes+lv_offset(lv_length).
      DATA lv_child_context TYPE string.
      CLEAR lv_child_context.
      CASE iv_context.
        WHEN 'ROOT'.
          IF lv_id = '1A45DFA3'. lv_child_context = 'HEADER'.
          ELSEIF lv_id = '18538067'. lv_child_context = 'SEGMENT'. rs_info-segment = abap_true. ENDIF.
        WHEN 'HEADER'.
          IF lv_id = '4282'.
            IF lv_payload <> '7765626D'. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'EBML DocType must be webm.'. ENDIF.
            rs_info-doctype = abap_true.
          ENDIF.
        WHEN 'SEGMENT'.
          IF lv_id = '1654AE6B'. lv_child_context = 'TRACKS'. rs_info-tracks = abap_true.
          ELSEIF lv_id = '1F43B675'. lv_child_context = 'CLUSTER'. rs_info-cluster = abap_true. ENDIF.
        WHEN 'TRACKS'.
          IF lv_id = 'AE'. lv_child_context = 'ENTRY'. ENDIF.
        WHEN 'ENTRY'.
          IF lv_id = 'E0'. lv_child_context = 'VIDEO'.
          ELSEIF lv_id = 'D7' OR lv_id = '83'.
            IF lv_length < 1 OR lv_length > 4. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid WebM track identifier/type.'. ENDIF.
            IF lv_id = 'D7'. lv_track = lv_payload. ELSE. lv_track_type = lv_payload. ENDIF.
          ELSEIF lv_id = '86'.
            lv_codec = xsdbool( lv_payload = '565F565038' OR lv_payload = '565F565039' OR lv_payload = '565F415631' ).
          ENDIF.
        WHEN 'VIDEO'.
          IF lv_id = 'B0' OR lv_id = 'BA'.
            IF lv_length < 1 OR lv_length > 4 OR CONV int8( lv_payload ) = 0.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'WebM video dimensions must be positive.'.
            ENDIF.
            IF lv_id = 'B0'. rs_info-width = abap_true. ELSE. rs_info-height = abap_true. ENDIF.
          ENDIF.
        WHEN 'CLUSTER'.
          IF lv_id = 'A0'. lv_child_context = 'GROUP'. ENDIF.
      ENDCASE.
      IF ( iv_context = 'CLUSTER' AND lv_id = 'A3' ) OR ( iv_context = 'GROUP' AND lv_id = 'A1' ).
        IF lv_length < 5. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'WebM block payload is missing.'. ENDIF.
        lv_first = CONV i( lv_payload(1) ). lv_mask = 128.
        DATA lv_track_length TYPE i.
        lv_track_length = 1.
        WHILE lv_mask > 0 AND lv_first < lv_mask. lv_mask = lv_mask DIV 2. lv_track_length += 1. ENDWHILE.
        IF lv_track_length > 4 OR lv_track_length + 3 >= lv_length.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid WebM block track/timecode/payload.'.
        ENDIF.
        DATA(lv_block_track) = lv_first - lv_mask.
        DO lv_track_length - 1 TIMES.
          DATA(lv_track_offset) = sy-index.
          lv_block_track = lv_block_track * 256 + CONV i( lv_payload+lv_track_offset(1) ).
        ENDDO.
        IF lv_block_track < 1. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'WebM block requires a track number.'. ENDIF.
        INSERT lv_block_track INTO TABLE rs_info-block_tracks.
      ENDIF.
      IF lv_child_context IS NOT INITIAL.
        DATA(ls_child) = ebml( iv_bytes = lv_payload iv_context = lv_child_context iv_depth = iv_depth + 1 ).
        rs_info-doctype = xsdbool( rs_info-doctype = abap_true OR ls_child-doctype = abap_true ).
        rs_info-width = xsdbool( rs_info-width = abap_true OR ls_child-width = abap_true ).
        rs_info-height = xsdbool( rs_info-height = abap_true OR ls_child-height = abap_true ).
        rs_info-tracks = xsdbool( rs_info-tracks = abap_true OR ls_child-tracks = abap_true ).
        rs_info-cluster = xsdbool( rs_info-cluster = abap_true OR ls_child-cluster = abap_true ).
        INSERT LINES OF ls_child-video_tracks INTO TABLE rs_info-video_tracks.
        INSERT LINES OF ls_child-block_tracks INTO TABLE rs_info-block_tracks.
      ENDIF.
      lv_offset += lv_length.
    ENDWHILE.
    IF iv_context = 'ENTRY' AND lv_track_type = 1.
      IF lv_track < 1 OR lv_codec = abap_false OR rs_info-width = abap_false OR rs_info-height = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'WebM video track requires number, supported codec and dimensions.'.
      ENDIF.
      INSERT lv_track INTO TABLE rs_info-video_tracks.
    ENDIF.
  ENDMETHOD.
  METHOD webm.
    IF xstrlen( iv_bytes ) < 32 OR iv_bytes(4) <> '1A45DFA3'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid WebM EBML signature.'.
    ENDIF.
    DATA(ls_info) = ebml( iv_bytes = iv_bytes iv_context = 'ROOT' ).
    DATA(lv_video_data) = abap_false.
    LOOP AT ls_info-video_tracks INTO DATA(lv_track).
      READ TABLE ls_info-block_tracks TRANSPORTING NO FIELDS WITH TABLE KEY table_line = lv_track.
      IF sy-subrc = 0. lv_video_data = abap_true. EXIT. ENDIF.
    ENDLOOP.
    IF ls_info-doctype = abap_false OR ls_info-segment = abap_false OR ls_info-tracks = abap_false
      OR ls_info-cluster = abap_false OR lv_video_data = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'WebM requires DocType, Segment, video track and matching media blocks.'.
    ENDIF.
  ENDMETHOD.
  METHOD file.
    rs_document = is_document.
    DATA(lv_mime) = to_lower( is_document-mime_type ).
    IF lv_mime <> 'image/jpeg' AND lv_mime <> 'image/png' AND lv_mime <> 'image/webp'
      AND lv_mime <> 'video/mp4' AND lv_mime <> 'video/webm'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Unsupported file MIME type.'.
    ENDIF.
    SELECT SINGLE value FROM ytb_it_hub_cfg WHERE kind = 'MIME_LIMIT' AND name = @lv_mime AND active = @abap_true INTO @DATA(lv_limit).
    IF sy-subrc <> 0 OR NOT matches( val = CONV string( lv_limit ) pcre = '\A[1-9][0-9]{0,9}\s*\z' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A tested positive size limit must be configured for this MIME type.'.
    ENDIF.
    DATA(lv_size) = xstrlen( is_document-content ).
    IF lv_size = 0 OR lv_size > CONV int8( lv_limit ) OR lv_size > 2147483647.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'File is empty or exceeds its configured limit.'.
    ENDIF.
    TRY.
    CASE lv_mime.
      WHEN 'image/jpeg'. jpeg( is_document-content ).
      WHEN 'image/png'. png( is_document-content ).
      WHEN 'image/webp'. webp( is_document-content ).
      WHEN 'video/mp4'. DATA(lv_video) = mp4( iv_bytes = is_document-content ).
      WHEN 'video/webm'. webm( is_document-content ).
    ENDCASE.
      CATCH cx_sy_conversion_overflow cx_sy_range_out_of_bounds.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Media contains an invalid numeric field or truncated payload.'.
    ENDTRY.
    rs_document-file_name = replace( val = is_document-file_name pcre = '[\\/\x00-\x1f\x7f]' with = '_' occ = 0 ).
    IF rs_document-file_name IS INITIAL OR rs_document-file_name = '.' OR rs_document-file_name = '..'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A safe download filename is required.'.
    ENDIF.
    TRY.
        cl_abap_message_digest=>calculate_hash_for_raw(
          EXPORTING if_algorithm = 'SHA-256' if_data = is_document-content
          IMPORTING ef_hashstring = DATA(lv_hash) ).
      CATCH cx_abap_message_digest.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'SHA-256 could not be calculated.'.
    ENDTRY.
    IF strlen( lv_hash ) <> 64. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Invalid SHA-256 result.'. ENDIF.
    rs_document-checksum_sha256 = to_lower( lv_hash ).
    rs_document-byte_size = lv_size.
    rs_document-mime_type = lv_mime.
    rs_document-media_kind = COND #( WHEN lv_mime CP 'image/*' THEN 'IMAGE' ELSE 'VIDEO' ).
  ENDMETHOD.
ENDCLASS.
