CLASS lhc_Member DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Member RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Member RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Member RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE Member.

    METHODS precheck_create FOR PRECHECK
      IMPORTING entities FOR CREATE Member.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Member.

    METHODS earlynumbering_cba_Skills FOR NUMBERING
      IMPORTING entities FOR CREATE Member\Skills.

    METHODS precheck_cba_Skills FOR PRECHECK
      IMPORTING entities FOR CREATE Member\Skills.

    METHODS earlynumbering_cba_Identity FOR NUMBERING
      IMPORTING entities FOR CREATE Member\_Identity.

    METHODS precheck_cba_Identity FOR PRECHECK
      IMPORTING entities FOR CREATE Member\_Identity.

    METHODS Deactivate FOR MODIFY
      IMPORTING keys FOR ACTION Member~Deactivate RESULT result.

    METHODS Reactivate FOR MODIFY
      IMPORTING keys FOR ACTION Member~Reactivate RESULT result.

    METHODS ReplaceSkills FOR MODIFY
      IMPORTING keys FOR ACTION Member~ReplaceSkills RESULT result.

    METHODS SetAppManager FOR MODIFY
      IMPORTING keys FOR ACTION Member~SetAppManager RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Member~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Member~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Member~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Member~TouchGoverned.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Member~TouchOnSave.
    METHODS SaveProfile FOR MODIFY IMPORTING keys FOR ACTION Member~SaveProfile RESULT result.
ENDCLASS.

CLASS lhc_Member IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Deactivate = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Reactivate = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-SetAppManager = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-ReplaceSkills = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-Skills = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-_Identity = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Deactivate = COND #( WHEN xsdbool( ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'DEACTIVATE' ir_row = REF #( ls_db ) ) = abap_true AND ls_db-active = abap_true ) = abap_true THEN if_abap_behv=>fc-o-enabled
ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Reactivate = COND #( WHEN xsdbool( ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'REACTIVATE' ir_row = REF #( ls_db ) ) = abap_true AND ls_db-active = abap_false ) = abap_true THEN if_abap_behv=>fc-o-enabled
ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-SetAppManager = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'SETAPPMANAGER' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-ReplaceSkills = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'REPLACESKILLS' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_memberskill TYPE ytb_it_hub_mskil.
      ls_cba_memberskill-member_id = ls_db-id.
      <result>-%features-%assoc-Skills = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_cba_memberskill ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_memberident TYPE ytb_it_hub_midn.
      ls_cba_memberident-member_id = ls_db-id.
      <result>-%features-%assoc-_Identity = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_cba_memberident ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF requested_authorizations-%update = if_abap_behv=>mk-on.
     <result>-%update = COND #( WHEN lv_found = abap_true AND ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Deactivate = if_abap_behv=>mk-on.
     <result>-%action-Deactivate = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'DEACTIVATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized )
.
     ENDIF.
     IF requested_authorizations-%action-Reactivate = if_abap_behv=>mk-on.
     <result>-%action-Reactivate = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'REACTIVATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized )
.
     ENDIF.
     IF requested_authorizations-%action-SetAppManager = if_abap_behv=>mk-on.
     <result>-%action-SetAppManager = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'SETAPPMANAGER' ir_row = REF #( ls_db ) ) = abap_true
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-ReplaceSkills = if_abap_behv=>mk-on.
     <result>-%action-ReplaceSkills = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'REPLACESKILLS' ir_row = REF #( ls_db ) ) = abap_true
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%create = if_abap_behv=>mk-on.
     result-%create = COND #( WHEN ls_actor-active = abap_true AND ls_actor-admin = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%update = if_abap_behv=>mk-on.
     result-%update = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Deactivate = if_abap_behv=>mk-on.
     result-%action-Deactivate = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Reactivate = if_abap_behv=>mk-on.
     result-%action-Reactivate = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-SetAppManager = if_abap_behv=>mk-on.
     result-%action-SetAppManager = COND #( WHEN xsdbool( ls_actor-active = abap_true AND ls_actor-admin = abap_true ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-ReplaceSkills = if_abap_behv=>mk-on.
     result-%action-ReplaceSkills = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD earlynumbering_create.
    LOOP AT entities INTO DATA(ls_entity).
      DATA(lv_id) = ls_entity-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_MEMBER' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-member.
        APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-member.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_MEMBER' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'MEMBER' iv_id = lv_id is_control = ls_entity-%control ).
          APPEND VALUE #( %cid = ls_entity-%cid id = lv_id ) TO mapped-member.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-member.
          APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Member identifier.' ) ) TO reported-member.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_create.
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_entity MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      name TYPE abp_behv_flag,
      email TYPE abp_behv_flag,
      email_normalized TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      team TYPE abp_behv_flag,
      initials TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      is_app_manager TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      name = ls_entity-%control-name
      email = ls_entity-%control-email
      email_normalized = ls_entity-%control-emailNormalized
      title = ls_entity-%control-title
      team = ls_entity-%control-team
      initials = ls_entity-%control-initials
      active = ls_entity-%control-active
      is_app_manager = ls_entity-%control-isAppManager
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBER' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-member.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-name = if_abap_behv=>mk-on. ls_db-name = ls_entity-name. ENDIF.
     IF ls_entity-%control-email = if_abap_behv=>mk-on. ls_db-email = ls_entity-email. ENDIF.
     IF ls_entity-%control-emailNormalized = if_abap_behv=>mk-on. ls_db-email_normalized = ls_entity-emailNormalized. ENDIF.
     IF ls_entity-%control-title = if_abap_behv=>mk-on. ls_db-title = ls_entity-title. ENDIF.
     IF ls_entity-%control-team = if_abap_behv=>mk-on. ls_db-team = ls_entity-team. ENDIF.
     IF ls_entity-%control-initials = if_abap_behv=>mk-on. ls_db-initials = ls_entity-initials. ENDIF.
     IF ls_entity-%control-active = if_abap_behv=>mk-on. ls_db-active = ls_entity-active. ENDIF.
     IF ls_entity-%control-isAppManager = if_abap_behv=>mk-on. ls_db-is_app_manager = ls_entity-isAppManager. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      name TYPE abp_behv_flag,
      email TYPE abp_behv_flag,
      email_normalized TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      team TYPE abp_behv_flag,
      initials TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      is_app_manager TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      name = ls_entity-%control-name
      email = ls_entity-%control-email
      email_normalized = ls_entity-%control-emailNormalized
      title = ls_entity-%control-title
      team = ls_entity-%control-team
      initials = ls_entity-%control-initials
      active = ls_entity-%control-active
      is_app_manager = ls_entity-%control-isAppManager
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBER' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_memb.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Skills.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_MEMBERSKILL' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-memberskill.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-memberskill.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_MEMBERSKILL' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'MEMBERSKILL' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-memberskill.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-memberskill.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a MemberSkill identifier.' ) ) TO reported-memberskill.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Skills.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_entity MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-member_id = ls_source-id.
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      member_id TYPE abp_behv_flag,
      skill_id TYPE abp_behv_flag,
      proficiency TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      member_id = ls_entity-%control-memberId
      skill_id = ls_entity-%control-skillId
      proficiency = ls_entity-%control-proficiency
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-memberskill.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberskill.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Identity.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_MEMBERIDENT' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-memberident.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-memberident.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_MEMBERIDENT' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'MEMBERIDENT' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-memberident.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-memberident.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a MemberIdent identifier.' ) ) TO reported-memberident.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Identity.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_entity MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-member_id = ls_source-id.
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      member_id TYPE abp_behv_flag,
      abap_user TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      member_id = ls_entity-%control-memberId
      abap_user = ls_entity-%control-abapUser
      active = ls_entity-%control-active
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-memberident.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberident.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD Deactivate.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'DEACTIVATE' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'DEACTIVATE' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'MEMBER' iv_id = ls_db-id iv_action = 'DEACTIVATE' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'MEMBER' iv_id = ls_db-id ).
     ls_db-active = abap_false.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-member TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD Reactivate.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'REACTIVATE' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'REACTIVATE' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'MEMBER' iv_id = ls_db-id iv_action = 'REACTIVATE' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'MEMBER' iv_id = ls_db-id ).
     ls_db-active = abap_true.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-member TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD ReplaceSkills.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'REPLACESKILLS' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'REPLACESKILLS' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'MEMBER' iv_id = ls_db-id iv_action = 'REPLACE_SKILLS' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'MEMBER' iv_id = ls_db-id ).
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member BY \skills
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_children).
    DATA lt_delete TYPE TABLE FOR DELETE YR_IT_HUB_MEMBER\\MemberSkill.
    DATA lt_create TYPE TABLE FOR CREATE YR_IT_HUB_MEMBER\skills.
    CLEAR: lt_delete, lt_create.
    DATA(lt_input) = ycl_it_hub_policy=>parse_skills( ls_key-%param-skillsJson ).
    DATA lt_desired TYPE STANDARD TABLE OF ytb_it_hub_mskil WITH EMPTY KEY.
    CLEAR lt_desired.

    LOOP AT lt_input INTO DATA(ls_input).
      DATA(lv_name) = to_lower( ycl_it_hub_policy=>normalize( ls_input-name ) ).
      DATA(lv_catalog_found) = abap_false.
      LOOP AT ycl_it_hub_tx=>rows( 'SKILL' ) INTO DATA(lr_catalog).
        IF ycl_it_hub_tx=>field( ir_row = lr_catalog iv_name = 'NAME_NORMALIZED' ) <> lv_name. CONTINUE. ENDIF.
        DATA(lv_skill_id) = CONV sysuuid_c36( ycl_it_hub_tx=>field( ir_row = lr_catalog iv_name = 'ID' ) ).
        DATA(lv_existing) = abap_false.
        LOOP AT lt_children INTO DATA(ls_existing_skill) WHERE skillId = lv_skill_id.
          lv_existing = abap_true.
          IF ycl_it_hub_tx=>field( ir_row = lr_catalog iv_name = 'ACTIVE' ) <> abap_true
            AND ls_existing_skill-proficiency <> ls_input-proficiency.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Retired assignments must remain unchanged.'.
          ENDIF.
        ENDLOOP.
        IF lv_existing = abap_false AND ycl_it_hub_tx=>field( ir_row = lr_catalog iv_name = 'ACTIVE' ) <> abap_true.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot introduce a retired skill.'.
        ENDIF.
        APPEND VALUE #( skill_id = lv_skill_id proficiency = ls_input-proficiency ) TO lt_desired.
        lv_catalog_found = abap_true.
        EXIT.
      ENDLOOP.
      IF lv_catalog_found = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Unknown catalog skill; replacement never creates catalog entries.'. ENDIF.
    ENDLOOP.
    DATA lt_child_updates TYPE TABLE FOR UPDATE YR_IT_HUB_MEMBER\\MemberSkill.
    CLEAR lt_child_updates.
    LOOP AT lt_children INTO DATA(ls_skill_child).
      DATA(lv_keep_skill) = abap_false.
      LOOP AT lt_desired INTO DATA(ls_desired_skill) WHERE skill_id = ls_skill_child-skillId.
        lv_keep_skill = abap_true.
        IF ls_desired_skill-proficiency <> ls_skill_child-proficiency.
          APPEND VALUE #( id = ls_skill_child-id proficiency = ls_desired_skill-proficiency %control-proficiency = if_abap_behv=>mk-on ) TO lt_child_updates.
        ENDIF.
      ENDLOOP.
      IF lv_keep_skill = abap_false. APPEND VALUE #( id = ls_skill_child-id ) TO lt_delete. ENDIF.
    ENDLOOP.
    APPEND VALUE #( id = ls_db-id ) TO lt_create ASSIGNING FIELD-SYMBOL(<source>).
    LOOP AT lt_desired INTO DATA(ls_desired).
      DATA(lv_has_skill) = abap_false.
      LOOP AT lt_children TRANSPORTING NO FIELDS WHERE skillId = ls_desired-skill_id. lv_has_skill = abap_true. EXIT. ENDLOOP.
      IF lv_has_skill = abap_false.
        APPEND VALUE #( %cid = |SKILL_{ ls_desired-skill_id }| skillId = ls_desired-skill_id proficiency = ls_desired-proficiency
          %control-skillId = if_abap_behv=>mk-on %control-proficiency = if_abap_behv=>mk-on ) TO <source>-%target.
      ENDIF.
    ENDLOOP.
    LOOP AT lt_delete INTO DATA(ls_delete_key).
      READ TABLE lt_children INTO DATA(ls_deleted_child) WITH TABLE KEY entity COMPONENTS id = ls_delete_key-id.
      DATA ls_deleted_db TYPE ytb_it_hub_mskil.
    ls_deleted_db = CORRESPONDING #( ls_deleted_child MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ycl_it_hub_tx=>stage_delete( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_deleted_db ) iv_actor = ls_actor-id ).
    ENDLOOP.
    MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill DELETE FROM lt_delete
      ENTITY MemberSkill UPDATE FROM lt_child_updates
      ENTITY Member CREATE BY \skills FROM lt_create
      FAILED DATA(ls_replace_failed) REPORTED DATA(ls_replace_reported).
    ls_messages = CORRESPONDING #( DEEP ls_replace_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
    IF ls_replace_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Replacement failed; no part of the replacement may be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    LOOP AT lt_delete INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'MEMBERSKILL' iv_id = ls_removed_key-id ).
    ENDLOOP.

    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'MEMBER' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-member TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD SetAppManager.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'MEMBER' iv_operation = 'SETAPPMANAGER' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'SETAPPMANAGER' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'MEMBER' iv_id = ls_db-id iv_action = 'SET_APP_MANAGER' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'MEMBER' iv_id = ls_db-id ).
     IF ls_key-%param-enabled <> abap_true AND ls_key-%param-enabled <> abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'enabled must be a boolean.'. ENDIF.
     ls_db-is_app_manager = ls_key-%param-enabled.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-member TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBER' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBER' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBER' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_MEMBER' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'MEMBER' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY Member ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_MEMBER' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_memb.
    ls_db = CORRESPONDING #( ls_row MAPPING email_normalized = emailNormalized is_app_manager = isAppManager created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'MEMBER' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-email <> ls_db-email. ls_update-email = ls_db-email. ls_update-%control-email = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-emailNormalized <> ls_db-email_normalized. ls_update-emailNormalized = ls_db-email_normalized. ls_update-%control-emailNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-team <> ls_db-team. ls_update-team = ls_db-team. ls_update-%control-team = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-initials <> ls_db-initials. ls_update-initials = ls_db-initials. ls_update-%control-initials = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isAppManager <> ls_db-is_app_manager. ls_update-isAppManager = ls_db-is_app_manager. ls_update-%control-isAppManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY Member UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-member.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-member.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD SaveProfile.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_tx=>lock( ).
          DATA(lt_desired) = ycl_it_hub_policy=>parse_skills( iv_json = ls_key-%param-skillsJson ).
          DATA lt_update TYPE TABLE FOR UPDATE yr_it_hub_member\\Member.
          CLEAR lt_update.
          APPEND VALUE #( %tky = ls_key-%tky ) TO lt_update ASSIGNING FIELD-SYMBOL(<update>).
          ycl_it_hub_policy=>apply_profile( iv_json = ls_key-%param-profileJson
            iv_fields = 'name,email,title,team,active' ir_update = REF #( <update> ) ).
          " Use normal EML so profile prechecks, features and authorization run.
          IF <update>-%control IS NOT INITIAL.
            MODIFY ENTITIES OF yr_it_hub_member ENTITY Member UPDATE FROM lt_update
              FAILED DATA(ls_update_failed) REPORTED DATA(ls_update_reported).
            LOOP AT ls_update_reported-member INTO DATA(ls_message).
              APPEND CORRESPONDING #( ls_message ) TO reported-member.
            ENDLOOP.
            IF ls_update_failed IS NOT INITIAL.
              RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Profile update failed; no detail changes were saved.'.
            ENDIF.
          ENDIF.
          MODIFY ENTITIES OF yr_it_hub_member ENTITY Member EXECUTE ReplaceSkills
            FROM VALUE #( ( id = ls_key-id %param-skillsJson = ls_key-%param-skillsJson ) )
            FAILED DATA(ls_related_failed) REPORTED DATA(ls_related_reported).
          LOOP AT ls_related_reported-member INTO DATA(ls_related_message).
            APPEND CORRESPONDING #( ls_related_message ) TO reported-member.
          ENDLOOP.
          IF ls_related_failed IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Related collection failed; no detail changes were saved.'.
          ENDIF.
          READ ENTITIES OF yr_it_hub_member IN LOCAL MODE ENTITY Member
            ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_after).
          READ TABLE lt_after INTO DATA(ls_after) INDEX 1.
          IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Saved detail could not be read.'. ENDIF.
          APPEND VALUE #( %tky = ls_key-%tky %param = ls_after ) TO result.
        CATCH ycx_it_hub INTO DATA(lx_detail).
          ycl_it_hub_tx=>fail( lx_detail->text ).
          APPEND VALUE #( %tky = ls_key-%tky ) TO failed-member.
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_detail->text ) ) TO reported-member.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_MemberIdent DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR MemberIdent RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE MemberIdent.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE MemberIdent.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR MemberIdent~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR MemberIdent~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR MemberIdent~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR MemberIdent~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR MemberIdent~validate_delete.
ENDCLASS.

CLASS lhc_MemberIdent IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberIdent ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERIDENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERIDENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberIdent ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-memberId = if_abap_behv=>mk-on. ls_db-member_id = ls_entity-memberId. ENDIF.
     IF ls_entity-%control-abapUser = if_abap_behv=>mk-on. ls_db-abap_user = ls_entity-abapUser. ENDIF.
     IF ls_entity-%control-active = if_abap_behv=>mk-on. ls_db-active = ls_entity-active. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      member_id TYPE abp_behv_flag,
      abap_user TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      member_id = ls_entity-%control-memberId
      abap_user = ls_entity-%control-abapUser
      active = ls_entity-%control-active
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERIDENT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_midn.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERIDENT' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-memberident.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberident.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberIdent ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERIDENT' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_midn.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERIDENT' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-memberident.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberident.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberIdent ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBERIDENT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER\\MemberIdent.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-abapUser <> ls_db-abap_user. ls_update-abapUser = ls_db-abap_user. ls_update-%control-abapUser = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY MemberIdent UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberident.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberIdent ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBERIDENT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER\\MemberIdent.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-abapUser <> ls_db-abap_user. ls_update-abapUser = ls_db-abap_user. ls_update-%control-abapUser = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY MemberIdent UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberident.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberIdent ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_midn.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId abap_user = abapUser created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-memberident.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberident.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'MEMBERIDENT' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-memberident.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'MEMBERIDENT' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'MEMBERIDENT' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'MEMBERIDENT' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-memberident.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-memberident.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_MemberSkill DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR MemberSkill RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE MemberSkill.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE MemberSkill.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR MemberSkill~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR MemberSkill~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR MemberSkill~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR MemberSkill~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR MemberSkill~validate_delete.
ENDCLASS.

CLASS lhc_MemberSkill IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSKILL' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-memberId = if_abap_behv=>mk-on. ls_db-member_id = ls_entity-memberId. ENDIF.
     IF ls_entity-%control-skillId = if_abap_behv=>mk-on. ls_db-skill_id = ls_entity-skillId. ENDIF.
     IF ls_entity-%control-proficiency = if_abap_behv=>mk-on. ls_db-proficiency = ls_entity-proficiency. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      member_id TYPE abp_behv_flag,
      skill_id TYPE abp_behv_flag,
      proficiency TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      member_id = ls_entity-%control-memberId
      skill_id = ls_entity-%control-skillId
      proficiency = ls_entity-%control-proficiency
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_mskil.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-memberskill.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberskill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSKILL' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_mskil.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSKILL' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-memberskill.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberskill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBERSKILL' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER\\MemberSkill.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-skillId <> ls_db-skill_id. ls_update-skillId = ls_db-skill_id. ls_update-%control-skillId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-proficiency <> ls_db-proficiency. ls_update-proficiency = ls_db-proficiency. ls_update-%control-proficiency = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY MemberSkill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberskill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBERSKILL' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_MEMBER\\MemberSkill.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-skillId <> ls_db-skill_id. ls_update-skillId = ls_db-skill_id. ls_update-%control-skillId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-proficiency <> ls_db-proficiency. ls_update-proficiency = ls_db-proficiency. ls_update-%control-proficiency = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE ENTITY MemberSkill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-member TO reported-member.
    APPEND LINES OF ls_messages-memberident TO reported-memberident.
    APPEND LINES OF ls_messages-memberskill TO reported-memberskill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberskill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_MEMBER IN LOCAL MODE
      ENTITY MemberSkill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mskil.
    ls_db = CORRESPONDING #( ls_row MAPPING member_id = memberId skill_id = skillId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-memberskill.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-memberskill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'MEMBERSKILL' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-memberskill.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'MEMBERSKILL' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'MEMBERSKILL' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'MEMBERSKILL' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-memberskill.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-memberskill.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_YR_IT_HUB_MEMBER DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_YR_IT_HUB_MEMBER IMPLEMENTATION.
  METHOD save_modified.
    ycl_it_hub_tx=>save( iv_owner = 'MEMBER' is_create = create is_update = update is_delete = delete ).
  ENDMETHOD.

  METHOD cleanup.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD cleanup_finalize.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

ENDCLASS.
