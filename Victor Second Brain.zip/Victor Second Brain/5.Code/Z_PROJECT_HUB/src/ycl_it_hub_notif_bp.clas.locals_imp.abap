CLASS lcl_inbox DEFINITION FINAL.
  PUBLIC SECTION.
    CLASS-DATA pending TYPE HASHED TABLE OF ytb_it_hub_notf WITH UNIQUE KEY client id.
    CLASS-METHODS stage IMPORTING is_row TYPE ytb_it_hub_notf.
    CLASS-METHODS get IMPORTING iv_id TYPE sysuuid_c36 RETURNING VALUE(rs_row) TYPE ytb_it_hub_notf RAISING ycx_it_hub.
    CLASS-METHODS visible IMPORTING is_row TYPE ytb_it_hub_notf is_actor TYPE ycl_it_hub_policy=>ty_actor
      iv_now TYPE timestampl iv_project_read TYPE abap_bool RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS stamp IMPORTING is_row TYPE ytb_it_hub_notf iv_now TYPE timestampl RETURNING VALUE(rs_row) TYPE ytb_it_hub_notf.
    CLASS-METHODS entity IMPORTING is_row TYPE ytb_it_hub_notf RETURNING VALUE(rs_entity) TYPE yce_it_hub_notifications.
ENDCLASS.
CLASS lcl_inbox IMPLEMENTATION.
  METHOD stage.
    DELETE TABLE pending WITH TABLE KEY client = is_row-client id = is_row-id.
    INSERT is_row INTO TABLE pending.
  ENDMETHOD.
  METHOD visible.
    IF is_actor-active = abap_false OR is_actor-id IS INITIAL OR is_row-client <> sy-mandt
      OR to_upper( is_row-recipient_id ) <> to_upper( is_actor-id ) OR iv_project_read = abap_false. RETURN. ENDIF.
    TRY.
        DATA(lv_cutoff) = cl_abap_tstmp=>subtractsecs( tstmp = iv_now secs = 7776000 ).
        rv_yes = xsdbool( is_row-created_at >= lv_cutoff AND is_row-created_at <= iv_now ).
      CATCH cx_root.
        rv_yes = abap_false.
    ENDTRY.
  ENDMETHOD.
  METHOD get.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA(lv_id) = to_lower( iv_id ).
    SELECT SINGLE * FROM ytb_it_hub_notf WHERE lower( id ) = @lv_id INTO @rs_row.
    IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Notification is unavailable.'. ENDIF.
    READ TABLE pending INTO DATA(ls_pending) WITH TABLE KEY client = sy-mandt id = rs_row-id.
    IF sy-subrc = 0. rs_row = ls_pending. ENDIF.
    DATA lv_now TYPE timestampl.
    GET TIME STAMP FIELD lv_now.
    DATA(ls_rights) = ycl_it_hub_policy=>permissions( iv_project = CONV #( rs_row-project_id ) ).
    IF visible( is_row = rs_row is_actor = ls_actor iv_now = lv_now iv_project_read = ls_rights-read ) = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Notification is unavailable.'.
    ENDIF.
  ENDMETHOD.
  METHOD stamp.
    rs_row = is_row.
    IF rs_row-read_at IS NOT INITIAL. RETURN. ENDIF.
    rs_row-read_at = iv_now.
    rs_row-updated_at = iv_now.
    rs_row-updated_by = sy-uname.
    rs_row-local_last_changed_at = iv_now.
  ENDMETHOD.
  METHOD entity.
    rs_entity = CORRESPONDING #( is_row MAPPING eventId = event_id eventType = event_type
      recipientId = recipient_id projectId = project_id taskId = task_id createdAt = created_at
      readAt = read_at localLastChangedAt = local_last_changed_at ).
  ENDMETHOD.
ENDCLASS.

CLASS lhc_Notification DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS read FOR READ IMPORTING keys FOR READ Notification RESULT result.
    METHODS lock FOR LOCK IMPORTING keys FOR LOCK Notification.
    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Notification RESULT result.
    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Notification RESULT result.
    METHODS MarkRead FOR MODIFY IMPORTING keys FOR ACTION Notification~MarkRead RESULT result.
    METHODS MarkAllRead FOR MODIFY IMPORTING keys FOR ACTION Notification~MarkAllRead.
ENDCLASS.
CLASS lhc_Notification IMPLEMENTATION.
  METHOD read.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          DATA(ls_row) = lcl_inbox=>get( CONV #( ls_key-id ) ).
          APPEND CORRESPONDING #( lcl_inbox=>entity( ls_row ) ) TO result.
        CATCH ycx_it_hub.
          APPEND VALUE #( %tky = ls_key-%tky %fail-cause = if_abap_behv=>cause-not_found ) TO failed-notification.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD lock.
    TRY.
        ycl_it_hub_tx=>lock( ).
      CATCH ycx_it_hub INTO DATA(lx_lock).
        LOOP AT keys INTO DATA(ls_key).
          APPEND VALUE #( id = ls_key-id %fail-cause = if_abap_behv=>cause-locked ) TO failed-notification.
          APPEND VALUE #( id = ls_key-id %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_lock->text ) ) TO reported-notification.
        ENDLOOP.
    ENDTRY.
  ENDMETHOD.
  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA(lv_allowed) = COND #( WHEN ls_actor-active = abap_true AND ls_actor-id IS NOT INITIAL
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    IF requested_authorizations-%action-MarkRead = if_abap_behv=>mk-on. result-%action-MarkRead = lv_allowed. ENDIF.
    IF requested_authorizations-%action-MarkAllRead = if_abap_behv=>mk-on. result-%action-MarkAllRead = lv_allowed. ENDIF.
  ENDMETHOD.
  METHOD get_instance_authorizations.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_allowed) = if_abap_behv=>auth-unauthorized.
      TRY.
          DATA(ls_row) = lcl_inbox=>get( CONV #( ls_key-id ) ).
          lv_allowed = if_abap_behv=>auth-allowed.
        CATCH ycx_it_hub.
          lv_allowed = if_abap_behv=>auth-unauthorized.
      ENDTRY.
      APPEND VALUE #( %tky = ls_key-%tky %action-MarkRead = lv_allowed ) TO result.
    ENDLOOP.
  ENDMETHOD.
  METHOD MarkRead.
    DATA lv_now TYPE timestampl.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_tx=>lock( ).
          DATA(ls_before) = lcl_inbox=>get( CONV #( ls_key-id ) ).
          GET TIME STAMP FIELD lv_now.
          DATA(ls_after) = lcl_inbox=>stamp( is_row = ls_before iv_now = lv_now ).
          IF ls_after-read_at <> ls_before-read_at.
            lcl_inbox=>stage( ls_after ).
          ENDIF.
          APPEND VALUE #( %tky = ls_key-%tky
            %param = CORRESPONDING #( lcl_inbox=>entity( ls_after ) ) ) TO result.
        CATCH ycx_it_hub INTO DATA(lx_read).
          APPEND VALUE #( %tky = ls_key-%tky ) TO failed-notification.
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_read->text ) ) TO reported-notification.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD MarkAllRead.
    DATA lv_cutoff TYPE timestampl.
    GET TIME STAMP FIELD lv_cutoff.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_tx=>lock( ).
          DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
          IF ls_actor-active = abap_false OR ls_actor-id IS INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'An active mapped notification recipient is required.'.
          ENDIF.
          DATA(lv_recipient) = to_lower( ls_actor-id ).
          SELECT * FROM ytb_it_hub_notf WHERE lower( recipient_id ) = @lv_recipient
            AND read_at = 0 AND created_at <= @lv_cutoff INTO TABLE @DATA(lt_rows).
          LOOP AT lt_rows INTO DATA(ls_row).
            DATA(ls_rights) = ycl_it_hub_policy=>permissions( iv_project = CONV #( ls_row-project_id ) ).
            IF lcl_inbox=>visible( is_row = ls_row is_actor = ls_actor iv_now = lv_cutoff iv_project_read = ls_rights-read ) = abap_false. CONTINUE. ENDIF.
            READ TABLE lcl_inbox=>pending INTO DATA(ls_pending) WITH TABLE KEY client = sy-mandt id = ls_row-id.
            IF sy-subrc = 0 AND ls_pending-read_at IS NOT INITIAL. CONTINUE. ENDIF.
            lcl_inbox=>stage( lcl_inbox=>stamp( is_row = ls_row iv_now = lv_cutoff ) ).
          ENDLOOP.
        CATCH ycx_it_hub INTO DATA(lx_all).
          APPEND VALUE #( %cid = ls_key-%cid ) TO failed-notification.
          APPEND VALUE #( %cid = ls_key-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_all->text ) ) TO reported-notification.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_Notifications DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.
    METHODS check_before_save REDEFINITION.
    METHODS save REDEFINITION.
    METHODS cleanup REDEFINITION.
    METHODS cleanup_finalize REDEFINITION.
ENDCLASS.
CLASS lsc_Notifications IMPLEMENTATION.
  METHOD check_before_save.
    LOOP AT lcl_inbox=>pending INTO DATA(ls_pending).
      TRY.
          DATA(ls_verified) = lcl_inbox=>get( CONV #( ls_pending-id ) ).
        CATCH ycx_it_hub INTO DATA(lx_check).
          APPEND VALUE #( id = ls_pending-id ) TO failed-notification.
          APPEND VALUE #( id = ls_pending-id %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_check->text ) ) TO reported-notification.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD save.
    LOOP AT lcl_inbox=>pending INTO DATA(ls_pending).
      UPDATE ytb_it_hub_notf SET read_at = @ls_pending-read_at, updated_at = @ls_pending-updated_at,
        updated_by = @ls_pending-updated_by, local_last_changed_at = @ls_pending-local_last_changed_at
        WHERE id = @ls_pending-id AND recipient_id = @ls_pending-recipient_id AND read_at = 0.
      ASSERT sy-dbcnt = 1.
    ENDLOOP.
  ENDMETHOD.
  METHOD cleanup.
    CLEAR lcl_inbox=>pending.
    ycl_it_hub_tx=>reset( ).
  ENDMETHOD.
  METHOD cleanup_finalize.
    CLEAR lcl_inbox=>pending.
    ycl_it_hub_tx=>reset( ).
  ENDMETHOD.
ENDCLASS.
