CLASS ycl_it_hub_proj_ve DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_sadl_exit_calc_element_read.

  PRIVATE SECTION.
    TYPES:
      BEGIN OF ty_result,
        id                 TYPE sysuuid_c36,
        completionPercent  TYPE p LENGTH 3 DECIMALS 0,
        taskCount          TYPE i,
        completedTaskCount TYPE i,
      END OF ty_result,

      tt_result TYPE STANDARD TABLE OF ty_result
        WITH EMPTY KEY,

      tt_project_ids TYPE SORTED TABLE OF sysuuid_c36
        WITH UNIQUE KEY table_line,

      tt_project_range TYPE RANGE OF sysuuid_c36,

      BEGIN OF ty_status_total,
        projectId TYPE sysuuid_c36,
        status    TYPE ytb_it_hub_task-status,
        weight    TYPE p LENGTH 16 DECIMALS 2,
        leafCount TYPE i,
      END OF ty_status_total,

      tt_status_total TYPE STANDARD TABLE OF ty_status_total
        WITH EMPTY KEY,

      BEGIN OF ty_project_total,
        projectId          TYPE sysuuid_c36,
        totalWeight        TYPE decfloat34,
        completedWeight    TYPE decfloat34,
        taskCount          TYPE i,
        completedTaskCount TYPE i,
      END OF ty_project_total,

      tt_project_total TYPE HASHED TABLE OF ty_project_total
        WITH UNIQUE KEY projectId.

    METHODS authorize_projects
      IMPORTING
        it_project_ids   TYPE tt_project_ids
        it_project_range TYPE tt_project_range
      RAISING
        cx_sadl_exit.

ENDCLASS.


CLASS ycl_it_hub_proj_ve IMPLEMENTATION.

  METHOD if_sadl_exit_calc_element_read~get_calculation_info.

    IF it_requested_calc_elements IS INITIAL.
      RETURN.
    ENDIF.

    IF iv_entity <> 'YC_IT_HUB_PROJECT'.
      RAISE EXCEPTION TYPE lcx_hub_project_kpi
        EXPORTING
          iv_message = 'Unsupported entity for project KPI calculation'.
    ENDIF.

    LOOP AT it_requested_calc_elements INTO DATA(lv_element).
      CASE lv_element.
        WHEN 'COMPLETIONPERCENT'
          OR 'TASKCOUNT'
          OR 'COMPLETEDTASKCOUNT'.

          INSERT CONV string( 'ID' )
            INTO TABLE et_requested_orig_elements.

        WHEN OTHERS.
          RAISE EXCEPTION TYPE lcx_hub_project_kpi
            EXPORTING
              iv_message = 'Unsupported project virtual element'.
      ENDCASE.
    ENDLOOP.

  ENDMETHOD.


  METHOD if_sadl_exit_calc_element_read~calculate.

    CLEAR ct_calculated_data.

    IF it_original_data IS INITIAL
       OR it_requested_calc_elements IS INITIAL.
      RETURN.
    ENDIF.

    DATA:
      lt_results       TYPE tt_result,
      lt_project_ids   TYPE tt_project_ids,
      lr_projects      TYPE tt_project_range,
      lt_status_totals TYPE tt_status_total,
      lt_totals        TYPE tt_project_total.

    " Keep the original row order, including repeated project IDs.
    lt_results = CORRESPONDING #( it_original_data ).

    LOOP AT lt_results ASSIGNING FIELD-SYMBOL(<result>).

      CLEAR:
        <result>-completionPercent,
        <result>-taskCount,
        <result>-completedTaskCount.

      IF <result>-id IS INITIAL.
        RAISE EXCEPTION TYPE lcx_hub_project_kpi
          EXPORTING
            iv_message = 'Project ID is required for KPI calculation'.
      ENDIF.

      INSERT <result>-id INTO TABLE lt_project_ids.
    ENDLOOP.

    " Build a nonempty range containing unique project IDs.
    lr_projects = VALUE #(
      FOR lv_project_id IN lt_project_ids
      ( sign   = 'I'
        option = 'EQ'
        low    = lv_project_id )
    ).

    authorize_projects(
      it_project_ids   = lt_project_ids
      it_project_range = lr_projects
    ).

    " One aggregate query for the entire requested project batch.
    " Widen the decimal before SUM to accommodate large totals.
    SELECT projectId,
           status,
           SUM(
             CAST( effortWeight AS DEC( 31, 2 ) )
           ) AS weight,
           COUNT( * ) AS leafCount
      FROM yi_it_hub_leaf_effort
      WHERE projectId IN @lr_projects
      GROUP BY projectId, status
      INTO TABLE @lt_status_totals.

    " Aggregate the status buckets in memory.
    LOOP AT lt_status_totals INTO DATA(ls_status_total).

      READ TABLE lt_totals
        ASSIGNING FIELD-SYMBOL(<total>)
        WITH TABLE KEY projectId = ls_status_total-projectId.

      IF sy-subrc <> 0.
        INSERT VALUE #(
          projectId = ls_status_total-projectId
        ) INTO TABLE lt_totals ASSIGNING <total>.
      ENDIF.

      <total>-totalWeight += CONV decfloat34( ls_status_total-weight ).
      <total>-taskCount   += ls_status_total-leafCount.

      IF ls_status_total-status = 'DONE'
         OR ls_status_total-status = 'CLOSED'.

        <total>-completedWeight += CONV decfloat34( ls_status_total-weight ).
        <total>-completedTaskCount += ls_status_total-leafCount.

      ENDIF.
    ENDLOOP.

    " Populate exactly one output row per original input row.
    LOOP AT lt_results ASSIGNING <result>.

      READ TABLE lt_totals
        ASSIGNING <total>
        WITH TABLE KEY projectId = <result>-id.

      IF sy-subrc <> 0.
        " Projects without leaf tasks keep all three KPIs at zero.
        CONTINUE.
      ENDIF.

      <result>-taskCount = <total>-taskCount.
      <result>-completedTaskCount = <total>-completedTaskCount.

      IF <total>-totalWeight > 0.
        <result>-completionPercent = round(
          val = CONV decfloat34( 100 )
                * <total>-completedWeight
                / <total>-totalWeight
          dec = 0
        ).
      ENDIF.

    ENDLOOP.

    ct_calculated_data = CORRESPONDING #( lt_results ).

  ENDMETHOD.


  METHOD authorize_projects.

    IF it_project_ids IS INITIAL
       OR it_project_range IS INITIAL.
      RAISE EXCEPTION TYPE lcx_hub_project_kpi
        EXPORTING
          iv_message = 'Project IDs are required'.
    ENDIF.

    DATA:
      lv_is_admin       TYPE abap_bool,
      lv_member_id      TYPE sysuuid_c36,
      lt_authorized_ids TYPE tt_project_ids.

    " Trusted SAP authorization, independent of browser role flags.
    AUTHORITY-CHECK OBJECT 'Y_IT_HUB'
      ID 'ACTVT'    FIELD '16'
      ID 'YHUB_CAP' FIELD 'ADMIN'.

    lv_is_admin = xsdbool( sy-subrc = 0 ).

    IF lv_is_admin = abap_false.

      AUTHORITY-CHECK OBJECT 'Y_IT_HUB'
        ID 'ACTVT'    FIELD '03'
        ID 'YHUB_CAP' FIELD 'USER'.

      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE lcx_hub_project_kpi
          EXPORTING
            iv_message = 'Application access denied'.
      ENDIF.

    ENDIF.

    IF lv_is_admin = abap_true.

      " Admin can read every existing project.
      SELECT id
        FROM ytb_it_hub_proj
        WHERE id IN @it_project_range
        INTO TABLE @lt_authorized_ids.

    ELSE.

      " Open SQL applies the current client automatically.
      " Ordinary users require an active identity and active Member.
      SELECT SINGLE identity~member_id
        FROM ytb_it_hub_midn AS identity
        INNER JOIN ytb_it_hub_memb AS member
          ON member~id = identity~member_id
        WHERE identity~abap_user = @sy-uname
          AND identity~active = @abap_true
          AND member~active = @abap_true
        INTO @lv_member_id.

      IF sy-subrc <> 0 OR lv_member_id IS INITIAL.
        RAISE EXCEPTION TYPE lcx_hub_project_kpi
          EXPORTING
            iv_message = 'Active application identity is required'.
      ENDIF.

      " Ordinary users need active membership in each project.
      SELECT DISTINCT project~id
        FROM ytb_it_hub_proj AS project
        INNER JOIN ytb_it_hub_mship AS membership
          ON membership~project_id = project~id
        WHERE project~id IN @it_project_range
          AND membership~member_id = @lv_member_id
          AND membership~active = @abap_true
        INTO TABLE @lt_authorized_ids.

    ENDIF.

    IF lines( lt_authorized_ids ) <> lines( it_project_ids ).
      RAISE EXCEPTION TYPE lcx_hub_project_kpi
        EXPORTING
          iv_message = 'Project does not exist or read access is denied'.
    ENDIF.

  ENDMETHOD.

ENDCLASS.
