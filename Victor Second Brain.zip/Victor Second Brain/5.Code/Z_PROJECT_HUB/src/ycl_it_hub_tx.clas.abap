CLASS ycl_it_hub_tx DEFINITION PUBLIC FINAL CREATE PRIVATE.
  PUBLIC SECTION.
    TYPES tt_refs TYPE STANDARD TABLE OF REF TO data WITH EMPTY KEY.
    TYPES: BEGIN OF ty_guard,
             entity TYPE string, operation TYPE string, row TYPE REF TO data, parameter TYPE REF TO data,
           END OF ty_guard,
           tt_guards TYPE STANDARD TABLE OF ty_guard WITH EMPTY KEY.
    CLASS-METHODS guard IMPORTING iv_entity TYPE string iv_operation TYPE string ir_row TYPE REF TO data
      is_parameter TYPE any OPTIONAL.
    CLASS-METHODS guards RETURNING VALUE(rt_guards) TYPE tt_guards.
    TYPES: BEGIN OF ty_audit,
             created_by TYPE sysuuid_c36,
             updated_by TYPE sysuuid_c36,
             token TYPE sysuuid_c36,
             changed TYPE abap_bool,
           END OF ty_audit.
    CLASS-METHODS lock RAISING ycx_it_hub.
    CLASS-METHODS get IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rr_row) TYPE REF TO data.
    CLASS-METHODS before IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rr_row) TYPE REF TO data.
    CLASS-METHODS rows IMPORTING iv_entity TYPE string
      RETURNING VALUE(rt_rows) TYPE tt_refs.
    CLASS-METHODS remember IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      iv_deleted TYPE abap_bool DEFAULT abap_false.
    CLASS-METHODS field IMPORTING ir_row TYPE REF TO data iv_name TYPE string
      RETURNING VALUE(rv_value) TYPE string.
    CLASS-METHODS put IMPORTING ir_row TYPE REF TO data iv_name TYPE string iv_value TYPE any.
    CLASS-METHODS image IMPORTING ir_row TYPE REF TO data
      RETURNING VALUE(rv_json) TYPE string.
    CLASS-METHODS audit IMPORTING iv_entity TYPE string ir_row TYPE REF TO data iv_actor TYPE sysuuid_c36
      RETURNING VALUE(rs_audit) TYPE ty_audit RAISING ycx_it_hub.
    CLASS-METHODS stage_delete IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      iv_actor TYPE sysuuid_c36 iv_cascade TYPE abap_bool DEFAULT abap_false.
    CLASS-METHODS delete_image IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rr_row) TYPE REF TO data.
    CLASS-METHODS confirm_delete IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rv_new) TYPE abap_bool RAISING ycx_it_hub.
    CLASS-METHODS overlay_deleted IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36.
    CLASS-METHODS confirm_children IMPORTING iv_entity TYPE string ir_row TYPE REF TO data RAISING ycx_it_hub.
    CLASS-METHODS cascade_delete IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS save_phase IMPORTING iv_on TYPE abap_bool.
    CLASS-METHODS in_save RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS canonical_id IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rv_id) TYPE sysuuid_c36.
    CLASS-METHODS deleted IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      iv_actor TYPE sysuuid_c36 RAISING ycx_it_hub.
    CLASS-METHODS operation IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36 iv_action TYPE string.
    CLASS-METHODS action IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rv_action) TYPE string.
    CLASS-METHODS fail IMPORTING iv_text TYPE string.
    CLASS-METHODS error RETURNING VALUE(rv_error) TYPE string.
    CLASS-METHODS scope IMPORTING iv_name TYPE string iv_id TYPE sysuuid_c36 iv_on TYPE abap_bool.
    CLASS-METHODS in_scope IMPORTING iv_name TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS touch IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36
      RETURNING VALUE(rv_token) TYPE sysuuid_c36 RAISING ycx_it_hub.
    CLASS-METHODS prepared IMPORTING iv_entity TYPE string ir_row TYPE REF TO data
      RETURNING VALUE(rv_ready) TYPE abap_bool.
    CLASS-METHODS save IMPORTING iv_owner TYPE string is_create TYPE any is_update TYPE any is_delete TYPE any.
    CLASS-METHODS create_controls IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36 is_control TYPE any.
    CLASS-METHODS controlled IMPORTING iv_entity TYPE string iv_id TYPE sysuuid_c36 iv_name TYPE string
      RETURNING VALUE(rv_yes) TYPE abap_bool.
    CLASS-METHODS reset.
    CLASS-METHODS begin_read RAISING ycx_it_hub.
    CLASS-METHODS end_read.
    CLASS-METHODS read_active RETURNING VALUE(rv_active) TYPE abap_bool.
  PRIVATE SECTION.
    TYPES: BEGIN OF ty_state,
             entity TYPE string, id TYPE sysuuid_c36, row TYPE REF TO data, deleted TYPE abap_bool,
           END OF ty_state,
           BEGIN OF ty_stamp,
             entity TYPE string, id TYPE sysuuid_c36, image TYPE string,
             actor TYPE sysuuid_c36, token TYPE sysuuid_c36,
             history TYPE ytb_it_hub_histo,
           END OF ty_stamp,
           BEGIN OF ty_action,
             entity TYPE string, id TYPE sysuuid_c36, action TYPE string,
           END OF ty_action,
           BEGIN OF ty_scope,
             name TYPE string, id TYPE sysuuid_c36,
           END OF ty_scope.
    TYPES: BEGIN OF ty_delete,
      entity TYPE string, id TYPE sysuuid_c36, row TYPE REF TO data,
      actor TYPE sysuuid_c36, cascade TYPE abap_bool, prepared TYPE abap_bool,
    END OF ty_delete.
    CLASS-DATA gt_deletes TYPE HASHED TABLE OF ty_delete WITH UNIQUE KEY entity id.
    CLASS-DATA gv_save_phase TYPE abap_bool.
    CLASS-DATA gt_guards TYPE tt_guards.
    CLASS-DATA gt_state TYPE HASHED TABLE OF ty_state WITH UNIQUE KEY entity id.
    CLASS-DATA gt_controls TYPE HASHED TABLE OF ty_state WITH UNIQUE KEY entity id.
    CLASS-DATA gt_base TYPE HASHED TABLE OF ty_state WITH UNIQUE KEY entity id.
    CLASS-DATA gt_loaded TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line.
    CLASS-DATA gt_stamps TYPE HASHED TABLE OF ty_stamp WITH UNIQUE KEY entity id.
    CLASS-DATA gt_actions TYPE HASHED TABLE OF ty_action WITH UNIQUE KEY entity id.
    CLASS-DATA gt_scopes TYPE HASHED TABLE OF ty_scope WITH UNIQUE KEY name id.
    CLASS-DATA gv_error TYPE string.
    CLASS-DATA gv_locked TYPE abap_bool.
    CLASS-DATA gv_correlation TYPE sysuuid_c36.
    CLASS-DATA gv_read_active TYPE abap_bool.
    CLASS-METHODS table_name IMPORTING iv_entity TYPE string RETURNING VALUE(rv_table) TYPE string.
    CLASS-METHODS owner IMPORTING iv_entity TYPE string RETURNING VALUE(rv_owner) TYPE string.
    CLASS-METHODS wire_name IMPORTING iv_entity TYPE string RETURNING VALUE(rv_name) TYPE string.
    CLASS-METHODS clone IMPORTING ir_row TYPE REF TO data RETURNING VALUE(rr_row) TYPE REF TO data.
    CLASS-METHODS cache_id IMPORTING iv_id TYPE sysuuid_c36 RETURNING VALUE(rv_id) TYPE sysuuid_c36.
    CLASS-METHODS load IMPORTING iv_entity TYPE string.
ENDCLASS.
CLASS ycl_it_hub_tx IMPLEMENTATION.
  METHOD begin_read.
    " A permission GET must never reset an in-progress write transaction.
    IF gv_read_active = abap_true OR gv_locked = abap_true
      OR gt_deletes IS NOT INITIAL OR gv_save_phase = abap_true
      OR gt_guards IS NOT INITIAL OR gt_state IS NOT INITIAL
      OR gt_controls IS NOT INITIAL OR gt_stamps IS NOT INITIAL
      OR gt_actions IS NOT INITIAL OR gt_scopes IS NOT INITIAL
      OR gv_error IS NOT INITIAL OR gv_correlation IS NOT INITIAL.
      RAISE EXCEPTION TYPE ycx_it_hub
        EXPORTING iv_text = 'Authorization context requires a standalone read request.'.
    ENDIF.
    CLEAR: gt_base, gt_loaded.
    gv_read_active = abap_true.
  ENDMETHOD.
  METHOD end_read.
    IF gv_read_active = abap_false. RETURN. ENDIF.
    " Clear only this read's cache; do not discard mutation buffers or locks.
    CLEAR: gt_base, gt_loaded, gv_read_active.
  ENDMETHOD.
  METHOD read_active.
    rv_active = gv_read_active.
  ENDMETHOD.
  METHOD lock.
    IF gv_locked = abap_true.
      RETURN.
    ENDIF.
    TRY.
        DATA(lo_lock) = cl_abap_lock_object_factory=>get_instance( iv_name = 'EY_IT_HUB_GOV' ).
        DATA lv_kind TYPE ytb_it_hub_gov-kind VALUE 'GOVERNANCE'.
        DATA lv_name TYPE ytb_it_hub_gov-name VALUE 'APP'.
        lo_lock->enqueue( it_parameter = VALUE #(
          ( name = 'KIND' value = REF #( lv_kind ) )
          ( name = 'NAME' value = REF #( lv_name ) ) ) ).
        gv_locked = abap_true.
        " Refresh persisted images at the write boundary; keep actual buffered changes.
        CLEAR: gt_base, gt_loaded.
      CATCH cx_abap_foreign_lock.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Another transaction is updating Project Hub. Retry the request.'.
      CATCH cx_abap_lock_failure.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Project Hub governance lock is unavailable.'.
    ENDTRY.
  ENDMETHOD.
  METHOD table_name.
    CASE iv_entity.
      WHEN 'PROJECT'. rv_table = 'YTB_IT_HUB_PROJ'.
      WHEN 'WORKSTREAM'. rv_table = 'YTB_IT_HUB_WSTR'.
      WHEN 'MEMBERSHIP'. rv_table = 'YTB_IT_HUB_MSHIP'.
      WHEN 'ROLEASSIGN'. rv_table = 'YTB_IT_HUB_PROLE'.
      WHEN 'MILESTONE'. rv_table = 'YTB_IT_HUB_MILE'.
      WHEN 'RISK'. rv_table = 'YTB_IT_HUB_RISK'.
      WHEN 'MEMBER'. rv_table = 'YTB_IT_HUB_MEMB'.
      WHEN 'MEMBERIDENT'. rv_table = 'YTB_IT_HUB_MIDN'.
      WHEN 'MEMBERSKILL'. rv_table = 'YTB_IT_HUB_MSKIL'.
      WHEN 'SKILL'. rv_table = 'YTB_IT_HUB_SKILL'.
      WHEN 'TASK'. rv_table = 'YTB_IT_HUB_TASK'.
      WHEN 'TASKDEP'. rv_table = 'YTB_IT_HUB_TDEP'.
      WHEN 'EVENT'. rv_table = 'YTB_IT_HUB_EVENT'.
      WHEN 'EVENTATTENDEE'. rv_table = 'YTB_IT_HUB_EATT'.
      WHEN 'COMMENT'. rv_table = 'YTB_IT_HUB_COMMT'.
      WHEN 'DOCUMENT'. rv_table = 'YTB_IT_HUB_DOCS'.
      WHEN 'DOCATTACH'. rv_table = 'YTB_IT_HUB_DOATT'.
    ENDCASE.
    ASSERT rv_table IS NOT INITIAL.
  ENDMETHOD.
  METHOD owner.
    CASE iv_entity.
      WHEN 'PROJECT'. rv_owner = 'PROJECT'.
      WHEN 'WORKSTREAM'. rv_owner = 'PROJECT'.
      WHEN 'MEMBERSHIP'. rv_owner = 'PROJECT'.
      WHEN 'ROLEASSIGN'. rv_owner = 'PROJECT'.
      WHEN 'MILESTONE'. rv_owner = 'PROJECT'.
      WHEN 'RISK'. rv_owner = 'PROJECT'.
      WHEN 'MEMBER'. rv_owner = 'MEMBER'.
      WHEN 'MEMBERIDENT'. rv_owner = 'MEMBER'.
      WHEN 'MEMBERSKILL'. rv_owner = 'MEMBER'.
      WHEN 'SKILL'. rv_owner = 'SKILL'.
      WHEN 'TASK'. rv_owner = 'TASK'.
      WHEN 'TASKDEP'. rv_owner = 'TASK'.
      WHEN 'EVENT'. rv_owner = 'EVENT'.
      WHEN 'EVENTATTENDEE'. rv_owner = 'EVENT'.
      WHEN 'COMMENT'. rv_owner = 'COMMENT'.
      WHEN 'DOCUMENT'. rv_owner = 'DOCUMENT'.
      WHEN 'DOCATTACH'. rv_owner = 'DOCUMENT'.
    ENDCASE.
  ENDMETHOD.
  METHOD wire_name.
    CASE iv_entity.
      WHEN 'PROJECT'. rv_name = 'projects'.
      WHEN 'WORKSTREAM'. rv_name = 'workstreams'.
      WHEN 'MEMBERSHIP'. rv_name = 'memberships'.
      WHEN 'ROLEASSIGN'. rv_name = 'projectRoleAssignments'.
      WHEN 'MILESTONE'. rv_name = 'milestones'.
      WHEN 'RISK'. rv_name = 'risks'.
      WHEN 'MEMBER'. rv_name = 'members'.
      WHEN 'MEMBERIDENT'. rv_name = 'memberIdentities'.
      WHEN 'MEMBERSKILL'. rv_name = 'memberSkills'.
      WHEN 'SKILL'. rv_name = 'skillCatalog'.
      WHEN 'TASK'. rv_name = 'tasks'.
      WHEN 'TASKDEP'. rv_name = 'taskDependencies'.
      WHEN 'EVENT'. rv_name = 'events'.
      WHEN 'EVENTATTENDEE'. rv_name = 'eventAttendees'.
      WHEN 'COMMENT'. rv_name = 'comments'.
      WHEN 'DOCUMENT'. rv_name = 'documents'.
      WHEN 'DOCATTACH'. rv_name = 'documentAttachments'.
    ENDCASE.
  ENDMETHOD.
  METHOD clone.
    IF ir_row IS NOT BOUND. RETURN. ENDIF.
    CREATE DATA rr_row LIKE ir_row->*.
    rr_row->* = ir_row->*.
  ENDMETHOD.
  METHOD load.
    READ TABLE gt_loaded TRANSPORTING NO FIELDS WITH TABLE KEY table_line = iv_entity.
    IF sy-subrc = 0. RETURN. ENDIF.
    DATA(lv_table) = table_name( iv_entity ).
    DATA(lo_line) = CAST cl_abap_datadescr( cl_abap_typedescr=>describe_by_name( lv_table ) ).
    DATA(lo_type) = cl_abap_tabledescr=>create( p_line_type = lo_line ).
    DATA lr_rows TYPE REF TO data.
    CREATE DATA lr_rows TYPE HANDLE lo_type.
    FIELD-SYMBOLS <rows> TYPE ANY TABLE.
    ASSIGN lr_rows->* TO <rows>.
    DATA(lv_columns) = CONV string( '*' ).
    IF iv_entity = 'DOCUMENT'.
      lv_columns = 'CLIENT,ID,PROJECT_ID,TITLE,DESCRIPTION,CATEGORY,SOURCE_TYPE,MEDIA_KIND,UPLOAD_STATUS,URL,FILE_NAME,MIME_TYPE,BYTE_SIZE,CHECKSUM_SHA256,CREATED_AT,CREATED_BY,UPDATED_AT,UPDATED_BY,LOCAL_LAST_CHANGED_AT,CREATED_BY_MEMBER_ID,UPDATED' &&
'_BY_MEMBER_ID,CHANGE_TOKEN'.
    ENDIF.
    " Map by name: DOCUMENT excludes CONTENT from the full DDIC row type.
    SELECT (lv_columns) FROM (lv_table)
      INTO CORRESPONDING FIELDS OF TABLE @<rows>.
    LOOP AT <rows> ASSIGNING FIELD-SYMBOL(<row>).
      DATA(lr_row) = clone( REF #( <row> ) ).
      " Fold only the cache key; the cloned persisted row retains its ID.
      DATA(lv_id) = cache_id( CONV #( field( ir_row = lr_row iv_name = 'ID' ) ) ).
      INSERT VALUE #( entity = iv_entity id = lv_id row = lr_row ) INTO TABLE gt_base.
    ENDLOOP.
    INSERT iv_entity INTO TABLE gt_loaded.
  ENDMETHOD.
  METHOD before.
    load( iv_entity ).
    DATA(lv_lookup_id) = cache_id( iv_id ).
    READ TABLE gt_base INTO DATA(ls_base) WITH TABLE KEY entity = iv_entity id = lv_lookup_id.
    IF sy-subrc = 0. rr_row = clone( ls_base-row ). ENDIF.
  ENDMETHOD.
  METHOD get.
    DATA(lv_lookup_id) = cache_id( iv_id ).
    READ TABLE gt_state INTO DATA(ls_state) WITH TABLE KEY entity = iv_entity id = lv_lookup_id.
    IF sy-subrc = 0.
      IF ls_state-deleted = abap_false. rr_row = clone( ls_state-row ). ENDIF.
      RETURN.
    ENDIF.
    rr_row = before( iv_entity = iv_entity iv_id = iv_id ).
  ENDMETHOD.
  METHOD rows.
    load( iv_entity ).
    LOOP AT gt_base INTO DATA(ls_base) WHERE entity = iv_entity.
      READ TABLE gt_state INTO DATA(ls_state) WITH TABLE KEY entity = iv_entity id = ls_base-id.
      IF sy-subrc = 0.
        IF ls_state-deleted = abap_false. APPEND clone( ls_state-row ) TO rt_rows. ENDIF.
      ELSE.
        APPEND clone( ls_base-row ) TO rt_rows.
      ENDIF.
    ENDLOOP.
    LOOP AT gt_state INTO ls_state WHERE entity = iv_entity AND deleted = abap_false.
      READ TABLE gt_base TRANSPORTING NO FIELDS WITH TABLE KEY entity = iv_entity id = ls_state-id.
      IF sy-subrc <> 0. APPEND clone( ls_state-row ) TO rt_rows. ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD remember.
    DATA(lv_id) = cache_id( CONV #( field( ir_row = ir_row iv_name = 'ID' ) ) ).
    IF lv_id IS INITIAL. RETURN. ENDIF.
    DELETE TABLE gt_state WITH TABLE KEY entity = iv_entity id = lv_id.
    INSERT VALUE #( entity = iv_entity id = lv_id row = clone( ir_row ) deleted = iv_deleted ) INTO TABLE gt_state.
  ENDMETHOD.
  METHOD cache_id.
    " UUID hex case is insignificant. Never rewrite the row or its DDIC type.
    rv_id = to_lower( iv_id ).
  ENDMETHOD.
  METHOD field.
    IF ir_row IS NOT BOUND. RETURN. ENDIF.
    ASSIGN COMPONENT iv_name OF STRUCTURE ir_row->* TO FIELD-SYMBOL(<field>).
    IF sy-subrc = 0. rv_value = <field>. ENDIF.
  ENDMETHOD.
  METHOD put.
    ASSIGN COMPONENT iv_name OF STRUCTURE ir_row->* TO FIELD-SYMBOL(<field>).
    ASSERT sy-subrc = 0.
    <field> = iv_value.
  ENDMETHOD.
  METHOD image.
    DATA(lr_image) = clone( ir_row ).
    IF lr_image IS NOT BOUND. rv_json = 'null'. RETURN. ENDIF.
    DATA(lv_skip) = 'CLIENT,CREATED_AT,CREATED_BY,UPDATED_AT,UPDATED_BY,LOCAL_LAST_CHANGED_AT,CREATED_BY_MEMBER_ID,UPDATED_BY_MEMBER_ID,CHANGE_TOKEN'.
    SPLIT lv_skip AT ',' INTO TABLE DATA(lt_skip).
    LOOP AT lt_skip INTO DATA(lv_field).
      ASSIGN COMPONENT lv_field OF STRUCTURE lr_image->* TO FIELD-SYMBOL(<field>).
      IF sy-subrc = 0. CLEAR <field>. ENDIF.
    ENDLOOP.
    " Byte content is represented by server-validated hash/size, never copied to history.
    ASSIGN COMPONENT 'CONTENT' OF STRUCTURE lr_image->* TO <field>.
    IF sy-subrc = 0. CLEAR <field>. ENDIF.
    rv_json = /ui2/cl_json=>serialize( data = lr_image->*
      pretty_name = /ui2/cl_json=>pretty_mode-camel_case ts_as_iso8601 = abap_true ).
  ENDMETHOD.
  METHOD operation.
    DELETE TABLE gt_actions WITH TABLE KEY entity = iv_entity id = iv_id.
    INSERT VALUE #( entity = iv_entity id = iv_id action = iv_action ) INTO TABLE gt_actions.
  ENDMETHOD.
  METHOD action.
    READ TABLE gt_actions INTO DATA(ls_action) WITH TABLE KEY entity = iv_entity id = iv_id.
    IF sy-subrc = 0. rv_action = ls_action-action. ENDIF.
  ENDMETHOD.
  METHOD audit.
    DATA(lv_id) = CONV sysuuid_c36( field( ir_row = ir_row iv_name = 'ID' ) ).
    DATA(lv_image) = image( ir_row ).
    DATA(lr_before) = before( iv_entity = iv_entity iv_id = lv_id ).
    READ TABLE gt_stamps INTO DATA(ls_stamp) WITH TABLE KEY entity = iv_entity id = lv_id.
    IF sy-subrc = 0 AND ls_stamp-image = lv_image AND ls_stamp-actor = iv_actor.
      rs_audit-token = ls_stamp-token.
    ELSE.
      TRY.
          rs_audit-token = ycl_it_hub_util=>create_uuid_c36( ).
          IF gv_correlation IS INITIAL. gv_correlation = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          IF ls_stamp-history-id IS INITIAL. ls_stamp-history-id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
        CATCH cx_uuid_error.
          fail( 'Could not prepare Project Hub audit identifiers.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = gv_error.
      ENDTRY.
      ls_stamp-entity = iv_entity.
      ls_stamp-id = lv_id.
      ls_stamp-image = lv_image.
      ls_stamp-actor = iv_actor.
      ls_stamp-token = rs_audit-token.
      GET TIME STAMP FIELD ls_stamp-history-occurred_at.
      ls_stamp-history-client = sy-mandt.
      ls_stamp-history-entity = wire_name( iv_entity ).
      ls_stamp-history-entity_id = lv_id.
      ls_stamp-history-project_id = field( ir_row = ir_row iv_name = 'PROJECT_ID' ).
      IF iv_entity = 'PROJECT'. ls_stamp-history-project_id = lv_id. ENDIF.
      ls_stamp-history-scope_type = COND #( WHEN ls_stamp-history-project_id IS INITIAL THEN 'GLOBAL' ELSE 'PROJECT' ).
      ls_stamp-history-action = action( iv_entity = iv_entity iv_id = lv_id ).
      IF ls_stamp-history-action IS INITIAL.
        ls_stamp-history-action = COND #( WHEN lr_before IS BOUND THEN 'UPDATE' ELSE 'CREATE' ).
      ENDIF.
      ls_stamp-history-detail = |{ ls_stamp-history-action } { ls_stamp-history-entity }|.
      ls_stamp-history-changes_json = '{"before":' && image( lr_before ) && ',"after":' && lv_image && '}'.
      ls_stamp-history-actor = sy-uname.
      ls_stamp-history-actor_member_id = iv_actor.
      ls_stamp-history-correlation_id = gv_correlation.
      DELETE TABLE gt_stamps WITH TABLE KEY entity = iv_entity id = lv_id.
      INSERT ls_stamp INTO TABLE gt_stamps.
      rs_audit-changed = abap_true.
    ENDIF.
    rs_audit-created_by = COND #( WHEN lr_before IS BOUND
      THEN CONV sysuuid_c36( field( ir_row = lr_before iv_name = 'CREATED_BY_MEMBER_ID' ) ) ELSE iv_actor ).
    rs_audit-updated_by = iv_actor.
    remember( iv_entity = iv_entity ir_row = ir_row ).
  ENDMETHOD.
  METHOD canonical_id.
    rv_id = iv_id.
    IF iv_id IS INITIAL. RETURN. ENDIF.
    CASE iv_entity.
      WHEN 'PROJECT' OR 'WORKSTREAM' OR 'MEMBERSHIP' OR 'ROLEASSIGN' OR 'MILESTONE' OR 'RISK'
        OR 'MEMBER' OR 'MEMBERIDENT' OR 'MEMBERSKILL' OR 'SKILL' OR 'TASK' OR 'TASKDEP'
        OR 'EVENT' OR 'EVENTATTENDEE' OR 'COMMENT' OR 'DOCUMENT' OR 'DOCATTACH'.
      WHEN OTHERS. RETURN.
    ENDCASE.
    DATA(lr_row) = get( iv_entity = iv_entity iv_id = iv_id ).
    IF lr_row IS BOUND. rv_id = field( ir_row = lr_row iv_name = 'ID' ). ENDIF.
  ENDMETHOD.
  METHOD save_phase.
    gv_save_phase = iv_on.
  ENDMETHOD.
  METHOD in_save.
    rv_yes = gv_save_phase.
  ENDMETHOD.
  METHOD stage_delete.
    DATA(lv_id) = cache_id( CONV #( field( ir_row = ir_row iv_name = 'ID' ) ) ).
    IF lv_id IS INITIAL. RETURN. ENDIF.
    READ TABLE gt_deletes ASSIGNING FIELD-SYMBOL(<pending>) WITH TABLE KEY entity = iv_entity id = lv_id.
    IF sy-subrc = 0.
      IF iv_cascade = abap_true. <pending>-cascade = abap_true. ENDIF.
      RETURN.
    ENDIF.
    INSERT VALUE #( entity = iv_entity id = lv_id row = clone( ir_row ) actor = iv_actor
      cascade = iv_cascade ) INTO TABLE gt_deletes.
    DATA: lv_child TYPE string, lv_parent_field TYPE string.
    CASE iv_entity.
      WHEN 'TASK'. lv_child = 'TASKDEP'. lv_parent_field = 'TASK_ID'.
      WHEN 'EVENT'. lv_child = 'EVENTATTENDEE'. lv_parent_field = 'EVENT_ID'.
      WHEN 'DOCUMENT'. lv_child = 'DOCATTACH'. lv_parent_field = 'DOCUMENT_ID'.
    ENDCASE.
    IF lv_child IS INITIAL. RETURN. ENDIF.
    LOOP AT rows( lv_child ) INTO DATA(lr_child).
      IF cache_id( CONV #( field( ir_row = lr_child iv_name = lv_parent_field ) ) ) = lv_id.
        stage_delete( iv_entity = lv_child ir_row = lr_child iv_actor = iv_actor iv_cascade = abap_true ).
      ENDIF.
    ENDLOOP.
    LOOP AT gt_deletes ASSIGNING FIELD-SYMBOL(<child_delete>) WHERE entity = lv_child.
      IF cache_id( CONV #( field( ir_row = <child_delete>-row iv_name = lv_parent_field ) ) ) = lv_id.
        <child_delete>-cascade = abap_true.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD delete_image.
    DATA(lv_id) = cache_id( iv_id ).
    READ TABLE gt_deletes INTO DATA(ls_pending) WITH TABLE KEY entity = iv_entity id = lv_id.
    IF sy-subrc = 0. rr_row = clone( ls_pending-row ). ENDIF.
  ENDMETHOD.
  METHOD cascade_delete.
    DATA(lv_id) = cache_id( iv_id ).
    READ TABLE gt_deletes INTO DATA(ls_pending) WITH TABLE KEY entity = iv_entity id = lv_id.
    rv_yes = xsdbool( sy-subrc = 0 AND ls_pending-cascade = abap_true AND ls_pending-prepared = abap_true ).
  ENDMETHOD.
  METHOD confirm_delete.
    DATA(lv_id) = cache_id( iv_id ).
    READ TABLE gt_deletes ASSIGNING FIELD-SYMBOL(<pending>) WITH TABLE KEY entity = iv_entity id = lv_id.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Deletion before image is unavailable.'.
    ENDIF.
    IF <pending>-prepared = abap_true. RETURN. ENDIF.
    deleted( iv_entity = iv_entity ir_row = <pending>-row iv_actor = <pending>-actor ).
    <pending>-prepared = abap_true.
    rv_new = abap_true.
  ENDMETHOD.
  METHOD overlay_deleted.
    DATA(lr_before) = delete_image( iv_entity = iv_entity iv_id = iv_id ).
    IF lr_before IS BOUND.
      " Reflect a successful internal EML delete, without confirming its audit.
      remember( iv_entity = iv_entity ir_row = lr_before iv_deleted = abap_true ).
    ENDIF.
  ENDMETHOD.
  METHOD confirm_children.
    DATA(lv_parent) = cache_id( CONV #( field( ir_row = ir_row iv_name = 'ID' ) ) ).
    DATA: lv_child TYPE string, lv_parent_field TYPE string.
    CASE iv_entity.
      WHEN 'TASK'. lv_child = 'TASKDEP'. lv_parent_field = 'TASK_ID'.
      WHEN 'EVENT'. lv_child = 'EVENTATTENDEE'. lv_parent_field = 'EVENT_ID'.
      WHEN 'DOCUMENT'. lv_child = 'DOCATTACH'. lv_parent_field = 'DOCUMENT_ID'.
    ENDCASE.
    IF lv_child IS INITIAL. RETURN. ENDIF.
    LOOP AT gt_deletes INTO DATA(ls_pending) WHERE entity = lv_child AND cascade = abap_true.
      IF cache_id( CONV #( field( ir_row = ls_pending-row iv_name = lv_parent_field ) ) ) = lv_parent.
        DATA(lv_new) = confirm_delete( iv_entity = lv_child iv_id = ls_pending-id ).
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
  METHOD deleted.
    DATA(ls_audit) = audit( iv_entity = iv_entity ir_row = ir_row iv_actor = iv_actor ).
    DATA(lv_id) = CONV sysuuid_c36( field( ir_row = ir_row iv_name = 'ID' ) ).
    READ TABLE gt_stamps ASSIGNING FIELD-SYMBOL(<stamp>) WITH TABLE KEY entity = iv_entity id = lv_id.
    <stamp>-history-action = 'DELETE'.
    <stamp>-history-detail = |DELETE { <stamp>-history-entity }|.
    <stamp>-history-changes_json = '{"before":' && image( ir_row ) && ',"after":null}'.
    remember( iv_entity = iv_entity ir_row = ir_row iv_deleted = abap_true ).
  ENDMETHOD.
  METHOD fail.
    IF gv_error IS INITIAL. gv_error = iv_text. ENDIF.
  ENDMETHOD.
  METHOD error.
    rv_error = gv_error.
  ENDMETHOD.
  METHOD scope.
    IF iv_on = abap_true.
      INSERT VALUE #( name = iv_name id = iv_id ) INTO TABLE gt_scopes.
    ELSE.
      DELETE TABLE gt_scopes WITH TABLE KEY name = iv_name id = iv_id.
    ENDIF.
  ENDMETHOD.
  METHOD in_scope.
    READ TABLE gt_scopes TRANSPORTING NO FIELDS WITH TABLE KEY name = iv_name id = iv_id.
    rv_yes = xsdbool( sy-subrc = 0 ).
  ENDMETHOD.
  METHOD touch.
    TRY.
        rv_token = ycl_it_hub_util=>create_uuid_c36( ).
      CATCH cx_uuid_error.
        fail( 'Could not prepare a governing ETag update.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = gv_error.
    ENDTRY.
    scope( iv_name = |TOUCH_{ iv_entity }| iv_id = iv_id iv_on = abap_true ).
    " Force the governing root to prepare a new stamp even for a child-only change.
    READ TABLE gt_stamps ASSIGNING FIELD-SYMBOL(<stamp>) WITH TABLE KEY entity = iv_entity id = iv_id.
    IF sy-subrc = 0. CLEAR <stamp>-image. ENDIF.
  ENDMETHOD.
  METHOD prepared.
    DATA(lv_id) = CONV sysuuid_c36( field( ir_row = ir_row iv_name = 'ID' ) ).
    READ TABLE gt_stamps INTO DATA(ls_stamp) WITH TABLE KEY entity = iv_entity id = lv_id.
    rv_ready = xsdbool( sy-subrc = 0 AND ls_stamp-image = image( ir_row )
      AND ls_stamp-token = field( ir_row = ir_row iv_name = 'CHANGE_TOKEN' )
      AND ls_stamp-actor = field( ir_row = ir_row iv_name = 'UPDATED_BY_MEMBER_ID' ) ).
  ENDMETHOD.
  METHOD save.
    " Only entries actually present in the managed saver input may be flushed.
    DATA lt_history TYPE STANDARD TABLE OF ytb_it_hub_histo WITH EMPTY KEY.
    FIELD-SYMBOLS <changes> TYPE ANY TABLE.
    LOOP AT gt_stamps INTO DATA(ls_stamp).
      IF owner( ls_stamp-entity ) <> iv_owner. CONTINUE. ENDIF.
      DATA(lv_component) = ls_stamp-entity.
      DATA(lv_confirmed) = abap_false.
      DO 3 TIMES.
        CASE sy-index.
          WHEN 1. ASSIGN COMPONENT lv_component OF STRUCTURE is_create TO <changes>.
          WHEN 2. ASSIGN COMPONENT lv_component OF STRUCTURE is_update TO <changes>.
          WHEN 3. ASSIGN COMPONENT lv_component OF STRUCTURE is_delete TO <changes>.
        ENDCASE.
        IF sy-subrc <> 0. CONTINUE. ENDIF.
        LOOP AT <changes> ASSIGNING FIELD-SYMBOL(<change>).
          ASSIGN COMPONENT 'ID' OF STRUCTURE <change> TO FIELD-SYMBOL(<id>).
          IF sy-subrc = 0 AND <id> = ls_stamp-id. lv_confirmed = abap_true. EXIT. ENDIF.
        ENDLOOP.
        IF lv_confirmed = abap_true. EXIT. ENDIF.
      ENDDO.
      IF lv_confirmed = abap_true.
        APPEND ls_stamp-history TO lt_history.
      ENDIF.
    ENDLOOP.
    IF lt_history IS NOT INITIAL.
      INSERT ytb_it_hub_histo FROM TABLE @lt_history.
      ASSERT sy-subrc = 0.
    ENDIF.
  ENDMETHOD.
  METHOD guard.
    DATA(ls_guard) = VALUE ty_guard( entity = iv_entity operation = iv_operation row = clone( ir_row ) ).
    IF is_parameter IS SUPPLIED. ls_guard-parameter = clone( REF #( is_parameter ) ). ENDIF.
    APPEND ls_guard TO gt_guards.
  ENDMETHOD.
  METHOD guards.
    rt_guards = gt_guards.
  ENDMETHOD.
  METHOD create_controls.
    DELETE TABLE gt_controls WITH TABLE KEY entity = iv_entity id = iv_id.
    INSERT VALUE #( entity = iv_entity id = iv_id row = clone( REF #( is_control ) ) ) INTO TABLE gt_controls.
  ENDMETHOD.
  METHOD controlled.
    READ TABLE gt_controls INTO DATA(ls_control) WITH TABLE KEY entity = iv_entity id = iv_id.
    IF sy-subrc <> 0. RETURN. ENDIF.
    ASSIGN COMPONENT iv_name OF STRUCTURE ls_control-row->* TO FIELD-SYMBOL(<flag>).
    rv_yes = xsdbool( sy-subrc = 0 AND <flag> = if_abap_behv=>mk-on ).
  ENDMETHOD.
  METHOD reset.
    CLEAR: gt_deletes, gv_save_phase, gt_guards, gt_state, gt_controls, gt_base, gt_loaded, gt_stamps, gt_actions, gt_scopes,
           gv_error, gv_locked, gv_correlation, gv_read_active.
    " Enqueue ownership is the SAP LUW; RAP releases it at transaction end.
  ENDMETHOD.
ENDCLASS.
