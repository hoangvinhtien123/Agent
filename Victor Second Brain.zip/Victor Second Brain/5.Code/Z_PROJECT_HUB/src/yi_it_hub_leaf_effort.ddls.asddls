@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub leaf task effort'
define view entity YI_IT_HUB_LEAF_EFFORT
  as select from ytb_it_hub_task as task
    left outer join ytb_it_hub_task as child
      on child.parent_id = task.id
{
  key task.id as id,
      task.project_id as projectId,
      task.status as status,
      case when task.estimate_hours > 1
           then task.estimate_hours else cast( 1 as abap.dec(9,2) )
      end as effortWeight
}
where task.task_type = 'TASK' and child.id is null
