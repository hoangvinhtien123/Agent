@EndUserText.label: 'IT Hub - Atomic Member Profile Save'
define abstract entity YA_IT_HUB_SAVE_PROFILE
{
  profileJson : abap.string(0);
  skillsJson : abap.string(0);
}
