@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Task'
define root view entity YR_IT_HUB_TASK
  as select from ytb_it_hub_task
  composition [0..*] of YI_IT_HUB_TASKDEP as dependencies
  association [0..1] to YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
  association [0..1] to YI_IT_HUB_WORKSTREAM as _Workstream on $projection.workstreamId = _Workstream.id
  association [0..1] to YR_IT_HUB_TASK as _Parent on $projection.parentId = _Parent.id
  association [0..1] to YR_IT_HUB_MEMBER as _Assignee on $projection.assigneeId = _Assignee.id
  association [0..1] to YR_IT_HUB_MEMBER as _Tester on $projection.testerId = _Tester.id
  association [0..*] to YR_IT_HUB_TASK as _Child on $projection.id = _Child.parentId
{
  key id as id,
  project_id as projectId,
  workstream_id as workstreamId,
  parent_id as parentId,
  source_task_id as sourceTaskId,
  title as title,
  description as description,
  task_type as type,
  status as status,
  priority as priority,
  assignee_id as assigneeId,
  tester_id as testerId,
  implementation_actors_json as implementationActorsJson,
  cycle_reopened as cycleReopened,
  last_outcome_json as lastOutcomeJson,
  due_date as dueDate,
  estimate_hours as estimateHours,
  blocked as blocked,
  blocked_reason as blockedReason,
  impact as impact,
  resolution as resolution,
  completed_at as completedAt,
  sort_order as sortOrder,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  dependencies,
  _Project,
  _Workstream,
  _Parent,
  _Assignee,
  _Tester,
  _Child
}
