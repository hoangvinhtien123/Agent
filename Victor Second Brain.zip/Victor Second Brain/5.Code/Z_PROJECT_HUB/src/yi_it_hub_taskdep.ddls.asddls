@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - TaskDep'
define view entity YI_IT_HUB_TASKDEP
  as select from ytb_it_hub_tdep
  association to parent YR_IT_HUB_TASK as _Task on $projection.taskId = _Task.id
  association [0..1] to YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
  association [0..1] to YR_IT_HUB_TASK as _DependsOn on $projection.dependsOnTaskId = _DependsOn.id
{
  key id as id,
  project_id as projectId,
  task_id as taskId,
  depends_on_task_id as dependsOnTaskId,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Task,
  _Project,
  _DependsOn
}
