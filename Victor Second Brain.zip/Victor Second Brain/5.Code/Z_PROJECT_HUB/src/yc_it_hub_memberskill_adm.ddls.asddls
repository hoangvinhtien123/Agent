@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub admin projection'
define view entity YC_IT_HUB_MEMBERSKILL_ADM
  as projection on YI_IT_HUB_MEMBERSKILL
{
  key id,
  memberId,
  skillId,
  proficiency,
  createdAt,
  updatedAt,
  localLastChangedAt,
  createdBy,
  updatedBy,
  name,
  catalogActive,
  _Catalog : redirected to YC_IT_HUB_SKILL,
  _Member : redirected to parent YC_IT_HUB_MEMBER_ADM
}
