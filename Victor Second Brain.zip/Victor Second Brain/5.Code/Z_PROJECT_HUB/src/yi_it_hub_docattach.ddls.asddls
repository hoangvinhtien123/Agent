@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - DocAttach'
define view entity YI_IT_HUB_DOCATTACH
  as select from ytb_it_hub_doatt
  association to parent YR_IT_HUB_DOCUMENT as _Document on $projection.documentId = _Document.id
  association [0..1] to YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
{
  key id as id,
  project_id as projectId,
  document_id as documentId,
  target_type as targetType,
  target_id as targetId,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Document,
  _Project
}
