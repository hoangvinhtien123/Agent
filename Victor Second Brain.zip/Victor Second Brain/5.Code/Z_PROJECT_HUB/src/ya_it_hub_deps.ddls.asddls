@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_DEPS
{
  dependencyIdsJson : abap.string(0);
}
