@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Event'
define root view entity YC_IT_HUB_EVENT
  provider contract transactional_query
  as projection on YR_IT_HUB_EVENT
{
  key id,
  projectId,
  title,
  kind,
  startAt,
  endAt,
  eventTimeZone,
  location,
  reminderMinutes,
  reminderEnabled,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  attendees : redirected to composition child YC_IT_HUB_EVENTATTENDEE,
  _Project : redirected to YC_IT_HUB_PROJECT
}
