@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Task'
define root view entity YC_IT_HUB_TASK
  provider contract transactional_query
  as projection on YR_IT_HUB_TASK
{
  key id,
  projectId,
  workstreamId,
  parentId,
  sourceTaskId,
  title,
  description,
  type,
  status,
  priority,
  assigneeId,
  testerId,
  implementationActorsJson,
  cycleReopened,
  lastOutcomeJson,
  dueDate,
  estimateHours,
  blocked,
  blockedReason,
  impact,
  resolution,
  completedAt,
  sortOrder,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  dependencies : redirected to composition child YC_IT_HUB_TASKDEP,
  _Project : redirected to YC_IT_HUB_PROJECT,
  _Workstream : redirected to YC_IT_HUB_WORKSTREAM,
  _Parent : redirected to YC_IT_HUB_TASK,
  _Assignee : redirected to YC_IT_HUB_MEMBER,
  _Tester : redirected to YC_IT_HUB_MEMBER,
  _Child : redirected to YC_IT_HUB_TASK
}
