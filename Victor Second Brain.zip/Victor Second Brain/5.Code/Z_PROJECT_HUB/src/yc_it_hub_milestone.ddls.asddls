@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Milestone'
define view entity YC_IT_HUB_MILESTONE
  as projection on YI_IT_HUB_MILESTONE
{
  key id,
  projectId,
  title,
  dueDate,
  status,
  ownerId,
  completedAt,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  _Project : redirected to parent YC_IT_HUB_PROJECT,
  _Owner : redirected to YC_IT_HUB_MEMBER
}
