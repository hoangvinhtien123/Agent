CLASS lhc_Project DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Project RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Project RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Project RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE Project.

    METHODS precheck_create FOR PRECHECK
      IMPORTING entities FOR CREATE Project.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Project.

    METHODS earlynumbering_cba_Membership FOR NUMBERING
      IMPORTING entities FOR CREATE Project\_Membership.

    METHODS precheck_cba_Membership FOR PRECHECK
      IMPORTING entities FOR CREATE Project\_Membership.

    METHODS earlynumbering_cba_Milestone FOR NUMBERING
      IMPORTING entities FOR CREATE Project\_Milestone.

    METHODS precheck_cba_Milestone FOR PRECHECK
      IMPORTING entities FOR CREATE Project\_Milestone.

    METHODS earlynumbering_cba_Risk FOR NUMBERING
      IMPORTING entities FOR CREATE Project\_Risk.

    METHODS precheck_cba_Risk FOR PRECHECK
      IMPORTING entities FOR CREATE Project\_Risk.

    METHODS earlynumbering_cba_Workstream FOR NUMBERING
      IMPORTING entities FOR CREATE Project\_Workstream.

    METHODS precheck_cba_Workstream FOR PRECHECK
      IMPORTING entities FOR CREATE Project\_Workstream.

    METHODS Archive FOR MODIFY
      IMPORTING keys FOR ACTION Project~Archive RESULT result.

    METHODS ReplaceManagers FOR MODIFY
      IMPORTING keys FOR ACTION Project~ReplaceManagers RESULT result.

    METHODS Restore FOR MODIFY
      IMPORTING keys FOR ACTION Project~Restore RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Project~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Project~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Project~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Project~TouchGoverned.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Project~TouchOnSave.
ENDCLASS.

CLASS lhc_Project IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Archive = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Restore = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-ReplaceManagers = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-_Membership = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-_Milestone = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-_Risk = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-_Workstream = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Archive = COND #( WHEN xsdbool( ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'ARCHIVE' ir_row = REF #( ls_db ) ) = abap_true AND ls_db-phase = 'CLOSED' AND ls_db-archived_at IS INITIAL ) = abap_true THEN
if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Restore = COND #( WHEN xsdbool( ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'RESTORE' ir_row = REF #( ls_db ) ) = abap_true AND ls_db-archived_at IS NOT INITIAL ) = abap_true
       THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-ReplaceManagers = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'REPLACEMANAGERS' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_membership TYPE ytb_it_hub_mship.
      ls_cba_membership-project_id = ls_db-id.
      <result>-%features-%assoc-_Membership = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'CREATE' ir_row = REF #( ls_cba_membership ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_milestone TYPE ytb_it_hub_mile.
      ls_cba_milestone-project_id = ls_db-id.
      <result>-%features-%assoc-_Milestone = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MILESTONE' iv_operation = 'CREATE' ir_row = REF #( ls_cba_milestone ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_risk TYPE ytb_it_hub_risk.
      ls_cba_risk-project_id = ls_db-id.
      <result>-%features-%assoc-_Risk = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'RISK' iv_operation = 'CREATE' ir_row = REF #( ls_cba_risk ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_workstream TYPE ytb_it_hub_wstr.
      ls_cba_workstream-project_id = ls_db-id.
      <result>-%features-%assoc-_Workstream = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'WORKSTREAM' iv_operation = 'CREATE' ir_row = REF #( ls_cba_workstream ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
    DATA(ls_permissions) = ycl_it_hub_policy=>permissions( ls_db-id ).
     IF requested_authorizations-%update = if_abap_behv=>mk-on.
     <result>-%update = COND #( WHEN lv_found = abap_true AND ls_permissions-read = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Archive = if_abap_behv=>mk-on.
     <result>-%action-Archive = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'ARCHIVE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Restore = if_abap_behv=>mk-on.
     <result>-%action-Restore = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'RESTORE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-ReplaceManagers = if_abap_behv=>mk-on.
     <result>-%action-ReplaceManagers = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'REPLACEMANAGERS' ir_row = REF #( ls_db ) ) = abap_true
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%create = if_abap_behv=>mk-on.
     result-%create = COND #( WHEN xsdbool( ls_actor-active = abap_true AND ( ls_actor-admin = abap_true OR ls_actor-manager = abap_true ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%update = if_abap_behv=>mk-on.
     result-%update = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Archive = if_abap_behv=>mk-on.
     result-%action-Archive = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Restore = if_abap_behv=>mk-on.
     result-%action-Restore = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-ReplaceManagers = if_abap_behv=>mk-on.
     result-%action-ReplaceManagers = COND #( WHEN xsdbool( ls_actor-active = abap_true AND ls_actor-admin = abap_true ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD earlynumbering_create.
    LOOP AT entities INTO DATA(ls_entity).
      DATA(lv_id) = ls_entity-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_PROJECT' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-project.
        APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-project.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_PROJECT' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'PROJECT' iv_id = lv_id is_control = ls_entity-%control ).
          APPEND VALUE #( %cid = ls_entity-%cid id = lv_id ) TO mapped-project.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-project.
          APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Project identifier.' ) ) TO reported-project.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_create.
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_entity MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_defaults=>apply( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      code TYPE abp_behv_flag,
      name TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      scope TYPE abp_behv_flag,
      phase TYPE abp_behv_flag,
      health TYPE abp_behv_flag,
      start_date TYPE abp_behv_flag,
      end_date TYPE abp_behv_flag,
      accent TYPE abp_behv_flag,
      archived_at TYPE abp_behv_flag,
      archived_by TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      code = ls_entity-%control-code
      name = ls_entity-%control-name
      description = ls_entity-%control-description
      scope = ls_entity-%control-scope
      phase = ls_entity-%control-phase
      health = ls_entity-%control-health
      start_date = ls_entity-%control-startDate
      end_date = ls_entity-%control-endDate
      accent = ls_entity-%control-accent
      archived_at = ls_entity-%control-archivedAt
      archived_by = ls_entity-%control-archivedByTechnical
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'PROJECT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-project.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-code = if_abap_behv=>mk-on. ls_db-code = ls_entity-code. ENDIF.
     IF ls_entity-%control-name = if_abap_behv=>mk-on. ls_db-name = ls_entity-name. ENDIF.
     IF ls_entity-%control-description = if_abap_behv=>mk-on. ls_db-description = ls_entity-description. ENDIF.
     IF ls_entity-%control-scope = if_abap_behv=>mk-on. ls_db-scope = ls_entity-scope. ENDIF.
     IF ls_entity-%control-phase = if_abap_behv=>mk-on. ls_db-phase = ls_entity-phase. ENDIF.
     IF ls_entity-%control-health = if_abap_behv=>mk-on. ls_db-health = ls_entity-health. ENDIF.
     IF ls_entity-%control-startDate = if_abap_behv=>mk-on. ls_db-start_date = ls_entity-startDate. ENDIF.
     IF ls_entity-%control-endDate = if_abap_behv=>mk-on. ls_db-end_date = ls_entity-endDate. ENDIF.
     IF ls_entity-%control-accent = if_abap_behv=>mk-on. ls_db-accent = ls_entity-accent. ENDIF.
     IF ls_entity-%control-archivedAt = if_abap_behv=>mk-on. ls_db-archived_at = ls_entity-archivedAt. ENDIF.
     IF ls_entity-%control-archivedByTechnical = if_abap_behv=>mk-on. ls_db-archived_by = ls_entity-archivedByTechnical. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      code TYPE abp_behv_flag,
      name TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      scope TYPE abp_behv_flag,
      phase TYPE abp_behv_flag,
      health TYPE abp_behv_flag,
      start_date TYPE abp_behv_flag,
      end_date TYPE abp_behv_flag,
      accent TYPE abp_behv_flag,
      archived_at TYPE abp_behv_flag,
      archived_by TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      code = ls_entity-%control-code
      name = ls_entity-%control-name
      description = ls_entity-%control-description
      scope = ls_entity-%control-scope
      phase = ls_entity-%control-phase
      health = ls_entity-%control-health
      start_date = ls_entity-%control-startDate
      end_date = ls_entity-%control-endDate
      accent = ls_entity-%control-accent
      archived_at = ls_entity-%control-archivedAt
      archived_by = ls_entity-%control-archivedByTechnical
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'PROJECT' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_proj.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     IF ls_row-startDate <> ls_db-start_date. ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'MANAGE_SCHEDULE' ir_row = REF #( ls_permission_db ) ). ENDIF.
     IF ls_row-endDate <> ls_db-end_date. ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'MANAGE_SCHEDULE' ir_row = REF #( ls_permission_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-project.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Membership.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_MEMBERSHIP' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-membership.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-membership.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_MEMBERSHIP' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'MEMBERSHIP' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-membership.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-membership.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Membership identifier.' ) ) TO reported-membership.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Membership.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-project_id = ls_source-id.
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      member_id TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      is_project_manager TYPE abp_behv_flag,
      edit_project TYPE abp_behv_flag,
      manage_members TYPE abp_behv_flag,
      assign_work TYPE abp_behv_flag,
      manage_schedule TYPE abp_behv_flag,
      delete_work_items TYPE abp_behv_flag,
      override_workflow TYPE abp_behv_flag,
      manage_permissions TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      member_id = ls_entity-%control-memberId
      active = ls_entity-%control-active
      is_project_manager = ls_entity-%control-isProjectManager
      edit_project = ls_entity-%control-editProject
      manage_members = ls_entity-%control-manageMembers
      assign_work = ls_entity-%control-assignWork
      manage_schedule = ls_entity-%control-manageSchedule
      delete_work_items = ls_entity-%control-deleteWorkItems
      override_workflow = ls_entity-%control-overrideWorkflow
      manage_permissions = ls_entity-%control-managePermissions
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSHIP' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSHIP' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-membership.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Milestone.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_MILESTONE' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-milestone.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-milestone.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_MILESTONE' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'MILESTONE' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-milestone.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-milestone.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Milestone identifier.' ) ) TO reported-milestone.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Milestone.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-project_id = ls_source-id.
     ycl_it_hub_defaults=>apply( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      due_date TYPE abp_behv_flag,
      status TYPE abp_behv_flag,
      owner_id TYPE abp_behv_flag,
      completed_at TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      title = ls_entity-%control-title
      due_date = ls_entity-%control-dueDate
      status = ls_entity-%control-status
      owner_id = ls_entity-%control-ownerId
      completed_at = ls_entity-%control-completedAt
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MILESTONE' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MILESTONE' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-milestone.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-milestone.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Risk.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_RISK' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-risk.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-risk.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_RISK' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'RISK' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-risk.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-risk.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Risk identifier.' ) ) TO reported-risk.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Risk.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-project_id = ls_source-id.
     ycl_it_hub_defaults=>apply( iv_entity = 'RISK' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      task_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      impact TYPE abp_behv_flag,
      likelihood TYPE abp_behv_flag,
      priority TYPE abp_behv_flag,
      owner_id TYPE abp_behv_flag,
      status TYPE abp_behv_flag,
      mitigation_plan TYPE abp_behv_flag,
      resolution TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      task_id = ls_entity-%control-taskId
      title = ls_entity-%control-title
      description = ls_entity-%control-description
      impact = ls_entity-%control-impact
      likelihood = ls_entity-%control-likelihood
      priority = ls_entity-%control-priority
      owner_id = ls_entity-%control-ownerId
      status = ls_entity-%control-status
      mitigation_plan = ls_entity-%control-mitigationPlan
      resolution = ls_entity-%control-resolution
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'RISK' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'RISK' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-risk.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-risk.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Workstream.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_WORKSTREAM' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-workstream.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-workstream.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_WORKSTREAM' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'WORKSTREAM' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-workstream.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-workstream.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Workstream identifier.' ) ) TO reported-workstream.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Workstream.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-project_id = ls_source-id.
     ycl_it_hub_defaults=>apply( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      name TYPE abp_behv_flag,
      owner_id TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      sort_order TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      name = ls_entity-%control-name
      owner_id = ls_entity-%control-ownerId
      description = ls_entity-%control-description
      sort_order = ls_entity-%control-sortOrder
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'WORKSTREAM' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'WORKSTREAM' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-workstream.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-workstream.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD Archive.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'ARCHIVE' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'ARCHIVE' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'PROJECT' iv_id = ls_db-id iv_action = 'ARCHIVE' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'PROJECT' iv_id = ls_db-id ).
     IF ls_db-phase <> 'CLOSED' OR ls_db-archived_at IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Only an unarchived Closed Project can be archived.'. ENDIF.
     GET TIME STAMP FIELD ls_db-archived_at.
     ls_db-archived_by = sy-uname.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-project.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-project TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD ReplaceManagers.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'REPLACEMANAGERS' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'REPLACEMANAGERS' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'PROJECT' iv_id = ls_db-id iv_action = 'REPLACE_MANAGERS' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'PROJECT' iv_id = ls_db-id ).

    DATA(lt_desired) = ycl_it_hub_policy=>parse_array( ls_key-%param-memberIdsJson ).
    READ ENTITIES OF yr_it_hub_project IN LOCAL MODE ENTITY Project BY \_Membership
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_memberships).
    IF lt_desired IS INITIAL AND ls_db-phase <> 'INITIATION'.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A manager is required after INITIATION.'.
    ENDIF.
    LOOP AT lt_desired INTO DATA(lv_member).
      DATA(lv_candidate) = abap_false.
      LOOP AT lt_memberships INTO DATA(ls_candidate) WHERE memberId = lv_member AND active = abap_true.
        lv_candidate = ycl_it_hub_policy=>eligible( ls_candidate-memberId ).
      ENDLOOP.
      IF lv_candidate = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Every manager candidate requires existing active eligible project membership.'.
      ENDIF.
    ENDLOOP.
    DATA lt_manager_updates TYPE TABLE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR lt_manager_updates.
    LOOP AT lt_memberships INTO DATA(ls_membership).
      READ TABLE lt_desired TRANSPORTING NO FIELDS WITH KEY table_line = CONV string( ls_membership-memberId ).
      DATA(lv_appointed) = xsdbool( sy-subrc = 0 ).
      IF lv_appointed = ls_membership-isProjectManager. CONTINUE. ENDIF.
      APPEND VALUE #( id = ls_membership-id isProjectManager = lv_appointed %control-isProjectManager = if_abap_behv=>mk-on ) TO lt_manager_updates ASSIGNING FIELD-SYMBOL(<manager>).
    <manager>-editProject = lv_appointed. <manager>-%control-editProject = if_abap_behv=>mk-on.
    <manager>-manageMembers = lv_appointed. <manager>-%control-manageMembers = if_abap_behv=>mk-on.
    <manager>-assignWork = lv_appointed. <manager>-%control-assignWork = if_abap_behv=>mk-on.
    <manager>-manageSchedule = lv_appointed. <manager>-%control-manageSchedule = if_abap_behv=>mk-on.
    <manager>-deleteWorkItems = lv_appointed. <manager>-%control-deleteWorkItems = if_abap_behv=>mk-on.
    <manager>-overrideWorkflow = lv_appointed. <manager>-%control-overrideWorkflow = if_abap_behv=>mk-on.
    <manager>-managePermissions = lv_appointed. <manager>-%control-managePermissions = if_abap_behv=>mk-on.
    ENDLOOP.
    MODIFY ENTITIES OF yr_it_hub_project IN LOCAL MODE ENTITY Membership UPDATE FROM lt_manager_updates
      FAILED DATA(ls_managers_failed) REPORTED DATA(ls_managers_reported).
    ls_messages = CORRESPONDING #( DEEP ls_managers_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
    IF ls_managers_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Manager replacement failed; the Project cannot be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'PROJECT' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-project.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-project TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD Restore.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'RESTORE' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'RESTORE' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'PROJECT' iv_id = ls_db-id iv_action = 'RESTORE' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'PROJECT' iv_id = ls_db-id ).
     IF ls_db-archived_at IS INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Project is not archived.'. ENDIF.
     CLEAR: ls_db-archived_at, ls_db-archived_by.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-project.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-project TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'PROJECT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.

    " Unmapped Admin can create INITIATION projects; no empty creator Membership.
    IF lv_new = abap_true AND ls_actor-id IS NOT INITIAL
      AND ycl_it_hub_tx=>in_scope( iv_name = 'CREATOR' iv_id = ls_db-id ) = abap_false.
      DATA(lv_has_creator) = abap_false.
      LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_creator).
        IF ycl_it_hub_tx=>field( ir_row = lr_creator iv_name = 'PROJECT_ID' ) = ls_db-id
          AND ycl_it_hub_tx=>field( ir_row = lr_creator iv_name = 'MEMBER_ID' ) = ls_actor-id.
          lv_has_creator = abap_true. EXIT.
        ENDIF.
      ENDLOOP.
      IF lv_has_creator = abap_false.
        IF ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ) = abap_false.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Creator authority was revoked.'.
        ENDIF.
        ycl_it_hub_tx=>scope( iv_name = 'CREATOR' iv_id = ls_db-id iv_on = abap_true ).
        MODIFY ENTITIES OF yr_it_hub_project IN LOCAL MODE
          ENTITY Project CREATE BY \_Membership FIELDS ( memberId active )
          WITH VALUE #( ( id = ls_db-id %target = VALUE #( ( %cid = |OWNER_{ ls_db-id }|
            memberId = ls_actor-id active = abap_true ) ) ) )
          FAILED DATA(ls_owner_failed) REPORTED DATA(ls_owner_reported).
        ycl_it_hub_tx=>scope( iv_name = 'CREATOR' iv_id = ls_db-id iv_on = abap_false ).
        ls_messages = CORRESPONDING #( DEEP ls_owner_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
        IF ls_owner_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'Creator Membership failed; the Project cannot be saved.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
      ENDIF.
    ENDIF.

     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'PROJECT' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.

    " Unmapped Admin can create INITIATION projects; no empty creator Membership.
    IF lv_new = abap_true AND ls_actor-id IS NOT INITIAL
      AND ycl_it_hub_tx=>in_scope( iv_name = 'CREATOR' iv_id = ls_db-id ) = abap_false.
      DATA(lv_has_creator) = abap_false.
      LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_creator).
        IF ycl_it_hub_tx=>field( ir_row = lr_creator iv_name = 'PROJECT_ID' ) = ls_db-id
          AND ycl_it_hub_tx=>field( ir_row = lr_creator iv_name = 'MEMBER_ID' ) = ls_actor-id.
          lv_has_creator = abap_true. EXIT.
        ENDIF.
      ENDLOOP.
      IF lv_has_creator = abap_false.
        IF ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ) = abap_false.
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Creator authority was revoked.'.
        ENDIF.
        ycl_it_hub_tx=>scope( iv_name = 'CREATOR' iv_id = ls_db-id iv_on = abap_true ).
        MODIFY ENTITIES OF yr_it_hub_project IN LOCAL MODE
          ENTITY Project CREATE BY \_Membership FIELDS ( memberId active )
          WITH VALUE #( ( id = ls_db-id %target = VALUE #( ( %cid = |OWNER_{ ls_db-id }|
            memberId = ls_actor-id active = abap_true ) ) ) )
          FAILED DATA(ls_owner_failed) REPORTED DATA(ls_owner_reported).
        ycl_it_hub_tx=>scope( iv_name = 'CREATOR' iv_id = ls_db-id iv_on = abap_false ).
        ls_messages = CORRESPONDING #( DEEP ls_owner_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
        IF ls_owner_failed IS NOT INITIAL.
          ycl_it_hub_tx=>fail( 'Creator Membership failed; the Project cannot be saved.' ).
          RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
        ENDIF.
      ENDIF.
    ENDIF.

     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'PROJECT' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.

     " Only an unmapped trusted Admin may create INITIATION without a creator appointment.
     IF ycl_it_hub_tx=>before( iv_entity = 'PROJECT' iv_id = ls_db-id ) IS NOT BOUND
       AND ( ls_db-created_by_member_id IS NOT INITIAL OR ls_actor-id IS NOT INITIAL
         OR ls_actor-admin = abap_false OR ls_db-phase <> 'INITIATION' ).
       DATA(lv_has_owner) = abap_false.
       LOOP AT ycl_it_hub_tx=>rows( 'MEMBERSHIP' ) INTO DATA(lr_owner).
         IF ycl_it_hub_tx=>field( ir_row = lr_owner iv_name = 'PROJECT_ID' ) = ls_db-id
           AND ycl_it_hub_tx=>field( ir_row = lr_owner iv_name = 'MEMBER_ID' ) = ls_db-created_by_member_id
           AND ycl_it_hub_tx=>field( ir_row = lr_owner iv_name = 'ACTIVE' ) = abap_true
           AND ycl_it_hub_tx=>field( ir_row = lr_owner iv_name = 'IS_PROJECT_MANAGER' ) = abap_true.
           lv_has_owner = abap_true.
           SPLIT 'EDIT_PROJECT,MANAGE_MEMBERS,ASSIGN_WORK,MANAGE_SCHEDULE,DELETE_WORK_ITEMS,OVERRIDE_WORKFLOW,MANAGE_PERMISSIONS' AT ',' INTO TABLE DATA(lt_owner_flags).
           LOOP AT lt_owner_flags INTO DATA(lv_owner_flag).
             IF ycl_it_hub_tx=>field( ir_row = lr_owner iv_name = lv_owner_flag ) <> abap_true. lv_has_owner = abap_false. EXIT. ENDIF.
           ENDLOOP.
           IF lv_has_owner = abap_true. EXIT. ENDIF.
         ENDIF.
       ENDLOOP.
       IF lv_has_owner = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'New Project requires its creator Membership and appointment.'. ENDIF.
     ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-project.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_PROJECT' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'PROJECT' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-project.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Project ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_PROJECT' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_proj.
    ls_db = CORRESPONDING #( ls_row MAPPING start_date = startDate end_date = endDate archived_at = archivedAt archived_by = archivedByTechnical created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'PROJECT' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-code <> ls_db-code. ls_update-code = ls_db-code. ls_update-%control-code = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-scope <> ls_db-scope. ls_update-scope = ls_db-scope. ls_update-%control-scope = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-phase <> ls_db-phase. ls_update-phase = ls_db-phase. ls_update-%control-phase = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-health <> ls_db-health. ls_update-health = ls_db-health. ls_update-%control-health = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-startDate <> ls_db-start_date. ls_update-startDate = ls_db-start_date. ls_update-%control-startDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-endDate <> ls_db-end_date. ls_update-endDate = ls_db-end_date. ls_update-%control-endDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-accent <> ls_db-accent. ls_update-accent = ls_db-accent. ls_update-%control-accent = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedAt <> ls_db-archived_at. ls_update-archivedAt = ls_db-archived_at. ls_update-%control-archivedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-archivedByTechnical <> ls_db-archived_by. ls_update-archivedByTechnical = ls_db-archived_by. ls_update-%control-archivedByTechnical = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Project UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-project.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-project.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_Workstream DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Workstream RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Workstream.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE Workstream.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Workstream~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Workstream~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Workstream~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR Workstream~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR Workstream~validate_delete.
ENDCLASS.

CLASS lhc_Workstream IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Workstream ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'WORKSTREAM' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'WORKSTREAM' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Workstream ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-name = if_abap_behv=>mk-on. ls_db-name = ls_entity-name. ENDIF.
     IF ls_entity-%control-ownerId = if_abap_behv=>mk-on. ls_db-owner_id = ls_entity-ownerId. ENDIF.
     IF ls_entity-%control-description = if_abap_behv=>mk-on. ls_db-description = ls_entity-description. ENDIF.
     IF ls_entity-%control-sortOrder = if_abap_behv=>mk-on. ls_db-sort_order = ls_entity-sortOrder. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      name TYPE abp_behv_flag,
      owner_id TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      sort_order TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      name = ls_entity-%control-name
      owner_id = ls_entity-%control-ownerId
      description = ls_entity-%control-description
      sort_order = ls_entity-%control-sortOrder
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'WORKSTREAM' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_wstr.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'WORKSTREAM' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     IF ls_row-ownerId <> ls_db-owner_id. ycl_it_hub_tx=>guard( iv_entity = 'WORKSTREAM' iv_operation = 'MANAGE_SCHEDULE' ir_row = REF #( ls_permission_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-workstream.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-workstream.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Workstream ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'WORKSTREAM' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_wstr.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'WORKSTREAM' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-workstream.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-workstream.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Workstream ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'WORKSTREAM' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Workstream.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-ownerId <> ls_db-owner_id. ls_update-ownerId = ls_db-owner_id. ls_update-%control-ownerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Workstream UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-workstream.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Workstream ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'WORKSTREAM' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Workstream.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-ownerId <> ls_db-owner_id. ls_update-ownerId = ls_db-owner_id. ls_update-%control-ownerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-sortOrder <> ls_db-sort_order. ls_update-sortOrder = ls_db-sort_order. ls_update-%control-sortOrder = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Workstream UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-workstream.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Workstream ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_wstr.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId owner_id = ownerId sort_order = sortOrder created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'WORKSTREAM' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-workstream.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-workstream.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'WORKSTREAM' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-workstream.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'WORKSTREAM' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'WORKSTREAM' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'WORKSTREAM' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-workstream.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-workstream.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_Membership DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Membership RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Membership RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Membership RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Membership.

    METHODS earlynumbering_cba_Roles FOR NUMBERING
      IMPORTING entities FOR CREATE Membership\Roles.

    METHODS precheck_cba_Roles FOR PRECHECK
      IMPORTING entities FOR CREATE Membership\Roles.

    METHODS ReplaceRoles FOR MODIFY
      IMPORTING keys FOR ACTION Membership~ReplaceRoles RESULT result.

    METHODS Reactivate FOR MODIFY
      IMPORTING keys FOR ACTION Membership~Reactivate RESULT result.

    METHODS SetManagerPermissions FOR MODIFY
      IMPORTING keys FOR ACTION Membership~SetManagerPermissions RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Membership~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Membership~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Membership~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Membership~TouchGoverned.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Membership~TouchOnSave.
ENDCLASS.

CLASS lhc_Membership IMPLEMENTATION.
  METHOD Reactivate.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_tx=>lock( ).
          " Validate the complete desired set before changing active state.
          DATA(lt_roles) = ycl_it_hub_policy=>parse_array(
            iv_json = ls_key-%param-rolesJson iv_kind = 'ROLE' ).
          DATA(lv_roles_json) = /ui2/cl_json=>serialize( data = lt_roles ).
          READ ENTITIES OF yr_it_hub_project IN LOCAL MODE ENTITY Membership
            ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_before).
          READ TABLE lt_before INTO DATA(ls_before) INDEX 1.
          IF sy-subrc <> 0.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Membership no longer exists.'.
          ENDIF.
          IF ls_before-active = abap_true.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Membership is already active; edit its existing responsibilities.'.
          ENDIF.
          DATA(ls_row) = VALUE ytb_it_hub_mship( id = ls_before-id
            project_id = ls_before-projectId member_id = ls_before-memberId active = ls_before-active ).
          IF ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'UPDATE'
            ir_row = REF #( ls_row ) ) = abap_false.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Membership reactivation is not authorized.'.
          ENDIF.
          IF ycl_it_hub_policy=>eligible( ls_before-memberId ) = abap_false.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Member requires an active identity and trusted app grant.'.
          ENDIF.
          " Normal EML retains prechecks, authorization and feature control.
          MODIFY ENTITIES OF yr_it_hub_project ENTITY Membership
            UPDATE FIELDS ( active ) WITH VALUE #( ( id = ls_key-id active = abap_true ) )
            FAILED DATA(ls_update_failed) REPORTED DATA(ls_update_reported).
          LOOP AT ls_update_reported-membership INTO DATA(ls_update_message).
            APPEND CORRESPONDING #( ls_update_message ) TO reported-membership.
          ENDLOOP.
          IF ls_update_failed IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Membership reactivation failed; no changes were saved.'.
          ENDIF.
          MODIFY ENTITIES OF yr_it_hub_project ENTITY Membership EXECUTE ReplaceRoles
            FROM VALUE #( ( id = ls_key-id %param-rolesJson = lv_roles_json ) )
            FAILED DATA(ls_roles_failed) REPORTED DATA(ls_roles_reported).
          LOOP AT ls_roles_reported-membership INTO DATA(ls_roles_message).
            APPEND CORRESPONDING #( ls_roles_message ) TO reported-membership.
          ENDLOOP.
          LOOP AT ls_roles_reported-roleassign INTO DATA(ls_child_message).
            APPEND CORRESPONDING #( ls_child_message ) TO reported-roleassign.
          ENDLOOP.
          IF ls_roles_failed IS NOT INITIAL.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Responsibility replacement failed; the membership remains inactive.'.
          ENDIF.
          READ ENTITIES OF yr_it_hub_project IN LOCAL MODE ENTITY Membership
            ALL FIELDS WITH VALUE #( ( id = ls_key-id ) ) RESULT DATA(lt_after).
          READ TABLE lt_after INTO DATA(ls_after) INDEX 1.
          IF sy-subrc <> 0.
            RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Reactivated membership could not be read.'.
          ENDIF.
          APPEND VALUE #( %tky = ls_key-%tky %param = CORRESPONDING #( ls_after ) ) TO result.
        CATCH ycx_it_hub INTO DATA(lx_reactivate).
          ycl_it_hub_tx=>fail( lx_reactivate->text ).
          APPEND VALUE #( %tky = ls_key-%tky ) TO failed-membership.
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_reactivate->text ) ) TO reported-membership.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-ReplaceRoles = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-SetManagerPermissions = if_abap_behv=>fc-o-disabled.
      <result>-%features-%assoc-Roles = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-ReplaceRoles = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'REPLACEROLES' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-SetManagerPermissions = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'SETMANAGERPERMISSIONS' ir_row = REF #( ls_db ) ) = abap_true
       THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      DATA ls_cba_roleassign TYPE ytb_it_hub_prole.
      ls_cba_roleassign-membership_id = ls_db-id.
      ls_cba_roleassign-project_id = ls_db-project_id.
      <result>-%features-%assoc-Roles = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'ROLEASSIGN' iv_operation = 'CREATE' ir_row = REF #( ls_cba_roleassign ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF requested_authorizations-%action-ReplaceRoles = if_abap_behv=>mk-on.
     <result>-%action-ReplaceRoles = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'REPLACEROLES' ir_row = REF #( ls_db ) ) = abap_true
      THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-SetManagerPermissions = if_abap_behv=>mk-on.
     <result>-%action-SetManagerPermissions = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'SETMANAGERPERMISSIONS' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE
if_abap_behv=>auth-unauthorized ).
     ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%action-ReplaceRoles = if_abap_behv=>mk-on.
     result-%action-ReplaceRoles = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-SetManagerPermissions = if_abap_behv=>mk-on.
     result-%action-SetManagerPermissions = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-memberId = if_abap_behv=>mk-on. ls_db-member_id = ls_entity-memberId. ENDIF.
     IF ls_entity-%control-active = if_abap_behv=>mk-on. ls_db-active = ls_entity-active. ENDIF.
     IF ls_entity-%control-isProjectManager = if_abap_behv=>mk-on. ls_db-is_project_manager = ls_entity-isProjectManager. ENDIF.
     IF ls_entity-%control-editProject = if_abap_behv=>mk-on. ls_db-edit_project = ls_entity-editProject. ENDIF.
     IF ls_entity-%control-manageMembers = if_abap_behv=>mk-on. ls_db-manage_members = ls_entity-manageMembers. ENDIF.
     IF ls_entity-%control-assignWork = if_abap_behv=>mk-on. ls_db-assign_work = ls_entity-assignWork. ENDIF.
     IF ls_entity-%control-manageSchedule = if_abap_behv=>mk-on. ls_db-manage_schedule = ls_entity-manageSchedule. ENDIF.
     IF ls_entity-%control-deleteWorkItems = if_abap_behv=>mk-on. ls_db-delete_work_items = ls_entity-deleteWorkItems. ENDIF.
     IF ls_entity-%control-overrideWorkflow = if_abap_behv=>mk-on. ls_db-override_workflow = ls_entity-overrideWorkflow. ENDIF.
     IF ls_entity-%control-managePermissions = if_abap_behv=>mk-on. ls_db-manage_permissions = ls_entity-managePermissions. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      member_id TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      is_project_manager TYPE abp_behv_flag,
      edit_project TYPE abp_behv_flag,
      manage_members TYPE abp_behv_flag,
      assign_work TYPE abp_behv_flag,
      manage_schedule TYPE abp_behv_flag,
      delete_work_items TYPE abp_behv_flag,
      override_workflow TYPE abp_behv_flag,
      manage_permissions TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      member_id = ls_entity-%control-memberId
      active = ls_entity-%control-active
      is_project_manager = ls_entity-%control-isProjectManager
      edit_project = ls_entity-%control-editProject
      manage_members = ls_entity-%control-manageMembers
      assign_work = ls_entity-%control-assignWork
      manage_schedule = ls_entity-%control-manageSchedule
      delete_work_items = ls_entity-%control-deleteWorkItems
      override_workflow = ls_entity-%control-overrideWorkflow
      manage_permissions = ls_entity-%control-managePermissions
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSHIP' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_mship.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSHIP' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-membership.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD earlynumbering_cba_Roles.
    LOOP AT entities INTO DATA(ls_source).
      LOOP AT ls_source-%target INTO DATA(ls_target).
      DATA(lv_id) = ls_target-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_ROLEASSIGN' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_target-%cid ) TO failed-roleassign.
        APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-roleassign.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_ROLEASSIGN' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'ROLEASSIGN' iv_id = lv_id is_control = ls_target-%control ).
          APPEND VALUE #( %cid = ls_target-%cid id = lv_id ) TO mapped-roleassign.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_target-%cid ) TO failed-roleassign.
          APPEND VALUE #( %cid = ls_target-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a RoleAssign identifier.' ) ) TO reported-roleassign.
      ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_cba_Roles.
    LOOP AT entities INTO DATA(ls_source).
     LOOP AT ls_source-%target INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_entity MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ls_db-membership_id = ls_source-id.
     DATA(lr_parent) = ycl_it_hub_tx=>get( iv_entity = 'MEMBERSHIP' iv_id = ls_source-id ).
     ls_db-project_id = ycl_it_hub_tx=>field( ir_row = lr_parent iv_name = 'PROJECT_ID' ).
     ycl_it_hub_defaults=>apply( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      membership_id TYPE abp_behv_flag,
      role TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      membership_id = ls_entity-%control-membershipId
      role = ls_entity-%control-role
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'ROLEASSIGN' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control
      iv_defer_parent = xsdbool( lr_parent IS NOT BOUND AND ( ls_source-%cid_ref IS NOT INITIAL OR ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_MEMBERSHIP' iv_id = ls_source-id ) = abap_true ) ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     IF lr_parent IS BOUND. ycl_it_hub_tx=>guard( iv_entity = 'ROLEASSIGN' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-roleassign.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-roleassign.
     ENDTRY.
    ENDLOOP.
    ENDLOOP.
  ENDMETHOD.

  METHOD ReplaceRoles.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'REPLACEROLES' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSHIP' iv_operation = 'REPLACEROLES' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id iv_action = 'REPLACE_ROLES' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id ).
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership BY \roles
      ALL FIELDS WITH VALUE #( ( id = ls_db-id ) ) RESULT DATA(lt_children).
    DATA lt_delete TYPE TABLE FOR DELETE YR_IT_HUB_PROJECT\\RoleAssign.
    DATA lt_create TYPE TABLE FOR CREATE YR_IT_HUB_PROJECT\\Membership\roles.
    CLEAR: lt_delete, lt_create.
    DATA(lt_desired) = ycl_it_hub_policy=>parse_array( iv_json = ls_key-%param-rolesJson iv_kind = 'ROLE' ).
    APPEND VALUE #( id = ls_db-id ) TO lt_create ASSIGNING FIELD-SYMBOL(<source>).
    IF ls_db-active <> abap_true OR ycl_it_hub_policy=>eligible( ls_db-member_id ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Roles require an active eligible Membership.'. ENDIF.
    LOOP AT lt_children INTO DATA(ls_child).
      READ TABLE lt_desired TRANSPORTING NO FIELDS WITH KEY table_line = CONV string( ls_child-role ).
      IF sy-subrc <> 0. APPEND VALUE #( id = ls_child-id ) TO lt_delete. ENDIF.
    ENDLOOP.
    LOOP AT lt_desired INTO DATA(lv_value).
      DATA(lv_existing) = abap_false.
      LOOP AT lt_children TRANSPORTING NO FIELDS WHERE role = lv_value. lv_existing = abap_true. EXIT. ENDLOOP.
      IF lv_existing = abap_true. CONTINUE. ENDIF.
    APPEND VALUE #( %cid = |LINK_{ lv_value }| role = CONV #( lv_value ) %control-role = if_abap_behv=>mk-on ) TO <source>-%target.
    ENDLOOP.
    LOOP AT lt_delete INTO DATA(ls_delete_key).
      READ TABLE lt_children INTO DATA(ls_deleted_child) WITH TABLE KEY entity COMPONENTS id = ls_delete_key-id.
      DATA ls_deleted_db TYPE ytb_it_hub_prole.
    ls_deleted_db = CORRESPONDING #( ls_deleted_child MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ycl_it_hub_tx=>stage_delete( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_deleted_db ) iv_actor = ls_actor-id ).
    ENDLOOP.
    MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign DELETE FROM lt_delete
      ENTITY Membership CREATE BY \roles FROM lt_create
      FAILED DATA(ls_replace_failed) REPORTED DATA(ls_replace_reported).
    ls_messages = CORRESPONDING #( DEEP ls_replace_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
    IF ls_replace_failed IS NOT INITIAL.
      ycl_it_hub_tx=>fail( 'Replacement failed; no part of the replacement may be saved.' ).
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
    ENDIF.
    LOOP AT lt_delete INTO DATA(ls_removed_key).
      ycl_it_hub_tx=>overlay_deleted( iv_entity = 'ROLEASSIGN' iv_id = ls_removed_key-id ).
    ENDLOOP.

    ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id ).
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isProjectManager <> ls_db-is_project_manager. ls_update-isProjectManager = ls_db-is_project_manager. ls_update-%control-isProjectManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-editProject <> ls_db-edit_project. ls_update-editProject = ls_db-edit_project. ls_update-%control-editProject = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageMembers <> ls_db-manage_members. ls_update-manageMembers = ls_db-manage_members. ls_update-%control-manageMembers = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assignWork <> ls_db-assign_work. ls_update-assignWork = ls_db-assign_work. ls_update-%control-assignWork = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageSchedule <> ls_db-manage_schedule. ls_update-manageSchedule = ls_db-manage_schedule. ls_update-%control-manageSchedule = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-deleteWorkItems <> ls_db-delete_work_items. ls_update-deleteWorkItems = ls_db-delete_work_items. ls_update-%control-deleteWorkItems = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-overrideWorkflow <> ls_db-override_workflow. ls_update-overrideWorkflow = ls_db-override_workflow. ls_update-%control-overrideWorkflow = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-managePermissions <> ls_db-manage_permissions. ls_update-managePermissions = ls_db-manage_permissions. ls_update-%control-managePermissions = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-membership.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-membership TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD SetManagerPermissions.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'MEMBERSHIP' iv_operation = 'SETMANAGERPERMISSIONS' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'MEMBERSHIP' iv_operation = 'SETMANAGERPERMISSIONS' ir_row = REF #( ls_db ) is_parameter = ls_key-%param ).
     ycl_it_hub_tx=>operation( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id iv_action = 'SET_MANAGER_PERMISSIONS' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id ).

    IF ls_db-active <> abap_true OR ls_db-is_project_manager <> abap_true OR ycl_it_hub_policy=>eligible( ls_db-member_id ) = abap_false.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Target must be an active eligible appointed manager.'.
    ENDIF.
    DATA(ls_permissions) = ycl_it_hub_policy=>permissions( iv_project = ls_db-project_id ).
    IF ls_actor-admin = abap_false AND ls_db-member_id = ls_actor-id.
      RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Managers cannot replace their own permission flags.'.
    ENDIF.
    IF ls_key-%param-editProject <> abap_true AND ls_key-%param-editProject <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-editProject = abap_true AND ls_permissions-edit_project = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-edit_project = ls_key-%param-editProject.
    IF ls_key-%param-manageMembers <> abap_true AND ls_key-%param-manageMembers <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-manageMembers = abap_true AND ls_permissions-manage_members = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-manage_members = ls_key-%param-manageMembers.
    IF ls_key-%param-assignWork <> abap_true AND ls_key-%param-assignWork <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-assignWork = abap_true AND ls_permissions-assign_work = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-assign_work = ls_key-%param-assignWork.
    IF ls_key-%param-manageSchedule <> abap_true AND ls_key-%param-manageSchedule <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-manageSchedule = abap_true AND ls_permissions-manage_schedule = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-manage_schedule = ls_key-%param-manageSchedule.
    IF ls_key-%param-deleteWorkItems <> abap_true AND ls_key-%param-deleteWorkItems <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-deleteWorkItems = abap_true AND ls_permissions-delete_work_items = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-delete_work_items = ls_key-%param-deleteWorkItems.
    IF ls_key-%param-overrideWorkflow <> abap_true AND ls_key-%param-overrideWorkflow <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-overrideWorkflow = abap_true AND ls_permissions-override_workflow = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-override_workflow = ls_key-%param-overrideWorkflow.
    IF ls_key-%param-managePermissions <> abap_true AND ls_key-%param-managePermissions <> abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'All permission values must be booleans.'.
    ENDIF.
    IF ls_actor-admin = abap_false AND ls_key-%param-managePermissions = abap_true AND ls_permissions-manage_permissions = abap_false.
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Cannot grant permissions beyond your own stored flags.'.
    ENDIF.
    ls_db-manage_permissions = ls_key-%param-managePermissions.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isProjectManager <> ls_db-is_project_manager. ls_update-isProjectManager = ls_db-is_project_manager. ls_update-%control-isProjectManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-editProject <> ls_db-edit_project. ls_update-editProject = ls_db-edit_project. ls_update-%control-editProject = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageMembers <> ls_db-manage_members. ls_update-manageMembers = ls_db-manage_members. ls_update-%control-manageMembers = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assignWork <> ls_db-assign_work. ls_update-assignWork = ls_db-assign_work. ls_update-%control-assignWork = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageSchedule <> ls_db-manage_schedule. ls_update-manageSchedule = ls_db-manage_schedule. ls_update-%control-manageSchedule = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-deleteWorkItems <> ls_db-delete_work_items. ls_update-deleteWorkItems = ls_db-delete_work_items. ls_update-%control-deleteWorkItems = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-overrideWorkflow <> ls_db-override_workflow. ls_update-overrideWorkflow = ls_db-override_workflow. ls_update-%control-overrideWorkflow = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-managePermissions <> ls_db-manage_permissions. ls_update-managePermissions = ls_db-manage_permissions. ls_update-%control-managePermissions = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-membership.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-membership TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isProjectManager <> ls_db-is_project_manager. ls_update-isProjectManager = ls_db-is_project_manager. ls_update-%control-isProjectManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-editProject <> ls_db-edit_project. ls_update-editProject = ls_db-edit_project. ls_update-%control-editProject = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageMembers <> ls_db-manage_members. ls_update-manageMembers = ls_db-manage_members. ls_update-%control-manageMembers = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assignWork <> ls_db-assign_work. ls_update-assignWork = ls_db-assign_work. ls_update-%control-assignWork = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageSchedule <> ls_db-manage_schedule. ls_update-manageSchedule = ls_db-manage_schedule. ls_update-%control-manageSchedule = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-deleteWorkItems <> ls_db-delete_work_items. ls_update-deleteWorkItems = ls_db-delete_work_items. ls_update-%control-deleteWorkItems = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-overrideWorkflow <> ls_db-override_workflow. ls_update-overrideWorkflow = ls_db-override_workflow. ls_update-%control-overrideWorkflow = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-managePermissions <> ls_db-manage_permissions. ls_update-managePermissions = ls_db-manage_permissions. ls_update-%control-managePermissions = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MEMBERSHIP' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isProjectManager <> ls_db-is_project_manager. ls_update-isProjectManager = ls_db-is_project_manager. ls_update-%control-isProjectManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-editProject <> ls_db-edit_project. ls_update-editProject = ls_db-edit_project. ls_update-%control-editProject = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageMembers <> ls_db-manage_members. ls_update-manageMembers = ls_db-manage_members. ls_update-%control-manageMembers = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assignWork <> ls_db-assign_work. ls_update-assignWork = ls_db-assign_work. ls_update-%control-assignWork = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageSchedule <> ls_db-manage_schedule. ls_update-manageSchedule = ls_db-manage_schedule. ls_update-%control-manageSchedule = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-deleteWorkItems <> ls_db-delete_work_items. ls_update-deleteWorkItems = ls_db-delete_work_items. ls_update-%control-deleteWorkItems = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-overrideWorkflow <> ls_db-override_workflow. ls_update-overrideWorkflow = ls_db-override_workflow. ls_update-%control-overrideWorkflow = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-managePermissions <> ls_db-manage_permissions. ls_update-managePermissions = ls_db-manage_permissions. ls_update-%control-managePermissions = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-membership.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_MEMBERSHIP' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'MEMBERSHIP' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isProjectManager <> ls_db-is_project_manager. ls_update-isProjectManager = ls_db-is_project_manager. ls_update-%control-isProjectManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-editProject <> ls_db-edit_project. ls_update-editProject = ls_db-edit_project. ls_update-%control-editProject = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageMembers <> ls_db-manage_members. ls_update-manageMembers = ls_db-manage_members. ls_update-%control-manageMembers = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assignWork <> ls_db-assign_work. ls_update-assignWork = ls_db-assign_work. ls_update-%control-assignWork = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageSchedule <> ls_db-manage_schedule. ls_update-manageSchedule = ls_db-manage_schedule. ls_update-%control-manageSchedule = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-deleteWorkItems <> ls_db-delete_work_items. ls_update-deleteWorkItems = ls_db-delete_work_items. ls_update-%control-deleteWorkItems = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-overrideWorkflow <> ls_db-override_workflow. ls_update-overrideWorkflow = ls_db-override_workflow. ls_update-%control-overrideWorkflow = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-managePermissions <> ls_db-manage_permissions. ls_update-managePermissions = ls_db-manage_permissions. ls_update-%control-managePermissions = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-membership.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Membership ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_MEMBERSHIP' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_mship.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId member_id = memberId is_project_manager = isProjectManager edit_project = editProject manage_members = manageMembers assign_work = assignWork manage_schedule = manageSchedule
delete_work_items = deleteWorkItems override_workflow = overrideWorkflow manage_permissions = managePermissions created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'MEMBERSHIP' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Membership.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-memberId <> ls_db-member_id. ls_update-memberId = ls_db-member_id. ls_update-%control-memberId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-isProjectManager <> ls_db-is_project_manager. ls_update-isProjectManager = ls_db-is_project_manager. ls_update-%control-isProjectManager = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-editProject <> ls_db-edit_project. ls_update-editProject = ls_db-edit_project. ls_update-%control-editProject = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageMembers <> ls_db-manage_members. ls_update-manageMembers = ls_db-manage_members. ls_update-%control-manageMembers = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-assignWork <> ls_db-assign_work. ls_update-assignWork = ls_db-assign_work. ls_update-%control-assignWork = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-manageSchedule <> ls_db-manage_schedule. ls_update-manageSchedule = ls_db-manage_schedule. ls_update-%control-manageSchedule = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-deleteWorkItems <> ls_db-delete_work_items. ls_update-deleteWorkItems = ls_db-delete_work_items. ls_update-%control-deleteWorkItems = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-overrideWorkflow <> ls_db-override_workflow. ls_update-overrideWorkflow = ls_db-override_workflow. ls_update-%control-overrideWorkflow = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-managePermissions <> ls_db-manage_permissions. ls_update-managePermissions = ls_db-manage_permissions. ls_update-%control-managePermissions = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Membership UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-membership.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-membership.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_RoleAssign DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR RoleAssign RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE RoleAssign.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE RoleAssign.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR RoleAssign~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR RoleAssign~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR RoleAssign~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR RoleAssign~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR RoleAssign~validate_delete.
ENDCLASS.

CLASS lhc_RoleAssign IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN abap_false = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'ROLEASSIGN' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-membershipId = if_abap_behv=>mk-on. ls_db-membership_id = ls_entity-membershipId. ENDIF.
     IF ls_entity-%control-role = if_abap_behv=>mk-on. ls_db-role = ls_entity-role. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      membership_id TYPE abp_behv_flag,
      role TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      membership_id = ls_entity-%control-membershipId
      role = ls_entity-%control-role
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'ROLEASSIGN' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_prole.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'ROLEASSIGN' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Link records are immutable; use the replacement action or create/delete.'.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-roleassign.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-roleassign.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'ROLEASSIGN' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_prole.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at =
localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'ROLEASSIGN' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-roleassign.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-roleassign.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'ROLEASSIGN' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_project IN LOCAL MODE ENTITY Membership
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-membership_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\RoleAssign.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-membershipId <> ls_db-membership_id. ls_update-membershipId = ls_db-membership_id. ls_update-%control-membershipId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-role <> ls_db-role. ls_update-role = ls_db-role. ls_update-%control-role = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY RoleAssign UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-roleassign.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'ROLEASSIGN' iv_id = ls_db-id ) IS NOT BOUND ).
    READ ENTITIES OF yr_it_hub_project IN LOCAL MODE ENTITY Membership
      FIELDS ( projectId ) WITH VALUE #( ( id = ls_db-membership_id ) ) RESULT DATA(lt_parent_rows).
    READ TABLE lt_parent_rows INTO DATA(ls_parent_row) INDEX 1.
    IF sy-subrc = 0. ls_db-project_id = ls_parent_row-projectId. ENDIF.
     IF ycl_it_hub_tx=>before( iv_entity = 'ROLEASSIGN' iv_id = ls_db-id ) IS NOT BOUND.
       ycl_it_hub_tx=>guard( iv_entity = 'ROLEASSIGN' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     ENDIF.
     ycl_it_hub_defaults=>apply( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\RoleAssign.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-membershipId <> ls_db-membership_id. ls_update-membershipId = ls_db-membership_id. ls_update-%control-membershipId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-role <> ls_db-role. ls_update-role = ls_db-role. ls_update-%control-role = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY RoleAssign UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-roleassign.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY RoleAssign ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_prole.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId membership_id = membershipId created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'ROLEASSIGN' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-roleassign.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-roleassign.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'ROLEASSIGN' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-roleassign.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'ROLEASSIGN' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'ROLEASSIGN' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'ROLEASSIGN' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-roleassign.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-roleassign.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_Milestone DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Milestone RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Milestone.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE Milestone.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Milestone~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Milestone~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Milestone~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR Milestone~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR Milestone~validate_delete.
ENDCLASS.

CLASS lhc_Milestone IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Milestone ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MILESTONE' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'MILESTONE' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Milestone ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-title = if_abap_behv=>mk-on. ls_db-title = ls_entity-title. ENDIF.
     IF ls_entity-%control-dueDate = if_abap_behv=>mk-on. ls_db-due_date = ls_entity-dueDate. ENDIF.
     IF ls_entity-%control-status = if_abap_behv=>mk-on. ls_db-status = ls_entity-status. ENDIF.
     IF ls_entity-%control-ownerId = if_abap_behv=>mk-on. ls_db-owner_id = ls_entity-ownerId. ENDIF.
     IF ls_entity-%control-completedAt = if_abap_behv=>mk-on. ls_db-completed_at = ls_entity-completedAt. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      due_date TYPE abp_behv_flag,
      status TYPE abp_behv_flag,
      owner_id TYPE abp_behv_flag,
      completed_at TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      title = ls_entity-%control-title
      due_date = ls_entity-%control-dueDate
      status = ls_entity-%control-status
      owner_id = ls_entity-%control-ownerId
      completed_at = ls_entity-%control-completedAt
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MILESTONE' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_mile.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MILESTONE' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-milestone.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-milestone.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Milestone ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MILESTONE' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_mile.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'MILESTONE' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-milestone.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-milestone.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Milestone ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MILESTONE' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Milestone.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-ownerId <> ls_db-owner_id. ls_update-ownerId = ls_db-owner_id. ls_update-%control-ownerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Milestone UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-milestone.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Milestone ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'MILESTONE' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Milestone.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-dueDate <> ls_db-due_date. ls_update-dueDate = ls_db-due_date. ls_update-%control-dueDate = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-ownerId <> ls_db-owner_id. ls_update-ownerId = ls_db-owner_id. ls_update-%control-ownerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-completedAt <> ls_db-completed_at. ls_update-completedAt = ls_db-completed_at. ls_update-%control-completedAt = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Milestone UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-milestone.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Milestone ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_mile.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId due_date = dueDate owner_id = ownerId completed_at = completedAt created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MILESTONE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-milestone.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-milestone.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'MILESTONE' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-milestone.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'MILESTONE' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'MILESTONE' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'MILESTONE' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-milestone.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-milestone.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lhc_Risk DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Risk RESULT result.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Risk.

    METHODS precheck_delete FOR PRECHECK
      IMPORTING keys FOR DELETE Risk.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Risk~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Risk~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Risk~validate_state.

    METHODS prepare_delete FOR DETERMINE ON SAVE IMPORTING keys FOR Risk~prepare_delete.
    METHODS validate_delete FOR VALIDATE ON SAVE IMPORTING keys FOR Risk~validate_delete.
ENDCLASS.

CLASS lhc_Risk IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Risk ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%delete = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'RISK' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%delete = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'RISK' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Risk ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-projectId = if_abap_behv=>mk-on. ls_db-project_id = ls_entity-projectId. ENDIF.
     IF ls_entity-%control-taskId = if_abap_behv=>mk-on. ls_db-task_id = ls_entity-taskId. ENDIF.
     IF ls_entity-%control-title = if_abap_behv=>mk-on. ls_db-title = ls_entity-title. ENDIF.
     IF ls_entity-%control-description = if_abap_behv=>mk-on. ls_db-description = ls_entity-description. ENDIF.
     IF ls_entity-%control-impact = if_abap_behv=>mk-on. ls_db-impact = ls_entity-impact. ENDIF.
     IF ls_entity-%control-likelihood = if_abap_behv=>mk-on. ls_db-likelihood = ls_entity-likelihood. ENDIF.
     IF ls_entity-%control-priority = if_abap_behv=>mk-on. ls_db-priority = ls_entity-priority. ENDIF.
     IF ls_entity-%control-ownerId = if_abap_behv=>mk-on. ls_db-owner_id = ls_entity-ownerId. ENDIF.
     IF ls_entity-%control-status = if_abap_behv=>mk-on. ls_db-status = ls_entity-status. ENDIF.
     IF ls_entity-%control-mitigationPlan = if_abap_behv=>mk-on. ls_db-mitigation_plan = ls_entity-mitigationPlan. ENDIF.
     IF ls_entity-%control-resolution = if_abap_behv=>mk-on. ls_db-resolution = ls_entity-resolution. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      project_id TYPE abp_behv_flag,
      task_id TYPE abp_behv_flag,
      title TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      impact TYPE abp_behv_flag,
      likelihood TYPE abp_behv_flag,
      priority TYPE abp_behv_flag,
      owner_id TYPE abp_behv_flag,
      status TYPE abp_behv_flag,
      mitigation_plan TYPE abp_behv_flag,
      resolution TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      project_id = ls_entity-%control-projectId
      task_id = ls_entity-%control-taskId
      title = ls_entity-%control-title
      description = ls_entity-%control-description
      impact = ls_entity-%control-impact
      likelihood = ls_entity-%control-likelihood
      priority = ls_entity-%control-priority
      owner_id = ls_entity-%control-ownerId
      status = ls_entity-%control-status
      mitigation_plan = ls_entity-%control-mitigationPlan
      resolution = ls_entity-%control-resolution
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'RISK' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_risk.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'RISK' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-risk.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-risk.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_delete.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Risk ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'RISK' iv_operation = 'DELETE' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_risk.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by =
updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'RISK' iv_operation = 'DELETE' ir_row = REF #( ls_permission_db ) ).
     ycl_it_hub_tx=>stage_delete( iv_entity = 'RISK' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-risk.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-risk.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Risk ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'RISK' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'RISK' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'RISK' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Risk.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-taskId <> ls_db-task_id. ls_update-taskId = ls_db-task_id. ls_update-%control-taskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-likelihood <> ls_db-likelihood. ls_update-likelihood = ls_db-likelihood. ls_update-%control-likelihood = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-ownerId <> ls_db-owner_id. ls_update-ownerId = ls_db-owner_id. ls_update-%control-ownerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mitigationPlan <> ls_db-mitigation_plan. ls_update-mitigationPlan = ls_db-mitigation_plan. ls_update-%control-mitigationPlan = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Risk UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'RISK' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-risk.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Risk ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'RISK' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'RISK' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'RISK' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_PROJECT\\Risk.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-projectId <> ls_db-project_id. ls_update-projectId = ls_db-project_id. ls_update-%control-projectId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-taskId <> ls_db-task_id. ls_update-taskId = ls_db-task_id. ls_update-%control-taskId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-title <> ls_db-title. ls_update-title = ls_db-title. ls_update-%control-title = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-impact <> ls_db-impact. ls_update-impact = ls_db-impact. ls_update-%control-impact = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-likelihood <> ls_db-likelihood. ls_update-likelihood = ls_db-likelihood. ls_update-%control-likelihood = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-priority <> ls_db-priority. ls_update-priority = ls_db-priority. ls_update-%control-priority = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-ownerId <> ls_db-owner_id. ls_update-ownerId = ls_db-owner_id. ls_update-%control-ownerId = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-status <> ls_db-status. ls_update-status = ls_db-status. ls_update-%control-status = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-mitigationPlan <> ls_db-mitigation_plan. ls_update-mitigationPlan = ls_db-mitigation_plan. ls_update-%control-mitigationPlan = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-resolution <> ls_db-resolution. ls_update-resolution = ls_db-resolution. ls_update-%control-resolution = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE ENTITY Risk UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-project TO reported-project.
    APPEND LINES OF ls_messages-workstream TO reported-workstream.
    APPEND LINES OF ls_messages-membership TO reported-membership.
    APPEND LINES OF ls_messages-roleassign TO reported-roleassign.
    APPEND LINES OF ls_messages-milestone TO reported-milestone.
    APPEND LINES OF ls_messages-risk TO reported-risk.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'RISK' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-risk.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_PROJECT IN LOCAL MODE
      ENTITY Risk ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_risk.
    ls_db = CORRESPONDING #( ls_row MAPPING project_id = projectId task_id = taskId owner_id = ownerId mitigation_plan = mitigationPlan created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical
local_last_changed_at = localLastChangedAt created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'RISK' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'RISK' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-risk.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-risk.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD prepare_delete.
    LOOP AT keys INTO DATA(ls_key).
      TRY.
          ycl_it_hub_bridge=>prepare_delete( iv_entity = 'RISK' iv_id = ls_key-id ).
        CATCH ycx_it_hub INTO DATA(lx_delete).
          ycl_it_hub_tx=>fail( lx_delete->text ).
          APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = lx_delete->text ) ) TO reported-risk.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD validate_delete.
    LOOP AT keys INTO DATA(ls_key).
      DATA(lv_error) = ycl_it_hub_tx=>error( ).
      IF lv_error IS INITIAL. lv_error = ycl_it_hub_policy=>final_authorizations( ). ENDIF.
      IF lv_error IS INITIAL AND ycl_it_hub_tx=>cascade_delete( iv_entity = 'RISK' iv_id = ls_key-id ) = abap_false.
        DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'RISK' iv_id = ls_key-id ).
        IF lr_before IS NOT BOUND.
          lv_error = 'Deletion before image is unavailable.'.
        ELSE.
          lv_error = ycl_it_hub_policy=>removed( iv_entity = 'RISK' ir_row = lr_before ).
        ENDIF.
      ENDIF.
      IF lv_error IS NOT INITIAL.
        APPEND VALUE #( %tky = ls_key-%tky ) TO failed-risk.
        APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = lv_error ) ) TO reported-risk.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_YR_IT_HUB_PROJECT DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_YR_IT_HUB_PROJECT IMPLEMENTATION.
  METHOD save_modified.
    ycl_it_hub_tx=>save( iv_owner = 'PROJECT' is_create = create is_update = update is_delete = delete ).
  ENDMETHOD.

  METHOD cleanup.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD cleanup_finalize.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

ENDCLASS.
