CLASS lhc_Skill DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    METHODS get_instance_features FOR INSTANCE FEATURES
      IMPORTING keys REQUEST requested_features FOR Skill RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR Skill RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR Skill RESULT result.

    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE Skill.

    METHODS precheck_create FOR PRECHECK
      IMPORTING entities FOR CREATE Skill.

    METHODS precheck_update FOR PRECHECK
      IMPORTING entities FOR UPDATE Skill.

    METHODS Reinstate FOR MODIFY
      IMPORTING keys FOR ACTION Skill~Reinstate RESULT result.

    METHODS Retire FOR MODIFY
      IMPORTING keys FOR ACTION Skill~Retire RESULT result.

    METHODS set_defaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Skill~set_defaults.

    METHODS stamp_actor FOR DETERMINE ON MODIFY
      IMPORTING keys FOR Skill~stamp_actor.

    METHODS validate_state FOR VALIDATE ON SAVE
      IMPORTING keys FOR Skill~validate_state.


    METHODS TouchGoverned FOR MODIFY IMPORTING keys FOR ACTION Skill~TouchGoverned.
    METHODS TouchOnSave FOR MODIFY IMPORTING keys FOR ACTION Skill~TouchOnSave.
ENDCLASS.

CLASS lhc_Skill IMPLEMENTATION.
  METHOD get_instance_features.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
      APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
      <result>-%tky = ls_key-%tky.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      <result>-%features-%update = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Retire = if_abap_behv=>fc-o-disabled.
      <result>-%features-%action-Reinstate = if_abap_behv=>fc-o-disabled.
      IF sy-subrc <> 0. CONTINUE. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      <result>-%features-%update = COND #( WHEN ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Retire = COND #( WHEN xsdbool( ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'RETIRE' ir_row = REF #( ls_db ) ) = abap_true AND ls_db-active = abap_true ) = abap_true THEN if_abap_behv=>fc-o-enabled ELSE
if_abap_behv=>fc-o-disabled ).
      <result>-%features-%action-Reinstate = COND #( WHEN xsdbool( ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'REINSTATE' ir_row = REF #( ls_db ) ) = abap_true AND ls_db-active = abap_false ) = abap_true THEN if_abap_behv=>fc-o-enabled
ELSE if_abap_behv=>fc-o-disabled ).
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<result>).
     <result>-%tky = ls_key-%tky.
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     DATA(lv_found) = xsdbool( sy-subrc = 0 ).
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF requested_authorizations-%update = if_abap_behv=>mk-on.
     <result>-%update = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Retire = if_abap_behv=>mk-on.
     <result>-%action-Retire = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'RETIRE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     IF requested_authorizations-%action-Reinstate = if_abap_behv=>mk-on.
     <result>-%action-Reinstate = COND #( WHEN lv_found = abap_true AND ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'REINSTATE' ir_row = REF #( ls_db ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
     ENDIF.
     ENDLOOP.
  ENDMETHOD.

  METHOD get_global_authorizations.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    IF requested_authorizations-%create = if_abap_behv=>mk-on.
     result-%create = COND #( WHEN xsdbool( ls_actor-active = abap_true AND ( ls_actor-admin = abap_true OR ls_actor-manager = abap_true ) ) = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%update = if_abap_behv=>mk-on.
     result-%update = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Retire = if_abap_behv=>mk-on.
     result-%action-Retire = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
    IF requested_authorizations-%action-Reinstate = if_abap_behv=>mk-on.
     result-%action-Reinstate = COND #( WHEN ls_actor-active = abap_true THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.
  ENDMETHOD.

  METHOD earlynumbering_create.
    LOOP AT entities INTO DATA(ls_entity).
      DATA(lv_id) = ls_entity-id.
      IF lv_id IS NOT INITIAL AND ycl_it_hub_tx=>in_scope( iv_name = 'NUMBERED_SKILL' iv_id = lv_id ) = abap_false.
        APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-skill.
        APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-error text = 'Identifiers must be allocated by the server.' ) ) TO reported-skill.
        ycl_it_hub_tx=>fail( 'Externally supplied identifiers are not allowed.' ).
        CONTINUE.
      ENDIF.
      TRY.
          IF lv_id IS INITIAL. lv_id = ycl_it_hub_util=>create_uuid_c36( ). ENDIF.
          ycl_it_hub_tx=>scope( iv_name = 'NUMBERED_SKILL' iv_id = lv_id iv_on = abap_true ).
          ycl_it_hub_tx=>create_controls( iv_entity = 'SKILL' iv_id = lv_id is_control = ls_entity-%control ).
          APPEND VALUE #( %cid = ls_entity-%cid id = lv_id ) TO mapped-skill.
        CATCH cx_uuid_error.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-skill.
          APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error text = 'Could not allocate a Skill identifier.' ) ) TO reported-skill.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_create.
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_entity MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id
= createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_defaults=>apply( iv_entity = 'SKILL' ir_row = REF #( ls_db ) iv_new = abap_true iv_actor = ls_actor-id iv_preview = abap_true ).
    TYPES: BEGIN OF ty_control,
      name TYPE abp_behv_flag,
      name_normalized TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      name = ls_entity-%control-name
      name_normalized = ls_entity-%control-nameNormalized
      description = ls_entity-%control-description
      active = ls_entity-%control-active
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'SKILL' iv_operation = 'CREATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'SKILL' iv_operation = 'CREATE' ir_row = REF #( ls_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-skill.
    APPEND VALUE #( %cid = ls_entity-%cid %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD precheck_update.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( entities )
      RESULT DATA(lt_rows).
    LOOP AT entities INTO DATA(ls_entity).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_entity-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Record no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ls_entity-%control-name = if_abap_behv=>mk-on. ls_db-name = ls_entity-name. ENDIF.
     IF ls_entity-%control-nameNormalized = if_abap_behv=>mk-on. ls_db-name_normalized = ls_entity-nameNormalized. ENDIF.
     IF ls_entity-%control-description = if_abap_behv=>mk-on. ls_db-description = ls_entity-description. ENDIF.
     IF ls_entity-%control-active = if_abap_behv=>mk-on. ls_db-active = ls_entity-active. ENDIF.
     IF ls_entity-%control-createdAt = if_abap_behv=>mk-on. ls_db-created_at = ls_entity-createdAt. ENDIF.
     IF ls_entity-%control-createdByTechnical = if_abap_behv=>mk-on. ls_db-created_by = ls_entity-createdByTechnical. ENDIF.
     IF ls_entity-%control-updatedAt = if_abap_behv=>mk-on. ls_db-updated_at = ls_entity-updatedAt. ENDIF.
     IF ls_entity-%control-updatedByTechnical = if_abap_behv=>mk-on. ls_db-updated_by = ls_entity-updatedByTechnical. ENDIF.
     IF ls_entity-%control-localLastChangedAt = if_abap_behv=>mk-on. ls_db-local_last_changed_at = ls_entity-localLastChangedAt. ENDIF.
     IF ls_entity-%control-createdBy = if_abap_behv=>mk-on. ls_db-created_by_member_id = ls_entity-createdBy. ENDIF.
     IF ls_entity-%control-updatedBy = if_abap_behv=>mk-on. ls_db-updated_by_member_id = ls_entity-updatedBy. ENDIF.
     IF ls_entity-%control-changeToken = if_abap_behv=>mk-on. ls_db-change_token = ls_entity-changeToken. ENDIF.
    TYPES: BEGIN OF ty_control,
      name TYPE abp_behv_flag,
      name_normalized TYPE abp_behv_flag,
      description TYPE abp_behv_flag,
      active TYPE abp_behv_flag,
      created_at TYPE abp_behv_flag,
      created_by TYPE abp_behv_flag,
      updated_at TYPE abp_behv_flag,
      updated_by TYPE abp_behv_flag,
      local_last_changed_at TYPE abp_behv_flag,
      created_by_member_id TYPE abp_behv_flag,
      updated_by_member_id TYPE abp_behv_flag,
      change_token TYPE abp_behv_flag,
    END OF ty_control.
    DATA(ls_control) = VALUE ty_control(
      name = ls_entity-%control-name
      name_normalized = ls_entity-%control-nameNormalized
      description = ls_entity-%control-description
      active = ls_entity-%control-active
      created_at = ls_entity-%control-createdAt
      created_by = ls_entity-%control-createdByTechnical
      updated_at = ls_entity-%control-updatedAt
      updated_by = ls_entity-%control-updatedByTechnical
      local_last_changed_at = ls_entity-%control-localLastChangedAt
      created_by_member_id = ls_entity-%control-createdBy
      updated_by_member_id = ls_entity-%control-updatedBy
      change_token = ls_entity-%control-changeToken ).
     DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'SKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_db ) is_control = ls_control ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_permission_db TYPE ytb_it_hub_skill.
    ls_permission_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt
created_by_member_id = createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     ycl_it_hub_tx=>guard( iv_entity = 'SKILL' iv_operation = 'UPDATE' ir_row = REF #( ls_permission_db ) ).
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_entity-%tky ) TO failed-skill.
    APPEND VALUE #( %tky = ls_entity-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD Reinstate.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'REINSTATE' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'SKILL' iv_operation = 'REINSTATE' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'SKILL' iv_id = ls_db-id iv_action = 'REINSTATE' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'SKILL' iv_id = ls_db-id ).
     ls_db-active = abap_true.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'SKILL' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_SKILL.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-nameNormalized <> ls_db-name_normalized. ls_update-nameNormalized = ls_db-name_normalized. ls_update-%control-nameNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-skill TO reported-skill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-skill.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-skill TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD Retire.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action target no longer exists.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_policy=>can( iv_entity = 'SKILL' iv_operation = 'RETIRE' ir_row = REF #( ls_db ) ) = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Action is not authorized.'. ENDIF.
     ycl_it_hub_tx=>guard( iv_entity = 'SKILL' iv_operation = 'RETIRE' ir_row = REF #( ls_db ) ).
     ycl_it_hub_tx=>operation( iv_entity = 'SKILL' iv_id = ls_db-id iv_action = 'RETIRE' ).
     ycl_it_hub_bridge=>touch( iv_entity = 'SKILL' iv_id = ls_db-id ).
     ls_db-active = abap_false.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'SKILL' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. ycl_it_hub_tx=>fail( lv_error ). RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_SKILL.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-nameNormalized <> ls_db-name_normalized. ls_update-nameNormalized = ls_db-name_normalized. ls_update-%control-nameNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-skill TO reported-skill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-skill.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill
      ALL FIELDS WITH CORRESPONDING #( keys ) RESULT DATA(lt_final).
    LOOP AT keys INTO DATA(ls_result_key).
      LOOP AT failed-skill TRANSPORTING NO FIELDS USING KEY id WHERE id = ls_result_key-id.
        EXIT.
      ENDLOOP.
      IF sy-subrc = 0. CONTINUE. ENDIF.
      READ TABLE lt_final INTO DATA(ls_final) WITH TABLE KEY entity COMPONENTS id = ls_result_key-id.
      IF sy-subrc = 0.
        APPEND VALUE #( %tky = ls_result_key-%tky %param = ls_final ) TO result.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD set_defaults.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'SKILL' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'SKILL' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'SKILL' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_SKILL.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-nameNormalized <> ls_db-name_normalized. ls_update-nameNormalized = ls_db-name_normalized. ls_update-%control-nameNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-skill TO reported-skill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'SKILL' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD stamp_actor.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT lt_rows INTO DATA(ls_row).
     TRY.
     ycl_it_hub_tx=>lock( ).
     DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Active actor identity and Member are required.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     DATA(lv_new) = xsdbool( ycl_it_hub_tx=>before( iv_entity = 'SKILL' iv_id = ls_db-id ) IS NOT BOUND ).
     ycl_it_hub_defaults=>apply( iv_entity = 'SKILL' ir_row = REF #( ls_db ) iv_new = lv_new iv_actor = ls_actor-id ).
     DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'SKILL' ir_row = REF #( ls_db ) iv_actor = ls_actor-id ).
     ls_db-created_by_member_id = ls_audit-created_by.
     ls_db-updated_by_member_id = ls_audit-updated_by.
     ls_db-change_token = ls_audit-token.
    DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_SKILL.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-nameNormalized <> ls_db-name_normalized. ls_update-nameNormalized = ls_db-name_normalized. ls_update-%control-nameNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-skill TO reported-skill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     IF ls_audit-changed = abap_true. ycl_it_hub_bridge=>parents( iv_entity = 'SKILL' ir_row = REF #( ls_db ) ). ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
     ycl_it_hub_tx=>fail( lx_error->text ).
    APPEND VALUE #( %tky = ls_row-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD validate_state.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
     ycl_it_hub_tx=>lock( ).
     READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
     IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Final record state is missing.'. ENDIF.
    DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
     IF ycl_it_hub_tx=>error( ) IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ). ENDIF.
     DATA(lv_auth_error) = ycl_it_hub_policy=>final_authorizations( ).
     IF lv_auth_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_auth_error. ENDIF.
     IF ls_actor-active = abap_false. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Actor authority was revoked.'. ENDIF.
     IF ycl_it_hub_tx=>prepared( iv_entity = 'SKILL' ir_row = REF #( ls_db ) ) = abap_false.
       RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Audit preparation is missing or stale; retry the change.'.
     ENDIF.
     DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'SKILL' ir_row = REF #( ls_db ) ).
     IF lv_error IS NOT INITIAL. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = lv_error. ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
    APPEND VALUE #( %tky = ls_key-%tky ) TO failed-skill.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchGoverned.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_SKILL' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'SKILL' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_SKILL.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-nameNormalized <> ls_db-name_normalized. ls_update-nameNormalized = ls_db-name_normalized. ls_update-%control-nameNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-skill TO reported-skill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %tky = ls_key-%tky ) TO failed-skill.
    APPEND VALUE #( %tky = ls_key-%tky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.

  METHOD TouchOnSave.
    DATA ls_messages LIKE reported.
    READ ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE
      ENTITY Skill ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_rows).
    LOOP AT keys INTO DATA(ls_key).
     TRY.
      ycl_it_hub_tx=>lock( ).
      DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
      IF ls_actor-active = abap_false OR ycl_it_hub_tx=>in_scope( iv_name = 'TOUCH_SKILL' iv_id = ls_key-id ) = abap_false.
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'A trusted governing-root touch ticket is required.'.
      ENDIF.
      READ TABLE lt_rows INTO DATA(ls_row) WITH TABLE KEY entity COMPONENTS id = ls_key-id.
      IF sy-subrc <> 0. RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = 'Governing root does not exist.'. ENDIF.
      DATA ls_db TYPE ytb_it_hub_skill.
    ls_db = CORRESPONDING #( ls_row MAPPING name_normalized = nameNormalized created_at = createdAt created_by = createdByTechnical updated_at = updatedAt updated_by = updatedByTechnical local_last_changed_at = localLastChangedAt created_by_member_id =
createdBy updated_by_member_id = updatedBy change_token = changeToken ).
      ls_db-change_token = ycl_it_hub_tx=>touch( iv_entity = 'SKILL' iv_id = ls_key-id ).
      DATA ls_update TYPE STRUCTURE FOR UPDATE YR_IT_HUB_SKILL.
    CLEAR ls_update.
    ls_update-%tky = ls_row-%tky.
    IF ls_row-name <> ls_db-name. ls_update-name = ls_db-name. ls_update-%control-name = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-nameNormalized <> ls_db-name_normalized. ls_update-nameNormalized = ls_db-name_normalized. ls_update-%control-nameNormalized = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-description <> ls_db-description. ls_update-description = ls_db-description. ls_update-%control-description = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-active <> ls_db-active. ls_update-active = ls_db-active. ls_update-%control-active = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-createdBy <> ls_db-created_by_member_id. ls_update-createdBy = ls_db-created_by_member_id. ls_update-%control-createdBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-updatedBy <> ls_db-updated_by_member_id. ls_update-updatedBy = ls_db-updated_by_member_id. ls_update-%control-updatedBy = if_abap_behv=>mk-on. ENDIF.
    IF ls_row-changeToken <> ls_db-change_token. ls_update-changeToken = ls_db-change_token. ls_update-%control-changeToken = if_abap_behv=>mk-on. ENDIF.
    IF ls_update-%control IS NOT INITIAL.
      MODIFY ENTITIES OF YR_IT_HUB_SKILL IN LOCAL MODE ENTITY Skill UPDATE FROM VALUE #( ( ls_update ) )
        FAILED DATA(ls_modify_failed) REPORTED DATA(ls_modify_reported).
      ls_messages = CORRESPONDING #( DEEP ls_modify_reported ).
    APPEND LINES OF ls_messages-skill TO reported-skill.
      IF ls_modify_failed IS NOT INITIAL.
        ycl_it_hub_tx=>fail( 'A nested RAP mutation failed; the complete change must be retried.' ).
        RAISE EXCEPTION TYPE ycx_it_hub EXPORTING iv_text = ycl_it_hub_tx=>error( ).
      ENDIF.
    ENDIF.
     CATCH ycx_it_hub INTO DATA(lx_error).
      ycl_it_hub_tx=>fail( lx_error->text ).
      APPEND VALUE #( %pky = ls_key-%pky ) TO failed-skill.
    APPEND VALUE #( %pky = ls_key-%pky %msg = new_message_with_text(
      severity = if_abap_behv_message=>severity-error text = lx_error->text ) ) TO reported-skill.
     ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.

CLASS lsc_YR_IT_HUB_SKILL DEFINITION INHERITING FROM cl_abap_behavior_saver.
  PROTECTED SECTION.

    METHODS save_modified REDEFINITION.

    METHODS cleanup REDEFINITION.

    METHODS cleanup_finalize REDEFINITION.

ENDCLASS.

CLASS lsc_YR_IT_HUB_SKILL IMPLEMENTATION.
  METHOD save_modified.
    ycl_it_hub_tx=>save( iv_owner = 'SKILL' is_create = create is_update = update is_delete = delete ).
  ENDMETHOD.

  METHOD cleanup.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD cleanup_finalize.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

ENDCLASS.
