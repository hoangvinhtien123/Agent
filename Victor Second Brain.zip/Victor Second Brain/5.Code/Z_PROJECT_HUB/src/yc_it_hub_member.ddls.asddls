@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Member'
define root view entity YC_IT_HUB_MEMBER
  provider contract transactional_query
  as projection on YR_IT_HUB_MEMBER
{
  key id,
  name,
  email,
  emailNormalized,
  title,
  team,
  initials,
  active,
  isAppManager,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  skills : redirected to composition child YC_IT_HUB_MEMBERSKILL
}
