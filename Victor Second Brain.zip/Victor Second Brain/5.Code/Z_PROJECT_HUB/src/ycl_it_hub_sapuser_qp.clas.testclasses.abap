*"* use this source file for your ABAP unit test classes
CLASS ltc_sapuser DEFINITION DEFERRED.
CLASS ycl_it_hub_sapuser_qp DEFINITION LOCAL FRIENDS ltc_sapuser.
CLASS ltc_sapuser DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PRIVATE SECTION.
    METHODS quoted_search FOR TESTING RAISING ycx_it_hub_authctx.
    METHODS invalid_search FOR TESTING.
    METHODS profile_matching FOR TESTING.
ENDCLASS.
CLASS ltc_sapuser IMPLEMENTATION.
  METHOD quoted_search.
    DATA(lt_terms) = ycl_it_hub_sapuser_qp=>search_terms( '"  Kha Nguyen  "' ).
    cl_abap_unit_assert=>assert_equals( act = lt_terms exp = VALUE ycl_it_hub_sapuser_qp=>tt_terms( ( `KHA` ) ( `NGUYEN` ) ) ).
    lt_terms = ycl_it_hub_sapuser_qp=>search_terms( '70028624' ).
    cl_abap_unit_assert=>assert_equals( act = lt_terms exp = VALUE ycl_it_hub_sapuser_qp=>tt_terms( ( `70028624` ) ) ).
    lt_terms = ycl_it_hub_sapuser_qp=>search_terms( '"A\"B\\C"' ).
    cl_abap_unit_assert=>assert_equals( act = lt_terms[ 1 ] exp = `A"B\C` ).
  ENDMETHOD.
  METHOD invalid_search.
    DATA(lt_inputs) = VALUE ycl_it_hub_sapuser_qp=>tt_terms(
      ( `` ) ( `""` ) ( `"a"` ) ( `"Kha` ) ( `"Kha" OR "Nguyen"` )
      ( `Kha OR Nguyen` ) ( `"bad\q"` ) ( repeat( val = `a` occ = 101 ) ) ).
    LOOP AT lt_inputs INTO DATA(lv_input).
      TRY.
          ycl_it_hub_sapuser_qp=>search_terms( lv_input ).
          cl_abap_unit_assert=>fail( msg = 'Invalid or unfiltered directory search was accepted.' ).
        CATCH ycx_it_hub_authctx.
          CONTINUE.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
  METHOD profile_matching.
    DATA(ls_user) = VALUE yce_it_hub_sapuser( name = 'Khai Nguyen' ntId = 'KNGUYEN' email = 'khai.nguyen@stengg.example' ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_sapuser_qp=>has_terms(
      is_user = ls_user it_terms = VALUE #( ( `KHA` ) ( `NGUYEN` ) ) ) ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_sapuser_qp=>has_terms(
      is_user = ls_user it_terms = VALUE #( ( `KNGUYEN` ) ) ) ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_sapuser_qp=>has_terms(
      is_user = ls_user it_terms = VALUE #( ( `STENGG.EXAMPLE` ) ) ) ).
    cl_abap_unit_assert=>assert_false( ycl_it_hub_sapuser_qp=>has_terms(
      is_user = ls_user it_terms = VALUE #( ( `KHA` ) ( `MISSING` ) ) ) ).
    cl_abap_unit_assert=>assert_false( ycl_it_hub_sapuser_qp=>has_terms(
      is_user = ls_user it_terms = VALUE #( ) ) ).
  ENDMETHOD.
ENDCLASS.
