@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Membership'
define view entity YC_IT_HUB_MEMBERSHIP
  as projection on YI_IT_HUB_MEMBERSHIP
{
  key id,
  projectId,
  memberId,
  active,
  isProjectManager,
  editProject,
  manageMembers,
  assignWork,
  manageSchedule,
  deleteWorkItems,
  overrideWorkflow,
  managePermissions,
  createdAt,
  updatedAt,
  createdBy,
  updatedBy,
  localLastChangedAt,
  roles : redirected to composition child YC_IT_HUB_ROLEASSIGN,
  _Project : redirected to parent YC_IT_HUB_PROJECT,
  _Member : redirected to YC_IT_HUB_MEMBER
}
