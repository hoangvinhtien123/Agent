CLASS ycl_it_hub_etag_backfill DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
  PRIVATE SECTION.
    TYPES ty_tables TYPE STANDARD TABLE OF tabname WITH EMPTY KEY.
    METHODS tables RETURNING VALUE(rt_tables) TYPE ty_tables.
ENDCLASS.

CLASS ycl_it_hub_etag_backfill IMPLEMENTATION.

  METHOD tables.
    rt_tables = VALUE #(
      ( 'YTB_IT_HUB_MEMB' )  ( 'YTB_IT_HUB_MIDN' )  ( 'YTB_IT_HUB_MSKIL' )
      ( 'YTB_IT_HUB_SKILL' ) ( 'YTB_IT_HUB_PROJ' )  ( 'YTB_IT_HUB_WSTR' )
      ( 'YTB_IT_HUB_MSHIP' ) ( 'YTB_IT_HUB_PROLE' ) ( 'YTB_IT_HUB_TASK' )
      ( 'YTB_IT_HUB_TDEP' )  ( 'YTB_IT_HUB_MILE' )  ( 'YTB_IT_HUB_EVENT' )
      ( 'YTB_IT_HUB_EATT' )  ( 'YTB_IT_HUB_RISK' )  ( 'YTB_IT_HUB_COMMT' )
      ( 'YTB_IT_HUB_DOCS' )  ( 'YTB_IT_HUB_DOATT' ) ).
  ENDMETHOD.

  METHOD if_oo_adt_classrun~main.
    DATA lv_now     TYPE abp_locinst_lastchange_tstmpl.
    DATA lv_created TYPE i.
    DATA lv_updated TYPE i.
    DATA lv_etag    TYPE i.
    CONSTANTS lc_set_updated TYPE string VALUE `updated_at = created_at`.
    CONSTANTS lc_set_etag    TYPE string VALUE `local_last_changed_at = updated_at`.


    GET TIME STAMP FIELD lv_now.

    DATA(lt_tables) = tables( ).

    LOOP AT lt_tables INTO DATA(lv_table).
      TRY.
          UPDATE (lv_table) SET created_at = @lv_now
            WHERE created_at = 0 OR created_at IS NULL.
          lv_created = sy-dbcnt.

          UPDATE (lv_table) SET (lc_set_updated)
            WHERE updated_at = 0 OR updated_at IS NULL.
          lv_updated = sy-dbcnt.

          UPDATE (lv_table) SET (lc_set_etag)
            WHERE local_last_changed_at = 0 OR local_last_changed_at IS NULL.
          lv_etag = sy-dbcnt.

          out->write( |{ lv_table WIDTH = 18 } created: { lv_created } updated: { lv_updated } etag: { lv_etag }| ).
        CATCH cx_sy_dynamic_osql_error INTO DATA(lx_sql).
          out->write( |{ lv_table WIDTH = 18 } ERROR: { lx_sql->get_text( ) }| ).
      ENDTRY.
    ENDLOOP.

    COMMIT WORK.
    out->write( 'Backfill committed.' ).
  ENDMETHOD.

ENDCLASS.
