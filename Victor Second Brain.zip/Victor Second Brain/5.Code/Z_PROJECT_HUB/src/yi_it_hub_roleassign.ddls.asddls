@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - RoleAssign'
define view entity YI_IT_HUB_ROLEASSIGN
  as select from ytb_it_hub_prole
  association to parent YI_IT_HUB_MEMBERSHIP as _Membership on $projection.membershipId = _Membership.id
  association [0..1] to YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
{
  key id as id,
  project_id as projectId,
  membership_id as membershipId,
  role as role,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Membership,
  _Project
}
