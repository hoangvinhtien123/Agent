CLASS ltc_policy DEFINITION FINAL FOR TESTING DURATION SHORT RISK LEVEL HARMLESS.
  PUBLIC SECTION.
    CLASS-DATA gs_actor TYPE ycl_it_hub_policy=>ty_actor.
    CLASS-DATA gv_use_actor_fixture TYPE abap_bool.
    CLASS-DATA gv_admin_grant TYPE abap_bool.
    CLASS-DATA gv_user_grant TYPE abap_bool.
  PRIVATE SECTION.
    CONSTANTS:
      c_project TYPE sysuuid_c36 VALUE '00000000-0000-0000-0000-000000000001',
      c_member TYPE sysuuid_c36 VALUE '00000000-0000-0000-0000-000000000002',
      c_developer TYPE sysuuid_c36 VALUE '00000000-0000-0000-0000-000000000003',
      c_tester TYPE sysuuid_c36 VALUE '00000000-0000-0000-0000-000000000004',
      c_membership TYPE sysuuid_c36 VALUE '00000000-0000-0000-0000-000000000005'.
    CLASS-DATA go_environment TYPE REF TO if_osql_test_environment.
    CLASS-METHODS class_setup RAISING cx_static_check.
    CLASS-METHODS class_teardown.
    METHODS setup.
    METHODS teardown.
    METHODS app_flag_is_not_project_grant FOR TESTING.
    METHODS member_create_authority FOR TESTING.
    METHODS member_create_revocation FOR TESTING.
    METHODS skill_deep_create_precheck FOR TESTING.
    METHODS uuid_array_case FOR TESTING RAISING ycx_it_hub.
    METHODS uuid_lookup_case FOR TESTING.
    METHODS uuid_buffer_overlay FOR TESTING.
    METHODS skill_reference_case FOR TESTING RAISING ycx_it_hub.
    METHODS revocation_blocks_save FOR TESTING.
    METHODS archive_blocks_admin_writes FOR TESTING.
    METHODS defaults_preserve_false_state FOR TESTING RAISING ycx_it_hub.
    METHODS independent_tester_override FOR TESTING RAISING ycx_it_hub.
    METHODS buffered_graph_overlay FOR TESTING.
    METHODS strict_json_and_url FOR TESTING RAISING ycx_it_hub.
    METHODS use_real_actor IMPORTING iv_mapping TYPE abap_bool DEFAULT abap_false.
    METHODS admin_unmapped_bootstrap FOR TESTING RAISING ycx_it_hub.
    METHODS identity_deep_create_precheck FOR TESTING RAISING ycx_it_hub.
    METHODS identity_precheck_guards FOR TESTING.
    METHODS document_loader_maps_by_name FOR TESTING.
    METHODS admin_inactive_mapping FOR TESTING.
    METHODS user_needs_active_mapping FOR TESTING.
    METHODS admin_grant_revoked_save FOR TESTING.
    METHODS missing_grants_deny FOR TESTING.
    METHODS transition_options_read_only FOR TESTING.
    METHODS team_inspection_is_scoped FOR TESTING RAISING ycx_it_hub.
    METHODS read_scope_preserves_writes FOR TESTING RAISING ycx_it_hub.
    METHODS delete_staging_is_read_only FOR TESTING RAISING ycx_it_hub.
    METHODS delete_history_confirmed_only FOR TESTING RAISING ycx_it_hub.
    METHODS profile_scalar_controls FOR TESTING RAISING ycx_it_hub.
    METHODS profile_rejects_protected FOR TESTING.
    METHODS reactivation_checks_target FOR TESTING.
    METHODS defect_assignment_roles FOR TESTING RAISING ycx_it_hub.
    METHODS main_task_status_moves FOR TESTING RAISING ycx_it_hub.
    METHODS subtask_direct_close FOR TESTING RAISING ycx_it_hub.
    METHODS deferred_dep_final_validation FOR TESTING.
ENDCLASS.
CLASS ltc_policy IMPLEMENTATION.
  METHOD subtask_direct_close.
    DATA lt_parents TYPE STANDARD TABLE OF ytb_it_hub_task WITH EMPTY KEY.
    lt_parents = VALUE #( ( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000074' project_id = c_project
      task_type = 'TASK' title = 'Parent task' status = 'IN_PROGRESS' assignee_id = c_member ) ).
    go_environment->insert_test_data( lt_parents ).
    DATA(ls_child) = VALUE ytb_it_hub_task( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000075' project_id = c_project
      parent_id = lt_parents[ 1 ]-id task_type = 'TASK' title = 'Direct subtask close' assignee_id = c_member ).
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_child )
      iv_new = abap_true iv_actor = c_member ).
    cl_abap_unit_assert=>assert_equals( act = ls_child-status exp = 'OPEN' ).
    DATA(lt_options) = ycl_it_hub_policy=>transition_options( ls_child ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_options ) exp = 2 ).
    cl_abap_unit_assert=>assert_true( lt_options[ status = 'Closed' ]-allowed ).
    cl_abap_unit_assert=>assert_false( lt_options[ status = 'Closed' ]-requires_reason ).
    DATA(ls_closed) = ycl_it_hub_policy=>transition( is_task = ls_child
      iv_status = 'Closed' iv_reason = '' iv_override = abap_false ).
    cl_abap_unit_assert=>assert_equals( act = ls_closed-status exp = 'CLOSED' ).
    cl_abap_unit_assert=>assert_not_initial( ls_closed-completed_at ).
    lt_options = ycl_it_hub_policy=>transition_options( ls_closed ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_options ) exp = 1 ).
    cl_abap_unit_assert=>assert_equals( act = lt_options[ 1 ]-status exp = 'Open' ).
    cl_abap_unit_assert=>assert_true( lt_options[ 1 ]-requires_reason ).
    TRY.
        DATA(ls_denied) = ycl_it_hub_policy=>transition( is_task = ls_closed
          iv_status = 'Open' iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>fail( msg = |Reopening must not reach { ls_denied-status } without a reason.| ).
      CATCH ycx_it_hub.
    ENDTRY.
    DATA(ls_reopened) = ycl_it_hub_policy=>transition( is_task = ls_closed
      iv_status = 'Open' iv_reason = 'Follow-up required' iv_override = abap_false ).
    cl_abap_unit_assert=>assert_equals( act = ls_reopened-status exp = 'OPEN' ).
    cl_abap_unit_assert=>assert_initial( ls_reopened-completed_at ).
    ls_child-blocked = abap_true.
    ls_child-blocked_reason = 'QAS offline'.
    TRY.
        ls_denied = ycl_it_hub_policy=>transition( is_task = ls_child
          iv_status = 'Closed' iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>fail( msg = |Blocked work must not reach { ls_denied-status }.| ).
      CATCH ycx_it_hub.
    ENDTRY.
    CLEAR: ls_child-blocked, ls_child-blocked_reason.
    DATA(ls_parent) = lt_parents[ 1 ].
    ls_parent-status = 'DONE'.
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_parent ) ).
    TRY.
        ls_denied = ycl_it_hub_policy=>transition( is_task = ls_child
          iv_status = 'Closed' iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>fail( msg = |A Done parent must prevent its child reaching { ls_denied-status }.| ).
      CATCH ycx_it_hub.
    ENDTRY.
  ENDMETHOD.

  METHOD main_task_status_moves.
    DATA(ls_task) = VALUE ytb_it_hub_task( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000073' project_id = c_project
      task_type = 'TASK' title = 'Flexible main task workflow' assignee_id = c_member ).
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_task )
      iv_new = abap_true iv_actor = c_member ).
    DATA(lt_from) = VALUE ycl_it_hub_policy=>tt_strings( ( `TODO` ) ( `IN_PROGRESS` ) ( `IN_REVIEW` ) ).
    DATA(lt_next) = VALUE ycl_it_hub_policy=>tt_strings( ( `To Do` ) ( `In Progress` ) ( `In Review` ) ( `Done` ) ).
    LOOP AT lt_from INTO DATA(lv_from).
      ls_task-status = lv_from.
      DATA(lt_options) = ycl_it_hub_policy=>transition_options( ls_task ).
      cl_abap_unit_assert=>assert_equals( act = lines( lt_options ) exp = 3 ).
      LOOP AT lt_options INTO DATA(ls_option).
        cl_abap_unit_assert=>assert_true( ls_option-allowed ).
        cl_abap_unit_assert=>assert_false( ls_option-requires_reason ).
        DATA(ls_changed) = ycl_it_hub_policy=>transition( is_task = ls_task
          iv_status = ls_option-status iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>assert_true( xsdbool( ls_changed-status <> ls_task-status ) ).
        IF ls_option-status = 'Done'.
          cl_abap_unit_assert=>assert_not_initial( ls_changed-completed_at ).
        ELSE.
          cl_abap_unit_assert=>assert_initial( ls_changed-completed_at ).
        ENDIF.
      ENDLOOP.
    ENDLOOP.
    ls_task-status = 'DONE'.
    GET TIME STAMP FIELD ls_task-completed_at.
    lt_options = ycl_it_hub_policy=>transition_options( ls_task ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_options ) exp = 1 ).
    cl_abap_unit_assert=>assert_equals( act = lt_options[ 1 ]-status exp = 'In Review' ).
    cl_abap_unit_assert=>assert_true( lt_options[ 1 ]-requires_reason ).
    LOOP AT lt_next INTO DATA(lv_next) WHERE table_line <> 'Done'.
      TRY.
          ls_changed = ycl_it_hub_policy=>transition( is_task = ls_task
            iv_status = lv_next iv_reason = '' iv_override = abap_false ).
          cl_abap_unit_assert=>fail( msg = |Done must not move to { ls_changed-status } without the reopening rule.| ).
        CATCH ycx_it_hub.
      ENDTRY.
    ENDLOOP.
    ls_changed = ycl_it_hub_policy=>transition( is_task = ls_task
      iv_status = 'In Review' iv_reason = 'Further work required' iv_override = abap_false ).
    cl_abap_unit_assert=>assert_equals( act = ls_changed-status exp = 'IN_REVIEW' ).
    cl_abap_unit_assert=>assert_initial( ls_changed-completed_at ).
    cl_abap_unit_assert=>assert_true( ls_changed-cycle_reopened ).
  ENDMETHOD.

  METHOD defect_assignment_roles.
    DATA lt_lead_roles TYPE STANDARD TABLE OF ytb_it_hub_prole WITH EMPTY KEY.
    lt_lead_roles = VALUE #( ( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000072' project_id = c_project
      membership_id = c_membership role = 'TECHNICAL_LEAD' ) ).
    go_environment->insert_test_data( lt_lead_roles ).
    DATA(ls_task) = VALUE ytb_it_hub_task( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000070' project_id = c_project
      task_type = 'DEFECT' title = 'Developer-only assignment' assignee_id = c_member ).
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_task )
      iv_new = abap_true iv_actor = c_member ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'TASK' ir_row = REF #( ls_task ) )
      exp = 'Defect assignee needs an eligible Developer.' ).
    TRY.
        DATA(ls_denied) = ycl_it_hub_policy=>transition( is_task = ls_task
          iv_status = 'In Fix' iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>fail( msg = |Non-Developer must not reach { ls_denied-status }.| ).
      CATCH ycx_it_hub.
    ENDTRY.
    ls_task-assignee_id = c_developer.
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>validate(
      iv_entity = 'TASK' ir_row = REF #( ls_task ) ) ).
    gs_actor-id = c_developer.
    DATA(ls_in_fix) = ycl_it_hub_policy=>transition( is_task = ls_task
      iv_status = 'In Fix' iv_reason = '' iv_override = abap_false ).
    cl_abap_unit_assert=>assert_equals( act = ls_in_fix-status exp = 'IN_FIX' ).
    ls_task-tester_id = c_member.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'TASK' ir_row = REF #( ls_task ) )
      exp = 'Defect tester needs an eligible Tester.' ).
    ls_task-tester_id = c_tester.
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>validate(
      iv_entity = 'TASK' ir_row = REF #( ls_task ) ) ).
    " Historical references can remain while editing other fields.
    ls_task-assignee_id = c_member.
    ls_task-tester_id = c_member.
    DATA lt_tasks TYPE STANDARD TABLE OF ytb_it_hub_task WITH EMPTY KEY.
    APPEND ls_task TO lt_tasks.
    go_environment->insert_test_data( lt_tasks ).
    ycl_it_hub_tx=>reset( ).
    ls_task-title = 'Existing assignments retained'.
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>validate(
      iv_entity = 'TASK' ir_row = REF #( ls_task ) ) ).
  ENDMETHOD.

  METHOD reactivation_checks_target.
    DATA lt_projects TYPE STANDARD TABLE OF ytb_it_hub_proj WITH EMPTY KEY.
    lt_projects = VALUE #( ( client = sy-mandt id = '00000000-0000-0000-0000-000000000068'
      code = 'REJOIN' name = 'Rejoin project' phase = 'INITIATION' health = 'ON_TRACK' accent = '#0EA5E9' ) ).
    go_environment->insert_test_data( lt_projects ).
    DATA lt_memberships TYPE STANDARD TABLE OF ytb_it_hub_mship WITH EMPTY KEY.
    lt_memberships = VALUE #( ( client = sy-mandt id = '00000000-0000-0000-0000-000000000067'
      project_id = lt_projects[ 1 ]-id member_id = c_tester active = abap_false ) ).
    go_environment->insert_test_data( lt_memberships ).
    DATA(ls_inactive) = lt_memberships[ 1 ].
    DATA(ls_active) = ls_inactive.
    ls_active-active = abap_true.
    DATA(ls_member) = VALUE ytb_it_hub_memb( client = sy-mandt id = c_tester
      name = 'Tester' email = 'tester@example.test' active = abap_false ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = REF #( ls_member ) ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_inactive ) ) ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_active ) )
      exp = 'Member requires an active identity and trusted app grant.' ).
    ls_member-active = abap_true.
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = REF #( ls_member ) ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERSHIP' ir_row = REF #( ls_active ) ) ).
  ENDMETHOD.

  METHOD delete_staging_is_read_only.
    DATA(ls_row) = VALUE ytb_it_hub_commt( client = sy-mandt id = c_developer project_id = c_project
      target_type = 'PROJECT' target_id = c_project body = 'Before delete' ).
    ycl_it_hub_tx=>remember( iv_entity = 'COMMENT' ir_row = REF #( ls_row ) ).
    ycl_it_hub_tx=>stage_delete( iv_entity = 'COMMENT' ir_row = REF #( ls_row ) iv_actor = c_member ).
    ls_row-body = 'Caller changed its working copy'.
    cl_abap_unit_assert=>assert_bound( ycl_it_hub_tx=>get( iv_entity = 'COMMENT' iv_id = c_developer ) ).
    DATA(lr_before) = ycl_it_hub_tx=>delete_image( iv_entity = 'COMMENT' iv_id = c_developer ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>field( ir_row = lr_before iv_name = 'BODY' ) exp = 'Before delete' ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_tx=>confirm_delete( iv_entity = 'COMMENT' iv_id = c_developer ) ).
    cl_abap_unit_assert=>assert_not_bound( ycl_it_hub_tx=>get( iv_entity = 'COMMENT' iv_id = c_developer ) ).
    cl_abap_unit_assert=>assert_false( ycl_it_hub_tx=>confirm_delete( iv_entity = 'COMMENT' iv_id = c_developer ) ).
    ycl_it_hub_tx=>reset( ).
    cl_abap_unit_assert=>assert_not_bound( ycl_it_hub_tx=>delete_image( iv_entity = 'COMMENT' iv_id = c_developer ) ).
  ENDMETHOD.
  METHOD delete_history_confirmed_only.
    DATA(ls_row) = VALUE ytb_it_hub_commt( client = sy-mandt id = c_developer project_id = c_project
      target_type = 'PROJECT' target_id = c_project body = 'Audit before delete' ).
    TYPES: BEGIN OF ty_delta, comment TYPE TABLE FOR DELETE yr_it_hub_comment\\Comment, END OF ty_delta.
    DATA: ls_empty TYPE ty_delta, ls_delete TYPE ty_delta.
    APPEND VALUE #( id = c_developer ) TO ls_delete-comment.
    ycl_it_hub_tx=>stage_delete( iv_entity = 'COMMENT' ir_row = REF #( ls_row ) iv_actor = c_member ).
    ycl_it_hub_tx=>save( iv_owner = 'COMMENT' is_create = ls_empty is_update = ls_empty is_delete = ls_delete ).
    SELECT COUNT( * ) FROM ytb_it_hub_histo WHERE entity = 'comments' INTO @DATA(lv_count).
    cl_abap_unit_assert=>assert_equals( act = lv_count exp = 0 ).
    DATA(lv_new) = ycl_it_hub_tx=>confirm_delete( iv_entity = 'COMMENT' iv_id = c_developer ).
    ycl_it_hub_tx=>save( iv_owner = 'COMMENT' is_create = ls_empty is_update = ls_empty is_delete = ls_empty ).
    SELECT COUNT( * ) FROM ytb_it_hub_histo WHERE entity = 'comments' INTO @lv_count.
    cl_abap_unit_assert=>assert_equals( act = lv_count exp = 0 ).
    ycl_it_hub_tx=>save( iv_owner = 'COMMENT' is_create = ls_empty is_update = ls_empty is_delete = ls_delete ).
    SELECT COUNT( * ) FROM ytb_it_hub_histo WHERE entity = 'comments' INTO @lv_count.
    cl_abap_unit_assert=>assert_equals( act = lv_count exp = 1 ).
  ENDMETHOD.
  METHOD profile_scalar_controls.
    DATA ls_update TYPE STRUCTURE FOR UPDATE yr_it_hub_task\\Task.
    ycl_it_hub_policy=>apply_profile( iv_json = '{"title":"2026-10-12","blocked":false,"estimateHours":0,"dueDate":"2026-10-23"}'
      iv_fields = 'title,blocked,estimateHours,dueDate' ir_update = REF #( ls_update ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_update-title exp = '2026-10-12' ).
    cl_abap_unit_assert=>assert_false( ls_update-blocked ).
    cl_abap_unit_assert=>assert_initial( ls_update-estimateHours ).
    cl_abap_unit_assert=>assert_equals( act = ls_update-dueDate exp = CONV d( '20261023' ) ).
    cl_abap_unit_assert=>assert_equals( act = ls_update-%control-blocked exp = if_abap_behv=>mk-on ).
    cl_abap_unit_assert=>assert_equals( act = ls_update-%control-estimateHours exp = if_abap_behv=>mk-on ).
  ENDMETHOD.
  METHOD profile_rejects_protected.
    DATA lt_json TYPE ycl_it_hub_policy=>tt_strings.
    lt_json = VALUE #( ( `{"title":"one","title":"two"}` ) ( `{"isAppManager":true}` )
      ( `{"title":{"nested":"value"}}` ) ( `{"title":"ok","id":"injected"}` ) ).
    LOOP AT lt_json INTO DATA(lv_json).
      TRY.
          DATA(lt_fields) = ycl_it_hub_policy=>profile_fields( iv_json = lv_json iv_fields = 'title' ).
          cl_abap_unit_assert=>fail( msg = 'Malformed/protected profile must fail before EML.' ).
        CATCH ycx_it_hub.
      ENDTRY.
    ENDLOOP.
    DATA ls_update TYPE STRUCTURE FOR UPDATE yr_it_hub_task\\Task.
    TRY.
        ycl_it_hub_policy=>apply_profile( iv_json = '{"blocked":"X"}' iv_fields = 'blocked' ir_update = REF #( ls_update ) ).
        cl_abap_unit_assert=>fail( msg = 'String must not act as a JSON boolean.' ).
      CATCH ycx_it_hub.
    ENDTRY.
  ENDMETHOD.
  METHOD deferred_dep_final_validation.
    DATA(ls_task) = VALUE ytb_it_hub_task( client = sy-mandt id = c_tester project_id = c_project task_type = 'TASK' title = 'Prerequisite' status = 'TODO' ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_task ) ).
    DATA(ls_link) = VALUE ytb_it_hub_tdep( task_id = c_developer depends_on_task_id = c_tester ).
    TYPES: BEGIN OF ty_control, id TYPE abp_behv_flag, END OF ty_control.
    DATA ls_control TYPE ty_control.
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>precheck( iv_entity = 'TASKDEP' iv_operation = 'CREATE'
      ir_row = REF #( ls_link ) is_control = ls_control iv_defer_parent = abap_true ) ).
    cl_abap_unit_assert=>assert_not_initial( act = ycl_it_hub_policy=>validate( iv_entity = 'TASKDEP' ir_row = REF #( ls_link ) ) ).
  ENDMETHOD.
  METHOD uuid_array_case.
    CONSTANTS lc_lower TYPE string VALUE 'aabbccdd-1111-4222-8333-aabbccddeeff'.
    DATA(lv_upper) = to_upper( lc_lower ).
    DATA(lt_upper) = ycl_it_hub_policy=>parse_array( iv_json = |["{ lv_upper }"]| ).
    cl_abap_unit_assert=>assert_equals( act = lt_upper[ 1 ] exp = lv_upper ).
    DATA(lt_lower) = ycl_it_hub_policy=>parse_array( iv_json = |["{ lc_lower }"]| ).
    cl_abap_unit_assert=>assert_equals( act = lt_lower[ 1 ] exp = lc_lower ).
    TRY.
        DATA(lt_duplicates) = ycl_it_hub_policy=>parse_array(
          iv_json = |["{ lc_lower }","{ lv_upper }"]| ).
        cl_abap_unit_assert=>fail( 'The same UUID in different cases must be rejected as a duplicate.' ).
      CATCH ycx_it_hub.
    ENDTRY.
    TRY.
        DATA(lt_invalid) = ycl_it_hub_policy=>parse_array(
          iv_json = '["ggbbccdd-1111-4222-8333-aabbccddeeff"]' ).
        cl_abap_unit_assert=>fail( 'Invalid hexadecimal identifiers must still be rejected.' ).
      CATCH ycx_it_hub.
    ENDTRY.
  ENDMETHOD.
  METHOD uuid_lookup_case.
    CONSTANTS lc_id TYPE sysuuid_c36 VALUE 'aabbccdd-1111-4222-8333-aabbccddeeff'.
    DATA lt_catalog TYPE STANDARD TABLE OF ytb_it_hub_skill WITH EMPTY KEY.
    lt_catalog = VALUE #( ( client = sy-mandt id = lc_id name = 'Case lookup'
      name_normalized = 'case lookup' active = abap_true )
      ( client = sy-mandt id = 'AABBCCDD-1111-4222-8333-AABBCCDDEE01' name = 'Uppercase stored key'
        name_normalized = 'uppercase stored key' active = abap_true ) ).
    go_environment->insert_test_data( lt_catalog ).
    DATA(lr_lower) = ycl_it_hub_tx=>get( iv_entity = 'SKILL' iv_id = lc_id ).
    DATA(lr_upper) = ycl_it_hub_tx=>get( iv_entity = 'SKILL' iv_id = to_upper( lc_id ) ).
    cl_abap_unit_assert=>assert_true( act = xsdbool( lr_lower IS BOUND AND lr_upper IS BOUND )
      msg = 'A persisted UUID must be found with either hex letter case.' ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>image( lr_upper )
      exp = ycl_it_hub_tx=>image( lr_lower ) ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>field( ir_row = lr_upper iv_name = 'ID' )
      exp = lc_id msg = 'Lookup must preserve the persisted row ID.' ).
    DATA(lr_upper_stored) = ycl_it_hub_tx=>get( iv_entity = 'SKILL'
      iv_id = 'aabbccdd-1111-4222-8333-aabbccddee01' ).
    cl_abap_unit_assert=>assert_true( xsdbool( lr_upper_stored IS BOUND ) ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>field( ir_row = lr_upper_stored iv_name = 'ID' )
      exp = 'AABBCCDD-1111-4222-8333-AABBCCDDEE01' ).
    DATA(lr_wrong_entity) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = to_upper( lc_id ) ).
    cl_abap_unit_assert=>assert_false( xsdbool( lr_wrong_entity IS BOUND ) ).
    DATA(lr_missing) = ycl_it_hub_tx=>get( iv_entity = 'SKILL'
      iv_id = 'aabbccdd-1111-4222-8333-aabbccddee00' ).
    cl_abap_unit_assert=>assert_false( xsdbool( lr_missing IS BOUND ) ).
  ENDMETHOD.
  METHOD uuid_buffer_overlay.
    CONSTANTS lc_id TYPE sysuuid_c36 VALUE 'aabbccdd-1111-4222-8333-aabbccddeeff'.
    DATA lt_catalog TYPE STANDARD TABLE OF ytb_it_hub_skill WITH EMPTY KEY.
    lt_catalog = VALUE #( ( client = sy-mandt id = lc_id name = 'Persisted catalog'
      name_normalized = 'persisted catalog' active = abap_true ) ).
    go_environment->insert_test_data( lt_catalog ).
    DATA(ls_buffered) = lt_catalog[ 1 ].
    ls_buffered-id = to_upper( lc_id ).
    ls_buffered-name = 'Buffered catalog'.
    ycl_it_hub_tx=>remember( iv_entity = 'SKILL' ir_row = REF #( ls_buffered ) ).
    DATA(lr_buffered) = ycl_it_hub_tx=>get( iv_entity = 'SKILL' iv_id = lc_id ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>field( ir_row = lr_buffered iv_name = 'NAME' )
      exp = 'Buffered catalog' msg = 'The changed row must override persistence across UUID case.' ).
    DATA(lt_effective) = ycl_it_hub_tx=>rows( 'SKILL' ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_effective ) exp = 1 ).
    DATA(lr_before) = ycl_it_hub_tx=>before( iv_entity = 'SKILL' iv_id = to_upper( lc_id ) ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>field( ir_row = lr_before iv_name = 'NAME' )
      exp = 'Persisted catalog' ).
    ycl_it_hub_tx=>remember( iv_entity = 'SKILL' ir_row = REF #( ls_buffered ) iv_deleted = abap_true ).
    DATA(lr_deleted_lower) = ycl_it_hub_tx=>get( iv_entity = 'SKILL' iv_id = lc_id ).
    DATA(lr_deleted_upper) = ycl_it_hub_tx=>get( iv_entity = 'SKILL' iv_id = to_upper( lc_id ) ).
    cl_abap_unit_assert=>assert_false( xsdbool( lr_deleted_lower IS BOUND ) ).
    cl_abap_unit_assert=>assert_false( xsdbool( lr_deleted_upper IS BOUND ) ).
    cl_abap_unit_assert=>assert_initial( ycl_it_hub_tx=>rows( 'SKILL' ) ).
    DATA(lr_still_before) = ycl_it_hub_tx=>before( iv_entity = 'SKILL' iv_id = lc_id ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>field( ir_row = lr_still_before iv_name = 'ID' )
      exp = lc_id msg = 'Buffered deletion must not rewrite persisted data.' ).
  ENDMETHOD.
  METHOD skill_reference_case.
    CONSTANTS lc_id TYPE sysuuid_c36 VALUE 'aabbccdd-1111-4222-8333-aabbccddeeff'.
    gs_actor-admin = abap_true.
    DATA lt_catalog TYPE STANDARD TABLE OF ytb_it_hub_skill WITH EMPTY KEY.
    lt_catalog = VALUE #( ( client = sy-mandt id = lc_id name = 'Reference case'
      name_normalized = 'reference case' active = abap_true ) ).
    go_environment->insert_test_data( lt_catalog ).
    DATA lt_existing TYPE STANDARD TABLE OF ytb_it_hub_mskil WITH EMPTY KEY.
    lt_existing = VALUE #( ( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000082' member_id = c_member
      skill_id = to_upper( lc_id ) proficiency = 'ADVANCED' ) ).
    go_environment->insert_test_data( lt_existing ).
    DATA(ls_skill) = VALUE ytb_it_hub_mskil( client = sy-mandt
      skill_id = to_upper( lc_id ) proficiency = 'ADVANCED' ).
    ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_skill )
      iv_new = abap_true iv_actor = c_member iv_preview = abap_true ).
    cl_abap_unit_assert=>assert_equals( act = ls_skill-skill_id exp = lc_id
      msg = 'A new assignment must use the catalog key spelling for its CDS association.' ).
    cl_abap_unit_assert=>assert_initial( ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_skill ) ) ).
    DATA(ls_existing) = lt_existing[ 1 ].
    ls_existing-proficiency = 'EXPERT'.
    ycl_it_hub_defaults=>apply( iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_existing )
      iv_new = abap_false iv_actor = c_member ).
    cl_abap_unit_assert=>assert_equals( act = ls_existing-skill_id exp = lt_existing[ 1 ]-skill_id
      msg = 'An unchanged reference on an existing assignment must retain its stored spelling.' ).
    cl_abap_unit_assert=>assert_equals( act = ls_existing-id exp = lt_existing[ 1 ]-id ).
    cl_abap_unit_assert=>assert_equals( act = ls_existing-proficiency exp = 'EXPERT' ).
    ls_skill-skill_id = 'aabbccdd-1111-4222-8333-aabbccddee00'.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_skill ) )
      exp = 'Skill catalog entry does not exist.' ).
  ENDMETHOD.
  METHOD member_create_authority.
    cl_abap_unit_assert=>assert_false( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ) ).
    gs_actor-manager = abap_true.
    cl_abap_unit_assert=>assert_false( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ) ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'UPDATE' ) ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_policy=>can(
      iv_entity = 'SKILL' iv_operation = 'CREATE' ) ).
    cl_abap_unit_assert=>assert_false( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ) ).
    gs_actor-active = abap_false.
    cl_abap_unit_assert=>assert_false( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ) ).
    gs_actor = VALUE #( active = abap_true admin = abap_true ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ) ).
  ENDMETHOD.
  METHOD skill_deep_create_precheck.
    gs_actor = VALUE #( id = c_member active = abap_true admin = abap_true ).
    DATA(ls_catalog) = VALUE ytb_it_hub_skill( client = sy-mandt id = c_tester
      name = 'ABAP RAP' name_normalized = 'abap rap' active = abap_true ).
    ycl_it_hub_tx=>remember( iv_entity = 'SKILL' ir_row = REF #( ls_catalog ) ).
    DATA(ls_skill) = VALUE ytb_it_hub_mskil( client = sy-mandt
      skill_id = c_tester proficiency = 'ADVANCED' ).
    DATA(lv_error) = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSKILL'
      iv_operation = 'CREATE' ir_row = REF #( ls_skill ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error
      msg = |Deep-create skill precheck must allow an unresolved parent: { lv_error }| ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_skill ) )
      exp = 'Skill assignment parent Member does not exist.' ).
    ls_skill-member_id = '00000000-0000-0000-0000-000000000099'.
    lv_error = ycl_it_hub_policy=>precheck( iv_entity = 'MEMBERSKILL'
      iv_operation = 'CREATE' ir_row = REF #( ls_skill ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error
      msg = |New resolved parent keys can still precede the buffer: { lv_error }| ).
    DATA(ls_parent) = VALUE ytb_it_hub_memb( client = sy-mandt id = ls_skill-member_id ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = REF #( ls_parent ) ).
    cl_abap_unit_assert=>assert_initial( ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_skill ) ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = REF #( ls_parent ) iv_deleted = abap_true ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERSKILL' ir_row = REF #( ls_skill ) )
      exp = 'Skill assignment parent Member does not exist.' ).
    ls_skill-proficiency = 'INVALID'.
    cl_abap_unit_assert=>assert_not_initial( ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_skill ) ) ).
    ls_skill-proficiency = 'ADVANCED'.
    ls_catalog-active = abap_false.
    ycl_it_hub_tx=>remember( iv_entity = 'SKILL' ir_row = REF #( ls_catalog ) ).
    cl_abap_unit_assert=>assert_not_initial( ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_skill ) ) ).
    gs_actor-admin = abap_false.
    cl_abap_unit_assert=>assert_false( ycl_it_hub_policy=>can(
      iv_entity = 'MEMBERSKILL' iv_operation = 'CREATE' ir_row = REF #( ls_skill ) ) ).
  ENDMETHOD.
  METHOD member_create_revocation.
    gs_actor-admin = abap_true.
    DATA(ls_member) = VALUE ytb_it_hub_memb( client = sy-mandt
      name = 'Imported member' email = 'import@example.test' active = abap_true ).
    ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'CREATE'
      ir_row = REF #( ls_member ) ).
    cl_abap_unit_assert=>assert_initial( ycl_it_hub_policy=>final_authorizations( ) ).
    gs_actor-admin = abap_false.
    gs_actor-manager = abap_true.
    cl_abap_unit_assert=>assert_not_initial( ycl_it_hub_policy=>final_authorizations( ) ).
  ENDMETHOD.
  METHOD class_setup.
    go_environment = cl_osql_test_environment=>create( VALUE #(
      ( 'YTB_IT_HUB_PROJ' ) ( 'YTB_IT_HUB_WSTR' ) ( 'YTB_IT_HUB_MEMB' )
      ( 'YTB_IT_HUB_MIDN' ) ( 'YTB_IT_HUB_MSKIL' ) ( 'YTB_IT_HUB_SKILL' )
      ( 'YTB_IT_HUB_MSHIP' ) ( 'YTB_IT_HUB_PROLE' ) ( 'YTB_IT_HUB_MILE' )
      ( 'YTB_IT_HUB_RISK' ) ( 'YTB_IT_HUB_TASK' ) ( 'YTB_IT_HUB_TDEP' )
      ( 'YTB_IT_HUB_EVENT' ) ( 'YTB_IT_HUB_EATT' ) ( 'YTB_IT_HUB_COMMT' )
      ( 'YTB_IT_HUB_DOCS' ) ( 'YTB_IT_HUB_DOATT' ) ( 'YTB_IT_HUB_CFG' ) ( 'YTB_IT_HUB_HISTO' ) ( 'USR02' ) ) ).
  ENDMETHOD.
  METHOD class_teardown.
    go_environment->destroy( ).
  ENDMETHOD.
  METHOD setup.
    go_environment->clear_doubles( ).
    ycl_it_hub_tx=>reset( ).
    gs_actor = VALUE #( id = c_member active = abap_true ).
    gv_use_actor_fixture = abap_true.
    CLEAR: gv_admin_grant, gv_user_grant.
    TEST-INJECTION current_actor.
      CLEAR rs_actor.
      IF ltc_policy=>gv_use_actor_fixture = abap_true.
        rs_actor = ltc_policy=>gs_actor.
        RETURN.
      ENDIF.
    END-TEST-INJECTION.
    TEST-INJECTION admin_grant.
      rs_actor-admin = ltc_policy=>gv_admin_grant.
    END-TEST-INJECTION.
    TEST-INJECTION user_grant.
      lv_has_user_grant = ltc_policy=>gv_user_grant.
    END-TEST-INJECTION.
    TEST-INJECTION eligible_grant.
      rv_yes = abap_true.
      RETURN.
    END-TEST-INJECTION.
    TEST-INJECTION member_grants.
      lv_admin = abap_false.
      lv_user_grant = abap_true.
    END-TEST-INJECTION.
    DATA lt_projects TYPE STANDARD TABLE OF ytb_it_hub_proj WITH EMPTY KEY.
    lt_projects = VALUE #(
      ( client = sy-mandt id = c_project code = 'P1' name = 'Test project' phase = 'INITIATION' health = 'ON_TRACK' accent = '#0EA5E9' ) ).
    DATA lt_members TYPE STANDARD TABLE OF ytb_it_hub_memb WITH EMPTY KEY.
    lt_members = VALUE #(
      ( client = sy-mandt id = c_member name = 'Manager' email = 'manager@example.test' active = abap_true )
      ( client = sy-mandt id = c_developer name = 'Developer' email = 'developer@example.test' active = abap_true )
      ( client = sy-mandt id = c_tester name = 'Tester' email = 'tester@example.test' active = abap_true ) ).
    DATA lt_identities TYPE STANDARD TABLE OF ytb_it_hub_midn WITH EMPTY KEY.
    lt_identities = VALUE #(
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000011' member_id = c_member abap_user = 'HUB_TEST_M' active = abap_true )
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000012' member_id = c_developer abap_user = 'HUB_TEST_D' active = abap_true )
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000013' member_id = c_tester abap_user = 'HUB_TEST_T' active = abap_true ) ).
    DATA lt_users TYPE STANDARD TABLE OF usr02 WITH EMPTY KEY.
    lt_users = VALUE #(
      ( mandt = sy-mandt bname = 'HUB_TEST_M' ustyp = 'A' )
      ( mandt = sy-mandt bname = 'HUB_TEST_D' ustyp = 'A' )
      ( mandt = sy-mandt bname = 'HUB_TEST_T' ustyp = 'A' ) ).
    DATA lt_memberships TYPE STANDARD TABLE OF ytb_it_hub_mship WITH EMPTY KEY.
    lt_memberships = VALUE #(
      ( client = sy-mandt id = c_membership project_id = c_project member_id = c_member active = abap_true )
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000006' project_id = c_project member_id = c_developer active = abap_true )
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000007' project_id = c_project member_id = c_tester active = abap_true ) ).
    DATA lt_roles TYPE STANDARD TABLE OF ytb_it_hub_prole WITH EMPTY KEY.
    lt_roles = VALUE #(
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000008' project_id = c_project membership_id = '00000000-0000-0000-0000-000000000006' role = 'DEVELOPER' )
      ( client = sy-mandt id = '00000000-0000-0000-0000-000000000009' project_id = c_project membership_id = '00000000-0000-0000-0000-000000000007' role = 'TESTER' ) ).
    go_environment->insert_test_data( lt_projects ).
    go_environment->insert_test_data( lt_members ).
    go_environment->insert_test_data( lt_identities ).
    go_environment->insert_test_data( lt_users ).
    go_environment->insert_test_data( lt_memberships ).
    go_environment->insert_test_data( lt_roles ).
  ENDMETHOD.
  METHOD teardown.
    ycl_it_hub_tx=>reset( ).
    ycl_it_hub_notif_plan=>reset( ).
  ENDMETHOD.

  METHOD transition_options_read_only.
    DATA(ls_task) = VALUE ytb_it_hub_task(
      id = '00000000-0000-0000-0000-000000000071' project_id = c_project
      task_type = 'TASK' status = 'DONE' assignee_id = c_member ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_task ) ).
    DATA(lv_before) = ycl_it_hub_tx=>image( REF #( ls_task ) ).
    DATA(lt_options) = ycl_it_hub_policy=>transition_options( ls_task ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_options ) exp = 1 ).
    cl_abap_unit_assert=>assert_equals( act = lt_options[ 1 ]-status exp = 'In Review' ).
    cl_abap_unit_assert=>assert_true( lt_options[ 1 ]-allowed ).
    cl_abap_unit_assert=>assert_true( lt_options[ 1 ]-requires_reason ).
    DATA(lr_after) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = ls_task-id ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_tx=>image( lr_after ) exp = lv_before ).
    cl_abap_unit_assert=>assert_initial( ycl_it_hub_tx=>guards( ) ).

    gs_actor-admin = abap_true.
    ls_task-status = 'IN_REVIEW'.
    ls_task-blocked = abap_true.
    lt_options = ycl_it_hub_policy=>transition_options( ls_task ).
    cl_abap_unit_assert=>assert_false( lt_options[ status = 'Done' ]-allowed ).
    cl_abap_unit_assert=>assert_false( lt_options[ status = 'Done' ]-override_allowed ).
  ENDMETHOD.

  METHOD team_inspection_is_scoped.
    " A Contributor cannot inspect another member even through the helper directly.
    TRY.
        DATA(ls_denied) = ycl_it_hub_policy=>member_access( iv_project = c_project iv_member = c_developer ).
        cl_abap_unit_assert=>fail( 'Team inspection must be authorized.' ).
      CATCH ycx_it_hub.
    ENDTRY.
    gs_actor-admin = abap_true.
    DATA(ls_target) = ycl_it_hub_policy=>member_access( iv_project = c_project iv_member = c_developer ).
    cl_abap_unit_assert=>assert_equals( act = ls_target-actor-id exp = c_developer ).
    cl_abap_unit_assert=>assert_false( ls_target-actor-admin ).
    cl_abap_unit_assert=>assert_true( ls_target-permissions-read ).
    cl_abap_unit_assert=>assert_false( ls_target-permissions-edit_project ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>actor( ) exp = gs_actor ).
    TRY.
        DATA(ls_outside) = ycl_it_hub_policy=>member_access(
          iv_project = c_project iv_member = '99999999-9999-4999-8999-999999999999' ).
        cl_abap_unit_assert=>fail( 'An unrelated member must not be inspected.' ).
      CATCH ycx_it_hub.
    ENDTRY.
  ENDMETHOD.

  METHOD read_scope_preserves_writes.
    ycl_it_hub_tx=>begin_read( ).
    cl_abap_unit_assert=>assert_true( ycl_it_hub_tx=>read_active( ) ).
    ycl_it_hub_tx=>end_read( ).
    cl_abap_unit_assert=>assert_false( ycl_it_hub_tx=>read_active( ) ).
    DATA(ls_task) = VALUE ytb_it_hub_task(
      id = '00000000-0000-0000-0000-000000000072' project_id = c_project task_type = 'TASK' status = 'TODO' ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_task ) ).
    TRY.
        ycl_it_hub_tx=>begin_read( ).
        cl_abap_unit_assert=>fail( 'A read must not reset an existing write transaction.' ).
      CATCH ycx_it_hub.
    ENDTRY.
    DATA(lr_task) = ycl_it_hub_tx=>get( iv_entity = 'TASK' iv_id = ls_task-id ).
    cl_abap_unit_assert=>assert_bound( lr_task ).
    cl_abap_unit_assert=>assert_equals(
      act = ycl_it_hub_tx=>field( ir_row = lr_task iv_name = 'STATUS' ) exp = 'TODO' ).
    DATA: BEGIN OF ls_control,
            title TYPE abap_bool,
          END OF ls_control.
    ls_control-title = abap_true.
    ycl_it_hub_tx=>create_controls( iv_entity = 'TASK' iv_id = ls_task-id is_control = ls_control ).
    ycl_it_hub_tx=>reset( ).
    " A completed write cleanup must also clear once-only create controls.
    ycl_it_hub_tx=>begin_read( ).
    ycl_it_hub_tx=>end_read( ).
  ENDMETHOD.
  METHOD use_real_actor.
    gv_use_actor_fixture = abap_false.
    CLEAR: gv_admin_grant, gv_user_grant.
    go_environment->clear_doubles( ).
    ycl_it_hub_tx=>reset( ).
    DATA lt_projects TYPE STANDARD TABLE OF ytb_it_hub_proj WITH EMPTY KEY.
    lt_projects = VALUE #( ( client = sy-mandt id = c_project code = 'P1'
      name = 'Bootstrap project' phase = 'INITIATION' health = 'ON_TRACK' accent = '#0EA5E9' ) ).
    go_environment->insert_test_data( lt_projects ).
    DATA lt_users TYPE STANDARD TABLE OF usr02 WITH EMPTY KEY.
    lt_users = VALUE #( ( mandt = sy-mandt bname = sy-uname ustyp = 'A' ) ).
    go_environment->insert_test_data( lt_users ).
    IF iv_mapping = abap_true.
      DATA lt_members TYPE STANDARD TABLE OF ytb_it_hub_memb WITH EMPTY KEY.
      lt_members = VALUE #( ( client = sy-mandt id = c_member name = 'Current user'
        email = 'current@example.test' active = abap_true ) ).
      DATA lt_identities TYPE STANDARD TABLE OF ytb_it_hub_midn WITH EMPTY KEY.
      lt_identities = VALUE #( ( client = sy-mandt id = c_developer member_id = c_member
        abap_user = sy-uname active = abap_true ) ).
      go_environment->insert_test_data( lt_members ).
      go_environment->insert_test_data( lt_identities ).
    ENDIF.
  ENDMETHOD.
  METHOD document_loader_maps_by_name.
    " Load metadata from a full DDIC row whose binary field is not selected.
    DATA lt_documents TYPE STANDARD TABLE OF ytb_it_hub_docs WITH EMPTY KEY.
    lt_documents = VALUE #( (
      client = sy-mandt id = '00000000-0000-0000-0000-000000000081'
      project_id = c_project title = 'Document metadata test'
      category = 'DESIGN' source_type = 'FILE' media_kind = 'PDF'
      upload_status = 'READY' file_name = 'metadata-test.pdf'
      mime_type = 'application/pdf' content = CONV xstring( '255044462D312E37' )
      byte_size = 8 checksum_sha256 = repeat( val = 'a' occ = 64 ) ) ).
    go_environment->insert_test_data( lt_documents ).
    DATA(lt_rows) = ycl_it_hub_tx=>rows( 'DOCUMENT' ).
    cl_abap_unit_assert=>assert_equals( act = lines( lt_rows ) exp = 1 ).
    DATA(lr_document) = lt_rows[ 1 ].
    DATA ls_loaded TYPE ytb_it_hub_docs.
    MOVE-CORRESPONDING lr_document->* TO ls_loaded.
    " Compare the numeric DDIC component, not its implicit string formatting.
    cl_abap_unit_assert=>assert_equals( act = ls_loaded-byte_size exp = lt_documents[ 1 ]-byte_size
      msg = 'Excluding CONTENT must not shift BYTE_SIZE into the binary component.' ).
    cl_abap_unit_assert=>assert_equals( act = ls_loaded-checksum_sha256 exp = lt_documents[ 1 ]-checksum_sha256
      msg = 'Metadata after the omitted column must retain its named field.' ).
    cl_abap_unit_assert=>assert_initial( act = ls_loaded-content
      msg = 'Permission reads must not load stored document bytes.' ).
  ENDMETHOD.
  METHOD identity_deep_create_precheck.
    use_real_actor( ).
    gv_admin_grant = abap_true.
    " Deep-create CBA can arrive with %cid_ref before the parent key exists.
    DATA(ls_identity) = VALUE ytb_it_hub_midn(
      client = sy-mandt abap_user = sy-uname active = abap_true ).
    DATA(lv_error) = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error
      msg = |A new identity must pass precheck before its parent is buffered: { lv_error }| ).
    " Early numbering can also resolve the key before the Member is buffered.
    ls_identity-member_id = c_member.
    lv_error = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error
      msg = |A resolved new parent key must not require a committed Member: { lv_error }| ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_identity ) )
      exp = 'Identity parent Member does not exist.'
      msg = 'Save validation must reject an identity whose resolved parent is absent.' ).
    DATA(ls_member) = VALUE ytb_it_hub_memb( client = sy-mandt id = c_member
      name = 'Deep-create Admin' email = 'deep-create@example.test' ).
    ycl_it_hub_defaults=>apply( iv_entity = 'MEMBER' ir_row = REF #( ls_member )
      iv_new = abap_true iv_actor = CONV #( '' ) ).
    DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBER'
      ir_row = REF #( ls_member ) iv_actor = CONV #( '' ) ).
    cl_abap_unit_assert=>assert_not_initial( act = ls_audit-token ).
    cl_abap_unit_assert=>assert_false( act = xsdbool( ycl_it_hub_tx=>before(
      iv_entity = 'MEMBER' iv_id = c_member ) IS BOUND )
      msg = 'The new parent must still be absent from committed storage.' ).
    ls_identity-id = c_developer.
    lv_error = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_identity ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error
      msg = |Save validation must resolve the new Member from transaction state: { lv_error }| ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = REF #( ls_member ) iv_deleted = abap_true ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_identity ) )
      exp = 'Identity parent Member does not exist.'
      msg = 'A parent removed from effective transaction state must still fail save.' ).
  ENDMETHOD.
  METHOD identity_precheck_guards.
    use_real_actor( iv_mapping = abap_true ).
    gv_user_grant = abap_true.
    DATA(ls_identity) = VALUE ytb_it_hub_midn(
      client = sy-mandt abap_user = sy-uname active = abap_true ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity ) )
      exp = 'You are not authorized for this operation.'
      msg = 'Deferring the parent lookup must never grant ordinary users identity creation.' ).
    gv_admin_grant = abap_true.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity ) )
      exp = 'Duplicate ABAP_USER is not allowed.'
      msg = 'Duplicate usernames must still fail before creating either record.' ).
    use_real_actor( ).
    gv_admin_grant = abap_true.
    ls_identity-abap_user = 'HUB_INVALID'.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity ) )
      exp = 'Active/new identity requires a currently valid unlocked dialog SAP user.'
      msg = 'SAP account eligibility must still be checked during deep-create precheck.' ).
    ls_identity-abap_user = sy-uname.
    ls_identity-member_id = c_member.
    DATA: BEGIN OF ls_control,
            member_id TYPE abp_behv_flag,
          END OF ls_control.
    ls_control-member_id = if_abap_behv=>mk-on.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity )
      is_control = ls_control ) exp = 'MEMBER_ID is maintained by the server.'
      msg = 'Clients must not provide the derived Member foreign key.' ).
    use_real_actor( iv_mapping = abap_true ).
    gv_admin_grant = abap_true.
    ls_identity-id = c_developer.
    DATA(ls_member) = VALUE ytb_it_hub_memb( client = sy-mandt id = c_member ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = REF #( ls_member ) iv_deleted = abap_true ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>precheck(
      iv_entity = 'MEMBERIDENT' iv_operation = 'UPDATE' ir_row = REF #( ls_identity ) )
      exp = 'Identity parent Member does not exist.'
      msg = 'Identity updates must retain their immediate parent-existence check.' ).
  ENDMETHOD.
  METHOD admin_unmapped_bootstrap.
    use_real_actor( ).
    gv_admin_grant = abap_true.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-admin ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-active ).
    cl_abap_unit_assert=>assert_initial( act = ls_actor-id ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-manager ).
    DATA(ls_member) = VALUE ytb_it_hub_memb( client = sy-mandt id = c_member
      name = 'Bootstrap Admin' email = 'bootstrap@example.test' ).
    ycl_it_hub_defaults=>apply( iv_entity = 'MEMBER' ir_row = REF #( ls_member )
      iv_new = abap_true iv_actor = ls_actor-id ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ir_row = REF #( ls_member ) ) ).
    DATA(lv_error) = ycl_it_hub_policy=>validate( iv_entity = 'MEMBER' ir_row = REF #( ls_member ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error msg = |Bootstrap Member validation: { lv_error }| ).
    DATA(ls_invalid_member) = ls_member.
    CLEAR ls_invalid_member-name.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBER' ir_row = REF #( ls_invalid_member ) ) exp = 'NAME is required.'
      msg = 'Optional Member title must not weaken mandatory name validation.' ).
    ls_invalid_member-name = ls_member-name.
    ls_invalid_member-title = repeat( val = 'X' occ = 101 ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'MEMBER' ir_row = REF #( ls_invalid_member ) ) exp = 'TITLE exceeds 100 characters.'
      msg = 'Optional Member title must still respect its maximum length.' ).
    DATA(ls_audit) = ycl_it_hub_tx=>audit( iv_entity = 'MEMBER'
      ir_row = REF #( ls_member ) iv_actor = ls_actor-id ).
    cl_abap_unit_assert=>assert_not_initial( act = ls_audit-token ).
    cl_abap_unit_assert=>assert_initial( act = ls_audit-created_by ).
    cl_abap_unit_assert=>assert_initial( act = ls_audit-updated_by ).
    DATA(ls_identity) = VALUE ytb_it_hub_midn( client = sy-mandt id = c_developer
      member_id = c_member abap_user = sy-uname active = abap_true ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ir_row = REF #( ls_identity ) ) ).
    lv_error = ycl_it_hub_policy=>validate( iv_entity = 'MEMBERIDENT' ir_row = REF #( ls_identity ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error msg = |Bootstrap identity validation: { lv_error }| ).
    ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'CREATE' ir_row = REF #( ls_member ) ).
    lv_error = ycl_it_hub_policy=>final_authorizations( ).
    cl_abap_unit_assert=>assert_initial( act = lv_error msg = |Bootstrap final authorization: { lv_error }| ).
    DATA(ls_rights) = ycl_it_hub_policy=>permissions( iv_project = c_project ).
    cl_abap_unit_assert=>assert_true( act = ls_rights-edit_project ).
    cl_abap_unit_assert=>assert_true( act = ls_rights-manage_permissions ).
    DATA(ls_project) = VALUE ytb_it_hub_proj( client = sy-mandt
      id = '00000000-0000-0000-0000-000000000021' code = 'BOOTSTRAP' name = 'New Admin project' ).
    ycl_it_hub_defaults=>apply( iv_entity = 'PROJECT' ir_row = REF #( ls_project )
      iv_new = abap_true iv_actor = ls_actor-id ).
    cl_abap_unit_assert=>assert_equals( act = ls_project-accent exp = '#0EA5E9'
      msg = 'Project defaults must supply the standard accent before validation.' ).
    lv_error = ycl_it_hub_policy=>validate( iv_entity = 'PROJECT' ir_row = REF #( ls_project ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error msg = |Bootstrap Project validation: { lv_error }| ).
    DATA(ls_color_project) = ls_project.
    ls_color_project-accent = '#aB12cD'.
    lv_error = ycl_it_hub_policy=>validate( iv_entity = 'PROJECT' ir_row = REF #( ls_color_project ) ).
    cl_abap_unit_assert=>assert_initial( act = lv_error msg = |Mixed-case hex color validation: { lv_error }| ).
    ls_color_project-accent = '#GG1122'.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'PROJECT' ir_row = REF #( ls_color_project ) ) exp = 'Accent must be a #RRGGBB color.'
      msg = 'Non-hex characters must not pass accent validation.' ).
    ls_color_project-accent = '0EA5E9'.
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'PROJECT' ir_row = REF #( ls_color_project ) ) exp = 'Accent must be a #RRGGBB color.'
      msg = 'Hex color must include its leading hash.' ).
    DATA(ls_existing_project) = VALUE ytb_it_hub_proj( client = sy-mandt id = c_project
      code = 'P1' name = 'Bootstrap project' phase = 'DESIGN' health = 'ON_TRACK' accent = '#0EA5E9' ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>validate(
      iv_entity = 'PROJECT' ir_row = REF #( ls_existing_project ) )
      exp = 'Project requires at least one eligible appointed manager after INITIATION.' ).
    DATA(ls_task) = VALUE ytb_it_hub_task( client = sy-mandt id = c_tester
      project_id = c_project task_type = 'TASK' title = 'Unassigned bootstrap task' ).
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_task )
      iv_new = abap_true iv_actor = ls_actor-id ).
    cl_abap_unit_assert=>assert_equals( act = ls_task-status exp = 'TODO' ).
    TRY.
        ycl_it_hub_policy=>transition( is_task = ls_task iv_status = 'In Progress'
          iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>fail( msg = 'A blank Member ID must not count as the assigned implementer.' ).
      CATCH ycx_it_hub.
    ENDTRY.
    ls_task = ycl_it_hub_policy=>transition( is_task = ls_task iv_status = 'In Progress'
      iv_reason = 'Admin bootstrap' iv_override = abap_true ).
    cl_abap_unit_assert=>assert_equals( act = ls_task-status exp = 'IN_PROGRESS' ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>parse_array(
      iv_json = ls_task-implementation_actors_json ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_task ) ).
    ls_task-title = 'Admin work without a Member mapping'.
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_task )
      iv_new = abap_false iv_actor = ls_actor-id ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>parse_array(
      iv_json = ls_task-implementation_actors_json ) ).
  ENDMETHOD.
  METHOD admin_inactive_mapping.
    use_real_actor( iv_mapping = abap_true ).
    gv_admin_grant = abap_true.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_equals( act = ls_actor-id exp = c_member ).
    DATA(lr_identity) = ycl_it_hub_tx=>get( iv_entity = 'MEMBERIDENT' iv_id = c_developer ).
    ycl_it_hub_tx=>put( ir_row = lr_identity iv_name = 'ACTIVE' iv_value = abap_false ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBERIDENT' ir_row = lr_identity ).
    DATA(lr_member) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = c_member ).
    ycl_it_hub_tx=>put( ir_row = lr_member iv_name = 'ACTIVE' iv_value = abap_false ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = lr_member ).
    ls_actor = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-admin ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-active ).
    cl_abap_unit_assert=>assert_initial( act = ls_actor-id ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBERIDENT' ir_row = lr_identity iv_deleted = abap_true ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = lr_member iv_deleted = abap_true ).
    ls_actor = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-active ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-admin ).
    cl_abap_unit_assert=>assert_initial( act = ls_actor-id ).
  ENDMETHOD.
  METHOD user_needs_active_mapping.
    use_real_actor( ).
    gv_user_grant = abap_true.
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-active ).
    use_real_actor( iv_mapping = abap_true ).
    gv_user_grant = abap_true.
    ls_actor = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_true( act = ls_actor-active ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-admin ).
    cl_abap_unit_assert=>assert_equals( act = ls_actor-id exp = c_member ).
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ) ).
    DATA(lr_member) = ycl_it_hub_tx=>get( iv_entity = 'MEMBER' iv_id = c_member ).
    ycl_it_hub_tx=>put( ir_row = lr_member iv_name = 'IS_APP_MANAGER' iv_value = abap_true ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = lr_member ).
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' )
      msg = 'The App Manager flag does not grant Admin-only Member creation.' ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'UPDATE' )
      msg = 'An active App Manager may maintain existing Member profiles.' ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can(
      iv_entity = 'PROJECT' iv_operation = 'CREATE' )
      msg = 'An active App Manager may create projects.' ).
    ycl_it_hub_tx=>put( ir_row = lr_member iv_name = 'ACTIVE' iv_value = abap_false ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = lr_member ).
    ls_actor = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-active ).
    ycl_it_hub_tx=>put( ir_row = lr_member iv_name = 'ACTIVE' iv_value = abap_true ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBER' ir_row = lr_member ).
    DATA(lr_identity) = ycl_it_hub_tx=>get( iv_entity = 'MEMBERIDENT' iv_id = c_developer ).
    ycl_it_hub_tx=>put( ir_row = lr_identity iv_name = 'ACTIVE' iv_value = abap_false ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBERIDENT' ir_row = lr_identity ).
    ls_actor = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-active ).
  ENDMETHOD.
  METHOD admin_grant_revoked_save.
    use_real_actor( ).
    gv_admin_grant = abap_true.
    DATA(ls_member) = VALUE ytb_it_hub_memb( id = c_member name = 'New member' email = 'new@example.test' ).
    ycl_it_hub_tx=>guard( iv_entity = 'MEMBER' iv_operation = 'CREATE' ir_row = REF #( ls_member ) ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>final_authorizations( ) ).
    gv_admin_grant = abap_false.
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBER' iv_operation = 'CREATE' ir_row = REF #( ls_member ) ) ).
    cl_abap_unit_assert=>assert_not_initial( act = ycl_it_hub_policy=>final_authorizations( ) ).
  ENDMETHOD.
  METHOD missing_grants_deny.
    use_real_actor( iv_mapping = abap_true ).
    DATA(ls_actor) = ycl_it_hub_policy=>actor( ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-active ).
    cl_abap_unit_assert=>assert_false( act = ls_actor-admin ).
    cl_abap_unit_assert=>assert_initial( act = ls_actor-id ).
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_policy=>can(
      iv_entity = 'MEMBERIDENT' iv_operation = 'CREATE' ) ).
  ENDMETHOD.
  METHOD app_flag_is_not_project_grant.
    gs_actor-manager = abap_true.
    DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = c_project ).
    cl_abap_unit_assert=>assert_bound( act = lr_project msg = 'Project fixture must be loaded from the SQL double.' ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'CREATE' ir_row = lr_project ) ).
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'UPDATE' ir_row = lr_project ) ).
    DATA(ls_rights) = ycl_it_hub_policy=>permissions( iv_project = c_project ).
    cl_abap_unit_assert=>assert_true( act = ls_rights-contribute msg = 'A Contributor can contribute when archived_at is zero.' ).
    cl_abap_unit_assert=>assert_false( act = ls_rights-edit_project ).
  ENDMETHOD.
  METHOD revocation_blocks_save.
    DATA(lr_membership) = ycl_it_hub_tx=>get( iv_entity = 'MEMBERSHIP' iv_id = c_membership ).
    cl_abap_unit_assert=>assert_bound( act = lr_membership msg = 'Membership fixture must be loaded from the SQL double.' ).
    ycl_it_hub_tx=>put( ir_row = lr_membership iv_name = 'IS_PROJECT_MANAGER' iv_value = abap_true ).
    ycl_it_hub_tx=>put( ir_row = lr_membership iv_name = 'EDIT_PROJECT' iv_value = abap_true ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBERSHIP' ir_row = lr_membership ).
    DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = c_project ).
    cl_abap_unit_assert=>assert_bound( act = lr_project msg = 'Project fixture must be loaded from the SQL double.' ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'UPDATE' ir_row = lr_project ) ).
    ycl_it_hub_tx=>guard( iv_entity = 'PROJECT' iv_operation = 'UPDATE' ir_row = lr_project ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>final_authorizations( ) ).
    ycl_it_hub_tx=>put( ir_row = lr_membership iv_name = 'ACTIVE' iv_value = abap_false ).
    ycl_it_hub_tx=>remember( iv_entity = 'MEMBERSHIP' ir_row = lr_membership ).
    cl_abap_unit_assert=>assert_equals( act = ycl_it_hub_policy=>final_authorizations( )
      exp = 'Authority for PROJECT UPDATE was revoked before save.' ).
  ENDMETHOD.
  METHOD archive_blocks_admin_writes.
    gs_actor-admin = abap_true.
    DATA(lr_project) = ycl_it_hub_tx=>get( iv_entity = 'PROJECT' iv_id = c_project ).
    cl_abap_unit_assert=>assert_bound( act = lr_project msg = 'Project fixture must be loaded from the SQL double.' ).
    DATA(ls_rights) = ycl_it_hub_policy=>permissions( iv_project = c_project ).
    cl_abap_unit_assert=>assert_true( act = ls_rights-contribute msg = 'An initial timestamp must leave the project writable.' ).
    ycl_it_hub_tx=>put( ir_row = lr_project iv_name = 'ARCHIVED_AT' iv_value = CONV timestampl( '20261007000000' ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'PROJECT' ir_row = lr_project ).
    ls_rights = ycl_it_hub_policy=>permissions( iv_project = c_project ).
    cl_abap_unit_assert=>assert_true( act = ls_rights-read msg = 'Archived projects must retain read permission.' ).
    cl_abap_unit_assert=>assert_false( act = ls_rights-contribute ).
    DATA(ls_task) = VALUE ytb_it_hub_task( project_id = c_project ).
    cl_abap_unit_assert=>assert_false( act = ycl_it_hub_policy=>can( iv_entity = 'TASK' iv_operation = 'CREATE' ir_row = REF #( ls_task ) ) ).
    cl_abap_unit_assert=>assert_true( act = ycl_it_hub_policy=>can( iv_entity = 'PROJECT' iv_operation = 'RESTORE' ir_row = lr_project ) ).
    ycl_it_hub_tx=>put( ir_row = lr_project iv_name = 'ARCHIVED_AT' iv_value = CONV timestampl( 0 ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'PROJECT' ir_row = lr_project ).
    ls_rights = ycl_it_hub_policy=>permissions( iv_project = c_project ).
    cl_abap_unit_assert=>assert_true( act = ls_rights-contribute msg = 'Clearing archived_at must restore writable project rights.' ).
  ENDMETHOD.
  METHOD defaults_preserve_false_state.
    DATA(ls_member) = VALUE ytb_it_hub_memb( id = '00000000-0000-0000-0000-000000000021' name = 'Inactive member' email = 'inactive@example.test' ).
    TYPES: BEGIN OF ty_control, active TYPE abp_behv_flag, END OF ty_control.
    DATA(ls_control) = VALUE ty_control( active = if_abap_behv=>mk-on ).
    ycl_it_hub_tx=>create_controls( iv_entity = 'MEMBER' iv_id = ls_member-id is_control = ls_control ).
    ycl_it_hub_defaults=>apply( iv_entity = 'MEMBER' ir_row = REF #( ls_member ) iv_new = abap_true iv_actor = c_member ).
    cl_abap_unit_assert=>assert_false( act = ls_member-active ).
    DATA(ls_task) = VALUE ytb_it_hub_task( id = '00000000-0000-0000-0000-000000000022' project_id = c_project title = 'New task' ).
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_task ) iv_new = abap_true iv_actor = c_member ).
    ls_task-status = 'IN_PROGRESS'.
    ls_task-implementation_actors_json = /ui2/cl_json=>serialize( VALUE ycl_it_hub_policy=>tt_strings( ( CONV string( c_member ) ) ) ).
    ycl_it_hub_defaults=>apply( iv_entity = 'TASK' ir_row = REF #( ls_task ) iv_new = abap_true iv_actor = c_member ).
    cl_abap_unit_assert=>assert_equals( act = ls_task-status exp = 'IN_PROGRESS' ).
    cl_abap_unit_assert=>assert_not_initial( act = ycl_it_hub_policy=>parse_array( iv_json = ls_task-implementation_actors_json ) ).
  ENDMETHOD.
  METHOD independent_tester_override.
    DATA(ls_task) = VALUE ytb_it_hub_task( id = '00000000-0000-0000-0000-000000000031' project_id = c_project
      task_type = 'DEFECT' title = 'Defect' status = 'READY_FOR_RETEST' assignee_id = c_developer tester_id = c_tester resolution = 'Fixed'
      implementation_actors_json = /ui2/cl_json=>serialize( VALUE ycl_it_hub_policy=>tt_strings( ( CONV string( c_developer ) ) ) ) ).
    gs_actor-id = c_tester.
    DATA(ls_closed) = ycl_it_hub_policy=>transition( is_task = ls_task iv_status = 'Closed' iv_reason = '' iv_override = abap_false ).
    cl_abap_unit_assert=>assert_equals( act = ls_closed-status exp = 'CLOSED' ).
    ls_task-implementation_actors_json = /ui2/cl_json=>serialize( VALUE ycl_it_hub_policy=>tt_strings( ( CONV string( c_tester ) ) ) ).
    TRY.
        ls_closed = ycl_it_hub_policy=>transition( is_task = ls_task iv_status = 'Closed' iv_reason = '' iv_override = abap_false ).
        cl_abap_unit_assert=>fail( 'An implementer cannot approve their own defect retest.' ).
      CATCH ycx_it_hub INTO DATA(lx_retest).
        cl_abap_unit_assert=>assert_equals( act = lx_retest->text
          exp = 'Retest requires an assigned independent Tester and known implementation evidence.' ).
    ENDTRY.
    gs_actor-admin = abap_true.
    ls_task-status = 'OPEN'.
    TRY.
        ls_closed = ycl_it_hub_policy=>transition( is_task = ls_task iv_status = 'Closed' iv_reason = 'Override' iv_override = abap_true ).
        cl_abap_unit_assert=>fail( 'Admin override cannot jump the workflow graph.' ).
      CATCH ycx_it_hub INTO DATA(lx_override).
        cl_abap_unit_assert=>assert_equals( act = lx_override->text exp = 'This workflow transition is not legal.' ).
    ENDTRY.
  ENDMETHOD.
  METHOD buffered_graph_overlay.
    DATA(ls_a) = VALUE ytb_it_hub_task( id = '00000000-0000-0000-0000-000000000041' project_id = c_project task_type = 'TASK' status = 'TODO' ).
    DATA(ls_b) = ls_a. ls_b-id = '00000000-0000-0000-0000-000000000042'.
    DATA(ls_c) = ls_a. ls_c-id = '00000000-0000-0000-0000-000000000043'.
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_a ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_b ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASK' ir_row = REF #( ls_c ) ).
    DATA(ls_ab) = VALUE ytb_it_hub_tdep( id = '00000000-0000-0000-0000-000000000044' project_id = c_project task_id = ls_a-id depends_on_task_id = ls_b-id ).
    DATA(ls_bc) = ls_ab. ls_bc-id = '00000000-0000-0000-0000-000000000045'. ls_bc-task_id = ls_b-id. ls_bc-depends_on_task_id = ls_c-id.
    DATA(ls_ca) = ls_ab. ls_ca-id = '00000000-0000-0000-0000-000000000046'. ls_ca-task_id = ls_c-id. ls_ca-depends_on_task_id = ls_a-id.
    ycl_it_hub_tx=>remember( iv_entity = 'TASKDEP' ir_row = REF #( ls_ab ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASKDEP' ir_row = REF #( ls_bc ) ).
    cl_abap_unit_assert=>assert_not_initial( act = ycl_it_hub_policy=>graph( ls_ca ) ).
    ycl_it_hub_tx=>remember( iv_entity = 'TASKDEP' ir_row = REF #( ls_bc ) iv_deleted = abap_true ).
    cl_abap_unit_assert=>assert_initial( act = ycl_it_hub_policy=>graph( ls_ca ) ).
  ENDMETHOD.
  METHOD strict_json_and_url.
    TRY.
        DATA(lt_values) = ycl_it_hub_policy=>parse_array( iv_json = '["00000000-0000-0000-0000-000000000001",null]' ).
        cl_abap_unit_assert=>fail( 'Mixed-type arrays must be rejected.' ).
      CATCH ycx_it_hub.
    ENDTRY.
    " No host configuration exists in the SQL double: any valid website is accepted.
    ycl_it_hub_media=>url( 'https://unconfigured.example/document' ).
    ycl_it_hub_media=>url( 'https://another.example.org:8443/document?version=2#section' ).
    ycl_it_hub_media=>url( 'HTTPS://Documents.Example.net/folder/specification%20draft.pdf' ).
    DATA lt_invalid_urls TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    lt_invalid_urls = VALUE #(
      ( `http://example.org/document` )
      ( `javascript:alert(1)` )
      ( `/relative/document` )
      ( `https:///document` )
      ( `https://user:secret@example.org/document` )
      ( `https://bad..example/document` )
      ( `https://example.org:0/document` )
      ( `https://example.org:65536/document` )
      ( `https://example.org/document with spaces` )
      ( `https://example.org/document%ZZ` )
      ( `https://example.org/document%` )
      ( `https://example.org/document%2` )
      ( `https://example.org/document?version=%ZZ` )
      ( `https://example.org/document#section%ZZ` )
      ( |https://example.org/document{ cl_abap_char_utilities=>horizontal_tab }name| )
      ( |https://example.org/document{ cl_abap_char_utilities=>newline }name| ) ).
    LOOP AT lt_invalid_urls INTO DATA(lv_url).
      TRY.
          ycl_it_hub_media=>url( lv_url ).
          cl_abap_unit_assert=>fail( |Invalid URL must be rejected: { lv_url }| ).
        CATCH ycx_it_hub.
      ENDTRY.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
