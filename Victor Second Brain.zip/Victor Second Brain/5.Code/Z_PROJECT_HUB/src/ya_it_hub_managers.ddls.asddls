@EndUserText.label: 'Project Hub action parameter'
define abstract entity YA_IT_HUB_MANAGERS
{
  memberIdsJson : abap.string(0);
}
