@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Project Hub - Workstream'
define view entity YI_IT_HUB_WORKSTREAM
  as select from ytb_it_hub_wstr
  association to parent YR_IT_HUB_PROJECT as _Project on $projection.projectId = _Project.id
  association [0..1] to YR_IT_HUB_MEMBER as _Owner on $projection.ownerId = _Owner.id
{
  key id as id,
  project_id as projectId,
  name as name,
  owner_id as ownerId,
  description as description,
  sort_order as sortOrder,
  @Semantics.systemDateTime.createdAt: true
  created_at as createdAt,
  @Semantics.user.createdBy: true
  created_by as createdByTechnical,
  @Semantics.systemDateTime.lastChangedAt: true
  updated_at as updatedAt,
  @Semantics.user.lastChangedBy: true
  updated_by as updatedByTechnical,
  @Semantics.systemDateTime.localInstanceLastChangedAt: true
  local_last_changed_at as localLastChangedAt,
  created_by_member_id as createdBy,
  updated_by_member_id as updatedBy,
  change_token as changeToken,
  _Project,
  _Owner
}
