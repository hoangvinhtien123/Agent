@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Working Day / Working Hour Config'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_MP_PROJ_WRKCL_CONFIG
  as select from ymp_proj_wrkcl
{
  key bukrs                 as CompanyCode,
  key gjahr                 as FiscalYear,
      work_days             as WorkDays,
      work_hours            as WorkHours,
      @Semantics.user.createdBy: true
      created_by            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      created_at            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      last_changed_by       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      last_changed_at       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      local_last_changed_at as LocalLastChangedAt
}
