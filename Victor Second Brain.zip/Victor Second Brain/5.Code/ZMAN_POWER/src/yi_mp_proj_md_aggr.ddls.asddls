@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Assigned Manday per Employee/Year'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_MD_AGGR
  as select from YR_MP_PROJ_MD_PER as _load
{
  key _load.EmployeeId  as EmployeeId,
  key _load.ProjectYear as ProjectYear,

      // Pivot period rows back to 12 columns so consumers keep the same shape
      cast( sum( case when _load.Period = '001' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd01,
      cast( sum( case when _load.Period = '002' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd02,
      cast( sum( case when _load.Period = '003' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd03,
      cast( sum( case when _load.Period = '004' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd04,
      cast( sum( case when _load.Period = '005' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd05,
      cast( sum( case when _load.Period = '006' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd06,
      cast( sum( case when _load.Period = '007' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd07,
      cast( sum( case when _load.Period = '008' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd08,
      cast( sum( case when _load.Period = '009' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd09,
      cast( sum( case when _load.Period = '010' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd10,
      cast( sum( case when _load.Period = '011' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd11,
      cast( sum( case when _load.Period = '012' then _load.ManDay else cast( 0 as abap.dec(7,2) ) end )
            as abap.dec(9,2) ) as AssignedMd12,
      cast( sum( _load.ManDay ) as abap.dec(9,2) ) as AssignedMdTotal
}
group by
  _load.EmployeeId,
  _load.ProjectYear
