@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Loading Projection'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_MP_PROJ_MD_LOAD
  as projection on YR_MP_PROJ_MD_LOAD
{
  key ProjectId,
  key EmployeeId,
  key ProjectYear,
      ShortText,
      ProjectName,
      CompanyCode,
      EmployeeName,
      EmployeeGroup,
      EmployeeSubgroup,
      CostCenter,
      OrganizationalUnit,
      OrganizationalUnitText,
      EmployeePositionText,
      ContractType,
      ContractTypeText,
      ContractEndDate,
      Currency,
      @Semantics.amount.currencyCode : 'Currency'
      MonthlyRate,
      RateYear,
      ManDayTotal,
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      LocalLastChangedAt,

      _period : redirected to composition child YC_MP_PROJ_MD_PER,
      _project_std,
      _project_uns,
      _employee,
      _md_total
}
