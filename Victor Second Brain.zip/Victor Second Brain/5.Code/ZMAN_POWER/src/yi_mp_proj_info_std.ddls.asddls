@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Project Information (Standard)'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_INFO_STD
  as select from proj as _project
  association [0..1] to ymp_proj_info as _proj_info on  _proj_info.proj_id         = _project.pspnr
                                                    and _proj_info.proj_definition = _project.pspid
{
  key cast( _project.pspnr as abap.numc(8) )  as ProjectID,
      cast( _project.pspid as abap.char(24) ) as ProjectDefinition,
      _proj_info.short_text                   as ShortText,
      ''                                      as IsUnsecured,
      _project.post1                          as ProjectName,
      _project.vbukr                          as CompanyCode,
      _project.vgsbr                          as BusinessArea,
      _project.vkokr                          as ControllingArea,
      _project.prctr                          as ProfitCenter,
      _project.pwhie                          as ProjectCurrency,
      _project.plfaz                          as StartDate,
      _project.plsez                          as FinishDate,
      _project.vernr                          as ResponsibleNo,
      _project.verna                          as ResponsibleName,
      _project.objnr                          as ObjectNumber
}
