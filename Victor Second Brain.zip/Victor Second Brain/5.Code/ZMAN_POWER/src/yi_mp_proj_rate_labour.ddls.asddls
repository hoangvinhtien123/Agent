@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Labour Rate'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_RATE_LABOUR
  as select from cssl  as _cssl
    inner join   cost  as _cost  on  _cssl.objnr = _cost.objnr
                                 and _cssl.gjahr = _cost.gjahr
    inner join   tka01 as _tka01 on _tka01.kokrs = _cssl.kokrs
    inner join   csks  as _csks  on  _csks.kokrs = _cssl.kokrs
                                 and _csks.kostl = _cssl.kostl
                                 and _csks.datbi >= $session.system_date
                                 and _csks.datab <= $session.system_date
{
  key _cssl.kokrs                                            as ControllingArea,
  key _cssl.kostl                                            as CostCenter,
  key _cssl.lstar                                            as ActivityType,
  key _cssl.gjahr                                            as FiscalYear,
  key _cost.objnr                                            as ObjectNumber,
  key _cost.versn                                            as Version,
  key _cost.tarkz                                            as PriceIndicator,
      _csks.bukrs                                            as CompanyCode,
      _tka01.waers                                           as Currency,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg001 - _cost.tkf001 as abap.curr(23,2) ) as LabourRate001,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg002 - _cost.tkf002 as abap.curr(23,2) ) as LabourRate002,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg003 - _cost.tkf003 as abap.curr(23,2) ) as LabourRate003,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg004 - _cost.tkf004 as abap.curr(23,2) ) as LabourRate004,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg005 - _cost.tkf005 as abap.curr(23,2) ) as LabourRate005,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg006 - _cost.tkf006 as abap.curr(23,2) ) as LabourRate006,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg007 - _cost.tkf007 as abap.curr(23,2) ) as LabourRate007,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg008 - _cost.tkf008 as abap.curr(23,2) ) as LabourRate008,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg009 - _cost.tkf009 as abap.curr(23,2) ) as LabourRate009,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg010 - _cost.tkf010 as abap.curr(23,2) ) as LabourRate010,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg011 - _cost.tkf011 as abap.curr(23,2) ) as LabourRate011,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg012 - _cost.tkf012 as abap.curr(23,2) ) as LabourRate012

}
where
      _cssl.lstar <> '10400'
  and _cost.wrttp =  '04'
  and _cost.lednr =  '00'
