CLASS zbp_r_mp_proj_wrkcl_config DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF yr_mp_proj_wrkcl_config.
ENDCLASS.

CLASS zbp_r_mp_proj_wrkcl_config IMPLEMENTATION.
ENDCLASS.
