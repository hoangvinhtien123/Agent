@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Annual Budget'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_BUDG_ANNUAL
  as select from bpja
{
  key objnr        as ObjectNumber,
  key gjahr        as FiscalYear,
  key twaer        as Currency,
      @Semantics.amount.currencyCode: 'Currency'
      sum( wtjhr ) as AnnualBudget
}
where
      wrttp = '45'
  and versn = '000'
group by
  objnr,
  gjahr,
  twaer
