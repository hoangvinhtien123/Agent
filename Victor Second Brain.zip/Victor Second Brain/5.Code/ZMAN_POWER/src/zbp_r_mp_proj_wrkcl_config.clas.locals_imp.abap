CLASS lhc_Work_calendar_config DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    CONSTANTS:
      c_min_work_days     TYPE i VALUE 1,
      c_max_work_days     TYPE i VALUE 31,
      c_max_hours_per_day TYPE p LENGTH 4 DECIMALS 2 VALUE '24.00',
      c_def_hours_per_day TYPE p LENGTH 3 DECIMALS 2 VALUE '8.00',
      c_max_period        TYPE i VALUE 12.
    TYPES:
      BEGIN OF ty_company_code,
        company_code TYPE bukrs,
      END OF ty_company_code,
      ty_company_codes TYPE SORTED TABLE OF ty_company_code WITH UNIQUE KEY company_code.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR WrkCalConfig RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR WrkCalConfig RESULT result.

    METHODS setDefaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR WrkCalConfig~setDefaults.

    METHODS validateWorkDays FOR VALIDATE ON SAVE
      IMPORTING keys FOR WrkCalConfig~validateWorkDays.

    METHODS validateWorkHours FOR VALIDATE ON SAVE
      IMPORTING keys FOR WrkCalConfig~validateWorkHours.
    METHODS validateCompanyCode FOR VALIDATE ON SAVE
      IMPORTING keys FOR WrkCalConfig~validateCompanyCode.

ENDCLASS.

CLASS lhc_Work_calendar_config IMPLEMENTATION.

  METHOD get_instance_authorizations.
  ENDMETHOD.

  METHOD get_global_authorizations.
  ENDMETHOD.

  METHOD setDefaults.
  ENDMETHOD.

  METHOD validateWorkDays.

    " WorkDays = number of working days in the month
    READ ENTITIES OF yr_mp_proj_wrkcl_config IN LOCAL MODE
      ENTITY WrkCalConfig
        FIELDS ( WorkDays )
        WITH CORRESPONDING #( keys )
      RESULT DATA(configs).

    LOOP AT configs INTO DATA(config).
      IF config-WorkDays < c_min_work_days OR config-WorkDays > c_max_work_days.
        APPEND VALUE #( %tky = config-%tky ) TO failed-wrkcalconfig.
        APPEND VALUE #( %tky              = config-%tky
                        %element-WorkDays = if_abap_behv=>mk-on
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Working days per month must be between { c_min_work_days } and { c_max_work_days } | ) )
               TO reported-wrkcalconfig.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

  METHOD validateWorkHours.
    " WorkHours = number of working hours in a day
    READ ENTITIES OF yr_mp_proj_wrkcl_config IN LOCAL MODE
      ENTITY WrkCalConfig
        FIELDS ( WorkHours )
        WITH CORRESPONDING #( keys )
      RESULT DATA(configs).

    LOOP AT configs INTO DATA(config).
      IF config-WorkHours <= 0 OR config-WorkHours > c_max_hours_per_day.
        APPEND VALUE #( %tky = config-%tky ) TO failed-wrkcalconfig.
        APPEND VALUE #( %tky               = config-%tky
                        %element-WorkHours = if_abap_behv=>mk-on
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Working hours per day must be greater than 0 and at most { c_max_hours_per_day }| ) )
               TO reported-wrkcalconfig.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD validateCompanyCode.
    READ ENTITIES OF yr_mp_proj_wrkcl_config IN LOCAL MODE
      ENTITY WrkCalConfig
        FIELDS ( CompanyCode )
        WITH CORRESPONDING #( keys )
      RESULT DATA(configs).

    DATA company_codes TYPE ty_company_codes.

    " INSERT ... INTO TABLE silently skips duplicates (sy-subrc = 4), no dump
    LOOP AT configs INTO DATA(config_key) WHERE CompanyCode IS NOT INITIAL.
      INSERT VALUE #( company_code = config_key-CompanyCode ) INTO TABLE company_codes.
    ENDLOOP.

    IF company_codes IS NOT INITIAL.
      SELECT FROM I_CompanyCode
        FIELDS CompanyCode
        FOR ALL ENTRIES IN @company_codes
        WHERE CompanyCode = @company_codes-company_code
        INTO TABLE @DATA(valid_company_codes).
    ENDIF.

    LOOP AT configs INTO DATA(config).
      IF config-CompanyCode IS INITIAL.
        APPEND VALUE #( %tky = config-%tky ) TO failed-wrkcalconfig.
        APPEND VALUE #( %tky                 = config-%tky
                        %element-CompanyCode = if_abap_behv=>mk-on
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = 'Company Code is mandatory' ) )
               TO reported-wrkcalconfig.
        CONTINUE.
      ENDIF.

      IF NOT line_exists( valid_company_codes[ CompanyCode = config-CompanyCode ] ).
        APPEND VALUE #( %tky = config-%tky ) TO failed-wrkcalconfig.
        APPEND VALUE #( %tky                 = config-%tky
                        %element-CompanyCode = if_abap_behv=>mk-on
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Company Code { config-CompanyCode } does not exist| ) )
               TO reported-wrkcalconfig.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

ENDCLASS.
