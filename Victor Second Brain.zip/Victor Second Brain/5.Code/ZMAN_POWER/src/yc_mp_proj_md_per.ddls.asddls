@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Loading per Period Projection'
@Metadata.ignorePropagatedAnnotations: true
define view entity YC_MP_PROJ_MD_PER
  as projection on YR_MP_PROJ_MD_PER
{
  key ProjectId,
  key EmployeeId,
  key ProjectYear,
  key Period,
      ManDay,
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LocalLastChangedAt,

      _header : redirected to parent YC_MP_PROJ_MD_LOAD
}
