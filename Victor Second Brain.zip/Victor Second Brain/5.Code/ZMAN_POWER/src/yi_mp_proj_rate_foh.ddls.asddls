@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Factory Overhead Rate'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_RATE_FOH
  as select from cssl  as _cssl
    inner join   cost  as _cost  on  _cssl.objnr = _cost.objnr
                                 and _cssl.gjahr = _cost.gjahr
    inner join   tka01 as _tka01 on _tka01.kokrs = _cssl.kokrs
{
  key _cssl.kokrs                                            as ControllingArea,
  key _cssl.kostl                                            as CostCenter,
  key _cssl.gjahr                                            as FiscalYear,
  key _cost.objnr                                            as ObjectNumber,
  key _cost.versn                                            as Version,
  key _cost.tarkz                                            as PriceIndicator,
      _tka01.waers                                           as Currency,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg001 - _cost.tkf001 as abap.curr(23,2) ) as FOHRate001,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg002 - _cost.tkf002 as abap.curr(23,2) ) as FOHRate002,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg003 - _cost.tkf003 as abap.curr(23,2) ) as FOHRate003,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg004 - _cost.tkf004 as abap.curr(23,2) ) as FOHRate004,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg005 - _cost.tkf005 as abap.curr(23,2) ) as FOHRate005,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg006 - _cost.tkf006 as abap.curr(23,2) ) as FOHRate006,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg007 - _cost.tkf007 as abap.curr(23,2) ) as FOHRate007,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg008 - _cost.tkf008 as abap.curr(23,2) ) as FOHRate008,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg009 - _cost.tkf009 as abap.curr(23,2) ) as FOHRate009,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg010 - _cost.tkf010 as abap.curr(23,2) ) as FOHRate010,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg011 - _cost.tkf011 as abap.curr(23,2) ) as FOHRate011,
      @Semantics.amount.currencyCode: 'Currency'
      cast( _cost.tkg012 - _cost.tkf012 as abap.curr(23,2) ) as FOHRate012

}
where
      _cssl.lstar = '10400'
  and _cost.wrttp = '04'
  and _cost.lednr = '00'
