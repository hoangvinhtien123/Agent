CLASS ycl_mp_proj_budget_ve DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_sadl_exit .
    INTERFACES if_sadl_exit_calc_element_read .
  PROTECTED SECTION.
  PRIVATE SECTION.

    CONSTANTS : c_annual  TYPE char10 VALUE 'Annual',   ##NO_TEXT
                c_overall TYPE char10 VALUE 'Overall'.  ##NO_TEXT

    TYPES:
      BEGIN OF st_budget,
        project_def       TYPE string,
        wbselement        TYPE string,
        bdgt_curr_overall TYPE string,
        bdgt_curr_anual   TYPE string,
        bdgt_asgn_overall TYPE string,
        currency          TYPE string,
        overll_anual      TYPE string,
        year              TYPE string,
      END OF st_budget.

    TYPES : BEGIN OF st_over_asg,
              objnr      TYPE prps-objnr,
              over_assig TYPE ytb_ppm_resource-over_assign_bud,
            END OF st_over_asg.

    DATA : lv_bukrs     TYPE t001-bukrs,
           lt_acc_main  TYPE TABLE OF bbp_acc_r3,
           ls_acc_main  TYPE bbp_acc_r3,
           lt_bp_budget TYPE TABLE OF bbp_budget,
           ls_bp_budget TYPE bbp_budget,
           lt_acc       TYPE TABLE OF bbp_acc_r3.

    DATA : lt_over_asg TYPE TABLE OF st_over_asg,
           ls_over_asg TYPE st_over_asg,
           lt_budget   TYPE TABLE OF st_budget,
           ls_budget   TYPE st_budget.

ENDCLASS.



CLASS YCL_MP_PROJ_BUDGET_VE IMPLEMENTATION.


  METHOD if_sadl_exit_calc_element_read~calculate.

    DATA:
        lt_data TYPE STANDARD TABLE OF yi_mp_proj_budg.

    lt_data = CORRESPONDING #( it_original_data ).
    CHECK lt_data IS NOT INITIAL.

    SELECT  objnr,
            wtges,
           twaer INTO TABLE @DATA(lt_budg)
                  FROM bpge
                 FOR ALL ENTRIES IN @lt_data
                  WHERE objnr = @lt_data-ObjectNumber
                  AND   wrttp = '45'.

    SELECT objnr,
           wrttp,
           gjahr,
           wlp01,
           wlp02,
           wlp03,
           wlp04,
           wlp05,
           wlp06,
           wlp07,
           wlp08,
           wlp09,
           wlp10,
           wlp11,
           wlp12   INTO TABLE @DATA(lt_assgin) FROM rpsco
                      FOR ALL ENTRIES IN @lt_data
                      WHERE objnr = @lt_data-ObjectNumber
                      AND   wrttp = '04'.

    LOOP AT lt_data INTO DATA(ls_data).

      "budget reading
      CLEAR :lt_acc_main.
      lv_bukrs = ls_data-CompanyCode.
      ls_acc_main-wbs_elem_e = ls_data-WbsElement.
      APPEND ls_acc_main TO lt_acc_main.
      CLEAR : ls_acc_main.

      CALL FUNCTION 'BBP_BUDGET_READ'
        EXPORTING
          co_code     = lv_bukrs
        TABLES
          it_acc_main = lt_acc_main
          it_acc      = lt_acc
          et_budget   = lt_bp_budget.

      IF sy-subrc = 0.

        READ TABLE lt_bp_budget INTO ls_bp_budget INDEX 1.
        READ TABLE lt_budg INTO DATA(ls_budg) WITH KEY objnr = ls_data-ObjectNumber.
        LOOP AT lt_assgin INTO DATA(ls_asgg) WHERE objnr = ls_data-ObjectNumber.

          ls_over_asg-objnr = ls_asgg-objnr.
          ls_over_asg-over_assig = ls_asgg-wlp01 + ls_asgg-wlp02 + ls_asgg-wlp03 + ls_asgg-wlp04
                                         +  ls_asgg-wlp05 + ls_asgg-wlp06 + ls_asgg-wlp07 + ls_asgg-wlp08
                                         + ls_asgg-wlp09 + ls_asgg-wlp10 + ls_asgg-wlp11 + ls_asgg-wlp12.

          COLLECT ls_over_asg INTO lt_over_asg.
          CLEAR: ls_asgg , ls_over_asg.
        ENDLOOP.

        IF lt_budg IS NOT INITIAL.
          LOOP AT lt_budg INTO ls_budg WHERE objnr = ls_data-ObjectNumber.
            READ TABLE lt_over_asg INTO ls_over_asg  WITH KEY objnr = ls_budg-objnr.
            IF sy-subrc = 0.
              ls_budget-bdgt_asgn_overall = ls_over_asg-over_assig.
            ENDIF.

            ls_budget-project_def       = ls_data-ProjectId.
            ls_budget-wbselement        = ls_data-WbsElement.
            ls_budget-bdgt_curr_overall = ls_budg-wtges.
            ls_budget-currency          = ls_budg-twaer.
            ls_budget-overll_anual      = c_overall ."'Annual'.


            APPEND ls_budget TO lt_budget.
            CLEAR : ls_budget  , ls_budg.

          ENDLOOP.

        ENDIF.


        SELECT  * FROM bpja INTO TABLE @DATA(lt_bpja)
                                     WHERE objnr = @ls_data-ObjectNumber
                                     AND   wrttp = '45'.

        IF lt_bpja IS NOT INITIAL.

          LOOP AT lt_bpja INTO DATA(ls_bpja).

            IF ls_bpja-wtjhr IS NOT INITIAL..

              ls_budget-project_def       = ls_data-ProjectId.
              ls_budget-wbselement        = ls_data-WbsElement.
*              ls_budget-bdgt_asgn_overall = ls_bp_budget-bdgt_assgn.
              READ TABLE lt_assgin INTO DATA(ls_asg) WITH KEY objnr = ls_bpja-objnr
                                                 gjahr = ls_bpja-gjahr.
              IF sy-subrc = 0.


                ls_budget-bdgt_asgn_overall = ls_asg-wlp01 + ls_asg-wlp02 + ls_asg-wlp03 + ls_asg-wlp04
                                            +  ls_asg-wlp05 + ls_asg-wlp06 + ls_asg-wlp07 + ls_asg-wlp08
                                            + ls_asg-wlp09 + ls_asg-wlp10 + ls_asg-wlp11 + ls_asg-wlp12.
              ENDIF.
*              ls_budget-bdgt_asgn_overall = ls_budg-wtges.
              ls_budget-bdgt_curr_overall = ls_budg-wtges.
              ls_budget-bdgt_curr_anual   = ls_bpja-wtjhr.
              ls_budget-currency          = ls_bp_budget-currency.
              ls_budget-overll_anual      = c_annual ."'Annual'.
              ls_budget-year              = ls_bpja-gjahr.
            ENDIF.

            IF   ls_budget-overll_anual IS INITIAL.

              ls_budget-year              = ls_bpja-gjahr.
              ls_budget-project_def       = ls_data-ProjectId .
              ls_budget-wbselement        = ls_data-WbsElement.

              ls_budget-bdgt_asgn_overall = ls_asg-wlp01 + ls_asg-wlp02 + ls_asg-wlp03 + ls_asg-wlp04
                                          +  ls_asg-wlp05 + ls_asg-wlp06 + ls_asg-wlp07 + ls_asg-wlp08
                                          + ls_asg-wlp09 + ls_asg-wlp10 + ls_asg-wlp11 + ls_asg-wlp12.

              ls_budget-bdgt_curr_anual   = ls_bpja-wtjhr.
              ls_budget-currency          = ls_bp_budget-currency.
              ls_budget-overll_anual      = c_overall."'Overall'.
            ENDIF.

            APPEND ls_budget TO lt_budget.
            CLEAR : ls_budget  , ls_bpja , ls_asg.


          ENDLOOP.
        ELSEIF lt_bpja[] IS INITIAL.

          READ TABLE lt_budget INTO ls_budget WITH KEY wbselement = ls_data-WbsElement.
          IF sy-subrc <> 0.

            ls_budget-project_def = ls_data-ProjectId .
            ls_budget-wbselement  = ls_data-WbsElement.
            ls_budget-bdgt_asgn_overall = ls_bp_budget-bdgt_assgn.
            ls_budget-bdgt_curr_overall = ls_budg-wtges.
            ls_budget-currency          = ls_bp_budget-currency.
            ls_budget-overll_anual = c_overall."'Overall'.

            APPEND ls_budget TO lt_budget.
            CLEAR : ls_budget , ls_bp_budget  , ls_bpja.

          ENDIF.
        ENDIF.
        CLEAR :ls_budget.

      ENDIF.

    ENDLOOP.

*    LOOP AT lt_budget INTO ls_budget.
*      READ TABLE lt_data ASSIGNING FIELD-SYMBOL(<lfs_data>)
*      WITH KEY wbselement = ls_budget-wbselement
*               FiscalYear = ls_budget-year.
*
*      IF sy-subrc <> 0.
*        READ TABLE lt_data ASSIGNING <lfs_data>
*        WITH KEY wbselement = ls_budget-wbselement.
*      ENDIF.
*
*      IF <lfs_data> IS ASSIGNED.
*        <lfs_data>-OverAllBudget    	= ls_budget-bdgt_curr_overall.
*        <lfs_data>-OverAssignBudget     = ls_budget-bdgt_asgn_overall.
*        <lfs_data>-OverAvailableBudget  = COND #( WHEN ls_budget-overll_anual = c_overall THEN ls_budget-bdgt_curr_overall - ls_budget-bdgt_asgn_overall
*                                                  ELSE ls_budget-bdgt_curr_anual - ls_budget-bdgt_asgn_overall ).
*        <lfs_data>-AnnulCurBudget       = ls_budget-bdgt_curr_anual.
*        <lfs_data>-Currency             = ls_budget-currency.
*      ENDIF.
*
*    ENDLOOP.

    ct_calculated_data = CORRESPONDING #( lt_data ).

  ENDMETHOD.


  METHOD if_sadl_exit_calc_element_read~get_calculation_info.

    LOOP AT it_requested_calc_elements INTO DATA(lv_element).
      CASE to_upper( lv_element ).
        WHEN 'CURRENCY' OR 'OVERALLBUDGET' OR 'OVERASSIGNBUDGET'
          OR 'ANNULCURBUDGET' OR 'OVERAVAILABLEBUDGET'.

          INSERT `COMPANYCODE`  INTO TABLE et_requested_orig_elements.
          INSERT `PROJECTID`    INTO TABLE et_requested_orig_elements.
          INSERT `OBJECTNUMBER` INTO TABLE et_requested_orig_elements.
          INSERT `WBSELEMENT`   INTO TABLE et_requested_orig_elements.
          INSERT `FISCALYEAR`   INTO TABLE et_requested_orig_elements.

      ENDCASE.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.
