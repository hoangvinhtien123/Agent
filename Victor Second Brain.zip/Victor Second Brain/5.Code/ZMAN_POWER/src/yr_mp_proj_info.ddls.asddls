@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Man Power: Project Information'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_MP_PROJ_INFO
  as select from ymp_proj_info as _proj_info
  association [0..1] to proj as _project on _project.pspnr = _proj_info.proj_id
{
  key _proj_info.proj_id               as ProjectId,
  key _proj_info.proj_definition       as ProjectDefinition,
      _proj_info.short_text            as ShortText,
      _proj_info.is_unsecured          as IsUnsecured,
      _project.post1                   as ProjectName,
      _project.vbukr                   as CompanyCode,
      _project.vgsbr                   as BusinessArea,
      _project.vkokr                   as ControllingArea,
      _project.prctr                   as ProfitCenter,
      _project.pwhie                   as ProjectCurrency,
      _project.plfaz                   as StartDate,
      _project.plsez                   as FinishDate,
      _project.vernr                   as ResponsibleNo,
      _project.verna                   as ResponsibleName,
      _project.objnr                   as ObjectNumber,
      @Semantics.user.createdBy: true
      _proj_info.created_by            as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      _proj_info.created_at            as CreatedAt,
      @Semantics.user.lastChangedBy: true
      _proj_info.last_changed_by       as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      _proj_info.last_changed_at       as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      _proj_info.local_last_changed_at as LocalLastChangedAt,

      _project
}
