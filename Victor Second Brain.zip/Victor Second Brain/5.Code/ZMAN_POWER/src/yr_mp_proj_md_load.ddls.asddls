@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Loading'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YR_MP_PROJ_MD_LOAD
  as select from ymp_proj_md_load as _proj_md
  composition [0..*] of YR_MP_PROJ_MD_PER as _period
  association [0..1] to YI_MP_PROJ_INFO_STD as _project_std on _project_std.ProjectID = _proj_md.proj_id
  association [0..1] to YI_MP_PROJ_INFO_UNS as _project_uns on _project_uns.ProjectId = _proj_md.proj_id
  association [0..1] to YI_MP_PROJ_EMPL     as _employee    on _employee.EmployeeNumber = _proj_md.employ_id
  association [0..1] to YI_MP_PROJ_MD_TOTAL as _md_total    on  _md_total.ProjectId   = _proj_md.proj_id
                                                            and _md_total.EmployeeId  = _proj_md.employ_id
                                                            and _md_total.ProjectYear = _proj_md.proj_year

{
  key _proj_md.proj_id                 as ProjectId,
  key _proj_md.employ_id               as EmployeeId,
  key _proj_md.proj_year               as ProjectYear,

      // Project
      case
        when _project_std.ShortText is not null then _project_std.ShortText
        else _project_uns.ShortText
      end                              as ShortText,
      _project_std.ProjectName         as ProjectName,
      _project_std.CompanyCode         as CompanyCode,

      // Employee
      _employee.EmployeeName           as EmployeeName,
      _employee.EmployeeGroup          as EmployeeGroup,
      _employee.EmployeeSubgroup       as EmployeeSubgroup,
      _employee.CostCenter             as CostCenter,
      _employee.OrganizationalUnit     as OrganizationalUnit,
      _employee.OrganizationalUnitText as OrganizationalUnitText,
      _employee.EmployeePositionText   as EmployeePositionText,
      _employee.ContractType           as ContractType,
      _employee.ContractTypeText       as ContractTypeText,
      _employee.ContractEndDate        as ContractEndDate,
       
       //Rate header
      _proj_md.currency                as Currency,
      @Semantics.amount.currencyCode : 'Currency'
      _proj_md.monthly_rate            as MonthlyRate,
      _proj_md.rate_year               as RateYear,

       //Manday load (sum over the period rows)
      _md_total.ManDayTotal            as ManDayTotal,

      @Semantics.user.createdBy: true
      _proj_md.created_by              as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      _proj_md.created_at              as CreatedAt,
      @Semantics.user.lastChangedBy: true
      _proj_md.last_changed_by         as LastChangedBy,
      @Semantics.systemDateTime.lastChangedAt: true
      _proj_md.last_changed_at         as LastChangedAt,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      _proj_md.local_last_changed_at   as LocalLastChangedAt,

      _period,
      _project_std,
      _project_uns,
      _employee,
      _md_total

}
