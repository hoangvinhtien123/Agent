@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Man Power: ManMonth Rates'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_RATE
  as select from    YI_MP_PROJ_RATE_LABOUR  as _labour
    left outer join YI_MP_PROJ_RATE_FOH     as _foh      on  _labour.ControllingArea = _foh.ControllingArea
                                                         and _labour.CostCenter      = _foh.CostCenter
                                                         and _labour.FiscalYear      = _foh.FiscalYear
                                                         and _labour.PriceIndicator  = _foh.PriceIndicator
                                                         and _labour.Version         = _foh.Version
    left outer join YR_MP_PROJ_WRKCL_CONFIG as _config   on  _config.CompanyCode = _labour.CompanyCode
                                                         and _config.FiscalYear  = _labour.FiscalYear
    left outer join YR_MP_PROJ_WRKCL_CONFIG as _config_1 on  _config_1.CompanyCode = _labour.CompanyCode
                                                         and _config_1.FiscalYear  = '0000'
{
  key _labour.ControllingArea                                                                       as ControllingArea,
  key _labour.CostCenter                                                                            as CostCenter,
  key _labour.ActivityType                                                                          as ActivityType,
  key _labour.FiscalYear                                                                            as FiscalYear,
  key _labour.ObjectNumber                                                                          as ObjectNumber,
  key _labour.Version                                                                               as Version,
  key _labour.PriceIndicator                                                                        as PriceIndicator,
      _labour.CompanyCode                                                                           as CompanyCode,
      _labour.Currency                                                                              as Currency,

      // ---- Manday per month and manday hours ----
      coalesce( _config.WorkHours, coalesce( _config_1.WorkHours, cast('8.8' as abap.dec(3,1) ) ) ) as ManDayHours,
      coalesce( _config.WorkDays, coalesce( _config_1.WorkDays, cast('21.0' as abap.dec(3,1) ) ) )  as ManMonthDays,
      cast( $projection.ManDayHours * $projection.ManMonthDays as abap.dec(5,1) )                   as ManMonthHours,

      // ---- Period 001 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate001                                                                         as LabourHourRate001,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate001 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate001,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate001 as abap.dec(23,2) ) +  cast( $projection.FOHHourRate001 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate001,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate001 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate001,

      // ---- Period 002 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate002                                                                         as LabourHourRate002,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate002 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate002,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate002 as abap.dec(23,2) ) + cast( $projection.FOHHourRate002 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate002,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate002 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate002,

      // ---- Period 003 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate003                                                                         as LabourHourRate003,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate003 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate003,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate003 as abap.dec(23,2) ) + cast( $projection.FOHHourRate003 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate003,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate003 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate003,

      // ---- Period 004 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate004                                                                         as LabourHourRate004,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate004 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate004,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate004 as abap.dec(23,2) ) + cast( $projection.FOHHourRate004 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate004,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate004 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate004,

      // ---- Period 005 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate005                                                                         as LabourHourRate005,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate005 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate005,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate005 as abap.dec(23,2) ) + cast( $projection.FOHHourRate005 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate005,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate005 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate005,

      // ---- Period 006 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate006                                                                         as LabourHourRate006,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate006 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate006,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate006 as abap.dec(23,2) ) + cast( $projection.FOHHourRate006 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate006,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate006 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate006,

      // ---- Period 007 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate007                                                                         as LabourHourRate007,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate007 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate007,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate007 as abap.dec(23,2) ) + cast( $projection.FOHHourRate007 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate007,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate007 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate007,

      // ---- Period 008 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate008                                                                         as LabourHourRate008,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate008 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate008,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate008 as abap.dec(23,2) ) + cast( $projection.FOHHourRate008 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate008,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate008 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate008,

      // ---- Period 009 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate009                                                                         as LabourHourRate009,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate009 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate009,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate009 as abap.dec(23,2) ) + cast( $projection.FOHHourRate009 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate009,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate009 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate009,

      // ---- Period 010 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate010                                                                         as LabourHourRate010,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate010 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate010,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate010 as abap.dec(23,2) ) + cast( $projection.FOHHourRate010 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate010,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate010 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate010,

      // ---- Period 011 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate011                                                                         as LabourHourRate011,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate011 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate011,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate011 as abap.dec(23,2) ) + cast( $projection.FOHHourRate011 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate011,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate011 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate011,

      // ---- Period 012 ----
      @Semantics.amount.currencyCode: 'Currency'
      _labour.LabourRate012                                                                         as LabourHourRate012,
      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _foh.FOHRate012 as abap.dec(23,2) ), 0 ) as abap.curr(23,2) )           as FOHHourRate012,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( _labour.LabourRate012 as abap.dec(23,2) ) + cast( $projection.FOHHourRate012 as abap.dec(23,2) ) )
            * $projection.ManDayHours   as abap.curr(23,2) )                                        as ManDayRate012,
      @Semantics.amount.currencyCode: 'Currency'
      cast( ( cast( $projection.ManDayRate012 as abap.dec(23,2) ) )
            * $projection.ManMonthDays as abap.curr(23,2) )                                         as ManMonthRate012
}
