@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Total per Project/Employee/Year'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_MD_TOTAL
  as select from ymp_proj_md_per as _proj_per
{
  key _proj_per.proj_id                              as ProjectId,
  key _proj_per.employ_id                            as EmployeeId,
  key _proj_per.proj_year                            as ProjectYear,

      cast( sum( _proj_per.man_day ) as abap.dec(9,2) ) as ManDayTotal
}
group by
  _proj_per.proj_id,
  _proj_per.employ_id,
  _proj_per.proj_year
