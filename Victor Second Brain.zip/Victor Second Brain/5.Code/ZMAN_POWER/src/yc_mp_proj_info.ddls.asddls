@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Project Information Projection'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_MP_PROJ_INFO as projection on YR_MP_PROJ_INFO
{
  key ProjectId,
  key ProjectDefinition,
      ShortText,
      IsUnsecured,
      ProjectName,
      CompanyCode,
      BusinessArea,
      ControllingArea,
      ProfitCenter,
      ProjectCurrency,
      StartDate,
      FinishDate,
      ResponsibleNo,
      ResponsibleName,
      ObjectNumber,
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      LocalLastChangedAt
}
