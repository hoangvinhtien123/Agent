@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Employee Availability'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_EMPL_AVAIL
  with parameters
    p_year : gjahr
  as select from    YI_MP_PROJ_EMPL         as _employee
    left outer join YI_MP_PROJ_MD_AGGR      as _load   on  _load.EmployeeId  = _employee.EmployeeNumber
                                                       and _load.ProjectYear = $parameters.p_year
    left outer join YR_MP_PROJ_WRKCL_CONFIG as _config on  _config.FiscalYear  = $parameters.p_year
                                                       and _config.CompanyCode = _employee.CompanyCode
{
  key _employee.EmployeeNumber                                                             as EmployeeNumber,
      $parameters.p_year                                                                   as ProjectYear,
      _employee.EmployeeName                                                               as EmployeeName,
      _employee.EmployeeGroup                                                              as EmployeeGroup,
      _employee.EmployeeSubgroup                                                           as EmployeeSubgroup,
      _employee.CostCenter                                                                 as CostCenter,
      _employee.OrganizationalUnit                                                         as OrganizationalUnit,
      _employee.OrganizationalUnitText                                                     as OrganizationalUnitText,
      _employee.EmployeePositionText                                                       as EmployeePositionText,
      _employee.ContractType                                                               as ContractType,
      _employee.ContractTypeText                                                           as ContractTypeText,
      _employee.ContractEndDate                                                            as ContractEndDate,

      coalesce(_config.WorkDays, cast( '21.0' as abap.dec(3,1) ) )                         as ManMonthDays,

      // Assigned mandays per period (0 when employee has no project)
      coalesce(_load.AssignedMd01, cast('0.00' as abap.dec(9,2)))                          as AssignedMd01,
      coalesce(_load.AssignedMd02, cast('0.00' as abap.dec(9,2)))                          as AssignedMd02,
      coalesce(_load.AssignedMd03, cast('0.00' as abap.dec(9,2)))                          as AssignedMd03,
      coalesce(_load.AssignedMd04, cast('0.00' as abap.dec(9,2)))                          as AssignedMd04,
      coalesce(_load.AssignedMd05, cast('0.00' as abap.dec(9,2)))                          as AssignedMd05,
      coalesce(_load.AssignedMd06, cast('0.00' as abap.dec(9,2)))                          as AssignedMd06,
      coalesce(_load.AssignedMd07, cast('0.00' as abap.dec(9,2)))                          as AssignedMd07,
      coalesce(_load.AssignedMd08, cast('0.00' as abap.dec(9,2)))                          as AssignedMd08,
      coalesce(_load.AssignedMd09, cast('0.00' as abap.dec(9,2)))                          as AssignedMd09,
      coalesce(_load.AssignedMd10, cast('0.00' as abap.dec(9,2)))                          as AssignedMd10,
      coalesce(_load.AssignedMd11, cast('0.00' as abap.dec(9,2)))                          as AssignedMd11,
      coalesce(_load.AssignedMd12, cast('0.00' as abap.dec(9,2)))                          as AssignedMd12,
      coalesce(_load.AssignedMdTotal, cast('0.00' as abap.dec(9,2)))                       as AssignedMdTotal,

      // Utilisation % per period = assigned / ManMonthDays * 100
      division( $projection.AssignedMd01 * 100, $projection.ManMonthDays, 2 ) as UtilPct01,
      division( $projection.AssignedMd02 * 100, $projection.ManMonthDays, 2 ) as UtilPct02,
      division( $projection.AssignedMd03 * 100, $projection.ManMonthDays, 2 ) as UtilPct03,
      division( $projection.AssignedMd04 * 100, $projection.ManMonthDays, 2 ) as UtilPct04,
      division( $projection.AssignedMd05 * 100, $projection.ManMonthDays, 2 ) as UtilPct05,
      division( $projection.AssignedMd06 * 100, $projection.ManMonthDays, 2 ) as UtilPct06,
      division( $projection.AssignedMd07 * 100, $projection.ManMonthDays, 2 ) as UtilPct07,
      division( $projection.AssignedMd08 * 100, $projection.ManMonthDays, 2 ) as UtilPct08,
      division( $projection.AssignedMd09 * 100, $projection.ManMonthDays, 2 ) as UtilPct09,
      division( $projection.AssignedMd10 * 100, $projection.ManMonthDays, 2 ) as UtilPct10,
      division( $projection.AssignedMd11 * 100, $projection.ManMonthDays, 2 ) as UtilPct11,
      division( $projection.AssignedMd12 * 100, $projection.ManMonthDays, 2 ) as UtilPct12

      //      //Yearly utilisation % = total assigned / (20 * 12) * 100
      //      division( coalesce(_load.AssignedMdTotal, cast('0.00' as abap.dec(9,2))) * 100, $projection.ManMonthDays * 20, 2 ) as UtilPctYear
}
