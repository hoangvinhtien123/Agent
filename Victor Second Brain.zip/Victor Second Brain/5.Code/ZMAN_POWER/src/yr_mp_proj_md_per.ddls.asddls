@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Manday Loading per Period'
@Metadata.ignorePropagatedAnnotations: true
define view entity YR_MP_PROJ_MD_PER
  as select from ymp_proj_md_per as _proj_per
  association        to parent YR_MP_PROJ_MD_LOAD as _header on  _header.ProjectId   = _proj_per.proj_id
                                                             and _header.EmployeeId  = _proj_per.employ_id
                                                             and _header.ProjectYear = _proj_per.proj_year

{
  key _proj_per.proj_id              as ProjectId,
  key _proj_per.employ_id            as EmployeeId,
  key _proj_per.proj_year            as ProjectYear,
  key _proj_per.period               as Period,

      _proj_per.man_day              as ManDay,

      @Semantics.user.createdBy: true
      _proj_per.created_by           as CreatedBy,
      @Semantics.systemDateTime.createdAt: true
      _proj_per.created_at           as CreatedAt,
      @Semantics.user.lastChangedBy: true
      _proj_per.last_changed_by      as LastChangedBy,
      @Semantics.systemDateTime.localInstanceLastChangedAt: true
      _proj_per.local_last_changed_at as LocalLastChangedAt,

      _header

}
