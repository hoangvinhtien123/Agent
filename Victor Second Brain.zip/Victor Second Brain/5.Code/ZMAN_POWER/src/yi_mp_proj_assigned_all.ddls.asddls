@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Assigned Cost all years'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_ASSIGNED_ALL
  as select from rpsco
{
  key objnr as ObjectNumber,
      cast( sum( wlp01 ) + sum( wlp02 ) + sum( wlp03 ) + sum( wlp04 )
          + sum( wlp05 ) + sum( wlp06 ) + sum( wlp07 ) + sum( wlp08 )
          + sum( wlp09 ) + sum( wlp10 ) + sum( wlp11 ) + sum( wlp12 )
          as abap.dec(23,2) ) as AssignedCost
}
where
      versn = '000'
//  and ( wrttp = '04'  or wrttp = '21' or wrttp = '22'  )
  and ( wrttp = '04'  )
group by
  objnr
