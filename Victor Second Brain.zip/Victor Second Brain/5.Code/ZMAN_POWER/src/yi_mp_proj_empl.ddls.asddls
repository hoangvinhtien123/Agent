@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: List Employee'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_EMPL
  as select from    pa0001 as _employee
    left outer join pa0016 as _contract     on  _contract.pernr = _employee.pernr
                                            and _contract.begda <= $session.system_date
                                            and _contract.endda >= $session.system_date
                                            and _contract.sprps = ''
    left outer join t547s  as _contractText on  _contractText.sprsl = $session.system_language
                                            and _contractText.cttyp = _contract.cttyp
    left outer join t527x  as _orgUnitText  on  _orgUnitText.orgeh = _employee.orgeh
                                            and _orgUnitText.sprsl = $session.system_language
                                            and _orgUnitText.begda <= $session.system_date
                                            and _orgUnitText.endda >= $session.system_date
    left outer join t528t  as _positionText on  _positionText.sprsl = $session.system_language
                                            and _positionText.otype = 'S'
                                            and _positionText.plans = _employee.plans
                                            and _positionText.begda <= $session.system_date
                                            and _positionText.endda >= $session.system_date
{
  key _employee.pernr        as EmployeeNumber,
      _employee.bukrs        as CompanyCode,
      _employee.ename        as EmployeeName,
      _employee.werks        as PersonnelArea,
      _employee.btrtl        as PersonnelSubarea,
      _employee.persg        as EmployeeGroup,
      _employee.persk        as EmployeeSubgroup,
      _employee.kostl        as CostCenter,
      _employee.orgeh        as OrganizationalUnit,
      _orgUnitText.orgtx     as OrganizationalUnitText,
      _employee.plans        as EmployeePosition,
      _positionText.plstx    as EmployeePositionText,
      _employee.stell        as Job,
      _contract.cttyp        as ContractType,
      _contractText.cttxt    as ContractTypeText,
      _contract.ctedt        as ContractEndDate,
      _employee.begda        as ValidityStartDate,
      _employee.endda        as ValidityEndDate
}
where
      _employee.begda <= $session.system_date
  and _employee.endda >= $session.system_date
  and _employee.sprps =  ''
