CLASS lsc_yr_mp_proj_info DEFINITION INHERITING FROM cl_abap_behavior_saver.

ENDCLASS.

CLASS lsc_yr_mp_proj_info IMPLEMENTATION.


ENDCLASS.

CLASS lhc_project_info DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PROTECTED SECTION.

  PRIVATE SECTION.

    CONSTANTS:
      gc_auth_object  TYPE xuobject   VALUE 'YMP_PLAN',
      gc_actvt_create TYPE activ_auth VALUE '01',
      gc_actvt_change TYPE activ_auth VALUE '02',
      gc_actvt_delete TYPE activ_auth VALUE '06'.

    TYPES: BEGIN OF ty_proj,
             project_definition TYPE string,
             description        TYPE string,
             short_text         TYPE string,
             project_profile    TYPE string,
             company_code       TYPE string,
           END OF ty_proj,

           tty_proj TYPE TABLE OF ty_proj.

    TYPES:
      tty_result TYPE TABLE FOR ACTION RESULT yr_mp_proj_info\\project_info~createnewproject.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR project_info RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR project_info RESULT result.

    METHODS validateProject FOR VALIDATE ON SAVE
      IMPORTING keys FOR project_info~validateProject.

ENDCLASS.

CLASS lhc_project_info IMPLEMENTATION.

  METHOD get_instance_authorizations.

*    READ ENTITIES OF yr_mp_proj_info IN LOCAL MODE
*      ENTITY project_info
*        FIELDS ( CompanyCode )
*        WITH CORRESPONDING #( keys )
*      RESULT DATA(lt_projects)
*      FAILED failed.
*
*    LOOP AT lt_projects INTO DATA(ls_project).
*      APPEND VALUE #( %tky = ls_project-%tky ) TO result ASSIGNING FIELD-SYMBOL(<ls_result>).
*
*      IF requested_authorizations-%update = if_abap_behv=>mk-on.
*        AUTHORITY-CHECK OBJECT gc_auth_object
*          ID 'BUKRS' FIELD ls_project-CompanyCode
*          ID 'ACTVT' FIELD gc_actvt_change.
*        <ls_result>-%update = COND #( WHEN sy-subrc = 0
*                                      THEN if_abap_behv=>auth-allowed
*                                      ELSE if_abap_behv=>auth-unauthorized ).
*      ENDIF.
*
*      IF requested_authorizations-%delete = if_abap_behv=>mk-on.
*        AUTHORITY-CHECK OBJECT gc_auth_object
*          ID 'BUKRS' FIELD ls_project-CompanyCode
*          ID 'ACTVT' FIELD gc_actvt_delete.
*        <ls_result>-%delete = COND #( WHEN sy-subrc = 0
*                                      THEN if_abap_behv=>auth-allowed
*                                      ELSE if_abap_behv=>auth-unauthorized ).
*      ENDIF.
*    ENDLOOP.

  ENDMETHOD.

  METHOD get_global_authorizations.

*    IF requested_authorizations-%create = if_abap_behv=>mk-on.
*      AUTHORITY-CHECK OBJECT gc_auth_object
*        ID 'BUKRS' DUMMY
*        ID 'ACTVT' FIELD gc_actvt_create.
*      result-%create = COND #( WHEN sy-subrc = 0
*                               THEN if_abap_behv=>auth-allowed
*                               ELSE if_abap_behv=>auth-unauthorized ).
*    ENDIF.

  ENDMETHOD.

  METHOD validateProject.

    READ ENTITIES OF yr_mp_proj_info IN LOCAL MODE
      ENTITY project_info
        FIELDS ( ProjectId )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_projects).

    CHECK lt_projects IS NOT INITIAL.

    SELECT pspnr
      FROM proj
      FOR ALL ENTRIES IN @lt_projects
      WHERE pspnr = @lt_projects-ProjectId
      INTO TABLE @DATA(lt_ps_projects).

    LOOP AT lt_projects INTO DATA(ls_project).
      IF  ls_project-IsUnsecured = 'X'.
        CONTINUE.
      ENDIF.
      IF NOT line_exists( lt_ps_projects[ pspnr = ls_project-ProjectId ] ).
        APPEND VALUE #( %tky = ls_project-%tky ) TO failed-project_info.
        APPEND VALUE #( %tky = ls_project-%tky
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Project { ls_project-ProjectId } does not exist in SAP| )
                        %element-ProjectId = if_abap_behv=>mk-on )
               TO reported-project_info.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

ENDCLASS.
