@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power : Employee by company code'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_EMPL_COMP
  with parameters
    p_bukrs : bukrs
  as select from    pa0001 as _employee
    inner join      pa0016 as _contract     on  _employee.pernr = _contract.pernr
                                            and _employee.subty = _contract.subty
                                            and _employee.objps = _contract.objps
                                            and _employee.sprps = _contract.sprps
                                            and _employee.endda = _contract.endda
                                            and _employee.begda = _contract.begda
                                            and _employee.seqnr = _contract.seqnr
    left outer join t547s  as _contractText on  _contractText.sprsl = $session.system_language
                                            and _contractText.cttyp = _contract.cttyp
{
  key _employee.pernr     as EmployeeNumber,
  key _employee.subty     as SubType,
  key _employee.objps     as ObjectId,
  key _employee.sprps     as LockIndicator,
  key _employee.endda     as ValidityEndDate,
  key _employee.begda     as ValidityStartDate,
  key _employee.seqnr     as RecordNo,
      _employee.bukrs     as CompanyCode,
      _employee.ename     as EmployeeName,
      _employee.werks     as PersonnelArea,
      _employee.persg     as EmployeeGroup,
      _employee.persk     as EmployeeSubgroup,
      _employee.kostl     as CostCenter,
      _employee.orgeh     as OrganizationalUnit,
      _employee.plans     as EmployeePosition,
      _contract.cttyp     as ContractType,
      _contractText.cttxt as ContractTypeText
}
where
      _employee.bukrs = $parameters.p_bukrs
  and _employee.begda <= $session.system_date
  and _employee.endda >= $session.system_date
