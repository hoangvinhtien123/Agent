@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Man Power: Budget'
@Metadata.ignorePropagatedAnnotations: true
// OData V2: /Project_Budget(p_gjahr='2026',ProjectId='00000123',WbsId='00000234')/Set
define view entity YI_MP_PROJ_BUDG
  with parameters
    p_gjahr : gjahr
  as select from    prps                     as _Wbs
    inner join      proj                     as _Proj         on _Proj.pspnr = _Wbs.psphi
    left outer join YI_MP_PROJ_BUDG_OVERALL  as _Overall      on _Overall.ObjectNumber = _Wbs.objnr
    left outer join YI_MP_PROJ_BUDG_ANNUAL   as _Annual       on  _Annual.ObjectNumber = _Wbs.objnr
                                                              and _Annual.FiscalYear   = $parameters.p_gjahr
    left outer join YI_MP_PROJ_ASSIGNED_ALL  as _AssignedAll  on _AssignedAll.ObjectNumber = _Wbs.objnr
    left outer join YI_MP_PROJ_ASSIGNED_YEAR as _AssignedYear on  _AssignedYear.ObjectNumber = _Wbs.objnr
                                                              and _AssignedYear.FiscalYear   = $parameters.p_gjahr
{
  key cast( _Proj.pspnr as abap.numc(8) )                    as ProjectId,
  key cast( _Wbs.pspnr as abap.numc(8) )                     as WbsId,
      $parameters.p_gjahr                                    as FiscalYear,
      cast( _Proj.pspid as abap.char(24) )                   as ProjectDefinition,
      cast( _Wbs.posid as abap.char(24) )                    as WbsElement,
      _Wbs.objnr                                             as ObjectNumber,
      _Wbs.post1                                             as Description,
      _Wbs.stufe                                             as WbsLevel,
      _Wbs.pbukr                                             as CompanyCode,
      _Wbs.prctr                                             as ProfitCenter,
      _Wbs.vernr                                             as ResponsibleNo,
      coalesce( _Overall.Currency, _Proj.pwhie )             as Currency,

      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _Overall.OverallBudget as abap.dec(23,2) ), 0 )
            as abap.curr(23,2) )                             as OverallBudget,

      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _Annual.AnnualBudget as abap.dec(23,2) ), 0 )
            as abap.curr(23,2) )                             as AnnualBudget,

      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( _AssignedAll.AssignedCost, 0 )
            as abap.curr(23,2) )                             as AssignedOverall,

      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( _AssignedYear.AssignedCost, 0 )
            as abap.curr(23,2) )                             as AssignedAnnual,

      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _Overall.OverallBudget as abap.dec(23,2) ), 0 )
          - coalesce( _AssignedAll.AssignedCost, 0 )
            as abap.curr(23,2) )                             as AvailableOverall,

      @Semantics.amount.currencyCode: 'Currency'
      cast( coalesce( cast( _Annual.AnnualBudget as abap.dec(23,2) ), 0 )
          - coalesce( _AssignedYear.AssignedCost, 0 )
            as abap.curr(23,2) )                             as AvailableAnnual
}
where
      _Wbs.yusr31 <> ''
  and _Wbs.loevm  <> 'X'

//@AbapCatalog.viewEnhancementCategory: [#NONE]
//@AccessControl.authorizationCheck: #NOT_REQUIRED
//@EndUserText.label: 'Man Power: Budget'
//@Metadata.ignorePropagatedAnnotations: true
//define view entity YI_MP_PROJ_BUDG
//  as select from prps as _Wbs
//    inner join   proj as _Proj on _Proj.pspnr = _Wbs.psphi
//  association [0..1] to bpja as _Budget on  _Budget.objnr = _Wbs.objnr
//                                        and _Budget.wrttp = '45'
//{
//  key cast( _Proj.pspnr as abap.numc(8) )  as ProjectId,
//  key cast( _Wbs.pspnr as abap.numc(8) )   as WbsId,
//  key _Budget.gjahr                        as FiscalYear,
//      cast( _Proj.pspid as abap.char(24) ) as ProjectDefinition,
//      cast( _Wbs.posid as abap.char(24) )  as WbsElement,
//      _Wbs.objnr                           as ObjectNumber,
//      _Wbs.post1                           as Description,
//      _Wbs.pbukr                           as CompanyCode,
//      _Wbs.prctr                           as ProfitCenter,
//      _Wbs.vernr                           as ResponsibleNo,
//
//      @ObjectModel.virtualElement: true
//      @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_MP_PROJ_BUDGET_VE'
//      cast( '' as waers_curc )             as Currency,
//
//      @ObjectModel.virtualElement: true
//      @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_MP_PROJ_BUDGET_VE'
//      @Semantics.amount.currencyCode: 'Currency'
//      cast( 0 as abap.curr( 23, 2 ) )      as OverAllBudget,
//
//      @ObjectModel.virtualElement: true
//      @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_MP_PROJ_BUDGET_VE'
//      @Semantics.amount.currencyCode: 'Currency'
//      cast( 0 as abap.curr( 23, 2 )  )     as OverAssignBudget,
//
//      @ObjectModel.virtualElement: true
//      @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_MP_PROJ_BUDGET_VE'
//      @Semantics.amount.currencyCode: 'Currency'
//      cast( 0 as abap.curr( 23, 2 )  )     as OverAvailableBudget,
//
//      @ObjectModel.virtualElement: true
//      @ObjectModel.virtualElementCalculatedBy: 'ABAP:YCL_MP_PROJ_BUDGET_VE'
//      @Semantics.amount.currencyCode: 'Currency'
//      cast( 0 as abap.curr( 23, 2 ) )      as AnnulCurBudget
//
//}
//where
//      _Wbs.yusr31 <> ''
//  and _Wbs.loevm  <> 'X'


