@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Project Information (Unsecured)'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_INFO_UNS as select from YR_MP_PROJ_INFO
{
    key ProjectId,
    key ProjectDefinition,
    ShortText,
    IsUnsecured
}
where IsUnsecured = 'X'
