CLASS lhc_YR_MP_PROJ_MD_LOAD DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    CONSTANTS:
      gc_auth_object  TYPE xuobject   VALUE 'YMP_PLAN',
      gc_actvt_create TYPE activ_auth VALUE '01',
      gc_actvt_change TYPE activ_auth VALUE '02',
      gc_actvt_delete TYPE activ_auth VALUE '06'.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR yr_mp_proj_md_load RESULT result.

    METHODS get_global_authorizations FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR yr_mp_proj_md_load RESULT result.
    METHODS setdefaults FOR DETERMINE ON MODIFY
      IMPORTING keys FOR project_md_load~setdefaults.

    METHODS validateemployee FOR VALIDATE ON SAVE
      IMPORTING keys FOR project_md_load~validateemployee.

    METHODS validateproject FOR VALIDATE ON SAVE
      IMPORTING keys FOR project_md_load~validateproject.

ENDCLASS.

CLASS lhc_YR_MP_PROJ_MD_LOAD IMPLEMENTATION.

  METHOD get_instance_authorizations.

*    READ ENTITIES OF yr_mp_proj_md_load IN LOCAL MODE
*      ENTITY project_md_load
*        FIELDS ( CompanyCode )
*        WITH CORRESPONDING #( keys )
*      RESULT DATA(lt_lines)
*      FAILED failed.
*
*    LOOP AT lt_lines INTO DATA(ls_line).
*      APPEND VALUE #( %tky = ls_line-%tky ) TO result ASSIGNING FIELD-SYMBOL(<ls_result>).
*
*      IF requested_authorizations-%update = if_abap_behv=>mk-on.
*        AUTHORITY-CHECK OBJECT gc_auth_object
*          ID 'BUKRS' FIELD ls_line-CompanyCode
*          ID 'ACTVT' FIELD gc_actvt_change.
*        <ls_result>-%update = COND #( WHEN sy-subrc = 0
*                                      THEN if_abap_behv=>auth-allowed
*                                      ELSE if_abap_behv=>auth-unauthorized ).
*      ENDIF.
*
*      IF requested_authorizations-%delete = if_abap_behv=>mk-on.
*        AUTHORITY-CHECK OBJECT gc_auth_object
*          ID 'BUKRS' FIELD ls_line-CompanyCode
*          ID 'ACTVT' FIELD gc_actvt_delete.
*        <ls_result>-%delete = COND #( WHEN sy-subrc = 0
*                                      THEN if_abap_behv=>auth-allowed
*                                      ELSE if_abap_behv=>auth-unauthorized ).
*      ENDIF.
*    ENDLOOP.

  ENDMETHOD.

  METHOD get_global_authorizations.

*    IF requested_authorizations-%create = if_abap_behv=>mk-on.
*      AUTHORITY-CHECK OBJECT gc_auth_object
*        ID 'BUKRS' DUMMY
*        ID 'ACTVT' FIELD gc_actvt_create.
*      result-%create = COND #( WHEN sy-subrc = 0
*                               THEN if_abap_behv=>auth-allowed
*                               ELSE if_abap_behv=>auth-unauthorized ).
*    ENDIF.

  ENDMETHOD.

" Currency default by company code from project, RateYeardefault = ProjectYear.
  METHOD setDefaults.

    DATA lt_update TYPE TABLE FOR UPDATE yr_mp_proj_md_load.
    DATA ls_update LIKE LINE OF lt_update.

    READ ENTITIES OF yr_mp_proj_md_load IN LOCAL MODE
      ENTITY project_md_load
        FIELDS ( ProjectYear CompanyCode Currency RateYear )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_lines).

    CHECK lt_lines IS NOT INITIAL.

    SELECT bukrs, waers
      FROM t001
      FOR ALL ENTRIES IN @lt_lines
      WHERE bukrs = @lt_lines-CompanyCode
      INTO TABLE @DATA(lt_company_codes).


    LOOP AT lt_lines INTO DATA(ls_line).
      CLEAR ls_update.
      ls_update-%tky = ls_line-%tky.

      IF ls_line-Currency IS INITIAL.
        READ TABLE lt_company_codes INTO DATA(ls_company_code)
          WITH KEY bukrs = ls_line-CompanyCode.
        IF sy-subrc = 0.
          ls_update-Currency          = ls_company_code-waers.
          ls_update-%control-Currency = if_abap_behv=>mk-on.
        ENDIF.
      ENDIF.

      IF ls_line-RateYear IS INITIAL.
        ls_update-RateYear          = ls_line-ProjectYear.
        ls_update-%control-RateYear = if_abap_behv=>mk-on.
      ENDIF.

      IF ls_update-%control-Currency = if_abap_behv=>mk-on
      OR ls_update-%control-RateYear = if_abap_behv=>mk-on.
        APPEND ls_update TO lt_update.
      ENDIF.
    ENDLOOP.

    IF lt_update IS NOT INITIAL.
      MODIFY ENTITIES OF yr_mp_proj_md_load IN LOCAL MODE
        ENTITY project_md_load
          UPDATE FROM lt_update
        REPORTED DATA(lt_reported).
      reported = CORRESPONDING #( DEEP lt_reported ).
    ENDIF.

  ENDMETHOD.

  "Employee must exist and active (YI_MP_PROJ_EMPL)
  METHOD validateEmployee.
    READ ENTITIES OF yr_mp_proj_md_load IN LOCAL MODE
      ENTITY project_md_load
        FIELDS ( EmployeeId )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_lines).

    CHECK lt_lines IS NOT INITIAL.

    SELECT EmployeeNumber
      FROM yi_mp_proj_empl WITH PRIVILEGED ACCESS
      FOR ALL ENTRIES IN @lt_lines
      WHERE EmployeeNumber = @lt_lines-EmployeeId
      INTO TABLE @DATA(lt_employees).

    LOOP AT lt_lines INTO DATA(ls_line).
      IF NOT line_exists( lt_employees[ EmployeeNumber = ls_line-EmployeeId ] ).
        APPEND VALUE #( %tky = ls_line-%tky ) TO failed-project_md_load.
        APPEND VALUE #( %tky = ls_line-%tky
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Employee { ls_line-EmployeeId } does not exist or is not active| )
                        %element-EmployeeId = if_abap_behv=>mk-on )
               TO reported-project_md_load.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

  METHOD validateProject.
  ENDMETHOD.

ENDCLASS.

CLASS lhc_YR_MP_PROJ_MD_PER DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.

    CONSTANTS:
      gc_max_man_days TYPE i     VALUE 31,
      gc_min_period   TYPE poper VALUE '001',
      gc_max_period   TYPE poper VALUE '012'.

    METHODS validatemandays FOR VALIDATE ON SAVE
      IMPORTING keys FOR project_md_period~validatemandays.

ENDCLASS.

CLASS lhc_YR_MP_PROJ_MD_PER IMPLEMENTATION.

    " Period must be 001-012 and its manday must be 0-31
  METHOD validateManDays.

    READ ENTITIES OF yr_mp_proj_md_load IN LOCAL MODE
      ENTITY project_md_period
        FIELDS ( Period ManDay )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_lines).

    LOOP AT lt_lines INTO DATA(ls_line).

      IF ls_line-Period < gc_min_period OR ls_line-Period > gc_max_period.
        APPEND VALUE #( %tky = ls_line-%tky ) TO failed-project_md_period.
        APPEND VALUE #( %tky = ls_line-%tky
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Period { ls_line-Period } must be between { gc_min_period } and { gc_max_period }| )
                        %element-Period = if_abap_behv=>mk-on )
               TO reported-project_md_period.
        CONTINUE.
      ENDIF.

      IF ls_line-ManDay < 0 OR ls_line-ManDay > gc_max_man_days.
        APPEND VALUE #( %tky = ls_line-%tky ) TO failed-project_md_period.
        APPEND VALUE #( %tky = ls_line-%tky
                        %msg = new_message_with_text(
                                 severity = if_abap_behv_message=>severity-error
                                 text     = |Man days for period { ls_line-Period } must be between 0 and { gc_max_man_days }| )
                        %element-ManDay = if_abap_behv=>mk-on )
               TO reported-project_md_period.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.
