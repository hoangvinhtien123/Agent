@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Overall Budget'
@Metadata.ignorePropagatedAnnotations: true
define view entity YI_MP_PROJ_BUDG_OVERALL
  as select from bpge
{
  key objnr        as ObjectNumber,
  key twaer        as Currency,
      @Semantics.amount.currencyCode: 'Currency'
      sum( wtges ) as OverallBudget
}
where
      wrttp = '45'
  and versn = '000'
group by
  objnr,
  twaer
