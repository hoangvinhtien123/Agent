@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Man Power: Working Day / Working Hour Config'
@Metadata.ignorePropagatedAnnotations: true
define root view entity YC_MP_PROJ_WRKCL_CONFIG
  as projection on YR_MP_PROJ_WRKCL_CONFIG
{
  key CompanyCode,
  key FiscalYear,
//  key Period,
      WorkDays,
      WorkHours,
      CreatedBy,
      CreatedAt,
      LastChangedBy,
      LastChangedAt,
      LocalLastChangedAt
}
