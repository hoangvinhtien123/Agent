# Naming — Correction Notes

> [!note] Correction 2026-08-21 — "May", "Monday", "June" without a date = colleague name
- Context: Any request that mentions a word that could be a date/day/month (e.g. "May", "June", "Monday") without an explicit date or date context — e.g. "Check the RAP for May".
- Was doing (wrong): Interpreting it as a calendar month/day and asking whether it meant a release period or a person.
- Do instead (correct): Treat it as a **colleague's name** by default. Only read it as a date when Victor gives an explicit date or clear date context (e.g. "May 2026", "week of 17/08/2026", "last Monday"). Apply this to all similar name-like words without asking again.
