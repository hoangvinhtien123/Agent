# SAP CAP — Knowledge

Reference notes on the SAP Cloud Application Programming Model (CAP), Node.js flavour.

> [!note] Added 2026-10-13 — Request: "add details about JWT-based authentication in SAP CAP services". Sources: capire "Node.js > Authentication" (https://cap.cloud.sap/docs/node.js/authentication); SAP Community "Understanding security approaches in SAP CAP using XSUAA in node.js flavor and MTA" (2020-03-16); SAP Community "SAP CAP JWT Token Flow in code" (2023-04-03); SAP Community "Securing an SAP CAP (Node.js) Application on BTP Cloud Foundry with XSUAA and Approuter".
> **JWT-based authentication (`kind: jwt`) — the default production strategy**
>
> - **How it works:** user identity, roles and user attributes come from a bound **UAA (XSUAA)** instance as a **JWT in the `Authorization` header** of each incoming HTTP request. The auth middleware validates the token and fills `cds.context.user` (also `req.user`), which is then used for all authorization checks.
> - **Defaults:** `mocked` during development, `jwt` in production. Override with `cds.requires.auth`. Check the effective config with `cds env get requires.auth`.
> - **Prerequisite:** `npm add @sap/xssec`. Keep it up to date (`npm update @sap/xssec`) because it is security-critical.
> - **Configuration** (`package.json`):
>
> ```json
> "cds": { "requires": { "auth": "jwt" } }
> ```
>
> **Token flow on BTP Cloud Foundry**
>
> 1. The browser calls the **App Router**, which redirects to XSUAA for login.
> 2. XSUAA returns an authorization code. The App Router exchanges it server-to-server for an OAuth access token (JWT).
> 3. The App Router forwards the request to the CAP service with the JWT. The destination to `srv` must have `"forwardAuthToken": true` (in `mta.yaml`, or in `default-env.json` when running locally).
> 4. CAP validates the JWT via `@sap/xssec`. The service never handles the login itself.
>
> - Without the App Router (or without `forwardAuthToken`), `req.headers.authorization` is `undefined` and the request is anonymous. With it, the header holds the bearer JWT.
>
> **What CAP gives you from the token (`cds.User`)**
>
> - `req.user.id` — unique user ID. Maps to `$user` in `@restrict`.
> - `req.user.is('<role>')` — role check. Role names match `@requires` / `@restrict.grants.to`. XSUAA scopes `$XSAPPNAME.Admin` map to role `Admin` (the prefix is stripped).
> - `req.user.attr.<x>` — user attributes. Maps to `$user.<x>` in `@restrict`.
> - `req.user.authInfo` — for `jwt`, `xsuaa` and `ias` this is the `@sap/xssec` `SecurityContext`. CAP does not guarantee its content, so use it with caution and pin dependency versions.
> - If authentication fails (for example, no `Authorization` header), CAP falls back to `cds.User.default` (= `cds.User.Anonymous`).
> - `cds.User.Privileged` / `cds.User.privileged` bypasses authorization checks for internal transactions (`this.tx({ user }, ...)`).
>
> **Declarative vs programmatic enforcement**
>
> ```cds
> service CustomerService @(requires: 'authenticated-user') {
>   entity Orders   @(restrict: [{ grant: ['READ','WRITE'], to: 'admin' }]) { /*...*/ }
>   entity Approval @(restrict: [{ grant: 'WRITE', where: '$user.level > 2' }]) { /*...*/ }
> }
> ```
>
> ```javascript
> this.before('*', req => req.user.is('authenticated') || req.reject(403))
> this.before(['READ','CREATE'], 'Orders', req => req.user.is('admin') || req.reject(403))
> this.before('*', 'Approval', req => req.user.attr.level > 2 || req.reject(403))
> ```
>
> **Related strategies that also use JWT (all need `@sap/xssec`)**
>
> | Kind | Token issuer | Difference vs `jwt` |
> |------|--------------|---------------------|
> | `jwt` | XSUAA (UAA) | Default for production. Adds `user.authInfo` |
> | `xsuaa` | XSUAA | Logical extension of `jwt`. Also exposes SAML attributes in `user.attr` (for example, `user.attr.familyName`) |
> | `ias` | SAP Cloud Identity Services (IAS) | IAS tokens contain **no scopes/authorization info**, so you have to close that gap yourself (for example, with AMS policies). Adds x5t thumbprint and proof-of-possession validation (on by default for the `.cert` route). Accepts XSUAA tokens as a fallback when `"xsuaa": true` is added to `cds.requires` (helps when migrating) |
>
> - IAS validation override: `"auth": { "kind": "ias", "config": { "validation": { "x5t": { "enabled": false }, "proofToken": { "enabled": false } } } }` (`config` is passed to `@sap/xssec` as-is).
>
> **Production behaviour**
>
> - **Enforced by default:** with `jwt` configured, every service without `@requires` / `@restrict` implicitly gets `@requires: 'authenticated-user'`. Disable with `cds.requires.auth.restrict_all_services: false` (or use `mocked` explicitly — not suitable for production).
> - **Cached by default (`@sap/xssec` ^4.8):** a signature cache (cryptographic JWT validation) and a token decode cache (base64 decoding) are both on.
>   - Configure or disable the signature cache via `cds.requires.auth.config`.
>   - Control the decode cache only at bootstrap (for example, in `server.js`) with `require('@sap/xssec').Token.enableDecodeCache(config?)`, or turn it off with `require('@sap/xssec').Token.decodeCache = false`.
>
> **Hybrid testing with a real XSUAA JWT (local CAP + BTP XSUAA)**
>
> 1. `cds add xsuaa --for hybrid` creates `xs-security.json` and adds the dependency. Set `xsappname` and `"tenant-mode": "dedicated"`.
> 2. Add `"oauth2-configuration": { "redirect-uris": ["http://localhost:5000/login/callback"] }` (in BAS, use the exact URL from the login error message; do not commit it).
> 3. `cf create-service xsuaa application <app>-uaa -c xs-security.json` (after changing scopes: `cf update-service <app>-uaa -c xs-security.json`).
> 4. `cf create-service-key <app>-uaa <app>-uaa-key`, then `cds bind -2 <app>-uaa`. This writes the `[hybrid]` auth binding (kind `xsuaa`) into `.cdsrc-private.json`. In BAS run configs, set env `cds_requires_auth_kind=xsuaa`.
> 5. Verify: `cds env list requires.auth --resolve-bindings --profile hybrid`.
> 6. In the BTP Cockpit, go to Security > Role Collections. Create a collection, add the app roles, and assign users.
> 7. `cds add approuter`, then `npm install --prefix app/router`, then `cds bind --exec -- npm start --prefix app/router` (App Router on `http://localhost:5000`).
> 8. `cds watch --profile hybrid`, then log in at `http://localhost:5000`.
>
> - To test UIs without a running UAA, set `"authenticationMethod": "none"` in `app/router/xs-app.json`.

> [!note] Added 2026-10-13 — Request: "summarize best practices and include a sample configuration snippet" for JWT-based authentication in CAP. Sources: capire "Guides > Security > Authentication" incl. "Pitfalls" (https://cap.cloud.sap/docs/guides/security/authentication); capire "Node.js > Authentication" (https://cap.cloud.sap/docs/node.js/authentication); npm `@sap/xssec` README (https://www.npmjs.com/package/@sap/xssec); SAP Community "Securing SAP CAP Applications: XSUAA, Roles, and Authorization Best Practices" (2025-07-14).
> **JWT authentication — best practices**
>
> - **Use profiles:** mocked users in `[development]` only, `jwt`/`xsuaa` in `[production]`. Never ship mocked auth to BTP.
> - **Always secure the backend itself.** CAP endpoints on BTP are reachable from the public network. The App Router does **not** shield the backend, so CAP must validate the JWT itself.
> - **Keep the security defaults.** Do not set `restrict_all_services: false` or replace the standard auth middleware unless absolutely necessary.
> - **Annotate every service:** `@requires: 'authenticated-user'` as the minimum, `@restrict` for role/instance rules. Put plain role checks in CDS annotations and only dynamic logic in handlers (`req.user.is()` + `req.reject(403)`).
> - **Keep `xs-security.json` in sync with CDS:** scope `$XSAPPNAME.<Role>` ↔ role name in `@requires`/`@restrict`. A correct annotation still rejects everyone (403) until the role collection is created **and** assigned in the BTP Cockpit.
> - **One XSUAA binding per CAP app** (several apps may share one instance). Plan `application` for UI apps without API access; `broker` for all others.
> - **Forward the token:** App Router destination to `srv` needs `forwardAuthToken: true`; otherwise every request reaches CAP anonymous.
> - **`@sap/xssec`:** declare with a caret (`"^4"`), run `npm update @sap/xssec` regularly (needs Node.js 18+), and do not rely on `req.user.authInfo` internals.
> - **Leave the token caches on** (`@sap/xssec` ^4.8 signature + decode cache) unless there is a specific reason.
> - **For new projects, prefer IAS** (+ AMS for authorization); XSUAA remains for existing apps. Hybrid IAS + XSUAA supports migration.
> - **Never share or commit service keys or tokens.** Keep local bindings in `.cdsrc-private.json` / `default-env.json` (git-ignored), and delete test service keys afterwards (`cf delete-service-key`).
> - **Test authentication:** add tests that verify unauthenticated requests are rejected (401) and wrong-role requests get 403.
>
> **Sample configuration**
>
> `package.json` (profile-based auth):
>
> ```json
> {
>   "dependencies": {
>     "@sap/xssec": "^4"
>   },
>   "cds": {
>     "requires": {
>       "auth": {
>         "[development]": {
>           "kind": "mocked",
>           "users": {
>             "alice": { "roles": ["Admin", "Viewer"] },
>             "bob":   { "roles": ["Viewer"] },
>             "*": false
>           }
>         },
>         "[production]": { "kind": "jwt" }
>       }
>     }
>   }
> }
> ```
>
> `xs-security.json` (scopes → role templates → role collections):
>
> ```json
> {
>   "xsappname": "my-cap-app",
>   "tenant-mode": "dedicated",
>   "scopes": [
>     { "name": "$XSAPPNAME.Viewer", "description": "Read access" },
>     { "name": "$XSAPPNAME.Admin",  "description": "Full access" }
>   ],
>   "role-templates": [
>     { "name": "Viewer", "scope-references": ["$XSAPPNAME.Viewer"] },
>     { "name": "Admin",  "scope-references": ["$XSAPPNAME.Admin", "$XSAPPNAME.Viewer"] }
>   ],
>   "role-collections": [
>     { "name": "MyCapApp_Viewer", "role-template-references": ["$XSAPPNAME.Viewer"] },
>     { "name": "MyCapApp_Admin",  "role-template-references": ["$XSAPPNAME.Admin"] }
>   ]
> }
> ```
>
> `srv/service.cds` (role names = scope names without `$XSAPPNAME.`):
>
> ```cds
> @requires: 'authenticated-user'
> service CatalogService {
>   @restrict: [
>     { grant: 'READ', to: 'Viewer' },
>     { grant: '*',    to: 'Admin' }
>   ]
>   entity Books as projection on my.Books;
>
>   @requires: 'Admin'
>   action restock(book : UUID, quantity : Integer);
> }
> ```
>
> `mta.yaml` (excerpt — XSUAA binding + token forwarding):
>
> ```yaml
> modules:
>   - name: my-cap-app-srv
>     requires:
>       - name: my-cap-app-auth
>     provides:
>       - name: srv-api
>         properties:
>           srv-url: ${default-url}
>   - name: my-cap-app-router
>     requires:
>       - name: my-cap-app-auth
>       - name: srv-api
>         group: destinations
>         properties:
>           name: srv-api
>           url: ~{srv-url}
>           forwardAuthToken: true
> resources:
>   - name: my-cap-app-auth
>     type: org.cloudfoundry.managed-service
>     parameters:
>       service: xsuaa
>       service-plan: application
>       path: ./xs-security.json
>       config:
>         xsappname: my-cap-app-${org}-${space}
>         tenant-mode: dedicated
> ```
>
> - Check the resolved config per profile: `cds env get requires.auth --profile production`.
