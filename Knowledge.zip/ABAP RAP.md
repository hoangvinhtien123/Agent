# ABAP RAP — Knowledge

Reference notes on the ABAP RESTful Application Programming Model (behaviour definitions, actions, Fiori Elements behaviour).

> [!note] Added 2026-10-05 — Question: "managed BO with standard create — can an abstract entity force the user to enter mandatory fields first, then continue with the other fields?". Sources: ABAP Keyword Documentation "RAP - Default Factory Action" and "RAP - action, factory", SAP-samples `abap-platform-rap110` ex07, SAP-samples Fiori feature showcase "Action Parameters".
> **Pattern: static default factory action with an abstract-entity parameter** — replaces the standard Create button in Fiori Elements with a parameter popup.
>
> - BDEF: `static default factory action createWithParams parameter ZA_CreateParams [1];` — keep `create;` (the handler creates via EML `IN LOCAL MODE`). Exactly one default factory action per entity; cardinality is mandatory; no result clause for factory actions.
> - Projection BDEF: `use create;` + `use action createWithParams;`. A default factory action cannot be defined in a BDEF extension.
> - Handler: `MODIFY ENTITIES ... IN LOCAL MODE ... CREATE FIELDS ( ... ) WITH VALUE #( FOR key IN keys ( %cid = key-%cid %is_draft = key-%param-%is_draft <field> = key-%param-<field> ) ) MAPPED mapped FAILED failed REPORTED reported.`
> - With `with draft`, Fiori Elements opens the new draft on the object page after the popup, so the remaining fields are entered afterwards. Without draft the factory action creates an active instance directly.
> - Availability: S/4HANA 2023 on-premise and later, plus BTP ABAP Environment / S/4HANA Cloud Public Edition (per community sources).
> - Mandatory popup fields: `field ( mandatory : execute )` in an **abstract behaviour definition** (`abstract; strict ( 2 ); with hierarchy;` + `with control` on a root abstract entity) with the action declared as `deep parameter` — 2023+ per the SAP feature showcase. Fallback: check `%param` in the handler and return `failed` / `reported`.
> - Defaults for popup fields: `@UI.defaultValue: '<value>'` in the abstract entity, or `{ default function GetDefaultsFor<ActionName>; }` on the action.
> - Remaining fields on the object page: `field ( mandatory )` plus a validation `on save { create; }` for consistency.

> [!note] Added 2026-10-05 — Follow-up: "true mandatory fields in the action popup". Sources: ABAP Keyword Documentation "RAP - Field Characteristics, Abstract BDEF", "RAP - Behavior Definition Header, Abstract BDEF", "RAP - RedefinedParameter", "RAP BDL - Feature Tables"; SAP Community Q&A "How can I create an action in RAP with mandatory parameters?" (Andre Fischer, 2024-08-09, comments 2026-04).
> **Three objects are needed:**
>
> 1. **Root abstract entity** — `define root abstract entity ZA_X { ... }` (the keyword `root` is required to attach a behaviour definition).
> 2. **Abstract BDEF with the same name** — `abstract; strict ( 2 ); with hierarchy;` then `define behavior for ZA_X with control { field ( mandatory : execute ) F1, F2; }`. All three prerequisites (`with hierarchy`, `with control`, strict mode) are mandatory. `with hierarchy like entity` is NOT allowed together with `mandatory:execute` / `with control`.
> 3. **Action declared with `deep parameter`** — `static default factory action createX deep parameter ZA_X [1];` (plain `parameter` ignores the abstract BDEF).
>
> - Effect in Fiori Elements: red asterisk on the popup field.
> - Runtime: if the `%control` flag of a mandatory:execute field is not set, a runtime error occurs. `IN LOCAL MODE` ignores `mandatory:execute`.
> - **Limitation (SAP, Apr 2026):** an empty value is NOT checked automatically — "by design", same as normal mandatory fields; still implement the empty-value check in the handler. Customer influence idea 305430 exists. Downside: on error the popup closes and the user must re-enter the values.
> - Projection: `use action createX;` reuses the deep parameter; a redefined parameter (`use action createX deep parameter ZA_Y;`) must keep every mandatory:execute field and match `with control`.
> - Release: `default` factory action 7.90 / on-premise 7.58 (S/4HANA 2023) / BTP 2211.
