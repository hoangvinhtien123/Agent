# ABAP CDS — Knowledge

Reference notes on ABAP Core Data Services on S/4HANA: modelling, annotations, and how to deliver fields that plain CDS SQL cannot produce.

> [!note] Added 2026-09-09 — Question: "build a CDS which fields can use FM, or logic to get data". Sources: SAP Help "Using Virtual Elements in CDS", SAP PRESS "Advanced CDS Functionality for ABAP Development", sapdev.eu "CDS Virtual Elements calculated in ABAP", discoveringabap.com "Virtual Elements in CDS".
> Four ways to fill a CDS field that is not persisted on the database, in the order they should be considered:
>
> 1. **CDS expression (pure SQL, full pushdown)** — `case`, `cast`, `coalesce`, arithmetic, `concat`, `substring`, date/time functions, currency/unit conversion. Use this whenever the rule can be expressed in SQL. No ABAP artifact needed.
> 2. **CDS table function + AMDP** — `define table function ... implemented by method <class>=>method`, class implements `IF_AMDP_MARKER_HDB`, method written `BY DATABASE FUNCTION FOR HDB` in SQLScript. Logic still runs on HANA, so performance stays good. Use when SQL is needed but CDS syntax is not enough.
> 3. **Virtual element (ABAP class exit)** — a transient field on a consumption/projection view calculated on the application server.
>    - Classic annotation form: `@ObjectModel.virtualElement: true` + `@ObjectModel.virtualElementCalculatedBy: 'ABAP:ZCL_MY_CALC'` on a `cast( ... )` element.
>    - RAP projection form: `virtual MyField : my_data_element;` with `@ObjectModel.virtualElementCalculatedBy: 'ABAP:ZCL_MY_CALC'` (the `virtualElement: true` annotation is omitted).
>    - The class implements `IF_SADL_EXIT_CALC_ELEMENT_READ` with two methods: `get_calculation_info` (declare every original field the calculation reads, so SADL supplies it even when the UI did not request it) and `calculate` (fill the values; here a function module such as `GET_WEEKDAY_NAME` or a BAPI can be called).
>    - Filtering/sorting on a virtual element needs `IF_SADL_EXIT_FILTER_TRANSFORM` / `IF_SADL_EXIT_SORT_TRANSFORM` plus `@ObjectModel.filter.transformedBy` / `@ObjectModel.sort.transformedBy`.
>    - **Important:** virtual elements are calculated only by the SADL/OData runtime. An ABAP SQL `SELECT` on the view and the ADT data preview return the initial value. Test through the service binding preview or `/IWFND/GW_CLIENT`.
>    - Pitfalls: `et_requested_orig_elements` is a sorted table — use `INSERT ... INTO TABLE`, never `APPEND`/index insert; `ct_calculated_data` holds only the virtual properties and is matched to `it_original_data` **by row index**, so append in the same order; when the virtual field is `CHAR(n)`, convert with `CONV` before moving a string in, otherwise the surplus characters overwrite the next fields in the response.
> 4. **CDS custom entity (unmanaged query)** — `define custom entity` with `@ObjectModel.query.implementedBy: 'ABAP:ZCL_MY_QUERY'`; the class implements `IF_RAP_QUERY_PROVIDER~select`. There is no data source: the whole result set is read in ABAP (function module, BAPI such as `BAPI_USER_GETLIST`, RFC, external API). Every element must be typed explicitly, and paging, filtering, sorting and the total record count must be programmed manually via `io_request` / `io_response`. A custom entity cannot be used as a data source of another CDS view or of an ABAP SQL `SELECT`, but its structured type is usable with `TYPE`.
>
> Rule of thumb: single transient field consumed by OData → virtual element; entire result set from an FM/BAPI/RFC → custom entity; heavy computation that can stay on the DB → table function/AMDP; anything expressible in SQL → CDS expression.

> [!note] Added 2026-10-05 — Question: "CDS view that uses another abstract CDS view for input — is an abstract entity like an ALV selection screen?". Sources: SAP Help "Abstract Entities" (ABAP Data Models 2025 FPS01), ABAP Keyword Documentation "CDS Abstract Entities", SAP Help "Creating Abstract CDS Entities" (AS ABAP 7.53 SP00), SAP Learning "Working with Event Parameters".
> **CDS abstract entity** (`define [root] abstract entity ... [with parameters ...] { ... }`) = a pure **type definition** with CDS annotations — a "further development of a DDIC structure". Available as of AS ABAP 7.53 SP00.
>
> - Transient: no database object, no client handling, no `as select from`. It **cannot** be a data source of a CDS view / view entity, cannot be used in CDS or ABAP SQL path expressions, and cannot be read with ABAP SQL `SELECT`.
> - CDS view parameters (`with parameters p : type`) are typed with data elements, built-in types or simple types — **not** with an abstract entity. So "a view that takes an abstract entity as input" is not possible directly.
> - Valid uses: parameter type of RAP actions / functions (`parameter ZA_X`, `deep parameter`, `deep table parameter`), payload of RAP business events, association target (expose only), and `TYPE` in ABAP (e.g. `TYPE ZA_X`, `%param` in EML).
> - Real pattern for "abstract entity as input to a view": RAP **function** or **action** with `parameter ZA_Filter`; the handler reads `keys[ 1 ]-%param` and passes the values to a **parameterised** CDS view entity (`SELECT FROM ZI_View( p_from = ..., p_to = ... )`).
>
> **ALV analogy:**
> - `SELECT-OPTIONS` / `PARAMETERS` of a report → CDS view `with parameters` (mandatory single values) + `@UI.selectionField` / `@Consumption.filter` (Fiori Elements filter bar, ranges).
> - Abstract entity → closest to a **popup input dialog** (like `POPUP_GET_VALUES`) for an action button, or a custom input structure — not the report selection screen itself.
