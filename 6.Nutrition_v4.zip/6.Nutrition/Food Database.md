---
tags: [nutrition, database]
---
# Food Database

| Item | Type | Per 100 | kcal / 100 | Protein / 100 (g) | Carbs / 100 (g) | Fat / 100 (g) | Source | Confidence |
|---|---|---|---|---|---|---|---|---|

