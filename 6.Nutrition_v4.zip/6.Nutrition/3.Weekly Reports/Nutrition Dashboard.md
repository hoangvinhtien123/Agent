---
tags: [nutrition, dashboard]
---
# Nutrition Dashboard

> Requires the **Dataview** community plugin.

## Last 7 Days
```dataview
TABLE WITHOUT ID file.link AS "Date", kcal, protein AS "Protein (g)", carbs AS "Carbs (g)", fat AS "Fat (g)", fiber AS "Fiber (g)", sodium AS "Sodium (mg)"
FROM "6.Nutrition/2.Daily Logs"
WHERE date >= date(today) - dur(7 days)
SORT date DESC
```

## Monthly Averages
```dataview
TABLE WITHOUT ID dateformat(date, "yyyy-MM") AS "Month", round(average(rows.kcal)) AS "Avg kcal", round(average(rows.protein), 1) AS "Avg Protein (g)", length(rows) AS "Days Logged"
FROM "6.Nutrition/2.Daily Logs"
GROUP BY dateformat(date, "yyyy-MM")
SORT rows.date DESC
```

## Food Library
```dataview
TABLE WITHOUT ID file.link AS "Item", type AS "Type", default_serving AS "Serving", confidence AS "Confidence"
FROM "6.Nutrition/1.Food Library"
SORT type, file.name
```
