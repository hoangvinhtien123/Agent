---
tags: [nutrition, targets]
updated: 2026-10-19
age: 
sex: 
height_cm: 
weight_kg: 
activity_level: 
goal: 
bmr: 
tdee: 
kcal_target: 
protein_target: 
carbs_target: 
fat_target: 
---
# Nutrition Targets

## Profile
| Field | Value |
|---|---|
| Age | |
| Sex | |
| Height (cm) | |
| Weight (kg) | |
| Activity Level | |
| Goal | |

## Calculation
| Step | Formula | Result |
|---|---|---|
| BMR (Mifflin-St Jeor) | | |
| Activity Multiplier | | |
| TDEE | BMR × Activity Multiplier | |
| Goal Adjustment | | |
| **Daily Calorie Target** | TDEE + Goal Adjustment | |

## Daily Targets
| Nutrient | Target | Unit |
|---|---|---|
| Calories | | kcal |
| Protein | | g |
| Carbs | | g |
| Fat | | g |

## History
| Date | Weight (kg) | Daily Calorie Target (kcal) | Note |
|---|---|---|---|
