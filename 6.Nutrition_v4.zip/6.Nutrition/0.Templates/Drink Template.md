---
type: drink
aliases: []
total_volume_ml: 
total_kcal: 
kcal_per_100ml: 
source: 
confidence: 
tags: [nutrition, drink]
---
# {{title}}

![[photo-name.jpg|250]]

## Nutrition Facts
| Nutrient | Total () | Per 100 ml |
|---|---|---|
| Calories (kcal) | | |
| Protein (g) | | |
| Carbs (g) | | |
| Fat (g) | | |
| Sugar (g) | | |
| Caffeine (mg) | | |
| Sodium (mg) | | |
