---
type: food
aliases: []
total_weight_g: 
total_kcal: 
kcal_per_100g: 
source: 
confidence: 
tags: [nutrition, food]
---
# {{title}}

![[photo-name.jpg|250]]

## Nutrition Facts
| Nutrient | Total () | Per 100 g |
|---|---|---|
| Calories (kcal) | | |
| Protein (g) | | |
| Carbs (g) | | |
| Fat (g) | | |
| Fiber (g) | | |
| Sugar (g) | | |
| Sodium (mg) | | |
