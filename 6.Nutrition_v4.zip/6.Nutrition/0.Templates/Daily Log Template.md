---
date: {{date:YYYY-MM-DD}}
tags: [nutrition, daily-log]
kcal: 0
kcal_target: 0
progress_pct: 0
kcal_remaining: 0
kcal_over: 0
status: Under Target
protein: 0
carbs: 0
fat: 0
fiber: 0
sugar: 0
sodium: 0
---
# Food Log – {{date:YYYY-MM-DD}}

## Food Log
| Time | Meal | Item | Amount | Total kcal | kcal / 100 g or ml | Protein (g) | Carbs (g) | Fat (g) | Fiber (g) | Sugar (g) | Sodium (mg) | Day Total (kcal) | Progress (%) | Confidence | Photo |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Calorie Progress
| Consumed (kcal) | Target (kcal) | Progress (%) | Remaining (kcal) | Over Target (kcal) | Status |
|---|---|---|---|---|---|
| 0 | | 0 | | 0 | Under Target |

## Daily Totals
| | kcal | Protein (g) | Carbs (g) | Fat (g) | Fiber (g) | Sugar (g) | Sodium (mg) |
|---|---|---|---|---|---|---|---|
| Total | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Target | | | | | | | |
| Remaining | | | | | | | |
