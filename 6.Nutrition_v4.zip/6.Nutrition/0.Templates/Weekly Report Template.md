---
week: {{date:GGGG-[W]WW}}
tags: [nutrition, weekly-report]
---
# Nutrition Report – {{date:GGGG-[W]WW}}

## Daily Summary
| Date | kcal | Protein (g) | Carbs (g) | Fat (g) | Fiber (g) | Sugar (g) | Sodium (mg) |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| **Average** | | | | | | | |
| **Target** | | | | | | | |

## Target Hit Rate
| Nutrient | Days on Target | Rate (%) |
|---|---|---|
| Calories | | |
| Protein | | |
| Fiber | | |

## Observations
1. 

## Suggestions
1. 
