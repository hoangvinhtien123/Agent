# Skill: SAP Smartforms — Form Development & XML Maintenance

## Description
Expert skill for SAP Smartforms (SMARTFORMS / SE71 successor) development and for editing a Smartform that has been downloaded as an XML export (`sf:SMARTFORM` / `urn:sap-com:SmartForms:2000:internal-structure`).
- Create new Smartforms, pages, windows, tables, templates and text nodes
- Update existing forms — add/remove output lines, columns, conditions, line types
- Refactor form logic — move ABAP out of text nodes into program-lines nodes, de-duplicate loops
- Fix output issues — wrong line type, missing currency reference field, suppressed rows, page-break problems
- Read and analyse an exported Smartform XML: rebuild the node tree, trace global data, conditions and program lines
- Patch an exported Smartform XML safely (clone-and-rename) and re-upload it into SAP

## When To Use
Activate when the request contains:
- `smartform`, `smart form`, `smartforms`, `sf export`, `sf xml`
- `sapscript`, `adobe form`, `print form`, `output form`, `invoice form`, `billing form`
- `text node`, `program lines`, `line type`, `table node`, `template node`, `window`, `folder`
- `NAST`, `output type`, `print program`, `SSF_FUNCTION_MODULE_NAME`
Examples:
- "Add a discount line under the sub-total of the invoice smartform"
- "Why is this row not printing in my smartform?"
- "Analyse this exported smartform XML and tell me what the footer does"
- "Move this logic out of the text node into program lines"

## Responsibilities
1. **Create** — build the page / window / table skeleton, define line types before cells, declare global data and reference fields, wire the form to its print program and output type.
2. **Update** — add new rows/cells/texts as *new* nodes; never re-key an existing node. Give every new node a unique internal name and a unique `%OUTATTRIBnnn` output attribute.
3. **Refactor** — pull ABAP out of text nodes into program-lines nodes with an explicit input/output parameter list; collapse repeated loops over the same table; replace hardcoded literals with global constants.
4. **Fix** — check in this order: node output condition → parent folder/loop condition → line type exists for that table → cell count matches the line type → reference field declared for currency/quantity → field actually filled at that point in the flow.
5. **Review** — walk the node tree in print order (Header → Main Area → Footer), list every condition, and report which globals each program-lines node reads and writes.
6. **XML patching** — when editing an export, always clone an existing sibling node of the same kind and rename it; validate node counts, duplicate internal names and cell counts before handing the file back.

## Supported Nodes / Artifacts
**Node types (XML `NODETYPE`)**
- `SE` Section — `SECTTYPE=C` table, `F` folder, `L` loop, `R` table line, `E` cell
- `TI` Text · `CO` Program lines · `CD` Alternative (condition) · `EV` Event (TRUE/FALSE, Header/Main/Footer)
- `WI` Window · `PA` Page · `GR` Graphic · `AD` Address · `CM` Command

**Form-level sections (XML)**
- `HEADER`, `INTERFACE` (import/export/tables), `GTYPES`, `GDATA` (global data), `GPLIST`, `GCODING` (initialization), `FCODING` (form routines), `REFFIELDS` (currency/quantity reference fields), `sf:VARHEADER` (the node tree)

**Text formatting**
- `TDFORMAT` paragraph key + `TDLINE`; `,,` = tab stop; `<B>…</>` character format
- Symbol options: `&FIELD(C)&` compress, `&FIELD(Z)&` suppress leading zeros, `&FIELD(<)&` / `&FIELD(>)&` sign position, `&FIELD'%'&` literal suffix

**Common runtime globals in a billing form**
- `IS_BIL_INVOICE` (`LBBIL_INVOICE`) with `HD_GEN`, `HD_KOMK`, `HD_KOND`, `IT_GEN`, `IT_KOND`, `IT_PRICE`
- `IS_NAST` (output control), `SFSY-PAGE`, `SFSY-FORMPAGES`

## Best Practices
Always: declare every currency/quantity output field in **REFFIELDS** with its currency field, otherwise the amount prints unformatted.
Always: put calculations in a **program-lines** node that runs *before* the row that prints the result — a spacer cell in the row above is a safe, valid anchor inside a table area.
Always: give a new row the **same line type** as the row you cloned, so the column widths already defined for that line type apply.
Always: suppress a line with the node's **output condition**, not by clearing the value — a cleared currency field still prints `0.00`.
Prefer: cloning an existing row and renaming it over hand-writing new XML — pattern, borders, output attributes and cell count stay consistent.
Prefer: one condition per concern (`GV_X NE 0`) over a compound condition that is hard to read in the Form Builder.
Prefer: reading `IT_KOND` (item conditions) when a condition type is item-level; header loops over `HD_KOND` will never see it.
Avoid: editing existing nodes when adding a feature — append new nodes so the form stays diff-able and transport-safe.
Avoid: duplicate internal names or duplicate `%OUTATTRIBnnn` values — the XML upload fails or silently merges nodes.
Avoid: business logic inside text nodes, hardcoded currencies, and relying on `SY-SUBRC` after a `LOOP` without checking it immediately.

## Output Rules
- **Create** — give the node tree first (Page → Window → Table → areas), then the global data / reference fields, then the ABAP for each program-lines node in a fenced `abap` block.
- **Update** — state exactly which nodes are added, which existing nodes are touched, and what each new output condition is; never silently change an existing node.
- **Refactor** — show the before/after node arrangement and confirm the printed output is unchanged.
- **Troubleshoot** — walk the suppression chain (condition → folder → line type → cell → reference field) and name the single root cause before proposing a fix.
- **XML patch** — hand back the complete re-uploadable XML plus a validation summary: node counts before/after, new internal names, duplicate check, cell-count check.

<!-- Append new Smartforms skills below this line. -->
