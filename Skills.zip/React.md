# React.md — React / TypeScript SAP Frontend Skills

> Routed from **[[1.Skills/Skills]]** by keywords: `react`, `tsx`, `vite`, `ui5 web components`, `hooks`, `approuter`, `spa`.
> If a needed skill is missing, research it and **append below** with a clear `> [!note] Added <date> — <reason>` comment. Never overwrite existing skills.

---

# Skill: React + UI5 Web Components SPA on SAP OData

## Description
Expert skill for building, reviewing, and refactoring a React + TypeScript single-page application that consumes an SAP OData service (V2 or V4) through the SAP BTP approuter, using the UI5 Web Components React library for a Fiori-consistent look.
- Create screens, routes, context providers, and typed data layers
- Update an existing app: new entity, new field, new filter, new KPI, new export
- Refactor components and hooks for readability and reuse without changing behaviour
- Fix OData plumbing problems: CSRF, ETag, pagination, date formats, key escaping, conflicts
- Review the app against its backend contract, authorization model, and runtime configuration

## When To Use
Activate when the request contains:
- react, tsx, jsx, vite, hooks, context, ui5 web components, approuter, xs-app.json, spa
Examples:
- "Add a department filter to this React screen"
- "Refactor the OData client in my React app"
- "Why does my write to the RAP service fail with 403 CSRF?"

## Responsibilities
1. Create — scaffold with Vite + TypeScript, define the entity types first, then the data provider, then the screens; keep routing declarative.
2. Update — extend the type, the provider, and the screen together so the UI never renders a field the service does not expose.
3. Refactor — lift shared logic into hooks (`useX`) and pure helper modules; keep components rendering-only; keep one source of truth for derived numbers.
4. Fix — diagnose in this order: network route → authentication → CSRF/ETag headers → payload shape → response parsing → rendering.
5. Review — check writable-field whitelists, role/scope gating, error surfacing, loading/empty states, and that demo/mock data cannot leak into a live run.

## Supported Libraries & Patterns
Runtime:
- React 18 function components, hooks (`useState`, `useMemo`, `useEffect`, `useCallback`, `useContext`), context providers, `react-router-dom` routes
UI:
- `@ui5/webcomponents-react` (ThemeProvider, ShellBar, SideNavigation, Page, Table/AnalyticalTable, Card, Dialog, Input, Select, Button, MessageStrip, BarChart/LineChart/DonutChart), `sap_horizon` theme
Data:
- Typed entity interfaces, a single OData client module, request-id guards against race conditions, optimistic list updates
OData V2 specifics:
- `$format=json`, `d.results` / `d.__next` pagination, `/Date(ms)/` parsing, `__metadata.etag`, CSRF `Fetch` + retry, `MERGE` via `X-HTTP-Method`, `If-Match`, quote-escaping in key predicates, parameterised entity sets `Entity(p_x='v')/Set`
Runtime config:
- approuter `xs-app.json` routes and destinations, `/user-api/currentUser` for identity, XSUAA scopes mapped to UI roles, Vite dev proxy, `.env` data-mode switches
Tooling:
- `npm`, `vite`, `tsc --noEmit`, node test runner, esbuild bundling for tests

## Best Practices
Always: type every OData entity; keep the service contract in one module; gate destructive actions by role and by backend authorization, not by the UI alone; show backend error messages instead of silently falling back; keep currency and unit with the amount; guard CSV export against formula injection.
Prefer: derived state via `useMemo` over duplicated state; one data-loading hub over per-screen fetches; relative URLs behind the approuter over absolute hosts; a documented demo provider that mirrors the live entity shape exactly; small pure helper functions for all money and capacity maths.
Avoid: business maths inside JSX; hidden fallbacks that make a failed live call look like success; hardcoded hosts, users, or rates; writing fields the behaviour definition marks read-only; mixing currencies in a total without conversion; leaving a helper's parameters unused while the UI claims they matter.

## Output Rules
- Create: give complete, copy-ready files (types, provider, hook, component) and the `package.json` scripts needed to run them.
- Update: show only the changed files in full and name the screens affected.
- Refactor: state the single concern, then give the complete corrected file; behaviour stays identical.
- Troubleshoot: name the root cause, then the corrected snippet, then the verification step (network tab, `$metadata` ping, node test).
- Always state the OData version assumed and flag any backend field or authorization that must be verified in the target system.

---

<!-- New React skills are appended below this line, each with a clear "Added <date> — <reason>" comment. Do not overwrite existing skills. -->
