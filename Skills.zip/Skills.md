# Skills.md — Skill Menu / Index (Victor Second Brain)

> **Purpose:** This is the **menu** the agent reads first. It does **not** contain skill details.
> It maps a **keyword** to the skill file that holds the actual skills.
>
> **How the agent uses this file:**
> 1. Read this menu and match the user's request to a **keyword** below.
> 2. Open the matching **skill file** and look for the specific skill there.
> 3. If the skill is **not** in that file → research it (internet / other sources), then **append** it to that skill file with a clear dated comment.
> 4. If a request spans multiple keywords, route to each matching file separately.

---

## Skill Routing Table

| Keyword(s) to match | Go to skill file | Covers |
|---------------------|------------------|--------|
| `fiori`, `sapui5`, `ui5`, `odata`, `launchpad`, `fragment`, `smart table`, `annotation` | **[[1.Skills/Fiori]]** | All SAP Fiori / SAPUI5 skills |
| `github`, `git`, `commit`, `merge`, `revert`, `reverse`, `conflict`, `log`, `branch`, `push`, `pull` | **[[1.Skills/GitHub]]** | Git / GitHub operations |
| `weekly`, `weekly log`, `weekly update`, `weekly goal`, `log file`, `status report` | **[[1.Skills/Weekly Log]]** | Weekly log creation & goal tracking |
| `read code`, `read the code`, `analyse code`, `analyze code`, `code review`, `review code`, `explain code`, `walkthrough`, `5.Code`, `codebase` | **[[1.Skills/Code Review]]** | Reading & analysing an existing codebase |
| `react`, `tsx`, `vite`, `ui5 web components`, `hooks`, `approuter`, `spa` | **[[1.Skills/React]]** | React / TypeScript SAP frontends |
| `abap`, `internal table`, `abap sql`, `oo abap`, `field symbol`, `rtti`, `string processing`, `abap unit`, `abap cloud`, `exception handling` | **[[1.Skills/AbapSkill]]** | Core ABAP language reference — classic & ABAP Cloud |
| `abap cds`, `cds view`, `view entity`, `ddl`, `dcl`, `association`, `cds annotation`, `access control`, `salv ida`, `metadata extension` | **[[1.Skills/AbapCdsSkill]]** | ABAP CDS data modelling, annotations, DCL |
| `rap`, `bdef`, `bdl`, `eml`, `managed bo`, `unmanaged bo`, `draft`, `determination`, `validation`, `side effect`, `behavior definition`, `behavior pool` | **[[1.Skills/RAPSkill]]** | RESTful ABAP Programming Model — BOs, EML, draft |
| `sapui5`, `ui5`, `xml view`, `controller`, `manifest.json`, `fiori elements`, `odata v2`, `odata v4`, `qunit`, `opa5`, `mock server`, `custom control`, `sap.ui.mdc` | **[[1.Skills/SapUi5Skill]]** | SAPUI5 framework reference — freestyle, Fiori Elements, testing |
| `tsd`, `technical spec`, `tech spec`, `technical specification`, `spec document`, `write a spec`, `design document`, `architecture decision` | **[[1.Skills/Technical Spec]]** | Technical specification (TSD) document authoring — required inputs, output format, guidelines, quality checks |
| `parallel`, `parallel processing`, `cl_abap_parallel`, `if_abap_parallel`, `run_inst`, `arfc`, `starting new task`, `mass processing`, `background task` | **[[1.Skills/Parallel Processing]]** | Parallel processing in ABAP — worker classes, task instances, per-task BAPI/EML commits |
| `smartform`, `smart form`, `smartforms`, `sapscript`, `adobe form`, `print form`, `output form`, `text node`, `program lines`, `line type`, `nast`, `output type` | **[[1.Skills/Smartforms]]** | SAP Smartforms — form development, output conditions, and exported-XML maintenance |

---

## Routing Rules

- **Match by keyword, flexibly.** A request only needs to *contain* a keyword (or a close synonym) to route — no exact match required.
- **Decompose multi-step requests.** Route each capability to its own file.
  > Example: *"Create a Fiori app, then commit to GitHub"* → route to **[[1.Skills/Fiori]]** and **[[1.Skills/GitHub]]** separately.
- **If a skill is missing** in the target file → research it (internet or other trusted sources), use it to answer, then **append** the new skill to that file below the existing ones with a clear comment:
  ```markdown
  > [!note] Added 2026-08-20 — <reason / source>

  ## <Skill Short Title>
  **When to use:** ...
  **Solution:** ...
  ```
- **If no keyword matches**, tell me there is no routing entry yet, research the answer, and (if it is reusable) propose a new keyword + file, or append to the closest existing file.
- **Keep this menu in sync:** when you create a brand-new skill file, add a routing row here.
- **Overlapping keywords:** when both a legacy file and a reference file match, read the reference file for framework/language detail and the legacy file for Victor's own patterns — e.g. `sapui5` → **[[1.Skills/SapUi5Skill]]** + **[[1.Skills/Fiori]]**, `abap`/`rap` → **[[1.Skills/AbapSkill]]** / **[[1.Skills/RAPSkill]]**.

---

<!-- Add new routing rows above this line when a new skill file/area is introduced. -->
