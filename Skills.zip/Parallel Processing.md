# Parallel Processing Skills (ABAP)

> Skill file for keyword routing from [[1.Skills/Skills]] — `parallel`, `cl_abap_parallel`, `if_abap_parallel`, `parallel processing`, `arfc`, `background task`.

# Skill: ABAP Parallel Processing with CL_ABAP_PARALLEL / IF_ABAP_PARALLEL

## Description
Expert skill for splitting mass ABAP workloads across parallel dialog work processes with the framework class `CL_ABAP_PARALLEL` and the interface `IF_ABAP_PARALLEL`, including transactional (BAPI / EML) workloads that need their own COMMIT per task.
- Create worker (parallel task) classes that implement `IF_ABAP_PARALLEL` + `IF_SERIALIZABLE_OBJECT`
- Create driver/report logic that builds the task instance table and calls `run_inst( )` / `run( )`
- Update existing sequential mass-processing reports into parallel ones without changing business logic
- Refactor legacy aRFC (`CALL FUNCTION ... STARTING NEW TASK` + `WAIT UNTIL`) patterns onto `CL_ABAP_PARALLEL`
- Fix result collection, timeout, locking, and commit-scope problems in parallel runs
- Review resource settings (`p_num_tasks`, `p_num_processes`, `p_percentage`, `p_timeout`, `p_local_server`)

## When To Use
Activate when the request contains:
- `parallel`, `parallel processing`, `cl_abap_parallel`, `if_abap_parallel`, `run_inst`, `do method`
- `arfc`, `starting new task`, `mass processing`, `mass creation`, `performance of a mass report`
Examples:
- "Give me an example of IF_ABAP_PARALLEL used for a BAPI commit"
- "Turn this mass sales order creation report into parallel processing"
- "Why are my parallel tasks timing out or returning no result?"

## Responsibilities
1. Create — design the worker class (input as instance attributes set in the constructor, logic in `if_abap_parallel~do`, result in instance attributes exposed by a getter); design the driver that fills `cl_abap_parallel=>t_in_inst_tab` and calls `run_inst( )`.
2. Update — add new input/result attributes, tune the degree of parallelism, add per-task logging.
3. Refactor — move sequential LOOP-over-BAPI logic into the worker class unchanged; keep the business logic identical and change only the execution model.
4. Fix — diagnose serialization errors (missing `IF_SERIALIZABLE_OBJECT`), empty results (result not stored on the instance), timeouts (`p_timeout`, `message` field in the output), lock collisions (same object processed by two tasks).
5. Review — check commit scope per task, `BAPIRET2` error handling, restartability, and that no task depends on another task's uncommitted data.

## Supported Classes / Interfaces / Parameters
- Interfaces: `IF_ABAP_PARALLEL` (method `do`), `IF_SERIALIZABLE_OBJECT` (mandatory for instance-based runs)
- Framework class: `CL_ABAP_PARALLEL` — constructor `p_num_tasks`, `p_timeout`, `p_percentage`, `p_num_processes`, `p_local_server`
- Instance mode: `run_inst( EXPORTING p_in_tab = ... IMPORTING p_out_tab = ... )` with types `t_in_inst_tab` / `t_out_inst_tab` (fields `inst`, `index`, `time`, `message`)
- xstring mode (subclass with `do` REDEFINITION): `run( p_in_tab, p_in_all, p_debug, p_out_tab )` using `EXPORT/IMPORT ... TO/FROM DATA BUFFER`, output fields `result`, `index`, `time`, `message`
- Transactional APIs inside `do`: any BAPI plus `BAPI_TRANSACTION_COMMIT` (`WAIT = 'X'`) / `BAPI_TRANSACTION_ROLLBACK`; in ABAP Cloud, EML `MODIFY ENTITIES` plus `COMMIT ENTITIES`
- Related SAP Notes: 2791374 (downport of `CL_ABAP_PARALLEL`), 3164040 (SSI_DISPATCH needs SM50/SM51)

## Best Practices
Always: implement `IF_SERIALIZABLE_OBJECT` alongside `IF_ABAP_PARALLEL`; keep one commit per task (each task is its own LUW in its own work process); evaluate `BAPIRET2` before committing and roll back on error; store results on the instance and read them back from `p_out_tab-inst`; check `p_out_tab-message` for timeouts and framework failures.
Prefer: instance mode `run_inst( )` for typed data; xstring mode only when a shared payload (`p_in_all`) or a subclass is required; disjoint data packages so tasks never lock each other; `p_num_tasks` sized to the available dialog work processes; `p_debug = 'X'` for sequential debugging.
Avoid: `COMMIT WORK` in the caller expecting it to cover the tasks; screen/list output, `MESSAGE`, or user interaction inside `do`; shared global state between tasks; passing non-serializable references into the worker; unbounded task counts that starve the dialog queue.

## Output Rules
- Create: deliver the complete worker class (DEFINITION + IMPLEMENTATION) and the complete driver/report, and state the commit strategy explicitly.
- Update/Refactor: show the full changed methods, confirm behaviour is unchanged, and flag any change in commit scope.
- Troubleshoot: name the probable cause (serialization / result storage / timeout / locking / commit scope), then give the corrected snippet.
- Always state the release assumption (`CL_ABAP_PARALLEL` needs SAP_BASIS 7.54+ or the downport in SAP Note 2791374) and remind that mass BAPI runs must be tested in a sandbox before transport.

<!-- Add new parallel-processing skills above this line. -->
